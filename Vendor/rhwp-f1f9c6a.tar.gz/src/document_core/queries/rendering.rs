//! 렌더링/페이지 정보/구성/페이지네이션/페이지 트리 관련 native 메서드

use super::super::helpers::color_ref_to_css;
use crate::document_core::{
    header_footer_apply_from_u8, DeferredPaginationJobState, DeferredPaginationStepResult,
    DeferredPaginationTargetStatus, DocumentCore, PendingPaginationJob,
};
use crate::error::HwpError;
use crate::model::control::Control;
use crate::model::document::{Document, Section};
use crate::model::header_footer::HeaderFooterApply;
use crate::model::page::{ColumnDef, PageAreas};
use crate::model::paragraph::{ColumnBreakType, Paragraph};
use crate::model::style::Alignment;
use crate::paint::{
    resolve_embedded_font_face_index, EmbeddedFontFace, LayerBuilder, LayerOutputOptions,
    PageLayerTree, RenderProfile,
};
use crate::renderer::canvas::CanvasRenderer;
use crate::renderer::composer::{
    compose_paragraph, compose_paragraph_with_horizontal_shaping,
    compose_section_with_horizontal_shaping, ComposedParagraph,
};
use crate::renderer::height_measurer::{HeightMeasurer, MeasuredSection, MeasuredTable};
use crate::renderer::html::HtmlRenderer;
use crate::renderer::kerning::{
    ExactFontRegistryRegistration, ExactFontSlot, MAX_KERNING_REGISTRY_SLOTS,
};
use crate::renderer::layer_renderer::LayerRenderer;
use crate::renderer::layout::{estimate_text_width, resolved_to_text_style, CellContext};
use crate::renderer::page_layout::PageLayoutInfo;
use crate::renderer::pagination::{
    HeaderFooterRef, MasterPageRef, PageContent, PaginationResult, Paginator,
};
use crate::renderer::render_tree::{
    BoundingBox, FieldMarkerType, PageRenderTree, RenderNode, RenderNodeType, TextRunNode,
};
use crate::renderer::svg::SvgRenderer;
use crate::renderer::svg_layer::SvgLayerRenderer;
use crate::renderer::typeset::TypesetEngine;
use crate::renderer::TextStyle;
use std::fmt::Write as _;

const MAX_EMBEDDED_FONT_BYTES: usize = 32 * 1024 * 1024;
const MAX_EMBEDDED_FONT_BYTES_PER_PAGE: usize = 64 * 1024 * 1024;
const FOCUSED_PAGE_REPAINT_PAD: f64 = 3.0;

#[derive(Debug, Clone, Copy)]
pub(crate) struct FocusedPageTreePatch {
    pub(crate) page_index: u32,
    pub(crate) dirty_rect: BoundingBox,
}

fn focused_partial_repaint_alignment_is_safe(
    alignment: Alignment,
    is_last_line: bool,
    has_line_break: bool,
) -> bool {
    alignment == Alignment::Left
        || (alignment == Alignment::Justify && is_last_line && !has_line_break)
}

/// 고정 dirty rect 밖으로 잉크/장식이 나가거나 cached run spacing을 재계산해야 하는
/// 스타일은 부분 repaint에서 제외한다. 이 경로는 plain horizontal text 전용이다.
fn focused_partial_repaint_style_is_safe(style: &TextStyle) -> bool {
    style.right_tab_block_width_override.is_none()
        && style.tab_leaders.is_empty()
        && style.inline_tabs.is_empty()
        && style.extra_word_spacing.abs() <= 0.001
        && style.extra_char_spacing.abs() <= 0.001
        && style.extra_dash_advance.abs() <= 0.001
        && style.letter_spacing >= -0.01
        && style.outline_type == 0
        && style.shadow_type == 0
        && !style.emboss
        && !style.engrave
        && !style.superscript
        && !style.subscript
        && style.emphasis_dot == 0
        && matches!(style.underline, crate::model::style::UnderlineType::None)
        && !style.strikethrough
}

/// [#3137 Stage 4] stable tail edit가 재사용할 수 있는 캐시된 마지막 TextLine 정보.
///
/// 페이지/셀 원점과 줄 bbox는 Stage 3의 same-line signature가 보존한다. 여기서는
/// 기존 line의 plain TextRun 자식만 교체하고 표/페이지 구조는 그대로 둔다.
#[derive(Clone)]
struct CachedFocusedTailLine {
    page_index: usize,
    line_node_id: u32,
    line_bbox: BoundingBox,
    run_x: f64,
    run_y: f64,
    run_height: f64,
    baseline: f64,
    column_x: f64,
    layout_style: TextStyle,
    cell_context: CellContext,
}

fn focused_flat_cell_context_matches(
    context: &CellContext,
    parent_para_idx: usize,
    control_idx: usize,
    cell_idx: usize,
    cell_para_idx: usize,
) -> bool {
    if context.parent_para_index != parent_para_idx || context.path.len() != 1 {
        return false;
    }
    let entry = &context.path[0];
    entry.control_index == control_idx
        && entry.cell_index == cell_idx
        && entry.cell_para_index == cell_para_idx
        && entry.text_direction == 0
}

#[allow(clippy::too_many_arguments)]
fn collect_cached_focused_tail_lines(
    node: &RenderNode,
    page_index: usize,
    section_idx: usize,
    parent_para_idx: usize,
    control_idx: usize,
    cell_idx: usize,
    cell_para_idx: usize,
    line_index: usize,
    line_start: usize,
    old_text_len: usize,
    output: &mut Vec<CachedFocusedTailLine>,
) {
    if let RenderNodeType::TextLine(line) = &node.node_type {
        let line_identity_matches = line.section_index == Some(section_idx)
            && line.para_index == Some(cell_para_idx)
            && line.line_index == Some(line_index as u32);
        if line_identity_matches && !node.children.is_empty() {
            let mut expected_char_start = line_start;
            let mut expected_x: Option<f64> = None;
            let mut first_run: Option<(&RenderNode, &TextRunNode)> = None;
            let mut valid = true;

            for (index, child) in node.children.iter().enumerate() {
                let RenderNodeType::TextRun(run) = &child.node_type else {
                    valid = false;
                    break;
                };
                let context_matches = run.cell_context.as_ref().is_some_and(|context| {
                    focused_flat_cell_context_matches(
                        context,
                        parent_para_idx,
                        control_idx,
                        cell_idx,
                        cell_para_idx,
                    )
                });
                if !context_matches
                    || run.section_index != Some(section_idx)
                    || run.para_index != Some(cell_para_idx)
                    || run.char_start != Some(expected_char_start)
                    || run.display_text.is_some()
                    || run.char_overlap.is_some()
                    || run.field_marker != FieldMarkerType::None
                    || run.is_line_break_end
                    || run.is_vertical
                    || run.rotation.abs() > 0.001
                    || !focused_partial_repaint_style_is_safe(&run.style)
                    || !child.visible
                    || child.editor_only
                    || child.layer.is_some()
                    || !child.children.is_empty()
                {
                    valid = false;
                    break;
                }
                if index + 1 == node.children.len() {
                    if !run.is_para_end {
                        valid = false;
                        break;
                    }
                } else if run.is_para_end {
                    valid = false;
                    break;
                }
                if let Some(x) = expected_x {
                    if (child.bbox.x - x).abs() > 0.051 {
                        valid = false;
                        break;
                    }
                }
                expected_x = Some(child.bbox.x + child.bbox.width);
                expected_char_start += run.text.chars().count();
                first_run.get_or_insert((child, run));
            }

            if valid && expected_char_start == old_text_len {
                if let Some((child, run)) = first_run {
                    let column_x = child.bbox.x - run.style.line_x_offset;
                    if child.bbox.x.is_finite()
                        && child.bbox.y.is_finite()
                        && child.bbox.height.is_finite()
                        && run.baseline.is_finite()
                        && column_x.is_finite()
                        && run.style.available_width.is_finite()
                        && run.style.available_width > 0.0
                    {
                        output.push(CachedFocusedTailLine {
                            page_index,
                            line_node_id: node.id,
                            line_bbox: node.bbox,
                            run_x: child.bbox.x,
                            run_y: child.bbox.y,
                            run_height: child.bbox.height,
                            baseline: run.baseline,
                            column_x,
                            layout_style: run.style.clone(),
                            cell_context: run
                                .cell_context
                                .clone()
                                .expect("검증된 focused cell context"),
                        });
                    }
                }
            }
        }
    }

    for child in &node.children {
        collect_cached_focused_tail_lines(
            child,
            page_index,
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
            line_index,
            line_start,
            old_text_len,
            output,
        );
    }
}

fn find_render_node_mut(node: &mut RenderNode, node_id: u32) -> Option<&mut RenderNode> {
    if node.id == node_id {
        return Some(node);
    }
    for child in &mut node.children {
        if let Some(found) = find_render_node_mut(child, node_id) {
            return Some(found);
        }
    }
    None
}

/// 문단 본문과 수식 script를 컨트롤 문자 위치에 직접 합친다.
///
/// 렌더 트리를 거치지 않는 텍스트 표면(Markdown 표 셀, `export-structure`)이 수식을
/// 버리지 않도록 하는 공용 조립기다 — 일반 본문 Markdown과 같은 수식 보존 계약이다.
/// [#3413] `export-structure` 가 `para.text` 를 그대로 써 수식이 통째로 빠지던 문제를
/// 같은 계약으로 닫기 위해 `pub(crate)` 로 올렸다.
pub(crate) fn paragraph_text_with_equations(para: &Paragraph) -> String {
    let text: Vec<char> = para.text.chars().collect();
    let control_positions = para.control_text_positions();
    let mut equations: Vec<(usize, &str)> = para
        .controls
        .iter()
        .enumerate()
        .filter_map(|(control_index, control)| match control {
            Control::Equation(equation) if !equation.script.trim().is_empty() => Some((
                control_positions
                    .get(control_index)
                    .copied()
                    .unwrap_or(text.len())
                    .min(text.len()),
                equation.script.trim(),
            )),
            _ => None,
        })
        .collect();
    equations.sort_by_key(|(position, _)| *position);

    let mut output = String::new();
    let mut equation_index = 0usize;
    for position in 0..=text.len() {
        while equation_index < equations.len() && equations[equation_index].0 == position {
            let script = equations[equation_index].1;
            if !output.is_empty() && !output.chars().last().is_some_and(char::is_whitespace) {
                output.push(' ');
            }
            output.push_str(script);
            if position < text.len() && !text[position].is_whitespace() {
                output.push(' ');
            }
            equation_index += 1;
        }
        if let Some(ch) = text.get(position) {
            output.push(*ch);
        }
    }
    output
}

fn load_bounded_embedded_font_bytes(
    contents: &[crate::model::bin_data::BinDataContent],
    font_ids: &[u16],
    per_font_limit: usize,
    page_limit: usize,
) -> std::collections::HashMap<u16, Vec<u8>> {
    let mut bytes_by_id = std::collections::HashMap::new();
    let mut attempted_ids = std::collections::HashSet::new();
    let mut loaded_bytes = 0usize;

    for &font_id in font_ids {
        if !attempted_ids.insert(font_id) {
            continue;
        }
        let remaining = page_limit.saturating_sub(loaded_bytes);
        let load_limit = per_font_limit.min(remaining);
        if load_limit == 0 {
            break;
        }
        let Some(bytes) = contents
            .iter()
            .find(|content| content.id == font_id)
            .and_then(|content| content.data.load_limited(load_limit))
            .filter(|bytes| !bytes.is_empty())
        else {
            continue;
        };
        loaded_bytes = loaded_bytes.saturating_add(bytes.len());
        bytes_by_id.insert(font_id, bytes);
    }

    bytes_by_id
}

fn collect_exact_font_slots_from_paragraphs(
    paragraphs: &[Paragraph],
    slots: &mut std::collections::HashSet<ExactFontSlot>,
    remaining_work_units: &mut usize,
    depth: usize,
) {
    const MAX_EXACT_FONT_TRAVERSAL_DEPTH: usize = 128;
    if depth > MAX_EXACT_FONT_TRAVERSAL_DEPTH
        || slots.len() >= MAX_KERNING_REGISTRY_SLOTS
        || *remaining_work_units == 0
    {
        return;
    }
    for paragraph in paragraphs {
        if *remaining_work_units == 0 {
            return;
        }
        *remaining_work_units -= 1;
        let composed = compose_paragraph(paragraph);
        for run in composed.lines.iter().flat_map(|line| &line.runs) {
            if *remaining_work_units == 0 {
                return;
            }
            *remaining_work_units -= 1;
            if !run.text.is_empty() {
                slots.insert(ExactFontSlot::new(run.char_style_id, run.lang_index));
                if slots.len() >= MAX_KERNING_REGISTRY_SLOTS {
                    return;
                }
            }
        }
        for control in &paragraph.controls {
            if *remaining_work_units == 0 {
                return;
            }
            *remaining_work_units -= 1;
            match control {
                Control::Table(table) => {
                    if let Some(caption) = &table.caption {
                        collect_exact_font_slots_from_paragraphs(
                            &caption.paragraphs,
                            slots,
                            remaining_work_units,
                            depth + 1,
                        );
                    }
                    for cell in &table.cells {
                        collect_exact_font_slots_from_paragraphs(
                            &cell.paragraphs,
                            slots,
                            remaining_work_units,
                            depth + 1,
                        );
                    }
                }
                Control::Shape(shape) => collect_exact_font_slots_from_shape(
                    shape,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::Picture(picture) => {
                    if let Some(caption) = &picture.caption {
                        collect_exact_font_slots_from_paragraphs(
                            &caption.paragraphs,
                            slots,
                            remaining_work_units,
                            depth + 1,
                        );
                    }
                }
                Control::Header(header) => collect_exact_font_slots_from_paragraphs(
                    &header.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::Footer(footer) => collect_exact_font_slots_from_paragraphs(
                    &footer.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::Footnote(note) => collect_exact_font_slots_from_paragraphs(
                    &note.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::Endnote(note) => collect_exact_font_slots_from_paragraphs(
                    &note.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::HiddenComment(comment) => collect_exact_font_slots_from_paragraphs(
                    &comment.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                ),
                Control::Field(field) if !field.memo_paragraphs.is_empty() => {
                    collect_exact_font_slots_from_paragraphs(
                        &field.memo_paragraphs,
                        slots,
                        remaining_work_units,
                        depth + 1,
                    )
                }
                _ => {}
            }
            if slots.len() >= MAX_KERNING_REGISTRY_SLOTS {
                return;
            }
        }
    }
}

fn collect_exact_font_slots_from_shape(
    shape: &crate::model::shape::ShapeObject,
    slots: &mut std::collections::HashSet<ExactFontSlot>,
    remaining_work_units: &mut usize,
    depth: usize,
) {
    if depth > 128 || slots.len() >= MAX_KERNING_REGISTRY_SLOTS || *remaining_work_units == 0 {
        return;
    }
    *remaining_work_units -= 1;
    if let Some(drawing) = shape.drawing() {
        if let Some(text_box) = &drawing.text_box {
            collect_exact_font_slots_from_paragraphs(
                &text_box.paragraphs,
                slots,
                remaining_work_units,
                depth + 1,
            );
        }
        if let Some(caption) = &drawing.caption {
            collect_exact_font_slots_from_paragraphs(
                &caption.paragraphs,
                slots,
                remaining_work_units,
                depth + 1,
            );
        }
    }
    match shape {
        crate::model::shape::ShapeObject::Group(group) => {
            if let Some(caption) = &group.caption {
                collect_exact_font_slots_from_paragraphs(
                    &caption.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                );
            }
            for child in &group.children {
                collect_exact_font_slots_from_shape(child, slots, remaining_work_units, depth + 1);
            }
        }
        crate::model::shape::ShapeObject::Picture(picture) => {
            if let Some(caption) = &picture.caption {
                collect_exact_font_slots_from_paragraphs(
                    &caption.paragraphs,
                    slots,
                    remaining_work_units,
                    depth + 1,
                );
            }
        }
        _ => {}
    }
}

// ── [#2004] 부동 전면 이미지 스택 → 인라인 재분류 (render-전용, 원본 무손상) ──

/// 부동(tac=false) 그림/그림-도형의 공통 속성(읽기).
fn floating_stack_picture_common(ctrl: &Control) -> Option<&crate::model::shape::CommonObjAttr> {
    match ctrl {
        Control::Picture(pic) => Some(&pic.common),
        Control::Shape(shape) => match shape.as_ref() {
            crate::model::shape::ShapeObject::Picture(p) => Some(&p.common),
            _ => None,
        },
        _ => None,
    }
}

/// 동일 위치·겹침불허·전면급 부동 그림 스택의 폭·높이 범위.
///
/// 모든 control이 비-TAC Square 그림/그림-도형이고, 가시 텍스트가 없으며, 세로 offset이
/// 그림 높이 하나 안에서 겹칠 때만 반환한다. 본문 정규화와 #1995 낱장 배치 억제가 같은
/// 저장 형상을 판정하도록 이 조건을 한 곳에 둔다.
fn floating_image_stack_extents(para: &Paragraph, min_height_hu: i32) -> Option<(i32, i32)> {
    use crate::model::shape::TextWrap;
    if para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}') {
        return None;
    }
    if para.controls.is_empty() {
        return None;
    }
    let mut count = 0usize;
    let mut min_voff = i32::MAX;
    let mut max_voff = i32::MIN;
    let mut min_pic_h = i32::MAX;
    let mut min_pic_w = i32::MAX;
    let mut max_pic_h = i32::MIN;
    for ctrl in &para.controls {
        let common = floating_stack_picture_common(ctrl)?;
        if common.treat_as_char
            || !matches!(common.text_wrap, TextWrap::Square)
            || common.allow_overlap
            || (common.height as i32) < min_height_hu
        {
            return None;
        }
        let voff = common.vertical_offset as i32;
        min_voff = min_voff.min(voff);
        max_voff = max_voff.max(voff);
        min_pic_h = min_pic_h.min(common.height as i32);
        min_pic_w = min_pic_w.min(common.width as i32);
        max_pic_h = max_pic_h.max(common.height as i32);
        count += 1;
    }
    // [#2004] 세로오프셋이 동일하거나(#1995: 전부 0) 이미지 높이보다 작은 band 안에서
    // varying(156714340: 0/-3360/-2940 …)이어 서로 크게 겹치면 "겹침 스택"으로 판정한다.
    // 오프셋 spread ≥ 이미지 높이면 이미 세로로 벌어진 정상 배치이므로 제외.
    (count >= 2 && (max_voff as i64 - min_voff as i64) <= min_pic_h as i64)
        .then_some((min_pic_w, max_pic_h))
}

/// 한 문단이 "동일 위치·겹침불허·전면급 부동 그림 다수" 스택인지.
/// 한글은 이런 그림을 쪽당 1장씩 배치하지만 rhwp 는 앵커 쪽에 겹쳐 그린다(#2004 부동 변종).
/// 게이트를 좁혀(모든 컨트롤이 tac=false·Square·overlap=false·전면급 그림 + 동일 세로오프셋 +
/// 개수≥2 + 가시 텍스트 없음) 일반 부동개체 문단 오검출을 차단한다.
fn para_is_floating_image_stack(para: &Paragraph, min_height_hu: i32) -> bool {
    floating_image_stack_extents(para, min_height_hu).is_some()
}

/// [#4770] 본문 그림 스택이 "앵커 쪽에 겹친 채 남는" 저장 형상인지.
///
/// 두 조건이 함께 성립해야 한다:
/// 1. 저장 첫 줄이 그림 폭 이상 오른쪽에서 시작(cs ≥ min 그림 폭) — 저작 한글이
///    빈 줄을 Square 배제로 그림 **옆에** 끼운 흔적.
/// 2. 첫 그림이 앵커 위치의 본문 하단에 물리적으로 들어감(저장 vpos + max 그림
///    높이 ≤ 본문 하단 절대 좌표) — 들어가지 않으면 한글은 겹침불허 캐스케이드로 낱장 분산한다.
///
/// HPV 코호트 s2/pi1007(그림 24장 150×212mm, cs=42520·vpos=5040, 한글 1쪽)은 둘 다
/// 성립 → 스택 유지. #2004 본문 96장(cs=0·vpos=53602, 한글 96쪽)과 셀 스택 픽스처
/// (cs-옆끼임이나 그림 h≈65k 가 잔여에 안 들어감, 한글 8쪽)는 성립하지 않아 기존
/// 낱장 분산이 보존된다. **셀 내부 스택에는 적용하지 않는다** — 컨테이너가 쪽이
/// 아니라 셀이라 잔여 판정의 기준이 다르다.
///
/// `vertical_pos`는 페이지 상단 기준 절대 좌표이므로 `body_bottom_hu`와 비교해야 한다.
/// 이 계약은 본문 정규화와 typeset의 #1995 낱장 배치 억제가 함께 사용한다.
pub(crate) fn body_pile_stays_on_anchor_page(
    para: &Paragraph,
    min_height_hu: i32,
    body_bottom_hu: i32,
) -> bool {
    let Some((min_pic_w, max_pic_h)) = floating_image_stack_extents(para, min_height_hu) else {
        return false;
    };
    para.line_segs.first().is_some_and(|seg| {
        seg.column_start >= min_pic_w
            && seg.vertical_pos.saturating_add(max_pic_h) <= body_bottom_hu
    })
}

/// 문단의 그림/그림-도형을 인라인(tac=true)으로 재분류(정규화본에만 적용, 원본 무손상).
fn reclassify_floating_pictures_inline(para: &mut Paragraph) {
    for ctrl in para.controls.iter_mut() {
        match ctrl {
            Control::Picture(pic) => pic.common.treat_as_char = true,
            Control::Shape(shape) => {
                if let crate::model::shape::ShapeObject::Picture(p) = shape.as_mut() {
                    p.common.treat_as_char = true;
                }
            }
            _ => {}
        }
    }
}

/// [#2004] 문단이 품은 표의 셀에서 부동 이미지 스택을 "이미지 1장짜리 inline 문단 N개"로
/// 분할·재분류한다(정규화본 전용, 원본 무손상). 156714340: 1×1 부동 표 셀에 전면 Square
/// 이미지 5장 스택. 부동 이미지는 셀 앵커 절대배치라 겹치고, flow 에 없어 intra-cell
/// 분할이 못 나눈다 → inline 문단 단위로 나눠 셀 흐름 유닛이 되게 한다. 변경 시 true.
fn reclassify_cell_floating_stacks(para: &mut Paragraph, min_height_hu: i32) -> bool {
    let mut changed = false;
    for ctrl in para.controls.iter_mut() {
        if let Control::Table(table) = ctrl {
            for cell in table.cells.iter_mut() {
                if !cell
                    .paragraphs
                    .iter()
                    .any(|p| para_is_floating_image_stack(p, min_height_hu))
                {
                    continue;
                }
                let mut new_paras: Vec<Paragraph> = Vec::with_capacity(cell.paragraphs.len());
                for cell_para in cell.paragraphs.drain(..) {
                    if para_is_floating_image_stack(&cell_para, min_height_hu) {
                        // [#2004 Stage1] 분할 문단에 이미지 높이를 담은 합성 line_seg 를
                        // 부여한다. line_segs 를 비우면 셀 composition 이 placeholder
                        // 1줄(400HWPU)로 붕괴해 셀 측정이 스택 총높이를 못 본다(3차 실증).
                        // raw_lh(이미지 높이) ≥ font size 라 corrected_line_height 가
                        // 줄간격 팽창 없이 그대로 반영한다.
                        use crate::model::paragraph::LineSeg;
                        let template = cell_para.line_segs.first().cloned().unwrap_or_default();
                        let mut cum_vpos = template.vertical_pos;
                        for img_ctrl in &cell_para.controls {
                            let mut sp = cell_para.clone();
                            sp.controls = vec![img_ctrl.clone()];
                            let img_h = floating_stack_picture_common(img_ctrl)
                                .map(|cm| cm.height as i32)
                                .unwrap_or(template.line_height);
                            sp.line_segs = vec![LineSeg {
                                text_start: 0,
                                vertical_pos: cum_vpos,
                                line_height: img_h,
                                text_height: img_h,
                                baseline_distance: img_h,
                                line_spacing: 0,
                                column_start: 0,
                                segment_width: template.segment_width,
                                tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
                            }];
                            cum_vpos = cum_vpos.saturating_add(img_h);
                            reclassify_floating_pictures_inline(&mut sp);
                            new_paras.push(sp);
                        }
                        changed = true;
                    } else {
                        new_paras.push(cell_para);
                    }
                }
                cell.paragraphs = new_paras;
            }
        }
    }
    changed
}

fn uses_hwp3_origin_page_tolerance(document: &Document) -> bool {
    let total_paragraphs: usize = document.sections.iter().map(|s| s.paragraphs.len()).sum();
    if total_paragraphs <= 50 {
        return false;
    }

    let para_shape_ratio = document.doc_info.para_shapes.len() as f64 / total_paragraphs as f64;
    let char_shape_ratio = document.doc_info.char_shapes.len() as f64 / total_paragraphs as f64;
    para_shape_ratio < 0.05 && char_shape_ratio < 0.15
}

pub(crate) fn uses_hwp3_origin_flow_spacing_before(document: &Document) -> bool {
    // HWP3→HWP5 변환본은 parser 가 ParaShape spacing 을 절반으로 정규화하므로
    // 본문 흐름에서만 원래 spacing_before 를 복원(*2)한다.
    // 원본 HWP3 는 parser 가 만든 값을 그대로 쓰고 여기서 재확대하지 않는다.
    // 그 HWPX export 도 IR 이 같은 스케일이다. 마커만으로 hwp3_layout 을 켜면
    // *2 가 한 번 더 들어가 sample16은 64→65, sample11은 151→152로 갈라진다
    // (#3518, #3737). HWP5 변환본의 HWPX는 hwp5-origin 마커가 있어 절반
    // 정규화가 있었던 경우만 *2를 유지한다.
    let profile = document.layout_profile();
    profile.hwp3_layout()
        && !profile.hwp3_native_layout()
        && (!profile.hwpx_container() || profile.hwp5_origin_hwpx())
}

fn should_insert_hwp3_title_filler_page(
    hwp3_origin_page_tolerance: bool,
    section_index: usize,
    section: &Section,
    carry_last_page_number: u32,
) -> bool {
    if !hwp3_origin_page_tolerance
        || section_index == 0
        || carry_last_page_number == 0
        || carry_last_page_number.is_multiple_of(2)
    {
        return false;
    }

    let Some(first_para) = section.paragraphs.first() else {
        return false;
    };

    let title_section_flags = section.section_def.flags & 0x3 == 0x3
        || first_para.controls.iter().any(|control| {
            matches!(
                control,
                Control::SectionDef(section_def) if section_def.flags & 0x3 == 0x3
            )
        });
    let has_first_page_hide = first_para.controls.iter().any(|control| {
        matches!(
            control,
            Control::PageHide(hide) if hide.hide_header && hide.hide_page_num
        )
    });
    let has_full_page_figure = first_para.controls.iter().any(|control| match control {
        Control::Picture(picture) => {
            !picture.common.treat_as_char
                && picture.common.width >= section.section_def.page_def.width * 9 / 10
                && picture.common.height >= section.section_def.page_def.height * 9 / 10
        }
        Control::Shape(shape) => {
            let common = shape.common();
            !common.treat_as_char
                && common.width >= section.section_def.page_def.width * 9 / 10
                && common.height >= section.section_def.page_def.height * 9 / 10
        }
        _ => false,
    });
    let has_early_explicit_page_break = section.paragraphs.iter().take(40).any(|para| {
        matches!(
            para.column_type,
            ColumnBreakType::Page | ColumnBreakType::Section
        )
    });

    title_section_flags
        && has_first_page_hide
        && has_full_page_figure
        && has_early_explicit_page_break
}

fn insert_hwp3_title_filler_page(result: &mut PaginationResult, section_index: usize) {
    let Some(first_page) = result.pages.first() else {
        return;
    };

    let blank = PageContent {
        page_index: 0,
        page_number: 1,
        page_number_restarted: false,
        section_index,
        layout: first_page.layout.clone(),
        column_contents: Vec::new(),
        active_header: None,
        active_footer: None,
        page_number_pos: None,
        page_hide: None,
        footnotes: Vec::new(),
        active_master_page: None,
        extra_master_pages: Vec::new(),
        ladder_band_tables: Vec::new(),
    };

    for (page_idx, page) in result.pages.iter_mut().enumerate() {
        page.page_index = (page_idx + 1) as u32;
        page.page_number = page.page_number.saturating_add(1);
    }
    result.pages.insert(0, blank);
}

fn assign_master_pages_for_section(
    result: &mut PaginationResult,
    section_index: usize,
    section: &Section,
    carry_master_odd: &Option<MasterPageRef>,
    carry_master_even: &Option<MasterPageRef>,
) {
    use crate::model::header_footer::HeaderFooterApply;

    for page in &mut result.pages {
        page.active_master_page = None;
        page.extra_master_pages.clear();
    }

    let mps = &section.section_def.master_pages;
    if mps.is_empty() {
        return;
    }

    let base_mp_indices: Vec<usize> = mps
        .iter()
        .enumerate()
        .filter(|(_, m)| !m.is_extension)
        .map(|(i, _)| i)
        .collect();
    let single_base_mp = if base_mp_indices.len() == 1 {
        base_mp_indices.first().copied()
    } else {
        None
    };
    let mp_both = base_mp_indices
        .iter()
        .copied()
        .find(|&i| mps[i].apply_to == HeaderFooterApply::Both);
    let mp_odd = base_mp_indices
        .iter()
        .copied()
        .find(|&i| mps[i].apply_to == HeaderFooterApply::Odd);
    let mp_even = base_mp_indices
        .iter()
        .copied()
        .find(|&i| mps[i].apply_to == HeaderFooterApply::Even);
    let ext_mp_indices: Vec<usize> = mps
        .iter()
        .enumerate()
        .filter(|(_, m)| m.is_extension)
        .map(|(i, _)| i)
        .collect();

    let section_page_count = result.pages.len();
    for (page_idx_in_section, page) in result.pages.iter_mut().enumerate() {
        let is_last = page_idx_in_section + 1 == section_page_count;
        let is_first_page = page_idx_in_section == 0;

        if is_first_page && section.section_def.hide_master_page {
            continue;
        }

        let selected = if page.page_number % 2 == 1 {
            mp_odd
                .or(mp_both)
                .map(|mi| MasterPageRef {
                    section_index,
                    master_page_index: mi,
                })
                .or_else(|| carry_master_odd.clone())
                .or_else(|| {
                    single_base_mp.map(|mi| MasterPageRef {
                        section_index,
                        master_page_index: mi,
                    })
                })
        } else {
            mp_even
                .or(mp_both)
                .map(|mi| MasterPageRef {
                    section_index,
                    master_page_index: mi,
                })
                .or_else(|| carry_master_even.clone())
                .or_else(|| {
                    single_base_mp.map(|mi| MasterPageRef {
                        section_index,
                        master_page_index: mi,
                    })
                })
        };
        page.active_master_page = selected;

        if is_last && !ext_mp_indices.is_empty() {
            let replace_exts: Vec<usize> = ext_mp_indices
                .iter()
                .filter(|&&i| !mps[i].overlap || mps[i].replace_base)
                .copied()
                .collect();
            let overlap_exts: Vec<usize> = ext_mp_indices
                .iter()
                .filter(|&&i| mps[i].overlap && !mps[i].replace_base)
                .copied()
                .collect();

            if let Some(&replace_idx) = replace_exts.last() {
                page.active_master_page = Some(MasterPageRef {
                    section_index,
                    master_page_index: replace_idx,
                });
            }

            let active_apply = page
                .active_master_page
                .as_ref()
                .and_then(|mp_ref| {
                    if mp_ref.section_index == section_index {
                        mps.get(mp_ref.master_page_index)
                    } else {
                        None
                    }
                })
                .map(|m| m.apply_to);
            let mut remaining_overlap_exts: Vec<usize> = Vec::new();
            for &i in &overlap_exts {
                if Some(mps[i].apply_to) == active_apply {
                    page.active_master_page = Some(MasterPageRef {
                        section_index,
                        master_page_index: i,
                    });
                } else {
                    remaining_overlap_exts.push(i);
                }
            }
            if !remaining_overlap_exts.is_empty() {
                page.extra_master_pages = remaining_overlap_exts
                    .iter()
                    .map(|&mi| MasterPageRef {
                        section_index,
                        master_page_index: mi,
                    })
                    .collect();
            }
        }
    }
}

fn update_master_page_carry_from_section(
    section_index: usize,
    section: &Section,
    carry_master_odd: &mut Option<MasterPageRef>,
    carry_master_even: &mut Option<MasterPageRef>,
) {
    use crate::model::header_footer::HeaderFooterApply;

    for (master_page_index, master_page) in section.section_def.master_pages.iter().enumerate() {
        if master_page.is_extension {
            continue;
        }
        let master_ref = MasterPageRef {
            section_index,
            master_page_index,
        };
        match master_page.apply_to {
            HeaderFooterApply::Both => {
                *carry_master_odd = Some(master_ref.clone());
                *carry_master_even = Some(master_ref);
            }
            HeaderFooterApply::Odd => *carry_master_odd = Some(master_ref),
            HeaderFooterApply::Even => *carry_master_even = Some(master_ref),
        }
    }
}

fn apply_page_number_layouts_for_section(result: &mut PaginationResult, section: &Section) {
    let page_def = &section.section_def.page_def;
    for page in &mut result.pages {
        page.layout
            .apply_page_number_margins(page_def, page.page_number);
        for column in &mut page.column_contents {
            if let Some(zone_layout) = &mut column.zone_layout {
                zone_layout.apply_page_number_margins(page_def, page.page_number);
            }
        }
    }
}

impl DocumentCore {
    /// Exact registry의 한 immutable snapshot에서 W9와 Q2-B contexts를 함께
    /// 만든다. 둘 중 하나만 남는 부분 갱신은 허용하지 않는다.
    pub(crate) fn refresh_exact_font_measurement_contexts(&mut self) {
        let (kerning, shaping) = self
            .layout_engine
            .exact_font_measurement_context_snapshots();
        self.styles.kerning_measurement_context = kerning;
        self.styles.horizontal_shaping_context = shaping;
    }

    fn ensure_exact_font_measurement_contexts(&mut self) {
        let generation = self.layout_engine.exact_font_source_registry_counts().3;
        let slot_count = self.layout_engine.exact_font_source_registry_counts().0;
        let (instance_request_count, instance_request_generation) = self
            .layout_engine
            .horizontal_shaping_instance_request_counts();
        let current = self
            .styles
            .kerning_measurement_context
            .as_ref()
            .zip(self.styles.horizontal_shaping_context.as_ref())
            .is_some_and(|(kerning, shaping)| {
                kerning.registry_generation() == generation
                    && shaping.registry_generation() == generation
                    && shaping.instance_request_generation() == instance_request_generation
                    && shaping.instance_request_count() == instance_request_count
            });
        if (slot_count == 0
            && (self.styles.kerning_measurement_context.is_some()
                || self.styles.horizontal_shaping_context.is_some()))
            || (slot_count > 0 && !current)
        {
            self.refresh_exact_font_measurement_contexts();
        }
    }

    pub(crate) fn recompose_all_with_horizontal_shaping(&mut self) {
        self.composed = self
            .document
            .sections
            .iter()
            .map(|section| compose_section_with_horizontal_shaping(section, &self.styles))
            .collect();
    }

    /// 현재 문서에서 실제 텍스트 run이 참조하는 embedded face만 exact slot registry에
    /// 선등록한다. 개별 32 MiB·문서 layout owner 총 64 MiB 상한은 기존 page lowering과
    /// 동일하며, 초과·손상 source는 추측 없이 등록하지 않는다.
    pub(crate) fn rebuild_embedded_exact_font_sources(&mut self) {
        self.layout_engine.clear_exact_font_sources();
        self.styles.kerning_measurement_context = None;
        self.styles.horizontal_shaping_context = None;
        let has_embedded_source = self
            .document
            .doc_info
            .font_faces
            .iter()
            .flatten()
            .any(|font| {
                (font.is_embedded && font.resolved_bin_data_id.is_some())
                    || font.subst_font.as_ref().is_some_and(|substitute| {
                        substitute.is_embedded && substitute.resolved_bin_data_id.is_some()
                    })
            });
        if !has_embedded_source {
            return;
        }

        let mut slot_set = std::collections::HashSet::new();
        let mut remaining_work_units = 1_000_000usize;
        for section in &self.document.sections {
            collect_exact_font_slots_from_paragraphs(
                &section.paragraphs,
                &mut slot_set,
                &mut remaining_work_units,
                0,
            );
            for master_page in &section.section_def.master_pages {
                collect_exact_font_slots_from_paragraphs(
                    &master_page.paragraphs,
                    &mut slot_set,
                    &mut remaining_work_units,
                    0,
                );
            }
        }
        let mut slots = slot_set.into_iter().collect::<Vec<_>>();
        slots.sort_by_key(|slot| (slot.char_shape_id, slot.language_index));

        let mut embedded_font_ids = Vec::new();
        for slot in &slots {
            let Some(font_id) = self
                .document
                .doc_info
                .char_shapes
                .get(slot.char_shape_id as usize)
                .and_then(|shape| shape.font_ids.get(slot.language_index))
                .copied()
            else {
                continue;
            };
            let Some(font) = self
                .document
                .doc_info
                .font_faces
                .get(slot.language_index)
                .and_then(|fonts| fonts.get(font_id as usize))
            else {
                continue;
            };
            if font.is_embedded {
                if let Some(bin_data_id) = font.resolved_bin_data_id {
                    embedded_font_ids.push(bin_data_id);
                }
            }
            if let Some(bin_data_id) = font
                .subst_font
                .as_ref()
                .filter(|substitute| substitute.is_embedded)
                .and_then(|substitute| substitute.resolved_bin_data_id)
            {
                embedded_font_ids.push(bin_data_id);
            }
        }
        let font_bytes_by_id = load_bounded_embedded_font_bytes(
            &self.document.bin_data_content,
            &embedded_font_ids,
            MAX_EMBEDDED_FONT_BYTES,
            MAX_EMBEDDED_FONT_BYTES_PER_PAGE,
        );

        for slot in slots {
            let Some(font_id) = self
                .document
                .doc_info
                .char_shapes
                .get(slot.char_shape_id as usize)
                .and_then(|shape| shape.font_ids.get(slot.language_index))
                .copied()
            else {
                continue;
            };
            let Some(font) = self
                .document
                .doc_info
                .font_faces
                .get(slot.language_index)
                .and_then(|fonts| fonts.get(font_id as usize))
            else {
                continue;
            };

            let primary = font
                .is_embedded
                .then_some(font.resolved_bin_data_id)
                .flatten()
                .and_then(|bin_data_id| {
                    let bytes = font_bytes_by_id.get(&bin_data_id)?;
                    let face_index = resolve_embedded_font_face_index(bytes, &font.name, None)?;
                    Some((&bytes[..], face_index))
                });
            let substitute = font
                .subst_font
                .as_ref()
                .filter(|substitute| substitute.is_embedded)
                .and_then(|substitute| {
                    let bin_data_id = substitute.resolved_bin_data_id?;
                    let bytes = font_bytes_by_id.get(&bin_data_id)?;
                    let face_index =
                        resolve_embedded_font_face_index(bytes, substitute.face.as_str(), None)?;
                    Some((&bytes[..], face_index))
                });
            let Some((bytes, face_index)) = primary.or(substitute) else {
                continue;
            };
            match self
                .layout_engine
                .register_exact_font_source(slot, bytes, face_index)
            {
                Ok(ExactFontRegistryRegistration::Registered)
                | Ok(ExactFontRegistryRegistration::AlreadyRegistered) => {}
                Err(_) => {
                    // Registry 상한·충돌은 fail-closed다. 문서 로드는 유지하고 해당 slot의
                    // kerning source만 없는 상태로 둔다.
                }
            }
        }
        self.refresh_exact_font_measurement_contexts();
    }

    /// 페이지 렌더 트리를 생성하여 반환한다 (native bridge / 외부 렌더러용).
    pub fn build_page_render_tree(&self, page_num: u32) -> Result<PageRenderTree, HwpError> {
        let tree = self.build_page_tree(page_num)?;
        let _overflows = self.layout_engine.take_overflows();
        Ok(tree)
    }

    /// 페이지 레이어 트리를 생성하여 반환한다 (native bridge / backend replay용).
    pub fn build_page_layer_tree(&self, page_num: u32) -> Result<PageLayerTree, HwpError> {
        self.build_page_layer_tree_with_profile(page_num, RenderProfile::Screen)
    }

    pub fn build_page_layer_tree_with_profile(
        &self,
        page_num: u32,
        profile: RenderProfile,
    ) -> Result<PageLayerTree, HwpError> {
        let _overflows = self.layout_engine.take_overflows();
        let idx = page_num as usize;
        let fingerprint = self
            .layer_output_options_fingerprint(profile, crate::paint::LayerJsonOptions::default());
        if let Some(variants) = self.page_layer_tree_cache.borrow().get(idx) {
            if let Some((_, tree)) = variants.iter().find(|(value, _)| *value == fingerprint) {
                return Ok(tree.clone());
            }
        }
        let show_editor_visuals = profile.shows_editor_visuals();
        let output_options = LayerOutputOptions {
            show_paragraph_marks: show_editor_visuals && self.show_paragraph_marks,
            show_control_codes: show_editor_visuals && self.show_control_codes,
            show_transparent_borders: show_editor_visuals && self.show_transparent_borders,
            clip_enabled: self.clip_enabled,
            debug_overlay: show_editor_visuals && self.debug_overlay,
        };
        let layer_tree = self.with_page_tree_cached(page_num, |tree| {
            let mut used_font_slots = Vec::new();
            let mut nodes = vec![&tree.root];
            while let Some(node) = nodes.pop() {
                if !node.visible {
                    continue;
                }
                nodes.extend(node.children.iter());
                let crate::renderer::render_tree::RenderNodeType::TextRun(run) = &node.node_type
                else {
                    continue;
                };
                let mut characters = run.text.chars();
                let (Some(character), None, Some(char_shape_id)) =
                    (characters.next(), characters.next(), run.char_shape_id)
                else {
                    continue;
                };
                let language_index =
                    crate::renderer::style_resolver::detect_lang_category(character);
                let slot = (char_shape_id, language_index);
                if !used_font_slots.contains(&slot) {
                    used_font_slots.push(slot);
                }
            }

            let mut embedded_font_ids = Vec::new();
            for &(char_shape_id, language_index) in &used_font_slots {
                let Some(font_id) = self
                    .document
                    .doc_info
                    .char_shapes
                    .get(char_shape_id as usize)
                    .and_then(|shape| shape.font_ids.get(language_index))
                    .copied()
                else {
                    continue;
                };
                let Some(font) = self
                    .document
                    .doc_info
                    .font_faces
                    .get(language_index)
                    .and_then(|fonts| fonts.get(font_id as usize))
                else {
                    continue;
                };
                if font.is_embedded {
                    if let Some(bin_data_id) = font.resolved_bin_data_id {
                        embedded_font_ids.push(bin_data_id);
                    }
                }
                if let Some(bin_data_id) = font
                    .subst_font
                    .as_ref()
                    .filter(|substitute| substitute.is_embedded)
                    .and_then(|substitute| substitute.resolved_bin_data_id)
                {
                    embedded_font_ids.push(bin_data_id);
                }
            }
            let font_bytes_by_id = load_bounded_embedded_font_bytes(
                &self.document.bin_data_content,
                &embedded_font_ids,
                MAX_EMBEDDED_FONT_BYTES,
                MAX_EMBEDDED_FONT_BYTES_PER_PAGE,
            );
            let mut resolved_fonts = Vec::new();
            for (char_shape_id, language_index) in used_font_slots {
                let Some(font_id) = self
                    .document
                    .doc_info
                    .char_shapes
                    .get(char_shape_id as usize)
                    .and_then(|shape| shape.font_ids.get(language_index))
                    .copied()
                else {
                    continue;
                };
                let Some(font) = self
                    .document
                    .doc_info
                    .font_faces
                    .get(language_index)
                    .and_then(|fonts| fonts.get(font_id as usize))
                else {
                    continue;
                };

                let mut resolved = None;
                if font.is_embedded {
                    if let Some(bin_data_id) = font.resolved_bin_data_id {
                        if let Some(bytes) = font_bytes_by_id.get(&bin_data_id) {
                            resolved = resolve_embedded_font_face_index(bytes, &font.name, None)
                                .map(|face_index| (bin_data_id, None, face_index));
                        }
                    }
                }
                if resolved.is_none() {
                    if let Some(substitute) = font
                        .subst_font
                        .as_ref()
                        .filter(|substitute| substitute.is_embedded)
                    {
                        if let Some(bin_data_id) = substitute.resolved_bin_data_id {
                            if let Some(bytes) = font_bytes_by_id.get(&bin_data_id) {
                                resolved = resolve_embedded_font_face_index(
                                    bytes,
                                    substitute.face.as_str(),
                                    None,
                                )
                                .map(|face_index| {
                                    (bin_data_id, Some(substitute.face.as_str()), face_index)
                                });
                            }
                        }
                    }
                }
                if let Some((bin_data_id, alternate_family, face_index)) = resolved {
                    resolved_fonts.push((
                        char_shape_id,
                        language_index,
                        font.name.as_str(),
                        alternate_family,
                        bin_data_id,
                        face_index,
                    ));
                }
            }
            let embedded_fonts = resolved_fonts
                .iter()
                .filter_map(
                    |&(
                        char_shape_id,
                        language_index,
                        family,
                        alternate_family,
                        bin_data_id,
                        face_index,
                    )| {
                        Some(EmbeddedFontFace {
                            char_shape_id,
                            language_index,
                            family,
                            alternate_family,
                            bytes: &font_bytes_by_id.get(&bin_data_id)?[..],
                            face_index,
                        })
                    },
                )
                .collect::<Vec<_>>();
            let mut builder = LayerBuilder::new(profile)
                .with_output_options(output_options)
                .with_bin_data_epoch(self.bin_data_epoch);
            Ok(builder.build_with_embedded_fonts(tree, &embedded_fonts))
        })?;
        {
            let mut cache = self.page_layer_tree_cache.borrow_mut();
            if cache.len() <= idx {
                cache.resize_with(idx + 1, Vec::new);
            }
            let variants = &mut cache[idx];
            variants.retain(|(value, _)| *value != fingerprint);
            if variants.len() >= 4 {
                variants.remove(0);
            }
            variants.push((fingerprint, layer_tree.clone()));
        }
        Ok(layer_tree)
    }

    /// 바이너리 데이터를 0-based `bin_data_content` 인덱스로 반환한다.
    /// [Task #2263] 지연 로딩 도입으로 바이트를 빌려줄 수 없어 소유값을 반환한다.
    /// [#2550] 압축 해제 상한 초과(deflate bomb 포함)는 항목 없음과 같은 `None` 이다.
    pub fn get_bin_data(&self, index: usize) -> Option<Vec<u8>> {
        // 공개 계약은 소유 `Vec` 이다 — 호출부가 WASM 경계로 넘긴다.
        self.document.bin_data_content.get(index).and_then(|b| {
            b.data
                .load_limited(crate::model::bin_data::MAX_BIN_DATA_BYTES)
        })
    }

    /// [#3668] 직전 렌더에서 발생한 `LAYOUT_OVERFLOW_CELL` 줄 수를 읽고 리셋한다.
    /// 페이지 렌더 직후 호출하면 그 페이지 귀속 카운트가 된다.
    pub fn take_overflow_cell_lines(&self) -> u32 {
        self.layout_engine.take_overflow_cell_lines()
    }

    /// [#4515] 직전 렌더에서 발생한 최상위 표 y 겹침(`LAYOUT_TABLE_OVERLAP`) 목록을
    /// 읽고 리셋한다. 페이지 렌더 직후 호출하면 그 페이지 귀속 목록이 된다.
    pub fn take_table_overlaps(&self) -> Vec<crate::renderer::layout::LayoutTableOverlap> {
        self.layout_engine.take_table_overlaps()
    }

    /// [Issue #4379] `RHWP_RENDER_PATH=layer-svg` 는 legacy/layer 두 SVG 경로를 A/B 대조하는
    /// **네이티브 전용** 디버그 스위치다. `#[cfg(not(target_arch = "wasm32"))]` 로 감싼 이유는
    /// 장식이 아니라 사실 표시다 — wasm32-unknown-unknown(rhwp-studio 브라우저 빌드)에는
    /// 프로세스 환경변수가 없어 `std::env::var` 가 항상 `Err` 를 반환하므로, 이 함수를 거쳐서는
    /// wasm 에서 layer 경로에 절대 도달할 수 없다(`renderPageSvg` → 항상 legacy). studio 가
    /// 실제로 인쇄 등가 SVG 를 원하면 이 함수를 우회해 `render_page_svg_layer_with_profile_native`
    /// (`renderPageSvgWithProfile`) 를 직접 불러야 한다 — PDF 내보내기(`file.ts:461`)가 이미
    /// 그렇게 한다. 이 cfg 분기는 "네이티브 디버그 스위치이지 프로덕션 경로 선택 API 가 아니다"를
    /// 코드로 드러낸다.
    pub fn render_page_svg_native(&self, page_num: u32) -> Result<String, HwpError> {
        #[cfg(not(target_arch = "wasm32"))]
        if matches!(
            std::env::var("RHWP_RENDER_PATH").ok().as_deref(),
            Some("layer-svg")
        ) {
            return self.render_page_svg_layer_native(page_num);
        }
        self.render_page_svg_legacy_native(page_num)
    }

    pub fn render_page_svg_legacy_native(&self, page_num: u32) -> Result<String, HwpError> {
        let tree = self.build_page_tree(page_num)?;
        let _overflows = self.layout_engine.take_overflows();
        let mut renderer = SvgRenderer::new();
        renderer.show_paragraph_marks = self.show_paragraph_marks;
        renderer.show_control_codes = self.show_control_codes;
        renderer.debug_overlay = self.debug_overlay;
        renderer.annotate_metric_font = self.annotate_metric_font;
        renderer.render_tree(&tree);
        Ok(renderer.output().to_string())
    }

    pub fn render_page_svg_layer_native(&self, page_num: u32) -> Result<String, HwpError> {
        self.render_page_svg_layer_with_profile_native(page_num, RenderProfile::Screen)
    }

    pub fn render_page_svg_layer_with_profile_native(
        &self,
        page_num: u32,
        profile: RenderProfile,
    ) -> Result<String, HwpError> {
        let layer_tree = self.build_page_layer_tree_with_profile(page_num, profile)?;
        let mut renderer = SvgLayerRenderer::new();
        // WASM에서도 문서 내장 face 사용량을 수집한다. 실제 CSS 생성은 아래의
        // embedded-only 경로가 담당하므로 시스템 font file I/O는 발생하지 않는다.
        renderer.inner_mut().font_embed_mode = crate::renderer::svg::FontEmbedMode::Style;
        renderer.inner_mut().annotate_metric_font = self.annotate_metric_font;
        renderer.render_page(&layer_tree)?;
        let mut svg = renderer.output().to_string();

        // [#2524/#3126] print/profile SVG도 브라우저가 문서 내장 폰트를 직접
        // 해석할 수 있게 원본 font bytes를 data URI로 포함한다. Layer SVG가
        // TextRun fallback을 재생하더라도 Blink에서 두부(□)가 되지 않는다.
        let embedded_fonts = self.collect_embedded_font_bytes_by_name();
        let style_css =
            crate::renderer::svg::generate_embedded_font_style(renderer.inner(), &embedded_fonts);
        if !style_css.is_empty() {
            if let Some(pos) = svg.find('>') {
                let insert = format!("\n<style>\n{}</style>\n", style_css);
                svg.insert_str(pos + 1, &insert);
            }
        }
        Ok(svg)
    }

    /// PDF export for one page, implemented as the current compatibility path:
    /// SVG render output -> svg2pdf.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_page_pdf_native(&self, page_num: u32) -> Result<Vec<u8>, HwpError> {
        self.render_pages_pdf_native(&[page_num])
    }

    /// PDF export for an explicit 0-based page selection.
    ///
    /// This keeps PDF as a native/export API surface rather than a WASM render path.
    /// The implementation intentionally reuses the SVG compatibility output until a
    /// direct/vector PDF backend is introduced.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_pages_pdf_native(&self, page_nums: &[u32]) -> Result<Vec<u8>, HwpError> {
        self.render_pages_pdf_native_with_options(
            page_nums,
            &crate::renderer::pdf::PdfExportOptions::default(),
        )
    }

    /// PDF export for an explicit 0-based page selection with font options.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_pages_pdf_native_with_options(
        &self,
        page_nums: &[u32],
        options: &crate::renderer::pdf::PdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        if page_nums.is_empty() {
            return Err(HwpError::RenderError(
                "PDF export requires at least one page".to_string(),
            ));
        }

        let mut svg_pages = Vec::with_capacity(page_nums.len());
        for &page_num in page_nums {
            svg_pages.push(self.render_page_svg_native(page_num)?);
        }
        crate::renderer::pdf::svgs_to_pdf_with_options(&svg_pages, options)
            .map_err(HwpError::RenderError)
    }

    /// PDF export using the layered SVG compatibility path for an explicit output profile.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_pages_pdf_native_with_profile_and_options(
        &self,
        page_nums: &[u32],
        profile: RenderProfile,
        options: &crate::renderer::pdf::PdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        if page_nums.is_empty() {
            return Err(HwpError::RenderError(
                "PDF export requires at least one page".to_string(),
            ));
        }

        let mut svg_pages = Vec::with_capacity(page_nums.len());
        for &page_num in page_nums {
            svg_pages.push(self.render_page_svg_layer_with_profile_native(page_num, profile)?);
        }
        crate::renderer::pdf::svgs_to_pdf_with_options(&svg_pages, options)
            .map_err(HwpError::RenderError)
    }

    /// PDF export for the full document.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_document_pdf_native(&self) -> Result<Vec<u8>, HwpError> {
        let pages: Vec<u32> = (0..self.page_count()).collect();
        self.render_pages_pdf_native(&pages)
    }

    /// PDF export for the full document with font options.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_document_pdf_native_with_options(
        &self,
        options: &crate::renderer::pdf::PdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        let pages: Vec<u32> = (0..self.page_count()).collect();
        self.render_pages_pdf_native_with_options(&pages, options)
    }

    /// Direct PageLayerTree PDF export for one page.
    ///
    /// This opt-in backend requires `native-skia`. The default print profile
    /// excludes editor-only overlays from exported documents.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_page_pdf_direct_native(&self, page_num: u32) -> Result<Vec<u8>, HwpError> {
        self.render_pages_pdf_direct_native(&[page_num])
    }

    /// Direct PageLayerTree PDF export for an explicit 0-based page selection.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_pages_pdf_direct_native(&self, page_nums: &[u32]) -> Result<Vec<u8>, HwpError> {
        self.render_pages_pdf_direct_native_with_profile_and_options(
            page_nums,
            RenderProfile::Print,
            &crate::renderer::pdf::DirectPdfExportOptions::default(),
        )
    }

    /// Direct PageLayerTree PDF export with native Skia recording options.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_pages_pdf_direct_native_with_options(
        &self,
        page_nums: &[u32],
        options: &crate::renderer::pdf::DirectPdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        self.render_pages_pdf_direct_native_with_profile_and_options(
            page_nums,
            RenderProfile::Print,
            options,
        )
    }

    /// Direct PageLayerTree PDF export with an explicit output profile.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_pages_pdf_direct_native_with_profile_and_options(
        &self,
        page_nums: &[u32],
        profile: RenderProfile,
        options: &crate::renderer::pdf::DirectPdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        if page_nums.is_empty() {
            return Err(HwpError::RenderError(
                "PDF export requires at least one page".to_string(),
            ));
        }

        let mut layer_trees = Vec::with_capacity(page_nums.len());
        for &page_num in page_nums {
            layer_trees.push(self.build_page_layer_tree_with_profile(page_num, profile)?);
        }
        crate::renderer::pdf::layer_trees_to_pdf_with_options(&layer_trees, options)
            .map_err(HwpError::RenderError)
    }

    /// Direct PageLayerTree PDF export for the full document.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_document_pdf_direct_native(&self) -> Result<Vec<u8>, HwpError> {
        self.render_document_pdf_direct_native_with_options(
            &crate::renderer::pdf::DirectPdfExportOptions::default(),
        )
    }

    /// Direct PageLayerTree PDF export for the full document with recording options.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_document_pdf_direct_native_with_options(
        &self,
        options: &crate::renderer::pdf::DirectPdfExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        let pages: Vec<u32> = (0..self.page_count()).collect();
        self.render_pages_pdf_direct_native_with_options(&pages, options)
    }

    /// [#2524] 문서 임베디드(BinData) 폰트를 face명 → 원본 bytes 로 수집한다.
    ///
    /// SVG `@font-face` 직접 임베딩용. 미설치 임베디드 폰트(bitmap 등)가
    /// `local()` 폴백으로 chrome 두부가 되던 문제 해소. 동일 face 명이 여러
    /// 언어 슬롯에 있으면 첫 항목만 담는다.
    fn collect_embedded_font_bytes_by_name(&self) -> std::collections::HashMap<String, Vec<u8>> {
        let mut ids = Vec::new();
        let mut name_id: Vec<(String, u16)> = Vec::new();
        for fonts in &self.document.doc_info.font_faces {
            for font in fonts {
                if font.is_embedded {
                    if let Some(id) = font.resolved_bin_data_id {
                        ids.push(id);
                        name_id.push((font.name.clone(), id));
                    }
                }
            }
        }
        if ids.is_empty() {
            return std::collections::HashMap::new();
        }
        let bytes_by_id = load_bounded_embedded_font_bytes(
            &self.document.bin_data_content,
            &ids,
            MAX_EMBEDDED_FONT_BYTES,
            MAX_EMBEDDED_FONT_BYTES_PER_PAGE,
        );
        let mut map = std::collections::HashMap::new();
        for (name, id) in name_id {
            if let Some(bytes) = bytes_by_id.get(&id) {
                map.entry(name).or_insert_with(|| bytes.clone());
            }
        }
        map
    }

    /// SVG 렌더링 (폰트 임베딩 옵션 포함)
    #[cfg(not(target_arch = "wasm32"))]
    pub fn render_page_svg_with_fonts(
        &self,
        page_num: u32,
        font_embed_mode: crate::renderer::svg::FontEmbedMode,
        font_paths: &[std::path::PathBuf],
    ) -> Result<String, HwpError> {
        let tree = self.build_page_tree(page_num)?;
        let _overflows = self.layout_engine.take_overflows();
        let mut renderer = SvgRenderer::new();
        renderer.show_paragraph_marks = self.show_paragraph_marks;
        renderer.show_control_codes = self.show_control_codes;
        renderer.debug_overlay = self.debug_overlay;
        renderer.font_embed_mode = font_embed_mode;
        renderer.font_paths = font_paths.to_vec();
        renderer.render_tree(&tree);

        // 폰트 임베딩 후처리
        let mut svg = renderer.output().to_string();
        if font_embed_mode != crate::renderer::svg::FontEmbedMode::None {
            // [#2524] 문서 임베디드(BinData) 폰트를 face명 → bytes 로 수집해
            // @font-face 직접 임베딩에 쓴다(미설치 임베디드 폰트 chrome 두부 해소).
            let embedded_fonts = self.collect_embedded_font_bytes_by_name();
            let style_css =
                crate::renderer::svg::generate_font_style(&renderer, font_paths, &embedded_fonts);
            if !style_css.is_empty() {
                // <svg ...> 직후에 <style> 삽입
                if let Some(pos) = svg.find('>') {
                    let insert = format!("\n<style>\n{}</style>\n", style_css);
                    svg.insert_str(pos + 1, &insert);
                }
            }
        }
        Ok(svg)
    }

    /// HTML 렌더링 (네이티브 에러 타입)
    pub fn render_page_html_native(&self, page_num: u32) -> Result<String, HwpError> {
        let tree = self.build_page_tree(page_num)?;
        let _overflows = self.layout_engine.take_overflows();
        let mut renderer = HtmlRenderer::new();
        renderer.show_paragraph_marks = self.show_paragraph_marks;
        renderer.show_control_codes = self.show_control_codes;
        renderer.render_tree(&tree);
        Ok(renderer.output().to_string())
    }

    /// Canvas 렌더링 (네이티브 에러 타입)
    pub fn render_page_canvas_native(&self, page_num: u32) -> Result<u32, HwpError> {
        let tree = self.build_page_layer_tree(page_num)?;
        let mut renderer = CanvasRenderer::new();
        renderer.render_page(&tree)?;
        Ok(renderer.command_count() as u32)
    }

    pub fn render_page_canvas_legacy_native(&self, page_num: u32) -> Result<u32, HwpError> {
        let tree = self.build_page_tree(page_num)?;
        let _overflows = self.layout_engine.take_overflows();
        let mut renderer = CanvasRenderer::new();
        renderer.render_tree(&tree);
        Ok(renderer.command_count() as u32)
    }

    pub fn get_canvaskit_replay_plan_native(
        &self,
        page_num: u32,
        mode: &str,
    ) -> Result<String, HwpError> {
        self.get_canvaskit_replay_plan_with_profile_native(page_num, mode, RenderProfile::Screen)
    }

    pub fn get_canvaskit_replay_plan_with_profile_native(
        &self,
        page_num: u32,
        mode: &str,
        profile: RenderProfile,
    ) -> Result<String, HwpError> {
        use crate::renderer::canvaskit_policy::{
            analyze_canvaskit_replay_plan, CanvasKitReplayMode,
        };

        let mode = CanvasKitReplayMode::from_str(mode).ok_or_else(|| {
            HwpError::RenderError(format!(
                "지원하지 않는 CanvasKit replay mode입니다: {mode}. allowed modes: default, compat"
            ))
        })?;
        let tree = self.build_page_layer_tree_with_profile(page_num, profile)?;
        let plan = analyze_canvaskit_replay_plan(&tree, mode);
        serde_json::to_string(&plan).map_err(|error| {
            HwpError::RenderError(format!(
                "CanvasKit replay plan JSON 직렬화에 실패했습니다: {error}"
            ))
        })
    }

    pub fn get_canvaskit_document_preflight_native(
        &self,
        mode: &str,
        profile: RenderProfile,
    ) -> Result<String, HwpError> {
        use crate::renderer::canvaskit_policy::{
            analyze_canvaskit_document_preflight, estimate_canvaskit_page_lowering_work,
            CanvasKitBoundedWorkCount, CanvasKitPreflightPageBuild, CanvasKitReplayMode,
        };

        let mode = CanvasKitReplayMode::from_str(mode).ok_or_else(|| {
            HwpError::RenderError(format!(
                "지원하지 않는 CanvasKit replay mode입니다: {mode}. allowed modes: default, compat"
            ))
        })?;
        let preflight = analyze_canvaskit_document_preflight(
            self.page_count(),
            mode,
            profile,
            |page_index, remaining_work_units| -> Result<CanvasKitPreflightPageBuild, HwpError> {
                let prelower_work = self.with_page_tree_cached(page_index, |tree| {
                    Ok(estimate_canvaskit_page_lowering_work(
                        tree,
                        remaining_work_units,
                    ))
                })?;
                let CanvasKitBoundedWorkCount::Complete(prelower_work_units) = prelower_work else {
                    return Ok(CanvasKitPreflightPageBuild::WorkLimitExceeded);
                };
                let tree = self.build_page_layer_tree_with_profile(page_index, profile)?;
                Ok(CanvasKitPreflightPageBuild::Complete {
                    tree: Box::new(tree),
                    prelower_work_units,
                })
            },
        );
        serde_json::to_string(&preflight).map_err(|error| {
            HwpError::RenderError(format!(
                "CanvasKit document preflight JSON 직렬화에 실패했습니다: {error}"
            ))
        })
    }

    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_page_png_native(&self, page_num: u32) -> Result<Vec<u8>, HwpError> {
        use crate::renderer::layer_renderer::LayerRasterRenderer;
        use crate::renderer::skia::SkiaLayerRenderer;

        let layer_tree = self.build_page_layer_tree(page_num)?;
        SkiaLayerRenderer::new().render_png(&layer_tree)
    }

    /// 사용자 지정 폰트 경로를 포함한 PNG 렌더링. SVG 의 `--font-path` 와 동일 패턴.
    /// ttfs 디렉토리의 한컴 전용 폰트 (HY견명조 등) 가 시스템 fontconfig 에 없을 때 사용.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_page_png_native_with_fonts(
        &self,
        page_num: u32,
        font_paths: &[std::path::PathBuf],
    ) -> Result<Vec<u8>, HwpError> {
        use crate::renderer::layer_renderer::LayerRasterRenderer;
        use crate::renderer::skia::SkiaLayerRenderer;

        let layer_tree = self.build_page_layer_tree(page_num)?;
        SkiaLayerRenderer::new()
            .with_font_paths(font_paths)
            .render_png(&layer_tree)
    }

    /// 옵션 (scale / max-dimension / VLM 프리셋 / font_paths) 적용 PNG 렌더링.
    /// AI 파이프라인 + VLM (Vision-Language Model) 연동 사용 사례용.
    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_page_png_native_with_export_options(
        &self,
        page_num: u32,
        options: &PngExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        self.render_page_png_native_with_profile_and_export_options(
            page_num,
            RenderProfile::Screen,
            options,
        )
    }

    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    pub fn render_page_png_native_with_profile_and_export_options(
        &self,
        page_num: u32,
        profile: RenderProfile,
        options: &PngExportOptions,
    ) -> Result<Vec<u8>, HwpError> {
        use crate::renderer::layer_renderer::{LayerRasterRenderer, RasterRenderOptions};
        use crate::renderer::skia::SkiaLayerRenderer;

        let layer_tree = self.build_page_layer_tree_with_profile(page_num, profile)?;

        // 페이지 크기에서 effective scale + max_dimension 결정
        let mut raster_options = RasterRenderOptions::default();

        // VLM 프리셋 적용 (longest edge 한도 + 픽셀 수 한도)
        let mut effective_max_dim: Option<i32> = options.max_dimension;
        let mut effective_max_pixels: Option<u64> = None;
        if let Some(target) = options.vlm_target {
            let (longest_edge, max_pixels) = target.constraints();
            // 명시 max_dimension 이 없으면 프리셋 한도 사용
            effective_max_dim.get_or_insert(longest_edge);
            effective_max_pixels = Some(max_pixels);
        }

        // scale 결정 우선순위:
        // 1. 명시 scale (사용자 직접 지정)
        // 2. max_dimension / VLM 기반 자동 계산
        // 3. --dpi 만 지정 시 scale = dpi / 96.0 (#614)
        // 4. 기본 1.0
        let scale = if let Some(s) = options.scale {
            s
        } else if effective_max_dim.is_some() || effective_max_pixels.is_some() {
            let mut auto_scale: f64 = 1.0;
            // longest edge 한도
            if let Some(max_dim) = effective_max_dim {
                let longest_page_edge = layer_tree.page_width.max(layer_tree.page_height);
                if longest_page_edge > 0.0 {
                    auto_scale = auto_scale.min(max_dim as f64 / longest_page_edge);
                }
            }
            // 픽셀 수 한도 (ceil + 부동소수점 오차 안전 마진 0.5%)
            if let Some(max_pixels) = effective_max_pixels {
                let page_pixels = layer_tree.page_width * layer_tree.page_height;
                if page_pixels > 0.0 {
                    let pixel_scale = (max_pixels as f64 / page_pixels).sqrt() * 0.995;
                    auto_scale = auto_scale.min(pixel_scale);
                }
            }
            // 1.0 초과 시는 페이지가 이미 충분히 작은 것이므로 1.0 으로 cap
            auto_scale.min(1.0).max(0.1)
        } else if let Some(dpi) = options.dpi {
            (dpi / 96.0).max(0.1)
        } else {
            1.0
        };

        raster_options.scale = scale;
        raster_options.dpi = options.dpi;
        if let Some(max_dim) = effective_max_dim {
            raster_options.max_dimension = max_dim;
        }
        if let Some(max_pixels) = effective_max_pixels {
            raster_options.max_pixels = max_pixels;
        }

        let png_bytes = SkiaLayerRenderer::new()
            .with_font_paths(&options.font_paths)
            .render_png_with_options(&layer_tree, raster_options)?;

        if let Some(dpi) = options.dpi {
            Ok(inject_png_phys(png_bytes, dpi))
        } else {
            Ok(png_bytes)
        }
    }
}

/// PNG 바이트에 pHYs chunk 를 삽입한다 (IHDR 직후, 첫 IDAT 직전).
/// pHYs chunk: 4-byte X ppm + 4-byte Y ppm + 1-byte unit(1=meter).
#[cfg(not(target_arch = "wasm32"))]
fn inject_png_phys(png: Vec<u8>, dpi: f64) -> Vec<u8> {
    const PNG_SIGNATURE: [u8; 8] = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    const IHDR_DATA_LEN: usize = 13;

    let ppm = (dpi / 0.0254).round() as u32;
    if png.len() < 8 || png[..8] != PNG_SIGNATURE {
        return png;
    }
    let pos = 8; // signature 이후
    if pos + 8 > png.len() {
        return png;
    }
    let ihdr_len =
        u32::from_be_bytes([png[pos], png[pos + 1], png[pos + 2], png[pos + 3]]) as usize;
    if ihdr_len != IHDR_DATA_LEN || &png[pos + 4..pos + 8] != b"IHDR" {
        return png;
    }
    let Some(ihdr_end) = pos.checked_add(4 + 4 + ihdr_len + 4) else {
        return png;
    };
    if ihdr_end > png.len() {
        return png;
    }

    // pHYs chunk 구성 (9 bytes data)
    let mut phys_data = Vec::with_capacity(9);
    phys_data.extend_from_slice(&ppm.to_be_bytes()); // X pixels per unit
    phys_data.extend_from_slice(&ppm.to_be_bytes()); // Y pixels per unit
    phys_data.push(1); // unit = meter

    let phys_type = b"pHYs";
    let mut phys_chunk = Vec::with_capacity(4 + 4 + 9 + 4);
    phys_chunk.extend_from_slice(&(9u32).to_be_bytes()); // length
    phys_chunk.extend_from_slice(phys_type);
    phys_chunk.extend_from_slice(&phys_data);
    // CRC: type + data
    let mut crc_input = Vec::with_capacity(4 + 9);
    crc_input.extend_from_slice(phys_type);
    crc_input.extend_from_slice(&phys_data);
    let crc = png_crc32(&crc_input);
    phys_chunk.extend_from_slice(&crc.to_be_bytes());

    let mut result = Vec::with_capacity(png.len() + phys_chunk.len());
    result.extend_from_slice(&png[..ihdr_end]);
    result.extend_from_slice(&phys_chunk);
    result.extend_from_slice(&png[ihdr_end..]);
    result
}

#[cfg(not(target_arch = "wasm32"))]
fn png_crc32(data: &[u8]) -> u32 {
    let mut crc: u32 = 0xFFFF_FFFF;
    for &byte in data {
        crc ^= byte as u32;
        for _ in 0..8 {
            if crc & 1 != 0 {
                crc = (crc >> 1) ^ 0xEDB8_8320;
            } else {
                crc >>= 1;
            }
        }
    }
    crc ^ 0xFFFF_FFFF
}

/// PNG 내보내기 옵션 (export-png CLI / API 통합).
///
/// AI 파이프라인 + VLM (Vision-Language Model) 연동 사용 사례용.
/// `vlm_target` 프리셋 → `max_dimension` → `scale` 순으로 우선순위.
#[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
#[derive(Debug, Clone, Default)]
pub struct PngExportOptions {
    /// 명시 배율 (scale). None 이면 max_dimension 기반 자동 계산.
    pub scale: Option<f64>,
    /// 한 변 최대 픽셀 (longest edge). VLM 입력 한도용.
    pub max_dimension: Option<i32>,
    /// VLM 프리셋. Claude / 향후 GPT-4V / Gemini / Qwen-VL / LLaVA 확장 (이슈 #613).
    pub vlm_target: Option<VlmTarget>,
    /// DPI 메타데이터. PNG pHYs chunk 에 기록. 실제 래스터 픽셀 수에 영향 없음.
    /// `scale` 미지정 시 `scale = dpi / 96.0` 자동 계산.
    pub dpi: Option<f64>,
    /// 사용자 지정 폰트 디렉토리 (ttfs 등). SVG 의 `--font-path` 와 동일.
    pub font_paths: Vec<std::path::PathBuf>,
}

/// VLM (Vision-Language Model) 입력 사양 프리셋.
#[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VlmTarget {
    /// Claude Vision (Anthropic): longest edge ≤1568 px, ≤1.15 MP.
    Claude,
    /// GPT-4V low detail (OpenAI): 512×512 고정.
    Gpt4vLow,
    /// GPT-4V high detail (OpenAI): 768×2000 tile 기반.
    Gpt4vHigh,
    /// Gemini (Google): longest edge ≤3072 px.
    Gemini,
    /// Qwen-VL (Alibaba): longest edge ≤2240 px, 28×28 patch 기반.
    QwenVl,
    /// LLaVA / 기타 OSS (CLIP backbone): longest edge ≤672 px.
    Llava,
}

#[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
impl VlmTarget {
    /// (longest_edge, max_pixels) 한도 반환.
    pub fn constraints(&self) -> (i32, u64) {
        match self {
            VlmTarget::Claude => (1568, 1_150_000),
            VlmTarget::Gpt4vLow => (512, 262_144),
            VlmTarget::Gpt4vHigh => (2000, 1_536_000),
            VlmTarget::Gemini => (3072, 9_437_184),
            VlmTarget::QwenVl => (2240, 5_017_600),
            VlmTarget::Llava => (672, 451_584),
        }
    }

    /// CLI 옵션 문자열 → VlmTarget 변환.
    /// 하이픈/밑줄 정규화 후 매칭. `gpt4v`/`qwen` 등 축약 별칭도 허용.
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().replace('-', "_").as_str() {
            "claude" => Some(VlmTarget::Claude),
            "gpt4v_low" => Some(VlmTarget::Gpt4vLow),
            "gpt4v_high" | "gpt4v" => Some(VlmTarget::Gpt4vHigh),
            "gemini" => Some(VlmTarget::Gemini),
            "qwen_vl" | "qwen" => Some(VlmTarget::QwenVl),
            "llava" => Some(VlmTarget::Llava),
            _ => None,
        }
    }

    pub fn all_names() -> &'static str {
        "claude, gpt4v-low, gpt4v-high (또는 gpt4v), gemini, qwen-vl (또는 qwen), llava"
    }
}

impl DocumentCore {
    pub fn get_page_layer_tree_native(&self, page_num: u32) -> Result<String, HwpError> {
        self.get_page_layer_tree_with_profile_native(page_num, RenderProfile::Screen)
    }

    pub fn get_page_layer_tree_with_profile_native(
        &self,
        page_num: u32,
        profile: RenderProfile,
    ) -> Result<String, HwpError> {
        self.get_page_layer_tree_with_options_native(
            page_num,
            profile,
            crate::paint::LayerJsonOptions::default(),
        )
    }

    /// [Task #3315] `options` 로 그림 base64 생략을 켤 수 있는 레이어 트리 JSON.
    ///
    /// 생략본과 종전 JSON 은 **서로 다른 캐시 변형**이다 — 같은 슬롯을 쓰면 한쪽 소비자가
    /// 다른 쪽 모양을 받는다. 그래서 아래 지문에 생략 여부를 함께 접는다.
    pub fn get_page_layer_tree_with_options_native(
        &self,
        page_num: u32,
        profile: RenderProfile,
        options: crate::paint::LayerJsonOptions,
    ) -> Result<String, HwpError> {
        // [Task #2222] 직렬화 JSON 캐시 — 트리 캐시(#2227 with_page_tree_cached)가
        // 있어도 1MB 급 재직렬화가 renderPage 마다 렌더 비용과 맞먹게 반복된다
        // (주보 p2 실측: 15.2ms/회, JSON 1.05MB). 출력옵션 지문이 다르면 미스.
        let idx = page_num as usize;
        let fp = self.layer_output_options_fingerprint(profile, options);
        if let Some(variants) = self.layer_tree_json_cache.borrow().get(idx) {
            if let Some((_, json)) = variants.iter().find(|(f, _)| *f == fp) {
                return Ok(json.clone());
            }
        }
        let json = self
            .build_page_layer_tree_with_profile(page_num, profile)?
            .to_json_with_options(options);
        {
            // 토글(투명선/잘림보기 등) 왕복이 매번 미스가 되지 않도록 페이지당
            // 옵션 변형 4개까지 보관 (초과 시 가장 오래된 변형 제거).
            let mut cache = self.layer_tree_json_cache.borrow_mut();
            if cache.len() <= idx {
                cache.resize_with(idx + 1, Vec::new);
            }
            let variants = &mut cache[idx];
            variants.retain(|(f, _)| *f != fp);
            if variants.len() >= 4 {
                variants.remove(0);
            }
            variants.push((fp, json.clone()));
        }
        Ok(json)
    }

    /// [Task #2222] 레이어 출력옵션 5종과 profile의 비트 지문 — JSON 캐시 키.
    /// [Task #3315/#4969] 그림·font 바이트 생략 여부를 서로 다른 비트에 함께 접는다.
    fn layer_output_options_fingerprint(
        &self,
        profile: RenderProfile,
        options: crate::paint::LayerJsonOptions,
    ) -> u16 {
        let profile_bits: u16 = match profile {
            RenderProfile::FastPreview => 0,
            RenderProfile::Screen => 1,
            RenderProfile::Print => 2,
            RenderProfile::HighQuality => 3,
        };
        u16::from(self.show_paragraph_marks)
            | (u16::from(self.show_control_codes) << 1)
            | (u16::from(self.show_transparent_borders) << 2)
            | (u16::from(self.clip_enabled) << 3)
            | (u16::from(self.debug_overlay) << 4)
            | (profile_bits << 5)
            | (u16::from(options.omit_image_bytes) << 7)
            | (u16::from(options.omit_font_bytes) << 8)
    }

    /// 페이지가 그리는 그림들의 신원 키만 작은 JSON 으로 반환한다 (Task #3315).
    ///
    /// `{"keys":["bin:0:1:src", ...]}` 형태이며, 등장 순서를 보존한다. 소비자는 이 목록을
    /// 서명으로 삼아 "그림이 그대로면 앞서 만든 디코드 결과를 재사용"할 수 있다 — 그러려고
    /// 수 MB 짜리 레이어 트리 JSON 을 다시 받아 정규식으로 훑을 이유가 없다.
    ///
    /// 안정된 신원이 없는 그림(`bin_data_id == 0`)은 목록에서 빠지는 대신 `null` 로 자리를
    /// 남기고 `cacheable:false`를 반환한다. 소비자는 이런 페이지의 prefetch 서명을 저장하지
    /// 않아야 하므로, 키를 만들 수 없는 합성 그림이 바뀌어도 이전 decode를 재사용하지 않는다.
    pub fn get_page_source_image_keys_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        fn collect(node: &RenderNode, epoch: u32, out: &mut Vec<Option<String>>) {
            // LayerBuilder와 같은 pre-order/visibility 계약을 써야 compact API와 JSON의
            // 키 순서가 같다. Screen profile은 editor-only 노드도 표시한다.
            if !node.visible {
                return;
            }
            if let RenderNodeType::Image(image) = &node.node_type {
                if image.data.is_some() {
                    out.push(crate::paint::source_image_key(epoch, image));
                }
            }
            for child in &node.children {
                collect(child, epoch, out);
            }
        }

        let mut keys = Vec::new();
        self.with_page_tree_cached(page_num, |tree| {
            collect(&tree.root, self.bin_data_epoch, &mut keys);
            Ok(())
        })?;

        let cacheable = keys.iter().all(Option::is_some);
        let mut buf = format!("{{\"cacheable\":{cacheable},\"keys\":[");
        for (index, key) in keys.iter().enumerate() {
            if index > 0 {
                buf.push(',');
            }
            match key {
                Some(key) => {
                    buf.push('"');
                    buf.push_str(&crate::document_core::helpers::json_escape(key));
                    buf.push('"');
                }
                None => buf.push_str("null"),
            }
        }
        buf.push_str("]}");
        Ok(buf)
    }

    /// 그림 신원 키로 그 op 이 내보내는 바이트와 mime 을 되돌려준다 (Task #3315).
    ///
    /// `get_page_layer_tree_with_options_native` 가 base64 를 생략했을 때 소비자가 바이트를
    /// 받는 경로다. 반환값은 인라인 base64 가 담고 있던 것과 **같은 바이트여야** 하므로 변환은
    /// JSON 경로와 같은 `emitted_image_bytes` 를 쓴다 — 사본을 두면 두 경로가 갈라진다.
    ///
    /// 키의 epoch 가 현재 문서 세대와 다르면 `None` 이다. 스냅샷 복원처럼 id→바이트 대응이
    /// 깨지는 연산 뒤에 옛 키로 물어본 경우이므로, 낡은 바이트를 주는 대신 소비자가 트리를
    /// 다시 받게 한다.
    ///
    /// 세션에 삽입한 그림은 `load_shared()` 가 같은 할당을 돌려주지만(#3411), 파일에서 읽은
    /// `Loaded` 바이트는 여기서 한 벌 복사된다. 이 조회는 페이지의 그림이 바뀔 때만 불리므로
    /// 키 입력마다 도는 경로가 아니다.
    pub fn get_source_image_bytes_native(&self, key: &str) -> Option<(&'static str, Vec<u8>)> {
        let (epoch, bin_data_id, variant) = crate::paint::parse_source_image_key(key)?;
        if epoch != self.bin_data_epoch {
            return None;
        }
        let content =
            crate::renderer::layout::find_bin_data(&self.document.bin_data_content, bin_data_id)?;
        // [#2550] 상한 초과는 레이아웃이 이미 placeholder 로 그린 항목이라 바이트도 없다.
        let data = content
            .data
            .load_limited_shared(crate::model::bin_data::MAX_BIN_DATA_BYTES)?;
        let (mime, bytes) =
            crate::renderer::image_resolver::emitted_image_bytes(&data, variant.bakes_watermark());
        Some((mime, bytes.into_owned()))
    }

    /// Portable font resource key로 현재 document generation의 exact source bytes를 받는다.
    ///
    /// key의 길이·BLAKE3 digest와 registry owner를 다시 대조한다. 등록되지 않았거나 오래된
    /// key, 비정규 표기, 32 MiB 상한 초과는 모두 `None`으로 닫힌다.
    pub fn get_source_font_bytes_native(&self, key: &str) -> Option<Vec<u8>> {
        self.layout_engine
            .exact_font_source_bytes_for_resource_key(key)
            .map(|bytes| bytes.to_vec())
    }

    /// 본문(flow) 그림의 **배치 정보만** 작은 JSON 으로 반환한다 (Task #3315).
    ///
    /// studio 는 flow 그림을 DOM `<img>` 로 내보내려고 편집마다 전체 레이어 트리 JSON 을
    /// 받아 왔다(`getFlowImagePaintOps`). 그림 1장이 4.77MB 면 그 JSON 이 6.6MB 라, 경계
    /// 복사와 `JSON.parse` 만으로 키 입력당 20 ms 가 나갔다.
    ///
    /// 캐시로는 풀 수 없는 문제다 — 본문이 흐르면 그림 bbox 가 움직이므로 그림이 그대로여도
    /// 결과가 달라진다. 그래서 캐시가 아니라 **질의를 좁힌다**: 바이트를 빼고 bbox·clip·
    /// 효과·신원 키만 준다. 바이트는 `get_source_image_bytes_native(key)` 로 그림이 바뀔 때만
    /// 따로 받는다.
    ///
    /// `clip` 은 조상 `ClipRect` 를 교차해 접은 값이다. 소비자가 트리 없이도 같은 잘림을
    /// 재현할 수 있어야 하므로, 계보를 넘기는 대신 결과만 준다. 조상 clip 이 있으면 그것이
    /// bbox 를 줄이든 아니든 **언제나** 싣는다 — 무엇을 자를지는 소비자의 판정이고, 생산자가
    /// 그 판정을 복제하면 갈라진다. 조상 clip 이 아예 없으면 필드도 없다.
    ///
    /// 그림이 clip 과 전혀 겹치지 않으면 보이지 않으므로 목록에서 빠진다.
    ///
    /// `sourceImageKey` 를 낼 수 없는 그림(`bin_data_id == 0` 합성 그림)이 하나라도 있으면
    /// `cacheable:false` 다 — 소비자는 그 페이지에 한해 종전의 전체 트리 경로로 되돌아가야
    /// 한다. 키가 없으면 바이트를 받을 방법이 없기 때문이다.
    pub fn get_page_flow_image_ops_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::paint::{
            paint_op_replay_plane_with_layer, LayerNode, LayerNodeKind, PaintOp, PaintReplayPlane,
        };
        use crate::renderer::render_tree::{BoundingBox, RenderLayerInfo};

        fn intersect(first: Option<BoundingBox>, second: BoundingBox) -> Option<BoundingBox> {
            let Some(first) = first else {
                return Some(second);
            };
            let left = first.x.max(second.x);
            let top = first.y.max(second.y);
            let right = (first.x + first.width).min(second.x + second.width);
            let bottom = (first.y + first.height).min(second.y + second.height);
            if right <= left || bottom <= top {
                return None;
            }
            Some(BoundingBox {
                x: left,
                y: top,
                width: right - left,
                height: bottom - top,
            })
        }

        fn write_bbox(buf: &mut String, bbox: BoundingBox) {
            let _ = write!(
                buf,
                "{{\"x\":{:.3},\"y\":{:.3},\"width\":{:.3},\"height\":{:.3}}}",
                bbox.x, bbox.y, bbox.width, bbox.height
            );
        }

        struct Collector {
            images: String,
            epoch: u32,
            cacheable: bool,
        }

        impl Collector {
            fn visit(
                &mut self,
                node: &LayerNode,
                inherited_layer: Option<RenderLayerInfo>,
                clip: Option<BoundingBox>,
            ) {
                let active_layer = node.layer.or(inherited_layer);
                match &node.kind {
                    LayerNodeKind::Group { children, .. } => {
                        for child in children {
                            self.visit(child, active_layer, clip);
                        }
                    }
                    LayerNodeKind::ClipRect {
                        child,
                        clip: node_clip,
                        ..
                    } => {
                        // 교차가 비면 이 아래는 전부 보이지 않는다 — 내려가지 않는다.
                        if let Some(next) = intersect(clip, *node_clip) {
                            self.visit(child, active_layer, Some(next));
                        }
                    }
                    LayerNodeKind::Leaf { ops } => {
                        for op in ops {
                            let PaintOp::Image {
                                bbox,
                                image,
                                resolved,
                            } = op
                            else {
                                continue;
                            };
                            if paint_op_replay_plane_with_layer(op, active_layer)
                                != PaintReplayPlane::Flow
                            {
                                continue;
                            }
                            let Some(data) = image.data.as_deref() else {
                                continue;
                            };
                            // 보이는 영역이 없으면 소비자가 그릴 것도 없다. 교차 결과는 가시성
                            // 판정에만 쓰고, 직렬화에는 canonical 한 조상 clip 을 그대로 넘긴다.
                            if intersect(clip, *bbox).is_none() {
                                continue;
                            }
                            let key = crate::paint::source_image_key(self.epoch, image);
                            if key.is_none() {
                                self.cacheable = false;
                            }
                            self.write_image(*bbox, clip, image, resolved.as_deref(), data, key);
                        }
                    }
                }
            }

            fn write_image(
                &mut self,
                bbox: BoundingBox,
                clip: Option<BoundingBox>,
                image: &crate::renderer::render_tree::ImageNode,
                resolved: Option<&crate::paint::ResolvedImagePayload>,
                data: &[u8],
                key: Option<String>,
            ) {
                let buf = &mut self.images;
                if !buf.is_empty() {
                    buf.push(',');
                }
                buf.push_str("{\"bbox\":");
                write_bbox(buf, bbox);
                // 조상 clip 이 있으면 **언제나** 싣는다. 교차한 값을 그대로 주고, 그것으로 무엇을
                // 할지는 소비자가 정한다.
                //
                // 이 자리에 "bbox 를 줄일 때만 싣기" 를 두면 소비자의 판정 조건을 흉내 내는
                // 것이고, 그 흉내는 이미 틀렸다 — 회전 그림은 clip 이 bbox 를 다 덮어도 wrapper
                // 로 모서리를 잘라야 한다(`page-renderer.ts` 의 `rotation !== 0` 분기). 생산자가
                // 소비자 조건을 복제하면 그 조건이 바뀔 때 두 생산자가 조용히 갈라진다.
                if let Some(clip) = clip {
                    buf.push_str(",\"clip\":");
                    write_bbox(buf, clip);
                }
                let mime = crate::renderer::image_resolver::emitted_image_mime(
                    data,
                    resolved,
                    crate::renderer::image_resolver::is_watermark_image(image),
                );
                let _ = write!(buf, ",\"mime\":\"{}\"", mime);
                match key {
                    Some(key) => {
                        let _ = write!(
                            buf,
                            ",\"sourceImageKey\":\"{}\"",
                            crate::document_core::helpers::json_escape(&key)
                        );
                    }
                    None => buf.push_str(",\"sourceImageKey\":null"),
                }
                if let Some((left, top, right, bottom)) = image.crop {
                    let _ = write!(
                        buf,
                        ",\"crop\":{{\"left\":{},\"top\":{},\"right\":{},\"bottom\":{}}}",
                        left, top, right, bottom
                    );
                }
                if let Some((width, height)) = image.original_size_hu {
                    let _ = write!(buf, ",\"originalSizeHu\":[{},{}]", width, height);
                }
                // 효과는 값으로 넘긴다 — CSS filter 조립은 studio 의 `composeImageFilter` 가
                // `web_canvas.rs::compose_image_filter` 와 맞춰 두었으므로 여기서 되풀이하지 않는다.
                let _ = write!(
                    buf,
                    ",\"effect\":\"{}\",\"brightness\":{},\"contrast\":{}",
                    match image.effect {
                        crate::model::image::ImageEffect::RealPic => "realPic",
                        crate::model::image::ImageEffect::GrayScale => "grayScale",
                        crate::model::image::ImageEffect::BlackWhite => "blackWhite",
                        crate::model::image::ImageEffect::Pattern8x8 => "pattern8x8",
                    },
                    image.brightness,
                    image.contrast
                );
                if matches!(
                    resolved.map(|payload| payload.kind),
                    Some(crate::paint::ResolvedImageKind::BakedWatermark)
                ) {
                    buf.push_str(",\"bakedWatermark\":true");
                }
                let _ = write!(
                    buf,
                    ",\"transform\":{{\"rotation\":{:.3},\"horzFlip\":{},\"vertFlip\":{}}}}}",
                    image.transform.rotation, image.transform.horz_flip, image.transform.vert_flip
                );
            }
        }

        let tree = self.build_page_layer_tree(page_num)?;
        let mut collector = Collector {
            images: String::new(),
            epoch: self.bin_data_epoch,
            cacheable: true,
        };
        collector.visit(&tree.root, None, None);

        Ok(format!(
            "{{\"cacheable\":{},\"images\":[{}]}}",
            collector.cacheable, collector.images
        ))
    }

    /// 페이지 overlay 이미지와 replay-plane summary만 작은 JSON으로 반환한다.
    ///
    /// Studio는 BehindText/InFrontOfText 그림 overlay 계산을 위해 전체 PageLayerTree JSON을
    /// 파싱할 필요가 없다. 특히 그림이 본문 layer에만 있는 페이지에서는 빈 overlay 배열과
    /// imageCount/rawSvgCount/flowImageCount/flowRawSvgCount/hasBehind/hasFront만
    /// 반환하여 입력 중 대용량 JSON 직렬화/파싱을 피한다.
    ///
    /// [#5763] `flowStaticOccluded` 는 flow 그림 밑에 불투명 채우기가 깔려 있어 flow-static
    /// 분리가 그림을 지우는 페이지 표시다 — 소비자는 이 값이 참이면 분리하지 않는다.
    pub fn get_page_overlay_images_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::model::image::ImageEffect;
        use crate::model::shape::TextWrap;
        use crate::paint::{
            paint_op_replay_plane_with_layer, FlowStaticOcclusion, LayerNode, LayerNodeKind,
            PaintOp, PaintReplayPlane, ResolvedImageKind, ResolvedImagePayload,
        };
        use crate::renderer::render_tree::RenderLayerInfo;
        use crate::renderer::render_tree::{BoundingBox, ImageNode};

        fn effect_str(value: ImageEffect) -> &'static str {
            match value {
                ImageEffect::RealPic => "realPic",
                ImageEffect::GrayScale => "grayScale",
                ImageEffect::BlackWhite => "blackWhite",
                ImageEffect::Pattern8x8 => "pattern8x8",
            }
        }

        fn wrap_str(value: TextWrap) -> &'static str {
            match value {
                TextWrap::BehindText => "behindText",
                TextWrap::InFrontOfText => "inFrontOfText",
                _ => "flow",
            }
        }

        fn write_json_str(buf: &mut String, value: &str) {
            buf.push('"');
            buf.push_str(&crate::document_core::helpers::json_escape(value));
            buf.push('"');
        }

        fn write_bbox(buf: &mut String, bbox: BoundingBox) {
            let _ = write!(
                buf,
                "{{\"x\":{:.3},\"y\":{:.3},\"width\":{:.3},\"height\":{:.3}}}",
                bbox.x, bbox.y, bbox.width, bbox.height
            );
        }

        fn write_overlay_image(
            buf: &mut String,
            bbox: BoundingBox,
            image: &ImageNode,
            resolved: Option<&ResolvedImagePayload>,
            wrap: TextWrap,
        ) {
            if !buf.is_empty() {
                buf.push(',');
            }

            let mut mime = "application/octet-stream";
            // base64 인코딩은 emit 시점에 버퍼로 직접 흘린다 — 수 MB 중간 String 을
            // 만들지 않는다 (Task #3315).
            let mut image_bytes: Option<std::borrow::Cow<[u8]>> = None;
            let mut baked_watermark = false;
            if let Some(payload) = resolved {
                mime = payload.mime;
                image_bytes = Some(std::borrow::Cow::Borrowed(&payload.data[..]));
                baked_watermark = matches!(payload.kind, ResolvedImageKind::BakedWatermark);
            } else if let Some(data) = &image.data {
                let detected = crate::renderer::svg::detect_image_mime_type(data);
                let (final_mime, final_data): (&str, std::borrow::Cow<[u8]>) =
                    if detected == "image/x-pcx" {
                        match crate::renderer::svg::pcx_bytes_to_png_bytes(data) {
                            Some(png) => ("image/png", std::borrow::Cow::Owned(png)),
                            None => (detected, std::borrow::Cow::Borrowed(&data[..])),
                        }
                    } else if detected == "image/bmp" {
                        match crate::renderer::svg::bmp_bytes_to_png_bytes(data) {
                            Some(png) => ("image/png", std::borrow::Cow::Owned(png)),
                            None => (detected, std::borrow::Cow::Borrowed(&data[..])),
                        }
                    } else if detected == "image/tiff" {
                        match crate::renderer::svg::tiff_bytes_to_png_bytes(data) {
                            Some(png) => ("image/png", std::borrow::Cow::Owned(png)),
                            None => (detected, std::borrow::Cow::Borrowed(&data[..])),
                        }
                    } else if detected == "application/postscript" {
                        match crate::renderer::image_resolver::eps_renderable_bytes(data) {
                            Some((m, bytes)) => (m, std::borrow::Cow::Owned(bytes)),
                            None => (detected, std::borrow::Cow::Borrowed(&data[..])),
                        }
                    } else {
                        (detected, std::borrow::Cow::Borrowed(&data[..]))
                    };
                mime = final_mime;
                image_bytes = Some(final_data);
            }

            buf.push('{');
            buf.push_str("\"bbox\":");
            write_bbox(buf, bbox);
            buf.push_str(",\"mime\":");
            write_json_str(buf, mime);
            buf.push_str(",\"base64\":");
            crate::document_core::helpers::write_json_base64(
                buf,
                image_bytes.as_deref().unwrap_or(&[]),
            );
            buf.push_str(",\"effect\":");
            write_json_str(buf, effect_str(image.effect));
            let _ = write!(
                buf,
                ",\"brightness\":{},\"contrast\":{},\"wrap\":",
                image.brightness, image.contrast
            );
            write_json_str(buf, wrap_str(wrap));
            let opacity = image.opacity.clamp(0.0, 1.0);
            if opacity < 1.0 {
                let _ = write!(buf, ",\"opacity\":{:.6}", opacity);
            }

            if let Some((left, top, right, bottom)) = image.crop {
                let _ = write!(
                    buf,
                    ",\"crop\":{{\"left\":{},\"top\":{},\"right\":{},\"bottom\":{}}}",
                    left, top, right, bottom
                );
            }

            let attr = crate::model::image::ImageAttr {
                brightness: image.brightness,
                contrast: image.contrast,
                effect: image.effect,
                bin_data_id: image.bin_data_id,
                transparency: 0,
                external_path: None,
            };
            if let Some(preset) = attr.watermark_preset() {
                let _ = write!(buf, ",\"watermark\":{{\"preset\":\"{}\"}}", preset);
            }
            if baked_watermark {
                buf.push_str(",\"bakedWatermark\":true");
            }

            let _ = write!(
                buf,
                ",\"transform\":{{\"rotation\":{:.3},\"horzFlip\":{},\"vertFlip\":{}}}}}",
                image.transform.rotation, image.transform.horz_flip, image.transform.vert_flip
            );
        }

        #[allow(clippy::too_many_arguments)]
        fn collect(
            node: &LayerNode,
            behind: &mut String,
            front: &mut String,
            image_count: &mut usize,
            raw_svg_count: &mut usize,
            flow_image_count: &mut usize,
            flow_raw_svg_count: &mut usize,
            has_behind: &mut bool,
            has_front: &mut bool,
            occlusion: &mut FlowStaticOcclusion,
            page_background: &mut Option<(Option<String>, bool)>,
            inherited_layer: Option<RenderLayerInfo>,
        ) {
            let active_layer = node.layer.or(inherited_layer);
            match &node.kind {
                LayerNodeKind::Group { children, .. } => {
                    for child in children {
                        collect(
                            child,
                            behind,
                            front,
                            image_count,
                            raw_svg_count,
                            flow_image_count,
                            flow_raw_svg_count,
                            has_behind,
                            has_front,
                            occlusion,
                            page_background,
                            active_layer,
                        );
                    }
                }
                LayerNodeKind::ClipRect { child, .. } => collect(
                    child,
                    behind,
                    front,
                    image_count,
                    raw_svg_count,
                    flow_image_count,
                    flow_raw_svg_count,
                    has_behind,
                    has_front,
                    occlusion,
                    page_background,
                    active_layer,
                ),
                LayerNodeKind::Leaf { ops } => {
                    for op in ops {
                        let plane = paint_op_replay_plane_with_layer(op, active_layer);
                        match plane {
                            PaintReplayPlane::BehindText => *has_behind = true,
                            PaintReplayPlane::InFrontOfText => *has_front = true,
                            _ => {}
                        }
                        // [#5763] flow-static 분리 가능 여부는 paint 순서에 달렸다 —
                        // 여기서 순서대로 먹인다.
                        occlusion.observe(plane, op);
                        // [#5780] DOM flow 그림 갈래는 canvas 대신 DIV 라 Background
                        // plane 을 실을 자리가 없다 — 쪽 배경을 요약으로 넘겨 소비자가
                        // DIV 배경(단색) 또는 canvas 폴백(그라데이션/이미지)을 고른다.
                        if let PaintOp::PageBackground { background, .. } = op {
                            if page_background.is_none() {
                                let css = background
                                    .background_color
                                    .map(crate::document_core::helpers::color_ref_to_css);
                                let complex =
                                    background.gradient.is_some() || background.image.is_some();
                                *page_background = Some((css, complex));
                            }
                        }
                        match op {
                            PaintOp::Image {
                                bbox,
                                image,
                                resolved,
                            } => {
                                *image_count += 1;
                                match plane {
                                    PaintReplayPlane::BehindText => {
                                        write_overlay_image(
                                            behind,
                                            *bbox,
                                            image,
                                            resolved.as_deref(),
                                            TextWrap::BehindText,
                                        );
                                    }
                                    PaintReplayPlane::InFrontOfText => {
                                        write_overlay_image(
                                            front,
                                            *bbox,
                                            image,
                                            resolved.as_deref(),
                                            TextWrap::InFrontOfText,
                                        );
                                    }
                                    PaintReplayPlane::Flow | PaintReplayPlane::Background => {
                                        *flow_image_count += 1;
                                    }
                                }
                            }
                            // OLE/차트 미리보기 등은 RawSvg 로 emit 되며 web_canvas 의 draw_image
                            // 경로(IMAGE_CACHE 비동기 디코드)를 그대로 탄다. scheduleReRender 재시도
                            // 발화를 위해 별도 rawSvgCount 로 노출한다.
                            PaintOp::RawSvg { .. } => {
                                *raw_svg_count += 1;
                                if plane == PaintReplayPlane::Flow {
                                    *flow_raw_svg_count += 1;
                                }
                            }
                            _ => {}
                        }
                    }
                }
            }
        }

        let tree = self.build_page_layer_tree(page_num)?;
        let mut behind = String::new();
        let mut front = String::new();
        let mut image_count = 0usize;
        let mut raw_svg_count = 0usize;
        let mut flow_image_count = 0usize;
        let mut flow_raw_svg_count = 0usize;
        let mut has_behind = false;
        let mut has_front = false;
        let mut occlusion = FlowStaticOcclusion::default();
        let mut page_background: Option<(Option<String>, bool)> = None;
        collect(
            &tree.root,
            &mut behind,
            &mut front,
            &mut image_count,
            &mut raw_svg_count,
            &mut flow_image_count,
            &mut flow_raw_svg_count,
            &mut has_behind,
            &mut has_front,
            &mut occlusion,
            &mut page_background,
            None,
        );

        // [#5780] 쪽 배경 요약: 단색이면 css 문자열, 그라데이션/이미지 배경이면
        // complex 플래그 — DOM flow 그림 갈래가 배경을 잃지 않게 한다.
        let (page_background_css, page_background_complex) = match &page_background {
            Some((css, complex)) => (css.clone(), *complex),
            None => (None, false),
        };
        let page_background_css_json = match &page_background_css {
            Some(css) => format!("\"{}\"", crate::document_core::helpers::json_escape(css)),
            None => "null".to_string(),
        };

        Ok(format!(
            "{{\"behind\":[{}],\"front\":[{}],\"imageCount\":{},\"rawSvgCount\":{},\"flowImageCount\":{},\"flowRawSvgCount\":{},\"flowStaticOccluded\":{},\"hasBehind\":{},\"hasFront\":{},\"pageBackgroundCss\":{},\"pageBackgroundComplex\":{}}}",
            behind,
            front,
            image_count,
            raw_svg_count,
            flow_image_count,
            flow_raw_svg_count,
            occlusion.occluded(),
            has_behind,
            has_front,
            page_background_css_json,
            page_background_complex
        ))
    }

    /// 페이지 정보 (네이티브 에러 타입)
    pub fn get_page_info_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::model::page::PageBorderBasis;
        use crate::renderer::hwpunit_to_px;
        use crate::renderer::layout::body_page_border_outset;
        let (page_content, _, _) = self.find_page(page_num)?;
        let sec_idx = page_content.section_index;
        let section_def = &self.document.sections[sec_idx].section_def;
        let page_def = &section_def.page_def;
        let page_border_fill = &section_def.page_border_fill;
        let ml = hwpunit_to_px(page_def.margin_left as i32, self.dpi);
        let mr = hwpunit_to_px(page_def.margin_right as i32, self.dpi);
        let mt = hwpunit_to_px(page_def.margin_top as i32, self.dpi);
        let mb = hwpunit_to_px(page_def.margin_bottom as i32, self.dpi);
        let mh = hwpunit_to_px(page_def.margin_header as i32, self.dpi);
        let mf = hwpunit_to_px(page_def.margin_footer as i32, self.dpi);
        // [#4971] 위 여섯은 PageDef 원본 값이다. 실제 본문 상자는 제본 여백이 더해지고
        // 맞쪽 제본의 짝수 쪽에서는 좌우가 뒤바뀌므로(model/page.rs), 그리기·히트테스트가
        // 쓸 값은 해석된 결과여야 한다. 규칙이 사는 곳은 PageAreas 하나뿐이므로 여기서
        // 다시 유도하지 않고 그대로 물어본다.
        let areas = PageAreas::from_page_def_for_page(page_def, page_content.page_number);
        let body_left = hwpunit_to_px(areas.body_area.left, self.dpi);
        let body_right = hwpunit_to_px(areas.body_area.right, self.dpi);
        let header_x = hwpunit_to_px(areas.header_area.left, self.dpi);
        let header_y = hwpunit_to_px(areas.header_area.top, self.dpi);
        let header_width = hwpunit_to_px(areas.header_area.width(), self.dpi);
        let header_height = hwpunit_to_px(areas.header_area.height(), self.dpi);
        let footer_x = hwpunit_to_px(areas.footer_area.left, self.dpi);
        let footer_y = hwpunit_to_px(areas.footer_area.top, self.dpi);
        let footer_width = hwpunit_to_px(areas.footer_area.width(), self.dpi);
        let footer_height = hwpunit_to_px(areas.footer_area.height(), self.dpi);
        // 본문 경계를 다시 PageDef 필드로 되돌리려면(눈금자 핀 드래그) 두 가지가 더 필요하다:
        // 제본 여백은 왼쪽 경계에만 더해지고, 맞쪽 제본의 짝수 쪽은 좌우가 뒤바뀐다.
        let gutter = hwpunit_to_px(page_def.margin_gutter as i32, self.dpi);
        let binding_mirrored = page_def.binding == crate::model::page::BindingMethod::DuplexSided
            && page_content.page_number != 0
            && page_content.page_number.is_multiple_of(2);
        let pbf_left = hwpunit_to_px(page_border_fill.spacing_left as i32, self.dpi);
        let pbf_right = hwpunit_to_px(page_border_fill.spacing_right as i32, self.dpi);
        let pbf_top = hwpunit_to_px(page_border_fill.spacing_top as i32, self.dpi);
        let pbf_bottom = hwpunit_to_px(page_border_fill.spacing_bottom as i32, self.dpi);
        let body_top = mt + mh;
        let body_bottom_margin = mb + mf;
        let visual_outsets = if matches!(page_border_fill.basis, PageBorderBasis::BodyBased)
            && page_border_fill.border_fill_id > 0
        {
            self.document
                .doc_info
                .border_fills
                .get((page_border_fill.border_fill_id - 1) as usize)
                .map(|bf| {
                    (
                        body_page_border_outset(&bf.borders[0]),
                        body_page_border_outset(&bf.borders[1]),
                        body_page_border_outset(&bf.borders[2]),
                        body_page_border_outset(&bf.borders[3]),
                    )
                })
                .unwrap_or((0.0, 0.0, 0.0, 0.0))
        } else {
            (0.0, 0.0, 0.0, 0.0)
        };
        let (out_l, out_r, out_t, _out_b) = visual_outsets;
        let (page_border_left, page_border_right, page_border_top, page_border_bottom) =
            match page_border_fill.basis {
                PageBorderBasis::PaperBased => (pbf_left, pbf_right, pbf_top, pbf_bottom),
                PageBorderBasis::BodyBased => (
                    (ml - pbf_left - out_l).max(0.0),
                    (mr - pbf_right - out_r).max(0.0),
                    (body_top - pbf_top - out_t).max(0.0),
                    (body_bottom_margin - pbf_bottom).max(0.0),
                ),
            };
        // 단별 영역 정보
        let cols_json: String = page_content
            .layout
            .column_areas
            .iter()
            .map(|ca| format!("{{\"x\":{:.1},\"width\":{:.1}}}", ca.x, ca.width))
            .collect::<Vec<_>>()
            .join(",");
        Ok(format!(
            "{{\"pageIndex\":{},\"pageNumber\":{},\"width\":{:.1},\"height\":{:.1},\"sectionIndex\":{},\
            \"marginLeft\":{:.1},\"marginRight\":{:.1},\"marginTop\":{:.1},\"marginBottom\":{:.1},\
            \"marginHeader\":{:.1},\"marginFooter\":{:.1},\
            \"headerArea\":{{\"x\":{:.1},\"y\":{:.1},\"width\":{:.1},\"height\":{:.1}}},\
            \"footerArea\":{{\"x\":{:.1},\"y\":{:.1},\"width\":{:.1},\"height\":{:.1}}},\
            \"bodyLeft\":{:.1},\"bodyRight\":{:.1},\"marginGutter\":{:.1},\
            \"bindingMirrored\":{},\
            \"pageBorderLeft\":{:.1},\"pageBorderRight\":{:.1},\"pageBorderTop\":{:.1},\"pageBorderBottom\":{:.1},\
            \"columns\":[{}]}}",
            page_content.page_index,
            // 문서가 매기는 쪽번호 — `쪽 > 새 번호로 시작`(NewNumber)을 반영한 값이다.
            // 물리 순번(pageIndex + 1)과 다를 수 있고, 상태 표시줄·인쇄물이 보여야 할 숫자는 이쪽이다.
            page_content.page_number,
            page_content.layout.page_width,
            page_content.layout.page_height,
            page_content.section_index,
            ml,
            mr,
            mt,
            mb,
            mh,
            mf,
            header_x,
            header_y,
            header_width,
            header_height,
            footer_x,
            footer_y,
            footer_width,
            footer_height,
            body_left,
            body_right,
            gutter,
            binding_mirrored,
            page_border_left,
            page_border_right,
            page_border_top,
            page_border_bottom,
            cols_json,
        ))
    }

    /// 구역 정의(SectionDef)를 JSON으로 반환 (네이티브 에러 타입)
    pub fn get_section_def_native(&self, section_idx: usize) -> Result<String, HwpError> {
        let section = self
            .document
            .sections
            .get(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        let sd = &section.section_def;
        Ok(format!(
            "{{\"pageNum\":{},\"pageNumType\":{},\"pictureNum\":{},\"tableNum\":{},\"equationNum\":{},\
            \"columnSpacing\":{},\"defaultTabSpacing\":{},\
            \"hideHeader\":{},\"hideFooter\":{},\"hideMasterPage\":{},\
            \"hideBorder\":{},\"hideFill\":{},\"hideEmptyLine\":{}}}",
            sd.page_num, sd.page_num_type,
            sd.picture_num, sd.table_num, sd.equation_num,
            sd.column_spacing, sd.default_tab_spacing,
            sd.hide_header, sd.hide_footer, sd.hide_master_page,
            sd.hide_border, sd.hide_fill, sd.hide_empty_line,
        ))
    }

    /// 단일 구역의 SectionDef 필드를 JSON에서 업데이트 (재조판 없이)
    fn apply_section_def_json(&mut self, section_idx: usize, json: &str) -> Result<(), HwpError> {
        use super::super::helpers::{json_bool, json_u16, json_u32};

        let section = self
            .document
            .sections
            .get_mut(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        let sd = &mut section.section_def;

        if let Some(v) = json_u16(json, "pageNum") {
            sd.page_num = v;
        }
        if let Some(v) = json_u16(json, "pageNumType") {
            sd.page_num_type = v as u8;
        }
        if let Some(v) = json_u16(json, "pictureNum") {
            sd.picture_num = v;
        }
        if let Some(v) = json_u16(json, "tableNum") {
            sd.table_num = v;
        }
        if let Some(v) = json_u16(json, "equationNum") {
            sd.equation_num = v;
        }
        if let Some(v) = json_u16(json, "columnSpacing") {
            sd.column_spacing = v as i16;
        }
        if let Some(v) = json_u32(json, "defaultTabSpacing") {
            sd.default_tab_spacing = v;
        }
        if let Some(v) = json_bool(json, "hideHeader") {
            sd.hide_header = v;
        }
        if let Some(v) = json_bool(json, "hideFooter") {
            sd.hide_footer = v;
        }
        if let Some(v) = json_bool(json, "hideMasterPage") {
            sd.hide_master_page = v;
        }
        if let Some(v) = json_bool(json, "hideBorder") {
            sd.hide_border = v;
        }
        if let Some(v) = json_bool(json, "hideFill") {
            sd.hide_fill = v;
        }
        if let Some(v) = json_bool(json, "hideEmptyLine") {
            sd.hide_empty_line = v;
        }

        // flags 비트플래그 재구성 (파서와 동일한 비트 위치)
        let flags = &mut sd.flags;
        fn set_bit(flags: &mut u32, mask: u32, val: bool) {
            if val {
                *flags |= mask;
            } else {
                *flags &= !mask;
            }
        }
        set_bit(flags, 0x0001, sd.hide_header); // bit 0
        set_bit(flags, 0x0002, sd.hide_footer); // bit 1
        set_bit(flags, 0x0004, sd.hide_master_page); // bit 2 (HWP5 스펙, 첫쪽 바탕쪽 감춤)
        set_bit(flags, 0x0008, sd.hide_border); // bit 3
        set_bit(flags, 0x0010, sd.hide_fill); // bit 4
        set_bit(flags, 0x00080000, sd.hide_empty_line); // bit 19
                                                        // bit 20-21: 쪽 번호 종류
        *flags &= !0x00300000; // clear bits 20-21
        *flags |= ((sd.page_num_type as u32) & 0x03) << 20;

        // paragraphs[0]의 Control::SectionDef에도 동기화
        let updated_sd = section.section_def.clone();
        if let Some(para) = section.paragraphs.get_mut(0) {
            for ctrl in &mut para.controls {
                if let Control::SectionDef(ref mut s) = ctrl {
                    s.page_num = updated_sd.page_num;
                    s.page_num_type = updated_sd.page_num_type;
                    s.picture_num = updated_sd.picture_num;
                    s.table_num = updated_sd.table_num;
                    s.equation_num = updated_sd.equation_num;
                    s.column_spacing = updated_sd.column_spacing;
                    s.default_tab_spacing = updated_sd.default_tab_spacing;
                    s.hide_header = updated_sd.hide_header;
                    s.hide_footer = updated_sd.hide_footer;
                    s.hide_master_page = updated_sd.hide_master_page;
                    s.hide_border = updated_sd.hide_border;
                    s.hide_fill = updated_sd.hide_fill;
                    s.hide_empty_line = updated_sd.hide_empty_line;
                    s.flags = updated_sd.flags;
                    break;
                }
            }
        }

        // raw_stream 무효화
        section.raw_stream = None;
        Ok(())
    }

    /// 재조판 + 재페이지네이션 수행
    fn recompose_and_paginate(&mut self) -> u32 {
        self.rebuild_embedded_exact_font_sources();
        self.recompose_all_with_horizontal_shaping();
        self.mark_all_sections_dirty();
        self.paginate();
        self.page_count()
    }

    /// 구역 정의(SectionDef)를 변경하고 재페이지네이션 (네이티브 에러 타입)
    pub fn set_section_def_native(
        &mut self,
        section_idx: usize,
        json: &str,
    ) -> Result<String, HwpError> {
        self.apply_section_def_json(section_idx, json)?;
        let page_count = self.recompose_and_paginate();
        Ok(format!("{{\"ok\":true,\"pageCount\":{}}}", page_count))
    }

    /// 모든 구역의 SectionDef를 일괄 변경하고 재페이지네이션 (네이티브 에러 타입)
    pub fn set_section_def_all_native(&mut self, json: &str) -> Result<String, HwpError> {
        let count = self.document.sections.len();
        for idx in 0..count {
            self.apply_section_def_json(idx, json)?;
        }
        let page_count = self.recompose_and_paginate();
        Ok(format!("{{\"ok\":true,\"pageCount\":{}}}", page_count))
    }

    /// 구역의 쪽 테두리/배경 설정을 JSON으로 반환한다.
    pub fn get_page_border_fill_native(&self, section_idx: usize) -> Result<String, HwpError> {
        use crate::document_core::helpers::{border_line_type_to_u8_val, color_ref_to_css};
        use crate::model::page::PageBorderUiBasis;
        use crate::model::style::FillType;

        let section = self
            .document
            .sections
            .get(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        let pbf = &section.section_def.page_border_fill;
        let basis = match pbf.ui_basis {
            PageBorderUiBasis::Paper => "paper",
            PageBorderUiBasis::Page => "page",
        };
        let fill_area = match (pbf.attr >> 3) & 0x03 {
            1 => "page",
            2 => "border",
            _ => "paper",
        };
        let mut border_json = concat!(
            "\"borderLeft\":{\"type\":0,\"width\":0,\"color\":\"#000000\"},",
            "\"borderRight\":{\"type\":0,\"width\":0,\"color\":\"#000000\"},",
            "\"borderTop\":{\"type\":0,\"width\":0,\"color\":\"#000000\"},",
            "\"borderBottom\":{\"type\":0,\"width\":0,\"color\":\"#000000\"},",
            "\"fillType\":\"none\",\"fillColor\":\"#ffffff\",\"patternColor\":\"#000000\",\"patternType\":0"
        )
        .to_string();

        if pbf.border_fill_id > 0 {
            if let Some(bf) = self
                .document
                .doc_info
                .border_fills
                .get((pbf.border_fill_id - 1) as usize)
            {
                let dir_names = ["Left", "Right", "Top", "Bottom"];
                let borders = bf
                    .borders
                    .iter()
                    .enumerate()
                    .map(|(idx, border)| {
                        format!(
                            "\"border{}\":{{\"type\":{},\"width\":{},\"color\":\"{}\"}}",
                            dir_names[idx],
                            border_line_type_to_u8_val(border.line_type),
                            border.width,
                            color_ref_to_css(border.color)
                        )
                    })
                    .collect::<Vec<_>>()
                    .join(",");
                let (fill_type, fill_color, pattern_color, pattern_type) =
                    match (&bf.fill.fill_type, &bf.fill.solid) {
                        (FillType::Solid, Some(solid)) => (
                            "solid",
                            color_ref_to_css(solid.background_color),
                            color_ref_to_css(solid.pattern_color),
                            solid.pattern_type,
                        ),
                        _ => ("none", "#ffffff".to_string(), "#000000".to_string(), 0),
                    };
                border_json = format!(
                    "{},\"fillType\":\"{}\",\"fillColor\":\"{}\",\"patternColor\":\"{}\",\"patternType\":{}",
                    borders, fill_type, fill_color, pattern_color, pattern_type
                );
            }
        }

        Ok(format!(
            "{{\"attr\":{},\"basis\":\"{}\",\"spacingLeft\":{},\"spacingRight\":{},\"spacingTop\":{},\"spacingBottom\":{},\
            \"borderFillId\":{},\"headerInside\":{},\"footerInside\":{},\"fillArea\":\"{}\",\
            \"hideBorder\":{},\"hideFill\":{},{} }}",
            pbf.attr,
            basis,
            pbf.spacing_left,
            pbf.spacing_right,
            pbf.spacing_top,
            pbf.spacing_bottom,
            pbf.border_fill_id,
            (pbf.attr & 0x02) != 0,
            (pbf.attr & 0x04) != 0,
            fill_area,
            section.section_def.hide_border,
            section.section_def.hide_fill,
            border_json,
        ))
    }

    /// 구역의 쪽 테두리/배경 설정을 JSON에서 업데이트하고 재조판한다.
    pub fn set_page_border_fill_native(
        &mut self,
        section_idx: usize,
        json: &str,
    ) -> Result<String, HwpError> {
        use crate::document_core::helpers::{json_bool, json_i16, json_str, json_u32};
        use crate::model::page::{PageBorderBasis, PageBorderUiBasis};

        let border_fill_id = self.create_border_fill_from_json(json);
        let section = self
            .document
            .sections
            .get_mut(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        let sd = &mut section.section_def;
        let pbf = &mut sd.page_border_fill;

        if let Some(v) = json_i16(json, "spacingLeft") {
            pbf.spacing_left = v;
        }
        if let Some(v) = json_i16(json, "spacingRight") {
            pbf.spacing_right = v;
        }
        if let Some(v) = json_i16(json, "spacingTop") {
            pbf.spacing_top = v;
        }
        if let Some(v) = json_i16(json, "spacingBottom") {
            pbf.spacing_bottom = v;
        }

        let mut attr = pbf.attr;
        if let Some(basis) = json_str(json, "basis") {
            if basis == "paper" {
                pbf.ui_basis = PageBorderUiBasis::Paper;
                pbf.basis = PageBorderBasis::PaperBased;
                attr &= !0x01;
            } else {
                pbf.ui_basis = PageBorderUiBasis::Page;
                pbf.basis = PageBorderBasis::BodyBased;
                attr |= 0x01;
            }
        }
        if let Some(v) = json_bool(json, "headerInside") {
            if v {
                attr |= 0x02;
            } else {
                attr &= !0x02;
            }
        }
        if let Some(v) = json_bool(json, "footerInside") {
            if v {
                attr |= 0x04;
            } else {
                attr &= !0x04;
            }
        }
        if let Some(area) = json_str(json, "fillArea") {
            attr &= !(0x03 << 3);
            attr |= match area.as_str() {
                "page" => 0x01 << 3,
                "border" => 0x02 << 3,
                _ => 0,
            };
        }
        pbf.attr = attr;
        pbf.border_fill_id = border_fill_id;

        let apply_page = json_str(json, "applyPage").unwrap_or_else(|| "all".to_string());
        let hide_first = apply_page == "exceptFirst";
        if let Some(v) = json_bool(json, "hideBorder") {
            sd.hide_border = v;
        } else {
            sd.hide_border = hide_first;
        }
        if let Some(v) = json_bool(json, "hideFill") {
            sd.hide_fill = v;
        } else {
            sd.hide_fill = hide_first;
        }

        let flags = &mut sd.flags;
        if pbf.ui_basis == PageBorderUiBasis::Page {
            pbf.attr |= 0x01;
        } else {
            pbf.attr &= !0x01;
        }
        if sd.hide_border {
            *flags |= 0x0008;
        } else {
            *flags &= !0x0008;
        }
        if sd.hide_fill {
            *flags |= 0x0010;
        } else {
            *flags &= !0x0010;
        }
        if let Some(raw) = json_u32(json, "attr") {
            pbf.attr = (pbf.attr & 0x0000_001f) | (raw & !0x0000_001f);
        }

        let updated_sd = sd.clone();
        if let Some(para) = section.paragraphs.get_mut(0) {
            for ctrl in &mut para.controls {
                if let Control::SectionDef(ref mut ctrl_sd) = ctrl {
                    ctrl_sd.page_border_fill = updated_sd.page_border_fill.clone();
                    ctrl_sd.hide_border = updated_sd.hide_border;
                    ctrl_sd.hide_fill = updated_sd.hide_fill;
                    ctrl_sd.flags = updated_sd.flags;
                    break;
                }
            }
        }

        section.raw_stream = None;
        let page_count = self.recompose_and_paginate();
        Ok(format!("{{\"ok\":true,\"pageCount\":{}}}", page_count))
    }

    /// 구역의 용지 설정(PageDef)을 HWPUNIT 원본값으로 반환 (네이티브 에러 타입)
    pub fn get_page_def_native(&self, section_idx: usize) -> Result<String, HwpError> {
        let section = self
            .document
            .sections
            .get(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        let pd = &section.section_def.page_def;
        let binding: u8 = match pd.binding {
            crate::model::page::BindingMethod::SingleSided => 0,
            crate::model::page::BindingMethod::DuplexSided => 1,
            crate::model::page::BindingMethod::TopFlip => 2,
        };
        Ok(format!(
            "{{\"width\":{},\"height\":{},\
            \"marginLeft\":{},\"marginRight\":{},\"marginTop\":{},\"marginBottom\":{},\
            \"marginHeader\":{},\"marginFooter\":{},\"marginGutter\":{},\
            \"landscape\":{},\"binding\":{}}}",
            pd.width,
            pd.height,
            pd.margin_left,
            pd.margin_right,
            pd.margin_top,
            pd.margin_bottom,
            pd.margin_header,
            pd.margin_footer,
            pd.margin_gutter,
            pd.landscape,
            binding,
        ))
    }

    /// 구역의 용지 설정(PageDef)을 변경하고 재페이지네이션 (네이티브 에러 타입)
    pub fn set_page_def_native(
        &mut self,
        section_idx: usize,
        json: &str,
    ) -> Result<String, HwpError> {
        use crate::model::page::BindingMethod;

        if section_idx >= self.document.sections.len() {
            return Err(HwpError::RenderError(format!(
                "구역 {} 범위 초과",
                section_idx
            )));
        }
        // 저장 line_segs 가 계산된 전제는 "본문이 접히는 폭"이다. 바뀌었는지는 아래에서
        // 같은 함수로 다시 재어 비교한다 — 필드를 손으로 나열하면 용지 높이처럼 줄바꿈과
        // 무관한 필드가 섞여 쓸데없이 전 구역을 다시 접고, 제본 여백·가로세로 뒤바꿈 규칙이
        // 두 벌이 된다.
        let wrap_width_before = self.body_wrap_width(section_idx);
        let section = &mut self.document.sections[section_idx];
        let pd = &mut section.section_def.page_def;

        use super::super::helpers::{json_bool, json_u32};

        if let Some(v) = json_u32(json, "width") {
            pd.width = v;
        }
        if let Some(v) = json_u32(json, "height") {
            pd.height = v;
        }
        if let Some(v) = json_u32(json, "marginLeft") {
            pd.margin_left = v;
        }
        if let Some(v) = json_u32(json, "marginRight") {
            pd.margin_right = v;
        }
        if let Some(v) = json_u32(json, "marginTop") {
            pd.margin_top = v;
        }
        if let Some(v) = json_u32(json, "marginBottom") {
            pd.margin_bottom = v;
        }
        if let Some(v) = json_u32(json, "marginHeader") {
            pd.margin_header = v;
        }
        if let Some(v) = json_u32(json, "marginFooter") {
            pd.margin_footer = v;
        }
        if let Some(v) = json_u32(json, "marginGutter") {
            pd.margin_gutter = v;
        }
        if let Some(v) = json_bool(json, "landscape") {
            pd.landscape = v;
        }
        if let Some(v) = json_u32(json, "binding") {
            pd.binding = match v {
                1 => BindingMethod::DuplexSided,
                2 => BindingMethod::TopFlip,
                _ => BindingMethod::SingleSided,
            };
        }

        // FIX 1: attr 비트플래그 재구성 (bit 0 = landscape, bit 1-2 = binding)
        pd.attr = (pd.attr & !0x07)
            | (if pd.landscape { 1 } else { 0 })
            | (match pd.binding {
                BindingMethod::SingleSided => 0u32,
                BindingMethod::DuplexSided => 1u32 << 1,
                BindingMethod::TopFlip => 2u32 << 1,
            });

        // FIX 2: paragraphs[0]의 Control::SectionDef에도 page_def 동기화
        let updated_page_def = section.section_def.page_def.clone();
        if let Some(para) = section.paragraphs.get_mut(0) {
            for ctrl in &mut para.controls {
                if let Control::SectionDef(ref mut sd) = ctrl {
                    sd.page_def = updated_page_def;
                    break;
                }
            }
        }

        // FIX 3: raw_stream 무효화 → 직렬화 시 모델에서 재구성
        section.raw_stream = None;

        // [#4956] 본문 가로 상자가 바뀌었으면 이 구역 본문을 새 폭으로 다시 접는다.
        //
        // 저장 분할은 파일이 기록해 둔 "이 용지 폭에서의 줄 나눔"이다. 본문 폭이 바뀌면 그
        // 전제가 깨지는데, 본문 재래핑 게이트(`paragraph_layout`/`typeset`/`height_measurer`
        // 의 `para.line_segs.is_empty()`)는 저장 분할이 있으면 무조건 신뢰한다 — 그래서 여백만
        // 바꾸면 줄은 그대로 두고 글자만 눌러 짜여 본문 밖으로 넘쳤다(실측: 본문 폭 657.7→438.6
        // 인데 3쪽 텍스트가 x 709.6 까지, run 수 109 불변).
        //
        // 비우기만 하고 재계산을 조판에 맡기지 않는다. 저장 분할이 없는 문단은 NO_LS 계급이
        // 되고, 그 계급은 쪽 나눔에서 문단 위 간격을 0 으로 세는데(typeset.rs) 렌더는 그대로
        // 그려, 여백을 조금만 건드려도 쪽 나눔과 그리기가 문단마다 spacing_before 만큼
        // 어긋난다. reflow_body_paragraphs_in_section 은 비우고 곧바로 다시 접어 그 계급에
        // 머무르지 않게 한다.
        //
        // 범위는 이 구역의 본문 문단뿐이다 — 표 셀 폭은 용지 여백이 아니라 표 자신이 정하므로
        // 셀 문단의 저장 분할은 여전히 유효하다.
        if self.body_wrap_width(section_idx) != wrap_width_before {
            self.reflow_body_paragraphs_in_section(section_idx);
        }

        // 재조판 + 재페이지네이션
        self.recompose_all_with_horizontal_shaping();
        self.mark_all_sections_dirty();
        self.paginate();

        let page_count = self.page_count();
        Ok(format!("{{\"ok\":true,\"pageCount\":{}}}", page_count))
    }

    /// 텍스트 레이아웃 정보 (네이티브 에러 타입)
    pub fn get_page_text_layout_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree(page_num)?;

        // 렌더 트리에서 TextRun 노드를 재귀적으로 수집
        fn collect_text_runs(node: &RenderNode, runs: &mut Vec<String>) {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                let positions = text_run.replay_positions_for(&text_run.text);
                let char_x: Vec<String> = positions.iter().map(|v| format!("{:.1}", v)).collect();

                let escaped_text = super::super::helpers::json_escape(&text_run.text);

                // 문서 좌표 (편집용)
                let doc_coords = match (
                    text_run.section_index,
                    text_run.para_index,
                    text_run.char_start,
                ) {
                    (Some(si), Some(pi), Some(cs)) => {
                        format!(",\"secIdx\":{},\"paraIdx\":{},\"charStart\":{}", si, pi, cs)
                    }
                    _ => String::new(),
                };

                // 표 셀 식별 정보 (편집용)
                let cell_coords = if let Some(ref ctx) = text_run.cell_context {
                    let outer = &ctx.path[0];
                    let path_entries: Vec<String> = ctx
                        .path
                        .iter()
                        .map(|e| {
                            format!(
                                "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                                e.control_index, e.cell_index, e.cell_para_index
                            )
                        })
                        .collect();
                    format!(",\"parentParaIdx\":{},\"controlIdx\":{},\"cellIdx\":{},\"cellParaIdx\":{},\"cellPath\":[{}]",
                        ctx.parent_para_index, outer.control_index, outer.cell_index, outer.cell_para_index,
                        path_entries.join(","))
                } else {
                    String::new()
                };

                let escaped_font = super::super::helpers::json_escape(&text_run.style.font_family);
                let font_info = format!(
                    ",\"fontFamily\":\"{}\",\"fontSize\":{:.1},\"bold\":{},\"italic\":{},\"ratio\":{:.2},\"letterSpacing\":{:.1}",
                    escaped_font,
                    text_run.style.font_size,
                    text_run.style.bold,
                    text_run.style.italic,
                    text_run.style.ratio,
                    text_run.style.letter_spacing,
                );

                // 서식 툴바용 추가 속성
                let format_info = format!(
                    ",\"underline\":{},\"strikethrough\":{},\"textColor\":\"{}\"",
                    !matches!(
                        text_run.style.underline,
                        crate::model::style::UnderlineType::None
                    ),
                    text_run.style.strikethrough,
                    color_ref_to_css(text_run.style.color),
                );

                // 글자/문단 모양 ID (서식 툴바용)
                let shape_ids = match (text_run.char_shape_id, text_run.para_shape_id) {
                    (Some(csid), Some(psid)) => {
                        format!(",\"charShapeId\":{},\"paraShapeId\":{}", csid, psid)
                    }
                    (Some(csid), None) => format!(",\"charShapeId\":{}", csid),
                    (None, Some(psid)) => format!(",\"paraShapeId\":{}", psid),
                    _ => String::new(),
                };

                runs.push(format!(
                    "{{\"text\":\"{}\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"charX\":[{}]{}{}{}{}{}}}",
                    escaped_text,
                    node.bbox.x,
                    node.bbox.y,
                    node.bbox.width,
                    node.bbox.height,
                    char_x.join(","),
                    font_info,
                    format_info,
                    shape_ids,
                    doc_coords,
                    cell_coords,
                ));
            }
            for child in &node.children {
                collect_text_runs(child, runs);
            }
        }

        let mut runs = Vec::new();
        collect_text_runs(&tree.root, &mut runs);

        Ok(format!("{{\"runs\":[{}]}}", runs.join(",")))
    }

    /// [#4694] 셀/글상자 안 ole 노드의 컨테이너 문맥 방출 — Image 방출(#1151/#1161)과
    /// 동형. 이것이 비면 studio 선택 ref 가 본문 직속과 구분 불가한 3좌표로 떨어져,
    /// 같은 문단에 앵커된 다른 차트를 조용히 여는 오매칭이 성립한다. 단일 레벨 스칼라
    /// (`cellIdx`/`cellParaIdx`/`outerTableControlIdx`)는 studio 의 by_path 폴백 조립과의
    /// 하위호환, `cellPath` 가 정본이다. 본문 직속(None)은 빈 문자열 — 기존 JSON 그대로.
    fn ole_layout_context_json(ctx: Option<&crate::renderer::layout::CellContext>) -> String {
        let Some(ctx) = ctx else {
            return String::new();
        };
        let mut out = String::new();
        if let [entry] = ctx.path.as_slice() {
            out.push_str(&format!(
                ",\"cellIdx\":{},\"cellParaIdx\":{},\"outerTableControlIdx\":{}",
                entry.cell_index, entry.cell_para_index, entry.control_index
            ));
        }
        let entries: Vec<String> = ctx
            .path
            .iter()
            .map(|e| {
                format!(
                    "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                    e.control_index, e.cell_index, e.cell_para_index
                )
            })
            .collect();
        out.push_str(&format!(
            ",\"parentParaIdx\":{},\"cellPath\":[{}]",
            ctx.parent_para_index,
            entries.join(",")
        ));
        out
    }

    /// 컨트롤(표, 이미지 등) 레이아웃 정보 (네이티브 에러 타입)
    pub fn get_page_control_layout_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree_cached(page_num)?;

        // 렌더 트리에서 Table, Image 노드를 재귀적으로 수집
        fn collect_controls(node: &RenderNode, controls: &mut Vec<String>) {
            // [Task #1280 v2] 컨트롤별 plane/zOrder/stableIndex 노출 — 렌더 정렬키
            // `paper_node_sort_key`(layout.rs)를 그대로 재사용해 프런트 히트테스트가
            // 겹침 시 "최상단 개체"를 선택할 수 있게 한다.
            // [#4334] stableIndex 는 더 이상 스칼라가 아니다 — next_id() 카운터/패킹된
            // u32 대신 문서 경로(정수 배열, `DocPath`)를 그대로 JSON 배열로 내보낸다.
            // TS `controlTopKey`/`isAboveControl`(input-handler-picture.ts)가 사전식
            // 배열 비교로 이미 갱신되어 있다.
            let (plane, z_order, doc_path) =
                crate::renderer::layout::LayoutEngine::paper_node_sort_key(node);
            let stable_index = format!(
                "[{}]",
                doc_path
                    .iter()
                    .map(u32::to_string)
                    .collect::<Vec<_>>()
                    .join(",")
            );
            // wrap 은 이미지뿐 아니라 shape/line/group/path 에도 노출(히트테스트 plane/wrap 일관성).
            // 이미지는 자체 wrap_str(image_node.text_wrap)을 방출하므로 중복 방지로 제외한다.
            let wrap_extra = if matches!(node.node_type, RenderNodeType::Image(_)) {
                ""
            } else {
                match node.layer.and_then(|l| l.text_wrap) {
                    Some(crate::model::shape::TextWrap::BehindText) => ",\"wrap\":\"behindText\"",
                    Some(crate::model::shape::TextWrap::InFrontOfText) => {
                        ",\"wrap\":\"inFrontOfText\""
                    }
                    Some(crate::model::shape::TextWrap::Square) => ",\"wrap\":\"square\"",
                    Some(crate::model::shape::TextWrap::Tight) => ",\"wrap\":\"tight\"",
                    Some(crate::model::shape::TextWrap::Through) => ",\"wrap\":\"through\"",
                    Some(crate::model::shape::TextWrap::TopAndBottom) => {
                        ",\"wrap\":\"topAndBottom\""
                    }
                    None => "",
                }
            };
            let layer_str = format!(
                ",\"plane\":{},\"zOrder\":{},\"stableIndex\":{}{}",
                plane, z_order, stable_index, wrap_extra
            );
            match &node.node_type {
                RenderNodeType::Table(table_node) => {
                    // 문서 좌표
                    let doc_coords = match (
                        table_node.section_index,
                        table_node.para_index,
                        table_node.control_index,
                    ) {
                        (Some(si), Some(pi), Some(ci)) => {
                            format!(
                                ",\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}",
                                si, pi, ci
                            )
                        }
                        _ => String::new(),
                    };

                    // 셀 정보 수집
                    let mut cells = Vec::new();
                    for (cell_idx, child) in node.children.iter().enumerate() {
                        if let RenderNodeType::TableCell(cell_node) = &child.node_type {
                            cells.push(format!(
                                "{{\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"row\":{},\"col\":{},\"rowSpan\":{},\"colSpan\":{},\"cellIdx\":{}}}",
                                child.bbox.x, child.bbox.y, child.bbox.width, child.bbox.height,
                                cell_node.row, cell_node.col, cell_node.row_span, cell_node.col_span,
                                cell_idx
                            ));
                        }
                    }

                    controls.push(format!(
                        "{{\"type\":\"table\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"rowCount\":{},\"colCount\":{}{}{},\"cells\":[{}]}}",
                        node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                        table_node.row_count, table_node.col_count,
                        doc_coords, layer_str,
                        cells.join(",")
                    ));
                    // Table 내부도 탐색 (셀 내 수식 등 수집)
                }
                RenderNodeType::Equation(eq_node) => {
                    let doc_coords = match (
                        eq_node.section_index,
                        eq_node.para_index,
                        eq_node.control_index,
                    ) {
                        (Some(si), Some(pi), Some(ci)) => {
                            format!(
                                ",\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}",
                                si, pi, ci
                            )
                        }
                        _ => String::new(),
                    };
                    let cell_coords = match (eq_node.cell_index, eq_node.cell_para_index) {
                        (Some(ci), Some(cpi)) => {
                            format!(",\"cellIdx\":{},\"cellParaIdx\":{}", ci, cpi)
                        }
                        _ => String::new(),
                    };
                    let note_ref = eq_node.note_ref.as_ref().map_or_else(String::new, |r| {
                        format!(
                            ",\"noteRef\":{{\"kind\":\"{}\",\"sectionIdx\":{},\"paraIdx\":{},\"controlIdx\":{},\"noteParaIdx\":{},\"innerControlIdx\":{}}}",
                            r.kind,
                            r.section_index,
                            r.para_index,
                            r.control_index,
                            r.note_para_index,
                            r.inner_control_index
                        )
                    });

                    controls.push(format!(
                        "{{\"type\":\"equation\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1}{}{}{}{}}}",
                        node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                        doc_coords, cell_coords, note_ref, layer_str
                    ));
                    return;
                }
                RenderNodeType::Image(image_node) => {
                    let doc_coords = match (
                        image_node.section_index,
                        image_node.para_index,
                        image_node.control_index,
                    ) {
                        (Some(si), Some(pi), Some(ci)) => {
                            format!(
                                ",\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}",
                                si, pi, ci
                            )
                        }
                        _ => String::new(),
                    };
                    // Task #516 결함 3: hit-test 정합 (옵션 3-C) — wrap 모드 노출.
                    // BehindText 그림은 텍스트 영역 위에서는 hit-test 후순위 처리.
                    let wrap_str = match image_node.text_wrap {
                        Some(crate::model::shape::TextWrap::BehindText) => {
                            ",\"wrap\":\"behindText\""
                        }
                        Some(crate::model::shape::TextWrap::InFrontOfText) => {
                            ",\"wrap\":\"inFrontOfText\""
                        }
                        Some(crate::model::shape::TextWrap::Square) => ",\"wrap\":\"square\"",
                        Some(crate::model::shape::TextWrap::Tight) => ",\"wrap\":\"tight\"",
                        Some(crate::model::shape::TextWrap::Through) => ",\"wrap\":\"through\"",
                        Some(crate::model::shape::TextWrap::TopAndBottom) => {
                            ",\"wrap\":\"topAndBottom\""
                        }
                        None => "",
                    };
                    // [Task #825] 머리말/꼬리말 그림 marker — rhwp-studio findPictureAtClick
                    // 이 secIdx 부재로 필터링하지 않도록 hf 정보 포함.
                    let hf_str = match &image_node.header_footer_ref {
                        Some(r) => {
                            let kind = match r.kind {
                                crate::renderer::render_tree::HeaderFooterKind::Header => "header",
                                crate::renderer::render_tree::HeaderFooterKind::Footer => "footer",
                            };
                            format!(
                                ",\"headerFooter\":{{\"kind\":\"{}\",\"outerParaIdx\":{},\"outerControlIdx\":{}}}",
                                kind, r.outer_para_index, r.outer_control_index
                            )
                        }
                        None => String::new(),
                    };
                    // [Task #1151 v4] 셀 안 inline picture 의 cellIdx/cellParaIdx /
                    // outerTableControlIdx 전달. RectangleNode 처리 (라인 1533-1546)
                    // 와 동일 패턴. 셀 외부 picture 는 cell_index 등이 None → 빈 문자열
                    // → 기존 JSON 출력 그대로 (회귀 0).
                    let cell_str = match (image_node.cell_index, image_node.cell_para_index) {
                        (Some(cei), Some(cpi)) => {
                            format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                        }
                        _ => String::new(),
                    };
                    let outer_table_str = match image_node.outer_table_control_index {
                        Some(otci) => format!(",\"outerTableControlIdx\":{}", otci),
                        None => String::new(),
                    };
                    // [Task #1161] 전체 다단계 cellPath (중첩 표/글상자). TextRun 방출
                    // (cell_coords, 라인 1313-1327) 과 동일 포맷. 단일 레벨 스칼라는 위
                    // cell_str/outer_table_str 로 하위호환 유지. 본문 picture 는 빈 문자열.
                    let cell_path_str = match &image_node.cell_context {
                        Some(ctx) => {
                            let entries: Vec<String> = ctx
                                .path
                                .iter()
                                .map(|e| {
                                    format!(
                                        "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                                        e.control_index, e.cell_index, e.cell_para_index
                                    )
                                })
                                .collect();
                            format!(
                                ",\"parentParaIdx\":{},\"cellPath\":[{}]",
                                ctx.parent_para_index,
                                entries.join(",")
                            )
                        }
                        None => String::new(),
                    };
                    controls.push(format!(
                        "{{\"type\":\"image\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1}{}{}{}{}{}{}{}}}",
                        node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                        doc_coords, wrap_str, hf_str, cell_str, outer_table_str, cell_path_str, layer_str
                    ));
                    return;
                }
                RenderNodeType::RawSvg(raw_node) => {
                    if let Some(control_ref) = raw_node
                        .control_ref
                        .as_ref()
                        .filter(|control_ref| control_ref.kind == "ole")
                    {
                        controls.push(format!(
                            "{{\"type\":\"ole\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}}}",
                            node.bbox.x,
                            node.bbox.y,
                            node.bbox.width,
                            node.bbox.height,
                            control_ref.section_index,
                            control_ref.para_index,
                            control_ref.control_index,
                            DocumentCore::ole_layout_context_json(raw_node.cell_context.as_ref()),
                            layer_str
                        ));
                        return;
                    }
                }
                RenderNodeType::Placeholder(placeholder_node) => {
                    if let Some(control_ref) = placeholder_node
                        .control_ref
                        .as_ref()
                        .filter(|control_ref| control_ref.kind == "ole")
                    {
                        controls.push(format!(
                            "{{\"type\":\"ole\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}}}",
                            node.bbox.x,
                            node.bbox.y,
                            node.bbox.width,
                            node.bbox.height,
                            control_ref.section_index,
                            control_ref.para_index,
                            control_ref.control_index,
                            DocumentCore::ole_layout_context_json(placeholder_node.cell_context.as_ref()),
                            layer_str
                        ));
                        return;
                    }
                    // [Task #2230] 그림 미지정 placeholder(kind="picture") 를
                    // image 컨트롤로 방출 — findPictureAtClick 가 기존 image
                    // 로직으로 hit 해 클릭 선택이 성립한다. missing 마커는
                    // studio 가 더블클릭 시 그림 지정 진입을 분기하는 근거.
                    // cellIdx/cellParaIdx/cellPath 는 Image 분기와 동일 포맷.
                    if let Some(control_ref) = placeholder_node
                        .control_ref
                        .as_ref()
                        .filter(|control_ref| control_ref.kind == "picture")
                    {
                        let (cell_str, cell_path_str) = match &placeholder_node.cell_context {
                            Some(ctx) => {
                                let (cei, cpi, _) = ctx.last_image_indices();
                                let cell_str = match (cei, cpi) {
                                    (Some(cei), Some(cpi)) => {
                                        format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                                    }
                                    _ => String::new(),
                                };
                                let entries: Vec<String> = ctx
                                    .path
                                    .iter()
                                    .map(|e| {
                                        format!(
                                            "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                                            e.control_index, e.cell_index, e.cell_para_index
                                        )
                                    })
                                    .collect();
                                let cell_path_str = format!(
                                    ",\"parentParaIdx\":{},\"cellPath\":[{}]",
                                    ctx.parent_para_index,
                                    entries.join(",")
                                );
                                (cell_str, cell_path_str)
                            }
                            None => (String::new(), String::new()),
                        };
                        controls.push(format!(
                            "{{\"type\":\"image\",\"missing\":true,\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                            node.bbox.x,
                            node.bbox.y,
                            node.bbox.width,
                            node.bbox.height,
                            control_ref.section_index,
                            control_ref.para_index,
                            control_ref.control_index,
                            cell_str,
                            cell_path_str,
                            layer_str
                        ));
                        return;
                    }
                }
                RenderNodeType::Group(group_node) => {
                    if let (Some(si), Some(pi), Some(ci)) = (
                        group_node.section_index,
                        group_node.para_index,
                        group_node.control_index,
                    ) {
                        controls.push(format!(
                            "{{\"type\":\"group\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}}}",
                            node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                            si, pi, ci, layer_str
                        ));
                        return; // 자식 개별 수집하지 않음 — 묶음 전체가 하나의 컨트롤
                    }
                }
                RenderNodeType::Rectangle(rect_node) => {
                    // 문서 좌표가 있는 Rectangle만 shape로 수집 (배경 사각형 제외)
                    if let (Some(si), Some(pi), Some(ci)) = (
                        rect_node.section_index,
                        rect_node.para_index,
                        rect_node.control_index,
                    ) {
                        // [Task #1138] 표 셀 안 사각형: cellIdx/cellParaIdx/outerTableControlIdx
                        let cell_str = match (rect_node.cell_index, rect_node.cell_para_index) {
                            (Some(cei), Some(cpi)) => {
                                format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                            }
                            _ => String::new(),
                        };
                        let outer_table_str = match rect_node.outer_table_control_index {
                            Some(otci) => format!(",\"outerTableControlIdx\":{}", otci),
                            None => String::new(),
                        };
                        controls.push(format!(
                            "{{\"type\":\"shape\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                            node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                            si, pi, ci, cell_str, outer_table_str, layer_str
                        ));
                        // [Task #1171] return 하지 않고 자식으로 재귀 — 사각형 글상자(text_box)
                        // 안 중첩 picture/도형이 cellPath(cell_index=0 sentinel)로 수집되도록 한다.
                        // 장식 노드(테두리 등)는 section/para/control 좌표가 None 이라 컨트롤로
                        // 방출되지 않는다(좌표 가드). Table 핸들러와 동일하게 자식 탐색.
                    }
                }
                RenderNodeType::Line(line_node) => {
                    if let (Some(si), Some(pi), Some(ci)) = (
                        line_node.section_index,
                        line_node.para_index,
                        line_node.control_index,
                    ) {
                        // [Task #1138] 표 셀 안 직선
                        let cell_str = match (line_node.cell_index, line_node.cell_para_index) {
                            (Some(cei), Some(cpi)) => {
                                format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                            }
                            _ => String::new(),
                        };
                        let outer_table_str = match line_node.outer_table_control_index {
                            Some(otci) => format!(",\"outerTableControlIdx\":{}", otci),
                            None => String::new(),
                        };
                        controls.push(format!(
                            "{{\"type\":\"line\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"x1\":{:.1},\"y1\":{:.1},\"x2\":{:.1},\"y2\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                            node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                            line_node.x1, line_node.y1, line_node.x2, line_node.y2,
                            si, pi, ci, cell_str, outer_table_str, layer_str
                        ));
                        return;
                    }
                }
                RenderNodeType::Ellipse(ell_node) => {
                    if let (Some(si), Some(pi), Some(ci)) = (
                        ell_node.section_index,
                        ell_node.para_index,
                        ell_node.control_index,
                    ) {
                        // [Task #1138] 표 셀 안 타원
                        let cell_str = match (ell_node.cell_index, ell_node.cell_para_index) {
                            (Some(cei), Some(cpi)) => {
                                format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                            }
                            _ => String::new(),
                        };
                        let outer_table_str = match ell_node.outer_table_control_index {
                            Some(otci) => format!(",\"outerTableControlIdx\":{}", otci),
                            None => String::new(),
                        };
                        controls.push(format!(
                            "{{\"type\":\"shape\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                            node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                            si, pi, ci, cell_str, outer_table_str, layer_str
                        ));
                        return;
                    }
                }
                RenderNodeType::Path(path_node) => {
                    if let (Some(si), Some(pi), Some(ci)) = (
                        path_node.section_index,
                        path_node.para_index,
                        path_node.control_index,
                    ) {
                        // [Task #1138] 표 셀 안 path (다각형/곡선/연결선)
                        let cell_str = match (path_node.cell_index, path_node.cell_para_index) {
                            (Some(cei), Some(cpi)) => {
                                format!(",\"cellIdx\":{},\"cellParaIdx\":{}", cei, cpi)
                            }
                            _ => String::new(),
                        };
                        let outer_table_str = match path_node.outer_table_control_index {
                            Some(otci) => format!(",\"outerTableControlIdx\":{}", otci),
                            None => String::new(),
                        };
                        if let Some((x1, y1, x2, y2)) = path_node.connector_endpoints {
                            // 연결선: 선 선택 방식 (시작/끝 좌표 포함)
                            controls.push(format!(
                                "{{\"type\":\"line\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"x1\":{:.1},\"y1\":{:.1},\"x2\":{:.1},\"y2\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                                node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                                x1, y1, x2, y2,
                                si, pi, ci, cell_str, outer_table_str, layer_str
                            ));
                        } else {
                            controls.push(format!(
                                "{{\"type\":\"shape\",\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1},\"secIdx\":{},\"paraIdx\":{},\"controlIdx\":{}{}{}{}}}",
                                node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height,
                                si, pi, ci, cell_str, outer_table_str, layer_str
                            ));
                        }
                        return;
                    }
                }
                _ => {}
            }
            for child in &node.children {
                collect_controls(child, controls);
            }
        }

        let mut controls = Vec::new();
        collect_controls(&tree.root, &mut controls);

        Ok(format!("{{\"controls\":[{}]}}", controls.join(",")))
    }

    /// 구역의 문단들에서 초기 ColumnDef를 추출한다.
    pub(crate) fn find_initial_column_def(paragraphs: &[Paragraph]) -> ColumnDef {
        for para in paragraphs {
            for ctrl in &para.controls {
                if let Control::ColumnDef(cd) = ctrl {
                    return cd.clone();
                }
            }
        }
        ColumnDef::default()
    }

    /// 특정 문단에 적용되는 ColumnDef를 찾는다.
    /// 문단 순서대로 탐색하여 para_idx 이하에서 가장 마지막 ColumnDef를 반환한다.
    /// (한 구역 내에서 다단↔단일단 전환이 여러 번 일어날 수 있음)
    pub(crate) fn find_column_def_for_paragraph(
        paragraphs: &[Paragraph],
        para_idx: usize,
    ) -> ColumnDef {
        let mut last_cd = ColumnDef::default();
        for (i, para) in paragraphs.iter().enumerate() {
            if i > para_idx {
                break;
            }
            for ctrl in &para.controls {
                if let Control::ColumnDef(cd) = ctrl {
                    last_cd = cd.clone();
                }
            }
        }
        last_cd
    }

    /// 구역을 재조판하고 dirty로 표시한다.
    pub(crate) fn recompose_section(&mut self, section_idx: usize) {
        self.invalidate_page_tree_cache();
        self.composed[section_idx] = compose_section_with_horizontal_shaping(
            &self.document.sections[section_idx],
            &self.styles,
        );
        self.mark_section_dirty(section_idx);
        // 전체 문단 dirty (모두 재측정 필요)
        if section_idx < self.dirty_paragraphs.len() {
            self.dirty_paragraphs[section_idx] = None;
        }
    }

    /// 구역을 dirty로 표시만 한다 (재조판 없이).
    /// 셀 내부 편집처럼 composed 데이터가 불변인 경우 사용.
    pub(crate) fn mark_section_dirty(&mut self, section_idx: usize) {
        self.mark_section_pagination_dirty(section_idx);
        self.invalidate_render_normalization_section(section_idx);
    }

    /// 구조가 안정적인 path edit에서 pagination만 dirty로 표시한다.
    ///
    /// 렌더 정규화의 section revision은 구조/기하 변경을 뜻하므로 여기서는 유지한다.
    /// 해당 path revision은 mutation 진입점에서 별도로 증가시킨다.
    pub(crate) fn mark_section_pagination_dirty(&mut self, section_idx: usize) {
        if section_idx < self.dirty_sections.len() {
            self.dirty_sections[section_idx] = true;
        }
        // 문단 dirty는 건드리지 않음 (셀 편집 시 문단 재측정 불필요)
    }

    /// section 구조·페이지 기하 변경으로 해당 normalization projection을 무효화한다.
    pub(crate) fn invalidate_render_normalization_section(&mut self, section_idx: usize) {
        if self.render_normalization.section_revisions.len() <= section_idx {
            self.render_normalization
                .section_revisions
                .resize(section_idx + 1, 0);
        }
        self.render_normalization.section_revisions[section_idx] =
            self.render_normalization.section_revisions[section_idx].wrapping_add(1);
    }

    /// 문단 dirty 비트 설정
    pub(crate) fn mark_paragraph_dirty(&mut self, section_idx: usize, para_idx: usize) {
        if section_idx >= self.dirty_paragraphs.len() {
            return;
        }
        let para_count = self.document.sections[section_idx].paragraphs.len();
        match &mut self.dirty_paragraphs[section_idx] {
            None => {
                // 전체 dirty 상태에서 선택적으로 전환:
                // 전체 dirty인데 특정 문단만 dirty로 설정하면 안 됨 → 이미 전체 dirty이므로 유지
                // (이 경우는 recompose_section 후 recompose_paragraph 호출 시 발생 불가)
            }
            Some(bits) => {
                bits.resize(para_count, false);
                if para_idx < bits.len() {
                    bits[para_idx] = true;
                }
            }
        }
    }

    /// 단일 문단만 재조판한다.
    pub(crate) fn recompose_paragraph(&mut self, section_idx: usize, para_idx: usize) {
        self.invalidate_page_tree_cache();
        let para = &self.document.sections[section_idx].paragraphs[para_idx];
        self.composed[section_idx][para_idx] =
            compose_paragraph_with_horizontal_shaping(para, &self.styles);
        self.mark_section_dirty(section_idx);
        self.mark_paragraph_dirty(section_idx, para_idx);
    }

    /// composed 벡터에 새 문단 항목을 삽입한다 (문단 분할/붙여넣기 후).
    pub(crate) fn insert_composed_paragraph(&mut self, section_idx: usize, para_idx: usize) {
        self.invalidate_page_tree_cache();
        let para = &self.document.sections[section_idx].paragraphs[para_idx];
        let composed = compose_paragraph_with_horizontal_shaping(para, &self.styles);
        self.composed[section_idx].insert(para_idx, composed);
        self.mark_section_dirty(section_idx);
        // measured_sections: 인덱스 조정으로 기존 측정값 재사용 (전체 재측정 회피)
        if section_idx < self.measured_sections.len() {
            self.measured_sections[section_idx].shift_for_insert(para_idx);
        }
        // dirty_paragraphs: 삽입된 문단과 분할 원본만 dirty 표시
        if section_idx < self.dirty_paragraphs.len() {
            let para_count = self.document.sections[section_idx].paragraphs.len();
            let bits =
                self.dirty_paragraphs[section_idx].get_or_insert_with(|| vec![false; para_count]);
            // 기존 비트맵에 삽입 위치 추가 (후속 인덱스 shift)
            if para_idx <= bits.len() {
                bits.insert(para_idx, true);
            }
            // 비트맵 길이를 문단 수에 맞춤
            bits.resize(para_count, false);
            // 분할 원본 문단도 dirty
            if para_idx > 0 {
                bits[para_idx - 1] = true;
            }
        }
        // para_offset 누적 (수렴 감지용)
        while self.para_offset.len() <= section_idx {
            self.para_offset.push(0);
        }
        self.para_offset[section_idx] += 1;
    }

    /// composed 벡터에서 문단 항목을 제거한다 (문단 병합/삭제 후).
    pub(crate) fn remove_composed_paragraph(&mut self, section_idx: usize, para_idx: usize) {
        self.invalidate_page_tree_cache();
        if para_idx < self.composed[section_idx].len() {
            self.composed[section_idx].remove(para_idx);
        }
        self.mark_section_dirty(section_idx);
        // measured_sections: 인덱스 조정으로 기존 측정값 재사용
        if section_idx < self.measured_sections.len() {
            self.measured_sections[section_idx].shift_for_remove(para_idx);
        }
        // dirty_paragraphs: 병합 대상 문단만 dirty 표시
        if section_idx < self.dirty_paragraphs.len() {
            let para_count = self.document.sections[section_idx].paragraphs.len();
            let bits =
                self.dirty_paragraphs[section_idx].get_or_insert_with(|| vec![false; para_count]);
            if para_idx < bits.len() {
                bits.remove(para_idx);
            }
            bits.resize(para_count, false);
            // 병합 결과 문단 dirty
            if para_idx < bits.len() {
                bits[para_idx] = true;
            }
            if para_idx > 0 && para_idx - 1 < bits.len() {
                bits[para_idx - 1] = true;
            }
        }
        // para_offset 누적 (수렴 감지용)
        while self.para_offset.len() <= section_idx {
            self.para_offset.push(0);
        }
        self.para_offset[section_idx] -= 1;
    }

    /// 모든 구역을 dirty로 표시한다.
    pub(crate) fn mark_all_sections_dirty(&mut self) {
        for d in &mut self.dirty_sections {
            *d = true;
        }
        self.render_normalization
            .section_revisions
            .resize(self.document.sections.len(), 0);
        for revision in &mut self.render_normalization.section_revisions {
            *revision = revision.wrapping_add(1);
        }
        self.render_normalization.document_epoch =
            self.render_normalization.document_epoch.wrapping_add(1);
        self.render_normalization.path_revisions.clear();
    }

    /// 원본 IR 은 그대로 두고, 거기서 파생된 렌더 상태를 전부 원본에서 다시 만든다.
    ///
    /// `document` 는 읽기만 한다 — 편집이 아니라 **메모된 파생본이 더는 원본과 대응하지
    /// 않게 된 순간**에 부르는 연산이다. 문서를 통째로 갈아끼운 직후(`set_document`,
    /// 스냅샷 복원), 그리고 파생본을 만든 코드 자체가 교체된 직후(핫패치)가 그 순간이다.
    ///
    /// 증분 게이트(`dirty_sections`·`section_revisions`·`measured_sections`·`table.dirty`)는
    /// 모두 "원본이 그대로면 파생본을 재사용한다"는 한 가지 규칙이라, 원본이 그대로인 채
    /// 파생본만 못 믿게 된 상황을 스스로 판별할 수 없다. 그래서 이 메서드가 게이트가 읽는
    /// 상태를 전부 비우고 재조판까지 한 번에 끝낸다 — 돌아온 뒤 "나중에 다시 계산해야
    /// 한다"고 남겨 두는 표식은 없다.
    ///
    /// 파생 순서는 소비 순서와 같다: 스타일 → exact source/context → 문단 구성 →
    /// (정규화·측정) → 페이지네이션 → 페이지 트리. 앞 단계를 뒤 단계보다 늦게
    /// 만들면 같은 패스 안에서 옛 값이 섞인다.
    pub(crate) fn rebuild_derived_state(&mut self) {
        self.rebuild_resolved_styles();
        self.rebuild_embedded_exact_font_sources();
        self.recompose_all_with_horizontal_shaping();
        self.mark_all_sections_dirty();
        self.measured_tables.clear();
        self.measured_sections.clear();
        self.dirty_paragraphs.clear();
        self.para_column_map.clear();
        self.invalidate_page_tree_cache();
        self.overflow_links_cache.borrow_mut().clear();
        self.paginate();
    }

    /// Batch 모드가 아닐 때만 paginate를 실행한다.
    /// Command 메서드에서 self.paginate() 대신 호출한다.
    /// [#2424] 최신 deferred descriptor를 shadow pagination job으로 승격한다.
    /// 지원하지 않는 문서 형상은 공개 pagination을 건드리지 않고 Fallback을 반환한다.
    pub fn begin_deferred_pagination(
        &mut self,
        fragment_budget: usize,
    ) -> DeferredPaginationStepResult {
        self.pending_pagination_job = None;
        let Some(descriptor) = self.deferred_pagination_descriptor.clone() else {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::None,
                revision: self.deferred_pagination_revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        };
        if !descriptor.cell_flow_changed
            || self.deferred_pagination_target_status(&descriptor)
                != DeferredPaginationTargetStatus::Current
            || self.document.sections.len() != 1
        {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Fallback,
                revision: descriptor.revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        }

        self.compute_render_normalized();
        let section_index = descriptor.section_index;
        let Some(section) = self.document.sections.get(section_index) else {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Fallback,
                revision: descriptor.revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        };
        let source_revision = self.render_normalization.section_revisions[section_index];
        let normalized = self
            .render_normalization
            .sections
            .get(section_index)
            .and_then(|entry| entry.as_ref())
            .filter(|entry| entry.source_revision == source_revision);
        let paragraphs: &[Paragraph] = match normalized {
            Some(normalized) => &normalized.paragraphs[..],
            None => &section.paragraphs,
        };
        let composed: &[ComposedParagraph] = match normalized {
            Some(normalized) => &normalized.composed[..],
            None => match self.composed.get(section_index) {
                Some(composed) => composed,
                None => {
                    return DeferredPaginationStepResult {
                        state: DeferredPaginationJobState::Fallback,
                        revision: descriptor.revision,
                        fragments_processed: 0,
                        page_count: self.page_count(),
                    };
                }
            },
        };
        let profile = self.effective_layout_profile();
        let hwp3_origin_flow_spacing_before = uses_hwp3_origin_flow_spacing_before(&self.document);
        let measurer = HeightMeasurer::new(self.dpi)
            .with_hwp3_variant(profile.hwp3_layout())
            .with_legacy_hwp3_stored_geometry(profile.legacy_hwp3_stored_geometry())
            .with_native_hwp5(profile.native_hwp5_layout())
            .with_hwp3_origin_flow_spacing_before(hwp3_origin_flow_spacing_before);
        let column_def = Self::find_initial_column_def(paragraphs);
        let layout =
            PageLayoutInfo::from_page_def(&section.section_def.page_def, &column_def, self.dpi);
        let column_width = layout
            .column_areas
            .first()
            .map(|area| area.width)
            .unwrap_or(layout.body_area.width);
        let measured = if self
            .measured_sections
            .get(section_index)
            .is_some_and(|cached| !cached.fallback_paragraphs.is_empty())
        {
            measurer.measure_section_selective(
                paragraphs,
                composed,
                &self.styles,
                &self.measured_sections[section_index],
                self.dirty_paragraphs
                    .get(section_index)
                    .and_then(|dirty| dirty.as_deref()),
                Some(column_width),
            )
        } else {
            measurer.measure_section(paragraphs, composed, &self.styles, Some(column_width))
        };
        let typesetter = TypesetEngine::new(self.dpi);
        let Some(renderer_job) = typesetter.begin_resumable_table_pagination(
            paragraphs,
            composed,
            &self.styles,
            &section.section_def.page_def,
            &column_def,
            section_index,
            &measured.tables,
            section.section_def.hide_empty_line,
            profile,
            hwp3_origin_flow_spacing_before,
            Some(&section.section_def.footnote_shape),
            descriptor.para_index,
            descriptor.control_index,
            fragment_budget,
        ) else {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Fallback,
                revision: descriptor.revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        };
        self.pending_pagination_job = Some(PendingPaginationJob {
            descriptor: descriptor.clone(),
            renderer_job,
            measured,
        });
        DeferredPaginationStepResult {
            state: DeferredPaginationJobState::Pending,
            revision: descriptor.revision,
            fragments_processed: 0,
            page_count: self.page_count(),
        }
    }

    /// [#2424] shadow job에서 fragment budget만큼 전진한다.
    /// 완료 전에는 기존 공개 pagination과 render tree cache를 유지한다.
    pub fn step_deferred_pagination(
        &mut self,
        fragment_budget: usize,
    ) -> DeferredPaginationStepResult {
        let Some(mut pending) = self.pending_pagination_job.take() else {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::None,
                revision: self.deferred_pagination_revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        };
        let revision = pending.descriptor.revision;
        if self.deferred_pagination_target_status(&pending.descriptor)
            != DeferredPaginationTargetStatus::Current
        {
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Stale,
                revision,
                fragments_processed: 0,
                page_count: self.page_count(),
            };
        }

        let (paragraph_index, control_index) =
            TypesetEngine::resumable_table_target(&pending.renderer_job);
        let step = {
            let Some(section) = self.document.sections.get(pending.descriptor.section_index) else {
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Stale,
                    revision,
                    fragments_processed: 0,
                    page_count: self.page_count(),
                };
            };
            let Some(paragraph) = section.paragraphs.get(paragraph_index) else {
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Stale,
                    revision,
                    fragments_processed: 0,
                    page_count: self.page_count(),
                };
            };
            let Some(Control::Table(table)) = paragraph.controls.get(control_index) else {
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Stale,
                    revision,
                    fragments_processed: 0,
                    page_count: self.page_count(),
                };
            };
            let Some(measured_table) = pending.measured.tables.iter().find(|measured| {
                measured.para_index == paragraph_index && measured.control_index == control_index
            }) else {
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Stale,
                    revision,
                    fragments_processed: 0,
                    page_count: self.page_count(),
                };
            };
            TypesetEngine::new(self.dpi).step_resumable_table_pagination(
                &mut pending.renderer_job,
                paragraph,
                table,
                measured_table,
                &self.styles,
                fragment_budget,
            )
        };
        if !step.complete {
            self.pending_pagination_job = Some(pending);
            return DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Pending,
                revision,
                fragments_processed: step.fragments_processed,
                page_count: self.page_count(),
            };
        }

        let section_index = pending.descriptor.section_index;
        let result = {
            let section = &self.document.sections[section_index];
            let Some(mut result) = TypesetEngine::new(self.dpi).finish_resumable_table_pagination(
                pending.renderer_job,
                &section.paragraphs,
                section_index,
            ) else {
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Fallback,
                    revision,
                    fragments_processed: step.fragments_processed,
                    page_count: self.page_count(),
                };
            };
            apply_page_number_layouts_for_section(&mut result, section);
            assign_master_pages_for_section(&mut result, section_index, section, &None, &None);
            result
        };
        let completed_page_count = result.pages.len() as u32;
        if self.pagination.len() <= section_index {
            self.pagination
                .resize_with(section_index + 1, || PaginationResult {
                    pages: Vec::new(),
                    wrap_around_paras: Vec::new(),
                    hidden_empty_paras: std::collections::HashSet::new(),
                    pre_emitted_host_paras: std::collections::HashSet::new(),
                    pre_emitted_host_heights: std::collections::HashMap::new(),
                    endnotes: Vec::new(),
                    endnote_paragraphs: Vec::new(),
                    endnote_para_sources: Vec::new(),
                    endnote_between_notes_hu: 0,
                    endnote_separator_above_hu: 0,
                    endnote_separator_below_hu: 0,
                });
        }
        self.pagination[section_index] = result;
        if self.measured_tables.len() <= section_index {
            self.measured_tables
                .resize_with(section_index + 1, Vec::new);
        }
        if self.measured_sections.len() <= section_index {
            self.measured_sections
                .resize_with(section_index + 1, || MeasuredSection {
                    fallback_paragraphs: Vec::new(),
                    tables: Vec::new(),
                });
        }
        self.measured_tables[section_index] = pending.measured.tables.clone();
        self.measured_sections[section_index] = pending.measured;
        self.dirty_sections
            .resize(self.document.sections.len(), false);
        self.dirty_sections[section_index] = false;
        self.dirty_paragraphs
            .resize_with(self.document.sections.len(), || None);
        let paragraph_count = self.document.sections[section_index].paragraphs.len();
        self.dirty_paragraphs[section_index] = Some(vec![false; paragraph_count]);
        self.para_column_map
            .resize_with(self.document.sections.len(), Vec::new);
        self.para_column_map[section_index] = vec![0; paragraph_count];
        for offset in &mut self.para_offset {
            *offset = 0;
        }
        for paragraph in &mut self.document.sections[section_index].paragraphs {
            for control in &mut paragraph.controls {
                if let Control::Table(table) = control {
                    table.dirty = false;
                }
            }
        }
        self.deferred_pagination_descriptor = None;
        self.invalidate_page_tree_cache();
        DeferredPaginationStepResult {
            state: DeferredPaginationJobState::Complete,
            revision,
            fragments_processed: step.fragments_processed,
            page_count: completed_page_count.max(1),
        }
    }

    pub fn cancel_deferred_pagination(&mut self) -> bool {
        self.pending_pagination_job.take().is_some()
    }

    /// 저장/인쇄/명시 flush용 동기 barrier. resumable job을 끝까지 drain하고,
    /// 시작 불가 또는 stale이면 기존 full pagination으로 복구한다.
    pub fn flush_deferred_pagination(&mut self) -> DeferredPaginationStepResult {
        if self.pending_pagination_job.is_none() {
            let begin = self.begin_deferred_pagination(usize::MAX);
            if begin.state != DeferredPaginationJobState::Pending {
                self.paginate();
                return DeferredPaginationStepResult {
                    state: DeferredPaginationJobState::Fallback,
                    revision: self.deferred_pagination_revision,
                    fragments_processed: 0,
                    page_count: self.page_count(),
                };
            }
        }
        let step = self.step_deferred_pagination(usize::MAX);
        if step.state == DeferredPaginationJobState::Complete {
            step
        } else {
            self.paginate();
            DeferredPaginationStepResult {
                state: DeferredPaginationJobState::Fallback,
                revision: self.deferred_pagination_revision,
                fragments_processed: step.fragments_processed,
                page_count: self.page_count(),
            }
        }
    }

    pub(crate) fn paginate_if_needed(&mut self) {
        if !self.batch_mode {
            self.paginate();
        }
    }

    /// 편집 API(누름틀 채움·전체 치환 등)가 `recompose_section` 으로 남긴 dirty
    /// 구역을 즉시 재페이지네이션하는 공개 표면 — 같은 인스턴스에서 편집 직후
    /// 페이지 어휘(page_count·페이지 텍스트·렌더·grep 의 page 주소)를 읽는
    /// 세션형 소비자(mcp-serve 핸들)가 호출한다. 무상태 CLI 는 편집 후 곧바로
    /// 직렬화·종료하므로 부르지 않는다. batch 모드에서는 Command 흐름과 같은
    /// 규약으로 미룬다.
    pub fn repaginate_if_needed(&mut self) {
        self.paginate_if_needed();
    }

    /// 모든 구역을 페이지로 분할한다 (dirty 구역만 재처리, 증분 표 측정).
    ///
    /// [Task #1046] 사후 reflow(A) 접근은 페이지네이터↔렌더러 측정 드리프트로 인해
    /// overflow 를 줄이지 못함이 확인되어(stage3 findings) 단일 패스로 둔다. 근본 해소는
    /// 측정 통일(B). `paginate_pass` 의 `force_break_before` 훅과 `LayoutOverflow` 의
    /// section_index/is_first_in_column 계측은 측정 통일 작업의 진단·후속용으로 유지한다.
    pub(crate) fn paginate(&mut self) {
        self.pending_pagination_job = None;
        let sec_count = self.document.sections.len().max(1);
        let empty_breaks: Vec<std::collections::HashSet<usize>> =
            vec![std::collections::HashSet::new(); sec_count];
        self.paginate_pass(&empty_breaks);
        // [#2424] full path가 최신 dirty state를 반영했으므로 deferred target을 소비한다.
        // 이후 resumable job도 shadow result commit 성공 시 같은 수명 규칙을 적용한다.
        self.deferred_pagination_descriptor = None;
    }

    fn paginate_pass(&mut self, force_breaks: &[std::collections::HashSet<usize>]) {
        // [#4968 R4C-3] 이번 pass의 모든 fresh-layout 경로가 동일한 exact-source
        // generation을 읽는다. 등록 source가 없으면 None으로 K0 fast path를 고정한다.
        self.ensure_exact_font_measurement_contexts();
        #[cfg(not(target_arch = "wasm32"))]
        let issue2424_profile_enabled =
            std::env::var("RHWP_2424_PROFILE").is_ok_and(|value| !value.is_empty() && value != "0");
        #[cfg(target_arch = "wasm32")]
        let issue2424_profile_enabled = false;
        let issue2424_pass_started = issue2424_profile_enabled.then(std::time::Instant::now);
        let issue2424_warm_sections = self
            .measured_sections
            .iter()
            .filter(|section| !section.fallback_paragraphs.is_empty())
            .count();
        let issue2424_dirty_sections = self
            .dirty_sections
            .iter()
            .copied()
            .filter(|dirty| *dirty)
            .count();
        let issue2424_invalidate_started = issue2424_profile_enabled.then(std::time::Instant::now);
        self.invalidate_page_tree_cache();
        let issue2424_invalidate_elapsed = issue2424_invalidate_started
            .map(|started| started.elapsed())
            .unwrap_or_default();
        // [#2308] #2004 revision cache와 #2195 sparse overlay를 source IR에서 갱신한다.
        let issue2424_normalize_started = issue2424_profile_enabled.then(std::time::Instant::now);
        self.compute_render_normalized();
        let issue2424_normalize_elapsed = issue2424_normalize_started
            .map(|started| started.elapsed())
            .unwrap_or_default();
        let issue2424_setup_started = issue2424_profile_enabled.then(std::time::Instant::now);
        let paginator = Paginator::new(self.dpi);
        let hwp3_origin_flow_spacing_before = uses_hwp3_origin_flow_spacing_before(&self.document);
        // [#2403] 소스분기 파생 일원화 — HWPX 시멘틱/HWP5→HWPX 마커/HWP3 변환본
        // 판단은 Document::layout_profile 이 단일 소유 (Issue #1770 규칙 승계).
        // 세션 호환 모드(hangul2024)는 effective_layout_profile 이 합성한다.
        let profile = self.effective_layout_profile();
        let measurer = HeightMeasurer::new(self.dpi)
            .with_hwp3_variant(profile.hwp3_layout())
            .with_legacy_hwp3_stored_geometry(profile.legacy_hwp3_stored_geometry())
            .with_native_hwp5(profile.native_hwp5_layout())
            .with_hwp3_origin_flow_spacing_before(hwp3_origin_flow_spacing_before)
            .with_render_normalization(std::sync::Arc::clone(&self.render_normalization.overlay));

        if self.document.sections.is_empty() {
            self.pagination.clear();
            self.measured_tables.clear();
            self.measured_sections.clear();
            let default_section = Section::default();
            let empty_composed: Vec<ComposedParagraph> = Vec::new();
            let measured = measurer.measure_section(
                &default_section.paragraphs,
                &empty_composed,
                &self.styles,
                None,
            );
            let result = paginator.paginate_with_measured(
                &default_section.paragraphs,
                &measured,
                &default_section.section_def.page_def,
                &ColumnDef::default(),
                0,
                &self.styles.para_styles,
            );
            self.pagination.push(result);
            self.measured_tables.push(measured.tables.clone());
            self.measured_sections.push(measured);
            return;
        }

        // 벡터 크기 동기화
        let sec_count = self.document.sections.len();
        while self.pagination.len() < sec_count {
            self.pagination.push(PaginationResult {
                pages: Vec::new(),
                wrap_around_paras: Vec::new(),
                hidden_empty_paras: std::collections::HashSet::new(),
                pre_emitted_host_paras: std::collections::HashSet::new(),
                pre_emitted_host_heights: std::collections::HashMap::new(),
                endnotes: Vec::new(),
                endnote_paragraphs: Vec::new(),
                endnote_para_sources: Vec::new(),
                endnote_between_notes_hu: 0,
                endnote_separator_above_hu: 0,
                endnote_separator_below_hu: 0,
            });
        }
        self.pagination.truncate(sec_count);
        while self.para_column_map.len() < sec_count {
            self.para_column_map.push(Vec::new());
        }
        self.para_column_map.truncate(sec_count);
        while self.measured_tables.len() < sec_count {
            self.measured_tables.push(Vec::new());
        }
        self.measured_tables.truncate(sec_count);
        self.dirty_sections.resize(sec_count, true);
        self.dirty_sections.truncate(sec_count);
        while self.measured_sections.len() < sec_count {
            self.measured_sections.push(MeasuredSection {
                fallback_paragraphs: Vec::new(),
                tables: Vec::new(),
            });
        }
        self.measured_sections.truncate(sec_count);
        while self.dirty_paragraphs.len() < sec_count {
            self.dirty_paragraphs.push(None);
        }
        self.dirty_paragraphs.truncate(sec_count);
        // [#4325] 이번 패스에서 실제로 재측정한 구역만 표시한다. dirty가 아니어서 건너뛴
        // 구역은 표 dirty 플래그를 지우면 안 된다 — 지우는 범위와 소비하는 범위(측정 스킵)가
        // 어긋나면 그 구역의 표가 이후 dirty로 마킹돼도 이번 패스의 clear로 소실된다.
        let mut remeasured_sections = vec![false; sec_count];

        // 구역 간 쪽번호 위치/번호 상속
        let mut carry_page_number_pos: Option<crate::model::control::PageNumberPos> = None;
        let mut carry_last_page_number: u32 = 0; // 이전 구역의 마지막 쪽번호

        // 구역 간 머리말/꼬리말 상속 (이전 구역의 홀수/짝수 페이지별 carry)
        use crate::renderer::pagination::HeaderFooterRef;
        let mut carry_header_odd: Option<HeaderFooterRef> = None;
        let mut carry_header_even: Option<HeaderFooterRef> = None;
        let mut carry_footer_odd: Option<HeaderFooterRef> = None;
        let mut carry_footer_even: Option<HeaderFooterRef> = None;
        let mut carry_master_odd: Option<MasterPageRef> = None;
        let mut carry_master_even: Option<MasterPageRef> = None;

        // [Task #1046] reflow force-break hint (구역별). reflow 루프(paginate)가 누적해 전달.
        let empty_breaks: std::collections::HashSet<usize> = std::collections::HashSet::new();
        let issue2424_setup_elapsed = issue2424_setup_started
            .map(|started| started.elapsed())
            .unwrap_or_default();
        let mut issue2424_measure_elapsed = std::time::Duration::ZERO;
        let mut issue2424_typeset_elapsed = std::time::Duration::ZERO;
        let mut issue2424_postprocess_elapsed = std::time::Duration::ZERO;
        for (idx, section) in self.document.sections.iter().enumerate() {
            if !self.dirty_sections[idx] {
                // dirty가 아닌 구역에서도 carry를 업데이트
                if let Some(pages) = self.pagination.get(idx) {
                    if let Some(last) = pages.pages.last() {
                        if last.page_number_pos.is_some() {
                            carry_page_number_pos = last.page_number_pos.clone();
                        }
                        carry_last_page_number = last.page_number;
                    }
                    // 머리말/꼬리말 carry 업데이트 (not-dirty 구역)
                    for page in &pages.pages {
                        let is_odd = page.page_number % 2 == 1;
                        if page.active_header.is_some() {
                            if is_odd {
                                carry_header_odd = page.active_header.clone();
                            } else {
                                carry_header_even = page.active_header.clone();
                            }
                        }
                        if page.active_footer.is_some() {
                            if is_odd {
                                carry_footer_odd = page.active_footer.clone();
                            } else {
                                carry_footer_even = page.active_footer.clone();
                            }
                        }
                    }
                }
                update_master_page_carry_from_section(
                    idx,
                    section,
                    &mut carry_master_odd,
                    &mut carry_master_even,
                );
                continue;
            }

            // [#2004] render-전용 정규화본(부동 이미지 스택 인라인 재분류) 우선. 원본 무손상.
            // 직접 필드 접근으로 disjoint-borrow 유지(이후 self.measured_* 가변 대입과 공존).
            let source_revision = self.render_normalization.section_revisions[idx];
            let norm = self
                .render_normalization
                .sections
                .get(idx)
                .and_then(|section| section.as_ref())
                .filter(|section| section.source_revision == source_revision);
            let para_src: &[Paragraph] = match norm {
                Some(normalized) => &normalized.paragraphs[..],
                None => &section.paragraphs[..],
            };
            let composed: &[ComposedParagraph] = match norm {
                Some(normalized) => &normalized.composed[..],
                None => {
                    if idx < self.composed.len() {
                        &self.composed[idx][..]
                    } else {
                        continue;
                    }
                }
            };

            // 증분 측정: 이전 측정 데이터가 있으면 문단/표 수준 선택적 캐싱
            let issue2424_measure_started = issue2424_profile_enabled.then(std::time::Instant::now);
            let measured = if !self.measured_sections[idx].fallback_paragraphs.is_empty() {
                let dirty_paras = self
                    .dirty_paragraphs
                    .get(idx)
                    .and_then(|opt| opt.as_deref());
                let column_def_sel = Self::find_initial_column_def(para_src);
                let layout_sel = crate::renderer::page_layout::PageLayoutInfo::from_page_def(
                    &section.section_def.page_def,
                    &column_def_sel,
                    self.dpi,
                );
                let col_w_sel = layout_sel
                    .column_areas
                    .first()
                    .map(|a| a.width)
                    .unwrap_or(layout_sel.body_area.width);
                measurer.measure_section_selective(
                    para_src,
                    composed,
                    &self.styles,
                    &self.measured_sections[idx],
                    dirty_paras,
                    Some(col_w_sel),
                )
            } else {
                let column_def_pre = Self::find_initial_column_def(para_src);
                let layout_pre = crate::renderer::page_layout::PageLayoutInfo::from_page_def(
                    &section.section_def.page_def,
                    &column_def_pre,
                    self.dpi,
                );
                let col_w_pre = layout_pre
                    .column_areas
                    .first()
                    .map(|a| a.width)
                    .unwrap_or(layout_pre.body_area.width);
                measurer.measure_section(para_src, composed, &self.styles, Some(col_w_pre))
            };
            if let Some(started) = issue2424_measure_started {
                issue2424_measure_elapsed += started.elapsed();
            }

            let issue2424_typeset_started = issue2424_profile_enabled.then(std::time::Instant::now);
            let hwp3_origin_page_tolerance = self.document.layout_profile().hwp3_layout()
                || uses_hwp3_origin_page_tolerance(&self.document);
            let column_def = Self::find_initial_column_def(para_src);
            // TypesetEngine을 main pagination으로 사용. RHWP_USE_PAGINATOR=1 로 fallback 가능.
            let use_paginator = std::env::var("RHWP_USE_PAGINATOR")
                .map(|v| v == "1")
                .unwrap_or(false);
            let mut result = if use_paginator {
                let profile = self.document.layout_profile();
                paginator.paginate_with_measured_profile(
                    para_src,
                    &measured,
                    &section.section_def.page_def,
                    &column_def,
                    idx,
                    &self.styles.para_styles,
                    crate::renderer::pagination::PaginationOpts {
                        hide_empty_line: section.section_def.hide_empty_line,
                        respect_vpos_reset: self.respect_vpos_reset,
                        is_hwp3_variant: profile.hwp3_layout(),
                        footnote_shape: Some(section.section_def.footnote_shape.clone()),
                    },
                    profile,
                )
            } else {
                use crate::renderer::pagination::{DeferredEndnote, EndnoteDeferral, EndnoteRef};
                use crate::renderer::typeset::TypesetEngine;
                // [미주 배치 — Hancom EndnoteEndOfSection vs EndnoteEndOfDocument]
                // rhwp 는 지금까지 구역마다 미주를 그 구역 끝에 렌더했으나(END_OF_SECTION),
                // 한컴 기본값은 END_OF_DOCUMENT(EACH_COLUMN)로 문서 끝에 모아 렌더한다.
                // END_OF_DOCUMENT 구역의 미주 본문은 마지막 구역 끝(=문서 끝)으로 미룬다.
                // (참조 표시 위첨자는 원래 위치에 남는다.) 단일 구역은 구역 끝 ≡ 문서 끝
                // 이라 동작 불변 — 회귀 없음.
                use crate::model::footnote::FootnotePlacement;
                let section_count = self.document.sections.len();
                let is_last_section = idx + 1 == section_count;
                let is_doc_end = matches!(
                    section.section_def.endnote_shape.placement,
                    FootnotePlacement::EachColumn
                );
                // 마지막 구역: 앞선 END_OF_DOCUMENT 구역들의 미주 본문을 문서 순서로 수집.
                let deferred: Vec<DeferredEndnote> = if is_last_section && section_count > 1 {
                    let mut acc = Vec::new();
                    for (sj, sec_j) in self.document.sections.iter().enumerate() {
                        if sj >= idx {
                            break;
                        }
                        if !matches!(
                            sec_j.section_def.endnote_shape.placement,
                            FootnotePlacement::EachColumn
                        ) {
                            continue;
                        }
                        for (pi, para) in sec_j.paragraphs.iter().enumerate() {
                            for (ci, ctrl) in para.controls.iter().enumerate() {
                                if let crate::model::control::Control::Endnote(en) = ctrl {
                                    acc.push(DeferredEndnote {
                                        reff: EndnoteRef {
                                            number: en.number,
                                            section_index: sj,
                                            para_index: pi,
                                            control_index: ci,
                                        },
                                        endnote: (**en).clone(),
                                    });
                                }
                            }
                        }
                    }
                    acc
                } else {
                    Vec::new()
                };
                let endnote_deferral = if section_count <= 1 {
                    EndnoteDeferral::None
                } else if is_last_section {
                    if deferred.is_empty() {
                        EndnoteDeferral::None
                    } else {
                        EndnoteDeferral::RenderAll(&deferred)
                    }
                } else if is_doc_end {
                    EndnoteDeferral::Suppress
                } else {
                    EndnoteDeferral::None
                };
                let typesetter = TypesetEngine::new(self.dpi);
                typesetter.typeset_section_with_variant(
                    para_src,
                    composed,
                    &self.styles,
                    &section.section_def.page_def,
                    &column_def,
                    idx,
                    &measured.tables,
                    section.section_def.hide_empty_line,
                    profile,
                    hwp3_origin_flow_spacing_before,
                    hwp3_origin_page_tolerance,
                    Some(&section.section_def.footnote_shape),
                    Some(&section.section_def.endnote_shape),
                    force_breaks.get(idx).unwrap_or(&empty_breaks),
                    endnote_deferral,
                )
            };
            if let Some(started) = issue2424_typeset_started {
                issue2424_typeset_elapsed += started.elapsed();
            }
            let issue2424_postprocess_started =
                issue2424_profile_enabled.then(std::time::Instant::now);

            // [Task #1086 Stage 3] HWP3 변환본의 표지성 구역은 한컴이 직전
            // 구역이 홀수 쪽에서 끝날 때 빈 쪽을 하나 삽입해 다음 구역 제목을
            // 홀수 쪽으로 맞춘다(hwpspec.hwp Part II). 본문 조판 규칙을 넓히지
            // 않도록 첫 문단의 표지/감추기/쪽나누기 패턴이 모두 맞는 경우만 보정한다.
            if should_insert_hwp3_title_filler_page(
                hwp3_origin_page_tolerance,
                idx,
                section,
                carry_last_page_number,
            ) {
                insert_hwp3_title_filler_page(&mut result, idx);
            }

            self.measured_tables[idx] = measured.tables.clone();
            self.measured_sections[idx] = measured;

            // ── 수렴 감지: 이전 페이지네이션과 비교하여 변경 흡수 지점 탐색 ──
            // 판단 후 검증: 수렴으로 복사한 결과를 full pagination과 비교하여 정합성 확인
            let offset = self.para_offset.get(idx).copied().unwrap_or(0);
            if offset != 0 {
                let old_result = &self.pagination[idx];
                if let Some(converge_page) = result.find_convergence(old_result, offset) {
                    let new_page_count = result.pages.len();
                    let old_page_count = old_result.pages.len();
                    if converge_page > 0
                        && converge_page < new_page_count
                        && converge_page < old_page_count
                    {
                        // 검증: full pagination에서 수렴 이후 페이지가 old+offset와 일치하는지 확인
                        let mut verified = true;
                        let check_end = result.pages.len().min(old_page_count);
                        for pi in converge_page..check_end {
                            let new_page = &result.pages[pi];
                            let old_page = &old_result.pages[pi];
                            let new_items: Vec<usize> = new_page
                                .column_contents
                                .iter()
                                .flat_map(|cc| cc.items.iter().map(|it| it.para_index()))
                                .collect();
                            let old_items: Vec<usize> = old_page
                                .column_contents
                                .iter()
                                .flat_map(|cc| {
                                    cc.items
                                        .iter()
                                        .map(|it| (it.para_index() as i64 + offset as i64) as usize)
                                })
                                .collect();
                            if new_items != old_items {
                                eprintln!("CONVERGENCE_VERIFY_FAIL: sec{} page {} new={:?} old+offset={:?}",
                                    idx, pi + 1, new_items, old_items);
                                verified = false;
                                break;
                            }
                        }
                        if result.pages.len() != old_page_count {
                            verified = false;
                        }

                        if verified {
                            eprintln!(
                                "CONVERGENCE: sec{} page {} 수렴 확인 ({}페이지 재사용 가능)",
                                idx,
                                converge_page + 1,
                                old_page_count - converge_page
                            );
                        }
                    }
                }
            }

            // [#5802] 이 구역 정의가 반영되기 **전**의 carry 스냅샷 — 아래 재선택
            // 블록의 슬롯(종류×홀짝) 단위 상속 폴백이 쓴다. 현재 구역 정의까지 섞인
            // carry 로 폴백하면 정의 문단 앞 쪽들이 자기 구역의 (나중) 정의를 미리
            // 쓰게 되므로, 앞 구역까지의 상태를 따로 보관한다.
            let carry_hf_before_section = (
                carry_header_odd.clone(),
                carry_header_even.clone(),
                carry_footer_odd.clone(),
                carry_footer_even.clone(),
            );
            // 머리말/꼬리말 carry 업데이트:
            // 페이지 active_header뿐 아니라 구역에 정의된 머리말 컨트롤도 carry에 반영
            // (짝수 페이지가 없어도 Even 머리말이 다음 구역에 상속되어야 함)
            {
                use crate::model::header_footer::HeaderFooterApply as HFA;
                let mut entries: Vec<(usize, HeaderFooterRef, bool, HFA)> = Vec::new();
                for (pi, para) in section.paragraphs.iter().enumerate() {
                    for (ci, ctrl) in para.controls.iter().enumerate() {
                        match ctrl {
                            Control::Header(h) => {
                                entries.push((
                                    pi,
                                    HeaderFooterRef {
                                        para_index: pi,
                                        control_index: ci,
                                        source_section_index: idx,
                                        table_path: Vec::new(),
                                    },
                                    true,
                                    h.apply_to,
                                ));
                            }
                            Control::Footer(f) => {
                                entries.push((
                                    pi,
                                    HeaderFooterRef {
                                        para_index: pi,
                                        control_index: ci,
                                        source_section_index: idx,
                                        table_path: Vec::new(),
                                    },
                                    false,
                                    f.apply_to,
                                ));
                            }
                            Control::Table(table) => {
                                crate::renderer::pagination::collect_nested_header_footer_controls(
                                    table,
                                    pi,
                                    idx,
                                    ci,
                                    &[],
                                    &mut entries,
                                );
                            }
                            _ => {}
                        }
                    }
                }

                for (_, reference, is_header, apply_to) in entries {
                    let (odd, even) = if is_header {
                        (&mut carry_header_odd, &mut carry_header_even)
                    } else {
                        (&mut carry_footer_odd, &mut carry_footer_even)
                    };
                    match apply_to {
                        HFA::Both => {
                            *odd = Some(reference.clone());
                            *even = Some(reference);
                        }
                        HFA::Odd => *odd = Some(reference),
                        HFA::Even => *even = Some(reference),
                    }
                }
            }

            // 구역 간 page_number_pos 상속: 이 구역에 PageNumberPos가 없으면 이전 구역 값 사용
            let section_has_own_pnp = result.pages.iter().any(|p| p.page_number_pos.is_some());
            if !section_has_own_pnp {
                if let Some(ref prev_pnp) = carry_page_number_pos {
                    for page in &mut result.pages {
                        page.page_number_pos = Some(prev_pnp.clone());
                    }
                }
            }

            // 구역 간 쪽번호 연속: NewNumber(Page) 컨트롤이 없으면 이전 구역에서 이어짐
            if idx > 0 && carry_last_page_number > 0 {
                use crate::model::control::{AutoNumberType, Control};
                let has_new_number = section.paragraphs.iter().any(|p|
                    p.controls.iter().any(|c| matches!(c, Control::NewNumber(nn) if nn.number_type == AutoNumberType::Page))
                );
                if !has_new_number {
                    // [Issue #6206] 표 셀 안 `newNum` 은 위 최상위 스캔(`has_new_number`)에
                    // 걸리지 않는다. 그런 구역에도 carry 를 더하되, 재시작이 발화한 쪽부터는
                    // 멈춘다 — `새 번호로 시작` 값은 절대값이라 carry 를 얹으면 안 된다.
                    // (재시작 앞 쪽들은 종전대로 앞 구역에서 이어져야 한다.)
                    for page in &mut result.pages {
                        if page.page_number_restarted {
                            break;
                        }
                        page.page_number += carry_last_page_number;
                    }
                }
            }

            // 맞쪽 편집 layout 은 구역 간 쪽번호 carry 이후 최종 page_number 기준으로 갱신한다.
            apply_page_number_layouts_for_section(&mut result, section);

            // 바탕쪽 선택은 구역 간 쪽번호 carry 보정 이후 최종 page_number 기준으로 수행한다.
            assign_master_pages_for_section(
                &mut result,
                idx,
                section,
                &carry_master_odd,
                &carry_master_even,
            );
            update_master_page_carry_from_section(
                idx,
                section,
                &mut carry_master_odd,
                &mut carry_master_even,
            );

            // 구역 간 머리말/꼬리말 상속 (쪽번호 보정 이후 실행)
            if idx > 0 {
                let section_has_header = result.pages.iter().any(|p| p.active_header.is_some());
                if !section_has_header {
                    for (pi, page) in result.pages.iter_mut().enumerate() {
                        let is_odd = page.page_number % 2 == 1;
                        page.active_header = if is_odd {
                            carry_header_odd
                                .clone()
                                .or_else(|| carry_header_even.clone())
                        } else {
                            carry_header_even
                                .clone()
                                .or_else(|| carry_header_odd.clone())
                        };
                    }
                }
                let section_has_footer = result.pages.iter().any(|p| p.active_footer.is_some());
                if !section_has_footer {
                    for (pi, page) in result.pages.iter_mut().enumerate() {
                        let is_odd = page.page_number % 2 == 1;
                        page.active_footer = if is_odd {
                            carry_footer_odd
                                .clone()
                                .or_else(|| carry_footer_even.clone())
                        } else {
                            carry_footer_even
                                .clone()
                                .or_else(|| carry_footer_odd.clone())
                        };
                    }
                }
            }
            // 첫 쪽 감추기: hide_header/hide_footer가 true이면 구역 첫 쪽의 머리말/꼬리말 제거
            if section.section_def.hide_header {
                if let Some(first_page) = result.pages.first_mut() {
                    first_page.active_header = None;
                }
            }
            if section.section_def.hide_footer {
                if let Some(first_page) = result.pages.first_mut() {
                    first_page.active_footer = None;
                }
            }

            // carry 업데이트
            if let Some(last) = result.pages.last() {
                if last.page_number_pos.is_some() {
                    carry_page_number_pos = last.page_number_pos.clone();
                }
                carry_last_page_number = last.page_number;
            }

            // 같은 구역 내 머리말/꼬리말 재선택:
            // pagination 은 구역 **지역** 쪽번호로 골랐다. 구역 간 쪽번호 carry 가 홀수면
            // 그 구역 모든 쪽의 홀짝이 뒤집히므로, carry 가 반영된 최종 쪽번호로 다시 고른다.
            // 규칙은 pagination 과 같은 `ActiveHeaderFooter` 를 쓴다 — 같은 규칙의 사본을
            // 여기에 따로 두면 홀짝만 보고 구체성을 놓친다 (#3234).
            {
                use crate::model::header_footer::HeaderFooterApply as HFA;
                use crate::renderer::pagination::{ActiveHeaderFooter, PageItem};

                let mut entries: Vec<(usize, HeaderFooterRef, bool, HFA)> = Vec::new();
                for (pi, para) in section.paragraphs.iter().enumerate() {
                    for (ci, ctrl) in para.controls.iter().enumerate() {
                        match ctrl {
                            Control::Header(h) => {
                                entries.push((
                                    pi,
                                    HeaderFooterRef {
                                        para_index: pi,
                                        control_index: ci,
                                        source_section_index: idx,
                                        table_path: Vec::new(),
                                    },
                                    true,
                                    h.apply_to,
                                ));
                            }
                            Control::Footer(f) => {
                                entries.push((
                                    pi,
                                    HeaderFooterRef {
                                        para_index: pi,
                                        control_index: ci,
                                        source_section_index: idx,
                                        table_path: Vec::new(),
                                    },
                                    false,
                                    f.apply_to,
                                ));
                            }
                            // 표 셀 안에 중첩 정의된 머리말/꼬리말도 수집한다. (수능 수학
                            // 선택과목 소책자의 4쪽 머리말이 제목표 셀 안에 있는 사례 — 이게
                            // 없으면 4쪽 쪽번호가 2쪽 머리말로 대체돼 잘못 표시된다.)
                            Control::Table(table) => {
                                crate::renderer::pagination::collect_nested_header_footer_controls(
                                    table,
                                    pi,
                                    idx,
                                    ci,
                                    &[],
                                    &mut entries,
                                );
                            }
                            _ => {}
                        }
                    }
                }
                let has_header = entries.iter().any(|(_, _, is_header, _)| *is_header);
                let has_footer = entries.iter().any(|(_, _, is_header, _)| !*is_header);

                let mut active = ActiveHeaderFooter::default();
                for page in result.pages.iter_mut() {
                    // 머리말은 정의된 문단이 나온 쪽부터 적용된다.
                    let page_last_para = page
                        .column_contents
                        .iter()
                        .flat_map(|col| col.items.iter())
                        .filter_map(|item| match item {
                            PageItem::FullParagraph { para_index } => Some(*para_index),
                            PageItem::PartialParagraph { para_index, .. } => Some(*para_index),
                            PageItem::Table { para_index, .. } => Some(*para_index),
                            PageItem::PartialTable { para_index, .. } => Some(*para_index),
                            PageItem::Shape { para_index, .. } => Some(*para_index),
                            PageItem::EndnoteSeparator { .. } => None,
                        })
                        .max();
                    if let Some(last_pi) = page_last_para {
                        active.accumulate(&entries, last_pi);
                    }
                    let (header, footer) = active.active(page.page_number);
                    // 이 구역에 없는 종류는 건드리지 않는다 — 앞 구역에서 상속받은 것이 살아 있다.
                    //
                    // [#5802] 종류는 있어도 **슬롯(홀짝)** 이 비면 앞 구역 carry 의 같은
                    // 홀짝 슬롯을 상속한다. 종전에는 종류 단위로 통째 덮어써, 홀수
                    // 머리말만 정의한 구역의 짝수 쪽(611쪽 보고서 ~300쪽)이 앞 구역의
                    // 짝수 정의를 잃고 빈 머리말이 됐다. 폴백은 홀짝 교차 없이 같은
                    // 슬롯만 본다 — 홀수 전용 정의가 짝수 쪽에 번지지 않게.
                    let is_odd = page.page_number % 2 == 1;
                    let (prev_h_odd, prev_h_even, prev_f_odd, prev_f_even) =
                        &carry_hf_before_section;
                    if has_header {
                        page.active_header = header.or_else(|| {
                            if is_odd {
                                prev_h_odd.clone()
                            } else {
                                prev_h_even.clone()
                            }
                        });
                    }
                    if has_footer {
                        page.active_footer = footer.or_else(|| {
                            if is_odd {
                                prev_f_odd.clone()
                            } else {
                                prev_f_even.clone()
                            }
                        });
                    }
                }
            }
            // 같은 구역 머리말/꼬리말 보정이 첫쪽 감춤을 되돌리지 않도록 마지막에 재적용한다.
            if let Some(first_page) = result.pages.first_mut() {
                if section.section_def.hide_header {
                    first_page.active_header = None;
                }
                if section.section_def.hide_footer {
                    first_page.active_footer = None;
                }
            }
            self.pagination[idx] = result;
            self.dirty_sections[idx] = false;
            remeasured_sections[idx] = true;
            // 문단 dirty 비트맵 초기화 (모든 문단 clean)
            let para_count = section.paragraphs.len();
            self.dirty_paragraphs[idx] = Some(vec![false; para_count]);

            // 문단→단 인덱스 매핑 구축
            {
                use crate::renderer::pagination::PageItem;
                let mut col_map = vec![0u16; para_count];
                for page in &self.pagination[idx].pages {
                    for col_content in &page.column_contents {
                        let ci = col_content.column_index;
                        for item in &col_content.items {
                            let pi = match item {
                                PageItem::FullParagraph { para_index } => *para_index,
                                PageItem::PartialParagraph { para_index, .. } => *para_index,
                                PageItem::Table { para_index, .. } => *para_index,
                                PageItem::PartialTable { para_index, .. } => *para_index,
                                PageItem::Shape { para_index, .. } => *para_index,
                                PageItem::EndnoteSeparator { .. } => usize::MAX,
                            };
                            if pi < col_map.len() {
                                col_map[pi] = ci;
                            }
                        }
                    }
                }
                self.para_column_map[idx] = col_map;
            }
            if let Some(started) = issue2424_postprocess_started {
                issue2424_postprocess_elapsed += started.elapsed();
            }
        }

        let issue2424_cleanup_started = issue2424_profile_enabled.then(std::time::Instant::now);
        // para_offset 리셋 (수렴 감지 완료)
        for off in &mut self.para_offset {
            *off = 0;
        }

        // 표 dirty 플래그 초기화. [#4325] 이번 패스에서 재측정하지 않고 건너뛴 구역은
        // 제외한다 — 그 구역의 표는 measure_section_incremental이 아직 소비하지 않았으므로
        // dirty를 여기서 지우면 이후 실제로 재측정될 때 변경 전 MeasuredTable을 그대로
        // clone하게 된다(issue #4325).
        for (idx, section) in self.document.sections.iter_mut().enumerate() {
            if !remeasured_sections[idx] {
                continue;
            }
            for para in &mut section.paragraphs {
                for ctrl in &mut para.controls {
                    if let Control::Table(table) = ctrl {
                        table.dirty = false;
                    }
                }
            }
        }
        let issue2424_cleanup_elapsed = issue2424_cleanup_started
            .map(|started| started.elapsed())
            .unwrap_or_default();
        if let Some(pass_started) = issue2424_pass_started {
            let total = pass_started.elapsed();
            let accounted = issue2424_invalidate_elapsed
                + issue2424_normalize_elapsed
                + issue2424_setup_elapsed
                + issue2424_measure_elapsed
                + issue2424_typeset_elapsed
                + issue2424_postprocess_elapsed
                + issue2424_cleanup_elapsed;
            let other = total.saturating_sub(accounted);
            let page_count: usize = self
                .pagination
                .iter()
                .map(|section| section.pages.len())
                .sum();
            let mode = if issue2424_warm_sections == 0 {
                "initial"
            } else {
                "incremental"
            };
            eprintln!(
                "RHWP_2424_PAGINATION_PROFILE mode={mode} sections={} dirty_sections={} pages={} total_ms={:.3} invalidate_ms={:.3} normalize_ms={:.3} setup_ms={:.3} measure_ms={:.3} typeset_ms={:.3} postprocess_ms={:.3} cleanup_ms={:.3} other_ms={:.3}",
                self.document.sections.len(),
                issue2424_dirty_sections,
                page_count,
                total.as_secs_f64() * 1000.0,
                issue2424_invalidate_elapsed.as_secs_f64() * 1000.0,
                issue2424_normalize_elapsed.as_secs_f64() * 1000.0,
                issue2424_setup_elapsed.as_secs_f64() * 1000.0,
                issue2424_measure_elapsed.as_secs_f64() * 1000.0,
                issue2424_typeset_elapsed.as_secs_f64() * 1000.0,
                issue2424_postprocess_elapsed.as_secs_f64() * 1000.0,
                issue2424_cleanup_elapsed.as_secs_f64() * 1000.0,
                other.as_secs_f64() * 1000.0,
            );
        }
    }

    /// 글로벌 페이지 번호로 해당 페이지와 문단/구성 목록을 찾는다.
    /// [#2004] 섹션의 render-전용 문단 (부동 이미지 스택 재분류본, 없으면 원본).
    pub(crate) fn section_render_paragraphs(&self, sec_idx: usize) -> &[Paragraph] {
        let source_revision = self
            .render_normalization
            .section_revisions
            .get(sec_idx)
            .copied()
            .unwrap_or(0);
        match self
            .render_normalization
            .sections
            .get(sec_idx)
            .and_then(|section| section.as_ref())
            .filter(|section| section.source_revision == source_revision)
        {
            Some(section) => &section.paragraphs[..],
            None => self
                .document
                .sections
                .get(sec_idx)
                .map(|s| &s.paragraphs[..])
                .unwrap_or(&[]),
        }
    }

    /// [#2004] 섹션의 render-전용 구성 (재분류본, 없으면 원본).
    pub(crate) fn section_render_composed(&self, sec_idx: usize) -> &[ComposedParagraph] {
        let source_revision = self
            .render_normalization
            .section_revisions
            .get(sec_idx)
            .copied()
            .unwrap_or(0);
        match self
            .render_normalization
            .sections
            .get(sec_idx)
            .and_then(|section| section.as_ref())
            .filter(|section| section.source_revision == source_revision)
        {
            Some(section) => &section.composed[..],
            None => self.composed.get(sec_idx).map(|c| &c[..]).unwrap_or(&[]),
        }
    }

    /// [#2004] 부동 전면 이미지 스택 섹션의 정규화본(그림 tac=true 재분류 + 재구성)을 재계산.
    /// 원본 `document`/`composed` 는 무손상(save 무결). paginate 시작 시 호출.
    pub(crate) fn compute_render_normalized(&mut self) {
        let sec_count = self.document.sections.len();
        self.render_normalization
            .section_revisions
            .resize(sec_count, 0);
        let mut previous = std::mem::take(&mut self.render_normalization.sections);
        previous.resize_with(sec_count, || None);
        let mut out = Vec::with_capacity(sec_count);
        for idx in 0..sec_count {
            let source_revision = self.render_normalization.section_revisions[idx];
            if previous[idx]
                .as_ref()
                .is_some_and(|section| section.source_revision == source_revision)
            {
                out.push(previous[idx].take());
                continue;
            }
            let section = &self.document.sections[idx];
            let pd = &section.section_def.page_def;
            let body_area = PageAreas::from_page_def(pd).body_area;
            let body_h_hu = body_area.height();
            let body_bottom_hu = body_area.bottom;
            let min_height_hu = (body_h_hu / 2).max(1);
            let matches: Vec<usize> = section
                .paragraphs
                .iter()
                .enumerate()
                .filter(|(_, p)| {
                    para_is_floating_image_stack(p, min_height_hu)
                        && !body_pile_stays_on_anchor_page(p, min_height_hu, body_bottom_hu)
                })
                .map(|(i, _)| i)
                .collect();
            // [#2004] 표 셀 내부 부동 이미지 스택 검출(본문 스택과 별개 경로).
            let has_cell_stack = section.paragraphs.iter().any(|p| {
                p.controls.iter().any(|ctrl| match ctrl {
                    Control::Table(table) => table.cells.iter().any(|cell| {
                        cell.paragraphs
                            .iter()
                            .any(|cp| para_is_floating_image_stack(cp, min_height_hu))
                    }),
                    _ => false,
                })
            });
            if matches.is_empty() && !has_cell_stack {
                out.push(None);
                continue;
            }
            let mut np = section.paragraphs.clone();
            if has_cell_stack {
                for p in np.iter_mut() {
                    reclassify_cell_floating_stacks(p, min_height_hu);
                }
            }
            for &i in &matches {
                reclassify_floating_pictures_inline(&mut np[i]);
            }
            let base = self.composed.get(idx);
            let nc: Vec<ComposedParagraph> = np
                .iter()
                .enumerate()
                .map(|(i, p)| {
                    if matches.binary_search(&i).is_ok() {
                        let mut c = compose_paragraph(p);
                        // [#2004] composer 가 line_seg 부족(HWP5 빈-문단)으로 1줄로 붕괴하면
                        // 그림 수만큼 줄을 합성(모두 char_start 동일)해 Stage2 stacked 게이트
                        // (comp.lines.len()==tac_controls) 가 발동하게 한다.
                        let npics = c.tac_controls.len();
                        if npics >= 2 && c.lines.len() != npics && !c.lines.is_empty() {
                            let template = c.lines[0].clone();
                            let mut lines = Vec::with_capacity(npics);
                            for k in 0..npics {
                                let lh_hu = p
                                    .controls
                                    .get(c.tac_controls[k].2)
                                    .and_then(|ctrl| {
                                        floating_stack_picture_common(ctrl)
                                            .map(|cm| cm.height as i32)
                                    })
                                    .unwrap_or(template.line_height);
                                let mut l = template.clone();
                                l.runs = Vec::new();
                                l.char_start = 0;
                                l.line_height = lh_hu;
                                l.has_line_break = false;
                                lines.push(l);
                            }
                            c.lines = lines;
                        }
                        c
                    } else {
                        base.and_then(|c| c.get(i))
                            .cloned()
                            .unwrap_or_else(|| compose_paragraph(p))
                    }
                })
                .collect();
            out.push(Some(super::super::RenderNormalizedSection {
                source_revision,
                paragraphs: std::sync::Arc::new(np),
                composed: std::sync::Arc::new(nc),
            }));
        }
        self.render_normalization.sections = out;
        let overlay = std::sync::Arc::new(
            crate::renderer::render_normalization::RenderNormalizationOverlay::from_document_reusing(
                &self.document,
                &self.render_normalization.overlay,
            ),
        );
        self.render_normalization.overlay = std::sync::Arc::clone(&overlay);
        self.layout_engine.set_render_normalization_overlay(overlay);
    }

    pub(crate) fn refresh_render_normalized_body_paragraph_after_edit(
        &mut self,
        section_idx: usize,
        para_idx: usize,
    ) {
        let source_para = self.document.sections[section_idx].paragraphs[para_idx].clone();
        let source_composed = self.composed[section_idx][para_idx].clone();
        let Some(Some(section)) = self.render_normalization.sections.get_mut(section_idx) else {
            return;
        };
        if let Some(target) = std::sync::Arc::make_mut(&mut section.paragraphs).get_mut(para_idx) {
            *target = source_para;
        }
        if let Some(target) = std::sync::Arc::make_mut(&mut section.composed).get_mut(para_idx) {
            *target = source_composed;
        }
    }

    /// [#2308] 구조가 안정적인 deferred 셀 편집의 logical path revision을 올린다.
    ///
    /// API 호환을 위해 입력의 table-caption sentinel은 여기서만 해석하고, derived-state
    /// cache에는 명시적인 `RenderPathEntry`만 저장한다. 경로 불일치는 stale cache를
    /// 조용히 유지하지 않고 오류로 표면화한다.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn mark_render_normalization_path_dirty(
        &mut self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
    ) -> Result<(), HwpError> {
        use crate::renderer::render_normalization::{RenderPath, RenderPathEntry};

        let control = self
            .document
            .sections
            .get(section_idx)
            .and_then(|section| section.paragraphs.get(parent_para_idx))
            .and_then(|paragraph| paragraph.controls.get(control_idx))
            .ok_or_else(|| {
                HwpError::RenderError(format!(
                    "render normalization path mismatch: section={section_idx} para={parent_para_idx} control={control_idx}"
                ))
            })?;

        let entry = match control {
            Control::Table(table) if cell_idx == super::super::TABLE_CAPTION_CELL_SENTINEL => {
                let valid = table
                    .caption
                    .as_ref()
                    .is_some_and(|caption| cell_para_idx < caption.paragraphs.len());
                if !valid {
                    return Err(HwpError::RenderError(format!(
                        "render normalization table-caption path mismatch: control={control_idx} para={cell_para_idx}"
                    )));
                }
                RenderPathEntry::TableCaption {
                    control_index: control_idx,
                    paragraph_index: cell_para_idx,
                }
            }
            Control::Table(table) => {
                let valid = table
                    .cells
                    .get(cell_idx)
                    .is_some_and(|cell| cell_para_idx < cell.paragraphs.len());
                if !valid {
                    return Err(HwpError::RenderError(format!(
                        "render normalization table-cell path mismatch: control={control_idx} cell={cell_idx} para={cell_para_idx}"
                    )));
                }
                RenderPathEntry::TableCell {
                    control_index: control_idx,
                    cell_index: cell_idx,
                    paragraph_index: cell_para_idx,
                }
            }
            Control::Shape(shape) => {
                let valid = super::super::helpers::get_textbox_from_shape(shape)
                    .is_some_and(|textbox| cell_para_idx < textbox.paragraphs.len());
                if !valid {
                    return Err(HwpError::RenderError(format!(
                        "render normalization shape-textbox path mismatch: control={control_idx} para={cell_para_idx}"
                    )));
                }
                RenderPathEntry::ShapeTextBox {
                    control_index: control_idx,
                    paragraph_index: cell_para_idx,
                }
            }
            Control::Picture(picture) => {
                let valid = picture
                    .caption
                    .as_ref()
                    .is_some_and(|caption| cell_para_idx < caption.paragraphs.len());
                if !valid {
                    return Err(HwpError::RenderError(format!(
                        "render normalization picture-caption path mismatch: control={control_idx} para={cell_para_idx}"
                    )));
                }
                RenderPathEntry::PictureCaption {
                    control_index: control_idx,
                    paragraph_index: cell_para_idx,
                }
            }
            _ => {
                return Err(HwpError::RenderError(format!(
                    "render normalization unsupported path control: section={section_idx} para={parent_para_idx} control={control_idx}"
                )));
            }
        };

        let path = RenderPath {
            section_index: section_idx,
            parent_paragraph_index: parent_para_idx,
            entries: vec![entry],
            target_control_index: None,
        };
        let revision = self
            .render_normalization
            .path_revisions
            .entry(path)
            .or_insert(0);
        *revision = revision.wrapping_add(1);
        Ok(())
    }

    pub(crate) fn find_page(
        &self,
        page_num: u32,
    ) -> Result<
        (
            &crate::renderer::pagination::PageContent,
            &[crate::model::paragraph::Paragraph],
            &[ComposedParagraph],
        ),
        HwpError,
    > {
        let mut offset = 0u32;
        for (sec_idx, pr) in self.pagination.iter().enumerate() {
            if (page_num as usize) < offset as usize + pr.pages.len() {
                let local_idx = (page_num - offset) as usize;
                // [#2004] render-전용 정규화본 우선(부동 이미지 스택 재분류). 없으면 원본.
                let paragraphs = self.section_render_paragraphs(sec_idx);
                let composed = self.section_render_composed(sec_idx);
                return Ok((&pr.pages[local_idx], paragraphs, composed));
            }
            offset += pr.pages.len() as u32;
        }
        Err(HwpError::PageOutOfRange(page_num))
    }

    /// [#3697] dump-pages 텍스트/JSON 두 출력이 공유하는 구역 전처리.
    ///
    /// 미주 문단 합침(#1082)과 items 밖 문단(어울림/빈 줄 감춤) 페이지 귀속
    /// (#1700·#1705·#1955)을 한 곳에 두어, 텍스트 덤프와 JSON 계약이 서로 다른
    /// 진단을 보고하는 드리프트를 구조적으로 차단한다.
    fn page_dump_section_ctx<'a>(
        &'a self,
        sec_idx: usize,
        pr: &'a PaginationResult,
        sec_start_page: u32,
    ) -> PageDumpSectionCtx<'a> {
        use crate::model::control::Control;
        use crate::renderer::hwpunit_to_px;
        use crate::renderer::pagination::PageItem;

        let dpi = self.dpi;
        let body_paragraphs = self.section_render_paragraphs(sec_idx);
        // [Task #1082] 미주 paragraphs 를 본문 뒤에 합쳐 인덱싱 정합.
        // 미주 PageItem 의 para_index = body_paragraphs.len() + 미주 로컬 인덱스
        // (typeset.rs en_para_idx 와 동일). 합치지 않으면 미주 항목이 out-of-bounds 로
        // 본문이 빈 것처럼 표시된다(시험지 다단 미주 디버깅 차단).
        let body_len = body_paragraphs.len();
        let paragraphs: std::borrow::Cow<'a, [Paragraph]> = if pr.endnote_paragraphs.is_empty() {
            std::borrow::Cow::Borrowed(body_paragraphs)
        } else {
            std::borrow::Cow::Owned(
                body_paragraphs
                    .iter()
                    .chain(pr.endnote_paragraphs.iter())
                    .cloned()
                    .collect(),
            )
        };

        // [Task #1700] cc.items 에 없는 문단(어울림 흡수 / 빈 줄 감춤)을 페이지 PI 로 표면화
        // 하기 위한 사전 패스. 한글(OLE)은 이들을 본문 문단으로 카운트하므로 문단→페이지
        // 매핑이 정합된다. 레이아웃/렌더 트리는 변경하지 않으므로 기하·페이지 수·시각 불변.
        // 1) items 문단 → 표시 페이지(global+1) 매핑 — **마지막** 출현 페이지(다중 페이지 표는
        //    끝 페이지에 빈 문단이 따라오므로 last-page 가 한글과 정합).
        let mut item_disp_page: std::collections::HashMap<usize, u32> =
            std::collections::HashMap::new();
        // [#1705] 표의 첫(앵커) 출현 페이지 — 어울림 빈 문단이 표 옆 wrap zone 에 있을 때 사용.
        let mut item_first_page: std::collections::HashMap<usize, u32> =
            std::collections::HashMap::new();
        for (li, page) in pr.pages.iter().enumerate() {
            let disp = sec_start_page + li as u32 + 1;
            for cc in &page.column_contents {
                for item in &cc.items {
                    let pidx = match item {
                        PageItem::FullParagraph { para_index }
                        | PageItem::PartialParagraph { para_index, .. }
                        | PageItem::Table { para_index, .. }
                        | PageItem::PartialTable { para_index, .. }
                        | PageItem::Shape { para_index, .. } => Some(*para_index),
                        _ => None,
                    };
                    if let Some(p) = pidx {
                        item_disp_page.insert(p, disp); // 마지막(끝) 페이지
                        item_first_page.entry(p).or_insert(disp); // 첫(앵커) 페이지
                    }
                }
            }
        }
        // 2) 표면화 대상을 페이지별로 그룹화: (para_index, is_wrap, table_pi).
        //    - 어울림(wrap-around): 앵커 표(table_para_index)의 페이지에 귀속.
        //    - 빈 줄 감춤(hidden_empty_paras): 직전 item 문단(대개 표)의 페이지에 귀속.
        let mut extra_by_page: std::collections::HashMap<u32, Vec<(usize, bool, usize)>> =
            std::collections::HashMap::new();
        let mut emitted_extra: std::collections::HashSet<usize> = std::collections::HashSet::new();
        for page in pr.pages.iter() {
            for cc in &page.column_contents {
                for wp in &cc.wrap_around_paras {
                    if !emitted_extra.insert(wp.para_index) {
                        continue;
                    }
                    // [#1705] 어울림(floating) 표의 트레일링 빈 문단 귀속:
                    //   line_seg 폭(sw)이 좁으면(표 옆 wrap zone) 표의 **첫(앵커) 페이지**,
                    //   전체 폭이면(표 아래로 흐름) 표의 **마지막 페이지**.
                    //   한글은 wrap zone 문단을 앵커 페이지에, 전체폭 문단을 표 끝 페이지에 둔다.
                    let sw_px = paragraphs
                        .get(wp.para_index)
                        .and_then(|p| p.line_segs.first())
                        .map(|s| hwpunit_to_px(s.segment_width as i32, dpi))
                        .unwrap_or(0.0);
                    let body_w = page.layout.body_area.width;
                    let is_wrap_zone = sw_px > 0.0 && sw_px < body_w * 0.9;
                    // [#1955] 글뒤로/글앞으로 anchor 표는 플로우를 소비하지 않으므로
                    // 후행 문단은 폭과 무관하게 **앵커 페이지** 귀속 (한글: stored
                    // LINE_SEG vpos 가 앵커 쪽 위치를 가리킴).
                    let anchor_behind = paragraphs
                        .get(wp.table_para_index)
                        .map(|p| {
                            p.controls.iter().any(|c| {
                                matches!(c, Control::Table(t)
                                    if !t.common.treat_as_char
                                        && matches!(t.common.text_wrap,
                                            crate::model::shape::TextWrap::BehindText
                                                | crate::model::shape::TextWrap::InFrontOfText))
                            })
                        })
                        .unwrap_or(false);
                    let disp = if is_wrap_zone || anchor_behind {
                        item_first_page.get(&wp.table_para_index)
                    } else {
                        item_disp_page.get(&wp.table_para_index)
                    }
                    .copied()
                    .unwrap_or(sec_start_page + 1);
                    extra_by_page.entry(disp).or_default().push((
                        wp.para_index,
                        true,
                        wp.table_para_index,
                    ));
                }
            }
        }
        let mut hidden_sorted: Vec<usize> = pr
            .hidden_empty_paras
            .iter()
            .copied()
            .filter(|p| !item_disp_page.contains_key(p) && !emitted_extra.contains(p))
            .collect();
        hidden_sorted.sort_unstable();
        for hidx in hidden_sorted {
            let mut disp = sec_start_page + 1;
            for j in (0..hidx).rev() {
                if let Some(d) = item_disp_page.get(&j) {
                    disp = *d;
                    break;
                }
            }
            extra_by_page
                .entry(disp)
                .or_default()
                .push((hidx, false, 0));
            emitted_extra.insert(hidx);
        }

        PageDumpSectionCtx {
            paragraphs,
            body_len,
            extra_by_page,
        }
    }

    /// 프로덕션 조판(`TypesetEngine::format_paragraph`)이 부여하는 문단 높이.
    /// dump-pages 가 fallback `MeasuredSection` 이 아니라 이 값을 말한다 (#4628).
    pub fn production_paragraph_height(
        &self,
        section_idx: usize,
        para_index: usize,
        column_width_px: Option<f64>,
    ) -> Option<f64> {
        let col_w =
            column_width_px.or_else(|| self.dump_paragraph_column_width(section_idx, para_index));
        self.dump_production_paragraph_height(section_idx, para_index, col_w)
            .map(|h| h.total)
    }

    /// HeightMeasurer fallback `total_height`. 프로덕션 페이지네이션은 읽지 않는다 (#4628).
    pub fn fallback_measured_paragraph_total_height(
        &self,
        section_idx: usize,
        para_index: usize,
    ) -> Option<f64> {
        self.measured_sections
            .get(section_idx)?
            .get_paragraph_height(para_index)
    }

    fn dump_section_typesetter(&self, sec_idx: usize) -> TypesetEngine {
        let typesetter = TypesetEngine::new(self.dpi);
        typesetter.apply_section_format_context(
            self.section_render_paragraphs(sec_idx),
            &self.styles,
            self.effective_layout_profile(),
        );
        typesetter
    }

    fn dump_paragraph_column_width(&self, sec_idx: usize, para_index: usize) -> Option<f64> {
        use crate::renderer::pagination::PageItem;
        let pr = self.pagination.get(sec_idx)?;
        for page in &pr.pages {
            for cc in &page.column_contents {
                let hit = cc.items.iter().any(|item| {
                    matches!(item, PageItem::FullParagraph { para_index: pi } if *pi == para_index)
                });
                if hit {
                    return Self::dump_column_width_px(page, cc);
                }
            }
        }
        pr.pages
            .first()?
            .layout
            .column_areas
            .first()
            .map(|area| area.width)
    }

    fn dump_production_paragraph_height(
        &self,
        sec_idx: usize,
        para_index: usize,
        column_width_px: Option<f64>,
    ) -> Option<crate::renderer::typeset::DumpFormattedParagraphHeight> {
        let typesetter = self.dump_section_typesetter(sec_idx);
        let body_len = self.section_render_paragraphs(sec_idx).len();
        let pr = self.pagination.get(sec_idx)?;
        let paragraphs: std::borrow::Cow<'_, [Paragraph]> = if pr.endnote_paragraphs.is_empty() {
            std::borrow::Cow::Borrowed(self.section_render_paragraphs(sec_idx))
        } else {
            std::borrow::Cow::Owned(
                self.section_render_paragraphs(sec_idx)
                    .iter()
                    .chain(pr.endnote_paragraphs.iter())
                    .cloned()
                    .collect(),
            )
        };
        self.dump_production_paragraph_height_with(
            &typesetter,
            sec_idx,
            para_index,
            body_len,
            paragraphs.as_ref(),
            column_width_px,
        )
    }

    fn dump_production_paragraph_height_with(
        &self,
        typesetter: &crate::renderer::typeset::TypesetEngine,
        sec_idx: usize,
        para_index: usize,
        body_len: usize,
        paragraphs: &[Paragraph],
        column_width_px: Option<f64>,
    ) -> Option<crate::renderer::typeset::DumpFormattedParagraphHeight> {
        let para = paragraphs.get(para_index)?;
        let composed = if para_index < body_len {
            self.section_render_composed(sec_idx).get(para_index)
        } else {
            None
        };
        Some(typesetter.dump_formatted_paragraph_height(
            para,
            composed,
            &self.styles,
            column_width_px,
            para_index >= body_len,
        ))
    }

    fn dump_column_width_px(
        page: &crate::renderer::pagination::PageContent,
        cc: &crate::renderer::pagination::ColumnContent,
    ) -> Option<f64> {
        cc.zone_layout
            .as_ref()
            .unwrap_or(&page.layout)
            .column_areas
            .get(cc.column_index as usize)
            .or(page.layout.column_areas.first())
            .map(|area| area.width)
    }

    /// [#3697] 페이지네이션 결과를 기계 계약 JSON 으로 덤프 (#3608 1-C).
    ///
    /// 텍스트 덤프(`dump_page_items`)와 같은 순회·같은 구역 전처리
    /// (`page_dump_section_ctx`)를 공유하고, 표현만 구조화 필드로 바꾼다.
    /// 반환값은 `pages` 배열 — 봉투(schemaVersion·source 등)는 CLI 가 감싼다.
    pub fn dump_page_items_json(&self, page_filter: Option<u32>) -> serde_json::Value {
        use crate::model::control::Control;
        use crate::renderer::pagination::PageItem;

        let dpi = self.dpi;
        let mut pages_out: Vec<serde_json::Value> = Vec::new();
        let mut global_page = 0u32;

        for (sec_idx, pr) in self.pagination.iter().enumerate() {
            let ctx = self.page_dump_section_ctx(sec_idx, pr, global_page);
            let paragraphs: &[Paragraph] = &ctx.paragraphs;
            let body_len = ctx.body_len;
            let typesetter = self.dump_section_typesetter(sec_idx);

            // 미주 항목(pi >= body_len)의 원본 위치 — 텍스트 덤프의 `src=...` 와 동일.
            let endnote_source_json = |para_index: usize| -> serde_json::Value {
                if para_index < body_len {
                    return serde_json::Value::Null;
                }
                pr.endnote_para_sources
                    .get(para_index - body_len)
                    .map(|src| {
                        serde_json::json!({
                            "section": src.section_index,
                            "para": src.para_index,
                            "controlIndex": src.control_index,
                            "noteParaIndex": src.note_para_index,
                        })
                    })
                    .unwrap_or(serde_json::Value::Null)
            };

            for page in pr.pages.iter() {
                if let Some(pf) = page_filter {
                    if global_page != pf {
                        global_page += 1;
                        continue;
                    }
                }

                let la = &page.layout;
                let mut columns_out: Vec<serde_json::Value> = Vec::new();
                for (col_idx, cc) in page.column_contents.iter().enumerate() {
                    let hwp_used_px = compute_hwp_used_height(cc, paragraphs, dpi);
                    let mut items_out: Vec<serde_json::Value> = Vec::new();
                    for item in &cc.items {
                        let v = match item {
                            PageItem::FullParagraph { para_index } => {
                                let col_w = Self::dump_column_width_px(page, cc);
                                let height = self
                                    .dump_production_paragraph_height_with(
                                        &typesetter,
                                        sec_idx,
                                        *para_index,
                                        body_len,
                                        paragraphs,
                                        col_w,
                                    )
                                    .map(|mp| {
                                        serde_json::json!({
                                            "total": mp.total,
                                            "spacingBefore": mp.spacing_before,
                                            "lineHeightSum": mp.line_height_sum,
                                            "lineSpacingSum": mp.line_spacing_sum,
                                            "spacingAfter": mp.spacing_after,
                                        })
                                    });
                                serde_json::json!({
                                    "kind": "fullParagraph",
                                    "paraIndex": para_index,
                                    "isEndnote": *para_index >= body_len,
                                    "endnoteSource": endnote_source_json(*para_index),
                                    "height": height,
                                    "vpos": vpos_range_json(paragraphs.get(*para_index), None, None),
                                    "lineSegs": line_seg_brief_json(paragraphs.get(*para_index)),
                                    "textPreview": para_text_preview(paragraphs.get(*para_index)),
                                })
                            }
                            PageItem::PartialParagraph {
                                para_index,
                                start_line,
                                end_line,
                            } => serde_json::json!({
                                "kind": "partialParagraph",
                                "paraIndex": para_index,
                                "startLine": start_line,
                                "endLine": end_line,
                                "isEndnote": *para_index >= body_len,
                                "endnoteSource": endnote_source_json(*para_index),
                                "vpos": vpos_range_json(
                                    paragraphs.get(*para_index),
                                    Some(*start_line),
                                    Some(*end_line),
                                ),
                                "lineSegs": line_seg_brief_json(paragraphs.get(*para_index)),
                            }),
                            PageItem::Table {
                                para_index,
                                control_index,
                            } => serde_json::json!({
                                "kind": "table",
                                "paraIndex": para_index,
                                "controlIndex": control_index,
                                "isEndnote": *para_index >= body_len,
                                "endnoteSource": endnote_source_json(*para_index),
                                "table": table_summary_json(
                                    paragraphs,
                                    *para_index,
                                    *control_index,
                                    dpi,
                                    true,
                                ),
                                "vpos": vpos_range_json(paragraphs.get(*para_index), None, None),
                                "lineSegs": line_seg_brief_json(paragraphs.get(*para_index)),
                            }),
                            PageItem::PartialTable {
                                para_index,
                                control_index,
                                start_row,
                                end_row,
                                is_continuation,
                                start_cut,
                                end_cut,
                                ..
                            } => serde_json::json!({
                                "kind": "partialTable",
                                "paraIndex": para_index,
                                "controlIndex": control_index,
                                "startRow": start_row,
                                "endRow": end_row,
                                "isContinuation": is_continuation,
                                "startCut": start_cut,
                                "endCut": end_cut,
                                "isEndnote": *para_index >= body_len,
                                "endnoteSource": endnote_source_json(*para_index),
                                "table": table_summary_json(
                                    paragraphs,
                                    *para_index,
                                    *control_index,
                                    dpi,
                                    false,
                                ),
                                "vpos": vpos_range_json(paragraphs.get(*para_index), None, None),
                                "lineSegs": line_seg_brief_json(paragraphs.get(*para_index)),
                            }),
                            PageItem::Shape {
                                para_index,
                                control_index,
                            } => {
                                let control = paragraphs
                                    .get(*para_index)
                                    .and_then(|p| p.controls.get(*control_index))
                                    .map(|c| match c {
                                        Control::Shape(s) => serde_json::json!({
                                            "type": "shape",
                                            "textWrap": format!("{:?}", s.common().text_wrap),
                                            "treatAsChar": s.common().treat_as_char,
                                        }),
                                        Control::Picture(p) => serde_json::json!({
                                            "type": "picture",
                                            "treatAsChar": p.common.treat_as_char,
                                        }),
                                        Control::Equation(_) => {
                                            serde_json::json!({ "type": "equation" })
                                        }
                                        _ => serde_json::json!({ "type": "other" }),
                                    });
                                serde_json::json!({
                                    "kind": "shape",
                                    "paraIndex": para_index,
                                    "controlIndex": control_index,
                                    "isEndnote": *para_index >= body_len,
                                    "endnoteSource": endnote_source_json(*para_index),
                                    "control": control,
                                    "vpos": vpos_range_json(paragraphs.get(*para_index), None, None),
                                    "lineSegs": line_seg_brief_json(paragraphs.get(*para_index)),
                                })
                            }
                            PageItem::EndnoteSeparator {
                                separator_length,
                                margin_above,
                                margin_below,
                                line_width,
                                color,
                                ..
                            } => serde_json::json!({
                                "kind": "endnoteSeparator",
                                "separatorLength": separator_length,
                                "marginAbove": margin_above,
                                "marginBelow": margin_below,
                                "lineWidth": line_width,
                                "color": format!("#{:06x}", color & 0x00ff_ffff),
                            }),
                        };
                        items_out.push(v);
                    }
                    columns_out.push(serde_json::json!({
                        "index": col_idx,
                        "itemCount": cc.items.len(),
                        "usedHeight": cc.used_height,
                        "hwpUsedHeight": hwp_used_px,
                        "usedDiff": hwp_used_px.map(|h| cc.used_height - h),
                        "zoneYOffset": cc.zone_y_offset,
                        "items": items_out,
                    }));
                }

                // [Task #1700] cc.items 에 없는 문단(어울림/빈 줄 감춤) — 텍스트 덤프와 동일 귀속.
                let disp_page = global_page + 1;
                let extras_out: Vec<serde_json::Value> = ctx
                    .extra_by_page
                    .get(&disp_page)
                    .map(|list| {
                        list.iter()
                            .map(|(pidx, is_wrap, tpi)| {
                                if *is_wrap {
                                    serde_json::json!({
                                        "kind": "wrapAroundPara",
                                        "paraIndex": pidx,
                                        "tableParaIndex": tpi,
                                        "textPreview": para_text_preview(paragraphs.get(*pidx)),
                                    })
                                } else {
                                    serde_json::json!({
                                        "kind": "hiddenEmptyPara",
                                        "paraIndex": pidx,
                                        "textPreview": para_text_preview(paragraphs.get(*pidx)),
                                    })
                                }
                            })
                            .collect()
                    })
                    .unwrap_or_default();

                pages_out.push(serde_json::json!({
                    "pageIndex": global_page,
                    "displayPage": global_page + 1,
                    "section": sec_idx,
                    "pageNumber": page.page_number,
                    "bodyArea": {
                        "x": la.body_area.x,
                        "y": la.body_area.y,
                        "width": la.body_area.width,
                        "height": la.body_area.height,
                    },
                    "columns": columns_out,
                    "extras": extras_out,
                }));

                global_page += 1;
            }
        }
        serde_json::Value::Array(pages_out)
    }

    /// 페이지네이션 결과를 텍스트로 덤프 (디버깅용).
    /// page_filter: None이면 전체, Some(n)이면 해당 페이지만.
    pub fn dump_page_items(&self, page_filter: Option<u32>) -> String {
        use crate::model::control::Control;
        use crate::renderer::hwpunit_to_px;
        use crate::renderer::pagination::PageItem;

        let dpi = self.dpi;
        let mut out = String::new();
        let mut global_page = 0u32;

        for (sec_idx, pr) in self.pagination.iter().enumerate() {
            // [#3697] 구역 전처리(미주 합침 #1082 · items 밖 문단 귀속 #1700 계열)는
            // JSON 덤프(`dump_page_items_json`)와 공유한다 — 두 출력의 드리프트 차단.
            let ctx = self.page_dump_section_ctx(sec_idx, pr, global_page);
            let paragraphs: &[Paragraph] = &ctx.paragraphs;
            let body_len = ctx.body_len;
            let extra_by_page = &ctx.extra_by_page;
            let typesetter = self.dump_section_typesetter(sec_idx);

            for (local_idx, page) in pr.pages.iter().enumerate() {
                if let Some(pf) = page_filter {
                    if global_page != pf {
                        global_page += 1;
                        continue;
                    }
                }

                out.push_str(&format!(
                    "\n=== 페이지 {} (global_idx={}, section={}, page_num={}) ===\n",
                    global_page + 1,
                    global_page,
                    sec_idx,
                    page.page_number
                ));

                // 페이지 레이아웃 정보
                let la = &page.layout;
                out.push_str(&format!(
                    "  body_area: x={:.1} y={:.1} w={:.1} h={:.1}\n",
                    la.body_area.x, la.body_area.y, la.body_area.width, la.body_area.height
                ));

                for (col_idx, cc) in page.column_contents.iter().enumerate() {
                    let hwp_used_px = compute_hwp_used_height(cc, paragraphs, dpi);
                    let diff_str = match hwp_used_px {
                        Some(hwp) => format!(
                            ", hwp_used≈{:.1}px, diff={:+.1}px",
                            hwp,
                            cc.used_height - hwp
                        ),
                        None => String::new(),
                    };
                    out.push_str(&format!(
                        "  단 {} (items={}, used={:.1}px{}{})\n",
                        col_idx,
                        cc.items.len(),
                        cc.used_height,
                        diff_str,
                        if cc.zone_y_offset > 0.0 {
                            format!(", zone_y_offset={:.1}", cc.zone_y_offset)
                        } else {
                            String::new()
                        }
                    ));

                    for item in &cc.items {
                        let endnote_source_info = |para_index: usize| -> String {
                            if para_index < body_len {
                                return String::new();
                            }
                            let local = para_index - body_len;
                            pr.endnote_para_sources
                                .get(local)
                                .map(|src| {
                                    format!(
                                        " src=s{}:p{}:ci{}:note{}",
                                        src.section_index,
                                        src.para_index,
                                        src.control_index,
                                        src.note_para_index
                                    )
                                })
                                .unwrap_or_default()
                        };

                        match item {
                            PageItem::FullParagraph { para_index } => {
                                let text_preview = paragraphs
                                    .get(*para_index)
                                    .map(|p| {
                                        let t: String = p
                                            .text
                                            .chars()
                                            .filter(|c| *c > '\u{001F}')
                                            .take(40)
                                            .collect();
                                        if t.is_empty() {
                                            "(빈)".to_string()
                                        } else {
                                            t
                                        }
                                    })
                                    .unwrap_or_default();
                                let col_w = Self::dump_column_width_px(page, cc);
                                let height = self
                                    .dump_production_paragraph_height_with(
                                        &typesetter,
                                        sec_idx,
                                        *para_index,
                                        body_len,
                                        paragraphs,
                                        col_w,
                                    )
                                    .map(|mp| {
                                        let lines = mp.line_height_sum + mp.line_spacing_sum;
                                        format!(
                                            "h={:.1} (sb={:.1} lines={:.1} lh={:.1} ls={:.1} sa={:.1})",
                                            mp.total,
                                            mp.spacing_before,
                                            lines,
                                            mp.line_height_sum,
                                            mp.line_spacing_sum,
                                            mp.spacing_after,
                                        )
                                    })
                                    .unwrap_or_default();
                                let vpos_info =
                                    format_vpos_range(paragraphs.get(*para_index), None, None);
                                let line_seg_info =
                                    format_line_seg_brief(paragraphs.get(*para_index));
                                let source_info = endnote_source_info(*para_index);
                                let kind = if *para_index >= body_len {
                                    "FullParagraph[미주]"
                                } else {
                                    "FullParagraph"
                                };
                                out.push_str(&format!(
                                    "    {}  pi={}  {}  {}{}  {}  \"{}\"\n",
                                    kind,
                                    para_index,
                                    height,
                                    vpos_info,
                                    source_info,
                                    line_seg_info,
                                    text_preview
                                ));
                            }
                            PageItem::PartialParagraph {
                                para_index,
                                start_line,
                                end_line,
                            } => {
                                let vpos_info = format_vpos_range(
                                    paragraphs.get(*para_index),
                                    Some(*start_line),
                                    Some(*end_line),
                                );
                                let line_seg_info =
                                    format_line_seg_brief(paragraphs.get(*para_index));
                                let source_info = endnote_source_info(*para_index);
                                // [#2152] 미주 문단 항목은 모든 kind 에 [미주] 라벨 —
                                // per-pi 오라클이 본문 pi 만 세도록 하는 판별 신호.
                                let en = if *para_index >= body_len {
                                    "[미주]"
                                } else {
                                    ""
                                };
                                out.push_str(&format!(
                                    "    PartialParagraph{}  pi={}  lines={}..{}  {}{}  {}\n",
                                    en,
                                    para_index,
                                    start_line,
                                    end_line,
                                    vpos_info,
                                    source_info,
                                    line_seg_info
                                ));
                            }
                            PageItem::Table {
                                para_index,
                                control_index,
                            } => {
                                let table_info = paragraphs
                                    .get(*para_index)
                                    .and_then(|p| p.controls.get(*control_index))
                                    .map(|c| {
                                        if let Control::Table(t) = c {
                                            let h = hwpunit_to_px(t.common.height as i32, dpi);
                                            let w = hwpunit_to_px(t.common.width as i32, dpi);
                                            format!(
                                                "{}x{}  {:.1}x{:.1}px  wrap={:?} tac={}",
                                                t.row_count,
                                                t.col_count,
                                                w,
                                                h,
                                                t.common.text_wrap,
                                                t.common.treat_as_char
                                            )
                                        } else {
                                            String::new()
                                        }
                                    })
                                    .unwrap_or_default();
                                let vpos_info =
                                    format_vpos_range(paragraphs.get(*para_index), None, None);
                                let line_seg_info =
                                    format_line_seg_brief(paragraphs.get(*para_index));
                                let source_info = endnote_source_info(*para_index);
                                let en = if *para_index >= body_len {
                                    "[미주]"
                                } else {
                                    ""
                                };
                                out.push_str(&format!(
                                    "    Table{}          pi={} ci={}  {}  {}{}  {}\n",
                                    en,
                                    para_index,
                                    control_index,
                                    table_info,
                                    vpos_info,
                                    source_info,
                                    line_seg_info
                                ));
                            }
                            PageItem::PartialTable {
                                para_index,
                                control_index,
                                start_row,
                                end_row,
                                is_continuation,
                                start_cut,
                                end_cut,
                                ..
                            } => {
                                let table_info = paragraphs
                                    .get(*para_index)
                                    .and_then(|p| p.controls.get(*control_index))
                                    .map(|c| {
                                        if let Control::Table(t) = c {
                                            format!("{}x{}", t.row_count, t.col_count)
                                        } else {
                                            String::new()
                                        }
                                    })
                                    .unwrap_or_default();
                                let vpos_info =
                                    format_vpos_range(paragraphs.get(*para_index), None, None);
                                let line_seg_info =
                                    format_line_seg_brief(paragraphs.get(*para_index));
                                let source_info = endnote_source_info(*para_index);
                                // [Task #993] 분할 표 진단 정보 — 행 컷이 비어 있지
                                // 않으면 셀 내 분할(컷 = 셀별 소비 유닛 수).
                                let split_info = if !start_cut.is_empty() || !end_cut.is_empty() {
                                    format!("  start_cut={:?} end_cut={:?}", start_cut, end_cut)
                                } else {
                                    String::new()
                                };
                                let en = if *para_index >= body_len {
                                    "[미주]"
                                } else {
                                    ""
                                };
                                out.push_str(&format!("    PartialTable{}   pi={} ci={}  rows={}..{}  cont={}  {}  {}{}  {}{}\n",
                                    en, para_index, control_index, start_row, end_row, is_continuation, table_info, vpos_info, source_info, line_seg_info, split_info));
                            }
                            PageItem::Shape {
                                para_index,
                                control_index,
                            } => {
                                let shape_info = paragraphs
                                    .get(*para_index)
                                    .and_then(|p| p.controls.get(*control_index))
                                    .map(|c| match c {
                                        Control::Shape(s) => format!(
                                            "wrap={:?} tac={}",
                                            s.common().text_wrap,
                                            s.common().treat_as_char
                                        ),
                                        Control::Picture(p) => {
                                            format!("그림 tac={}", p.common.treat_as_char)
                                        }
                                        Control::Equation(_) => "수식".to_string(),
                                        _ => String::new(),
                                    })
                                    .unwrap_or_default();
                                let vpos_info =
                                    format_vpos_range(paragraphs.get(*para_index), None, None);
                                let line_seg_info =
                                    format_line_seg_brief(paragraphs.get(*para_index));
                                let source_info = endnote_source_info(*para_index);
                                let en = if *para_index >= body_len {
                                    "[미주]"
                                } else {
                                    ""
                                };
                                out.push_str(&format!(
                                    "    Shape{}          pi={} ci={}  {}  {}{}  {}\n",
                                    en,
                                    para_index,
                                    control_index,
                                    shape_info,
                                    vpos_info,
                                    source_info,
                                    line_seg_info
                                ));
                            }
                            PageItem::EndnoteSeparator {
                                separator_length,
                                margin_above,
                                margin_below,
                                line_width,
                                color,
                                ..
                            } => {
                                out.push_str(&format!(
                                    "    EndnoteSeparator len={} above={} below={} width={} color=#{:06x}\n",
                                    separator_length, margin_above, margin_below, line_width, color & 0x00ff_ffff
                                ));
                            }
                        }
                    }
                }

                // [Task #1700] cc.items 에 없는 문단(어울림 / 빈 줄 감춤) 표면화.
                let disp_page = global_page + 1;
                if let Some(list) = extra_by_page.get(&disp_page) {
                    for (pidx, is_wrap, tpi) in list {
                        let preview = paragraphs
                            .get(*pidx)
                            .map(|p| {
                                let t: String = p
                                    .text
                                    .chars()
                                    .filter(|c| *c > '\u{001F}')
                                    .take(40)
                                    .collect();
                                if t.is_empty() {
                                    "(빈)".to_string()
                                } else {
                                    t
                                }
                            })
                            .unwrap_or_default();
                        if *is_wrap {
                            out.push_str(&format!(
                                "    WrapAroundPara  pi={}  table_pi={}  \"{}\"\n",
                                pidx, tpi, preview
                            ));
                        } else {
                            out.push_str(&format!(
                                "    HiddenEmptyPara  pi={}  \"{}\"\n",
                                pidx, preview
                            ));
                        }
                    }
                }

                global_page += 1;
            }
        }

        out
    }

    /// 페이지 렌더 트리 캐시 무효화 (from_page 이상 페이지만 무효화).
    pub(crate) fn invalidate_page_tree_cache_from(&self, from_page: u32) {
        let mut cache = self.page_tree_cache.borrow_mut();
        let from = from_page as usize;
        for i in from..cache.len() {
            cache[i] = None;
        }
        // 대표 HF tree는 일반 pagination tree와 다른 active target을 담는다. 부분
        // 무효화의 원인이 HF 자체가 아니더라도 body/쪽번호/페이지 기하가 바뀔 수 있어
        // 단일 entry를 보수적으로 비운다 (#6452).
        self.header_footer_preview_tree_cache.borrow_mut().take();
        let mut json_cache = self.layer_tree_json_cache.borrow_mut();
        for i in from..json_cache.len() {
            json_cache[i].clear();
        }
        let mut layer_cache = self.page_layer_tree_cache.borrow_mut();
        for i in from..layer_cache.len() {
            layer_cache[i].clear();
        }
    }

    /// 한 페이지의 렌더 트리와 그 파생 표현을 함께 무효화한다.
    pub(crate) fn invalidate_page_tree_cache_page(&self, page_num: u32) {
        let idx = page_num as usize;
        if let Some(slot) = self.page_tree_cache.borrow_mut().get_mut(idx) {
            *slot = None;
        }
        // 대표 HF tree도 페이지 숨김 상태를 포함하므로 함께 무효화한다 (#6452).
        self.header_footer_preview_tree_cache.borrow_mut().take();
        if let Some(variants) = self.layer_tree_json_cache.borrow_mut().get_mut(idx) {
            variants.clear();
        }
        if let Some(variants) = self.page_layer_tree_cache.borrow_mut().get_mut(idx) {
            variants.clear();
        }
    }

    /// [#3137 Stage 4] same-line인 셀 문단 꼬리 편집을 캐시된 TextLine에 반영한다.
    ///
    /// 이 경로는 새 page tree를 만들지 않는다. 기존 캐시에 대상 마지막 줄이 정확히
    /// 하나 있고, 편집 후 문단도 컨트롤/번호/배경 없는 가로 plain text이며 자연 폭이
    /// 셀 너비 안에 있는 경우에만 TextRun 자식을 재생성한다. 하나라도 다르면 caller가
    /// 기존 `invalidate_page_tree_cache_from(0)`으로 폴백한다.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn try_patch_cached_focused_cell_tail_line(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
        line_index: usize,
        line_start: usize,
        old_text_len: usize,
        new_text_len: usize,
    ) -> Option<FocusedPageTreePatch> {
        // partial Canvas replay는 일반 화면 text만 대상으로 한다. 편집 표식/디버그
        // overlay는 bbox 밖에 별도 glyph를 그릴 수 있으므로 기존 full repaint를 유지한다.
        if self.show_paragraph_marks || self.show_control_codes || self.debug_overlay {
            return None;
        }
        let valid_table_cell = self
            .document
            .sections
            .get(section_idx)
            .and_then(|section| section.paragraphs.get(parent_para_idx))
            .and_then(|paragraph| paragraph.controls.get(control_idx))
            .and_then(|control| match control {
                Control::Table(table) if cell_idx != super::super::TABLE_CAPTION_CELL_SENTINEL => {
                    table.cells.get(cell_idx)
                }
                _ => None,
            })
            .and_then(|cell| cell.paragraphs.get(cell_para_idx))
            .is_some();
        if !valid_table_cell {
            return None;
        }
        let paragraph = self.get_cell_paragraph_ref(
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
        )?;
        if paragraph.text.chars().count() != new_text_len
            || paragraph.text.encode_utf16().count() != new_text_len
            || !paragraph.controls.is_empty()
            || !paragraph.range_tags.is_empty()
            || !paragraph.field_ranges.is_empty()
            || !paragraph.orphan_field_ends.is_empty()
            || !paragraph.tab_extended.is_empty()
            || paragraph
                .text
                .chars()
                .any(|character| matches!(character, '\r' | '\n' | '\t'))
        {
            return None;
        }

        let composed = compose_paragraph(paragraph);
        if composed.numbering_text.is_some()
            || !composed.inline_controls.is_empty()
            || !composed.tac_controls.is_empty()
            || !composed.footnote_positions.is_empty()
            || !composed.tab_extended.is_empty()
            || composed.lines.len() != paragraph.line_segs.len()
            || line_index + 1 != composed.lines.len()
        {
            return None;
        }
        let line = composed.lines.get(line_index)?;
        if line.char_start != line_start || line.has_line_break || line.runs.is_empty() {
            return None;
        }
        let alignment = self
            .styles
            .para_styles
            .get(paragraph.para_shape_id as usize)
            .map(|style| style.alignment)
            .unwrap_or(Alignment::Left);
        if !focused_partial_repaint_alignment_is_safe(
            alignment,
            line_index + 1 == composed.lines.len(),
            line.has_line_break,
        ) {
            return None;
        }

        let mut candidates = Vec::new();
        {
            let cache = self.page_tree_cache.borrow();
            for (page_index, tree) in cache.iter().enumerate() {
                let Some(tree) = tree else {
                    continue;
                };
                collect_cached_focused_tail_lines(
                    &tree.root,
                    page_index,
                    section_idx,
                    parent_para_idx,
                    control_idx,
                    cell_idx,
                    cell_para_idx,
                    line_index,
                    line_start,
                    old_text_len,
                    &mut candidates,
                );
            }
        }
        if candidates.len() != 1 {
            return None;
        }
        let template = candidates.pop().expect("길이 1을 확인한 focused line");
        // HWPX 원본 LINE_SEG가 권위 폭을 담은 경우에는 cell layout이 다시 계산한 폭보다
        // 마지막 줄이 더 넓을 수 있다. same-line tail edit는 그 저장 폭까지 허용해야
        // #2214의 실제 61번째 boundary 전에도 #3137 cache patch를 유지한다. 이 값은
        // patch 허용 guard에만 사용하고, 기존 cached TextRun style은 바꾸지 않는다.
        let line_width_limit = if matches!(self.source_format, crate::parser::FileFormat::Hwpx) {
            paragraph
                .line_segs
                .get(line_index)
                .filter(|segment| {
                    segment.segment_width > 0
                        && segment.tag
                            & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                            == 0
                })
                .map(|segment| crate::renderer::hwpunit_to_px(segment.segment_width, self.dpi))
                .filter(|width| width.is_finite() && *width > 0.0)
                .unwrap_or(template.layout_style.available_width)
        } else {
            template.layout_style.available_width
        };
        if !template.line_bbox.x.is_finite()
            || !template.line_bbox.y.is_finite()
            || !template.line_bbox.width.is_finite()
            || !template.line_bbox.height.is_finite()
            || template.line_bbox.width <= 0.0
            || template.line_bbox.height <= 0.0
        {
            return None;
        }

        let mut char_start = line_start;
        let mut x = template.run_x;
        let mut prepared = Vec::with_capacity(line.runs.len());
        for (run_index, run) in line.runs.iter().enumerate() {
            let char_style = self.styles.char_styles.get(run.char_style_id as usize)?;
            let run_border_fill_id = char_style.border_fill_id;
            let run_has_background = run_border_fill_id > 0
                && self
                    .styles
                    .border_styles
                    .get((run_border_fill_id as usize).saturating_sub(1))
                    .is_some_and(|border| border.fill_color.is_some());
            if run.display_text.is_some()
                || run.char_overlap.is_some()
                || run.footnote_marker.is_some()
                || !(run.lang_index <= 3 || run.lang_index == 5)
                || run_has_background
            {
                return None;
            }

            let mut style = resolved_to_text_style(&self.styles, run.char_style_id, run.lang_index);
            if !focused_partial_repaint_style_is_safe(&style) {
                return None;
            }
            style.default_tab_width = template.layout_style.default_tab_width;
            style.tab_stops = template.layout_style.tab_stops.clone();
            style.auto_tab_right = template.layout_style.auto_tab_right;
            style.available_width = template.layout_style.available_width;
            style.text_start_offset = template.layout_style.text_start_offset;
            style.line_x_offset = x - template.column_x;
            style.right_tab_block_width_override = None;
            style.tab_leaders.clear();
            style.inline_tabs.clear();
            style.extra_word_spacing = 0.0;
            style.extra_char_spacing = 0.0;
            style.extra_dash_advance = 0.0;

            let width = estimate_text_width(&run.text, &style);
            if !width.is_finite() || width < 0.0 {
                return None;
            }
            let run_len = run.text.chars().count();
            let is_last_run = run_index + 1 == line.runs.len();
            prepared.push((
                TextRunNode {
                    text: run.text.clone(),
                    style,
                    char_shape_id: Some(run.char_style_id),
                    para_shape_id: Some(composed.para_style_id),
                    section_index: Some(section_idx),
                    para_index: Some(cell_para_idx),
                    char_start: Some(char_start),
                    cell_context: Some(template.cell_context.clone()),
                    is_para_end: is_last_run,
                    is_line_break_end: false,
                    rotation: 0.0,
                    is_vertical: false,
                    char_overlap: None,
                    border_fill_id: run_border_fill_id,
                    baseline: template.baseline,
                    field_marker: FieldMarkerType::None,
                    layout_positions: None,
                    display_text: None,
                },
                BoundingBox::new(x, template.run_y, width, template.run_height),
            ));
            char_start += run_len;
            x += width;
        }
        if char_start != new_text_len || x - template.run_x > line_width_limit + 0.051 {
            return None;
        }

        {
            let mut cache = self.page_tree_cache.borrow_mut();
            let tree = cache.get_mut(template.page_index)?.as_mut()?;
            let mut replacement_nodes = Vec::with_capacity(prepared.len());
            for (run, bbox) in prepared {
                let node_id = tree.next_id();
                replacement_nodes.push(RenderNode::new(
                    node_id,
                    RenderNodeType::TextRun(run),
                    bbox,
                ));
            }
            let line_node = find_render_node_mut(&mut tree.root, template.line_node_id)?;
            if !matches!(line_node.node_type, RenderNodeType::TextLine(_)) {
                return None;
            }
            line_node.children = replacement_nodes;
        }

        if let Some(variants) = self
            .layer_tree_json_cache
            .borrow_mut()
            .get_mut(template.page_index)
        {
            variants.clear();
        }
        if let Some(variants) = self
            .page_layer_tree_cache
            .borrow_mut()
            .get_mut(template.page_index)
        {
            variants.clear();
        }
        self.header_footer_preview_tree_cache.borrow_mut().take();
        Some(FocusedPageTreePatch {
            page_index: template.page_index as u32,
            dirty_rect: BoundingBox::new(
                template.line_bbox.x - FOCUSED_PAGE_REPAINT_PAD,
                template.line_bbox.y - FOCUSED_PAGE_REPAINT_PAD,
                template.line_bbox.width + FOCUSED_PAGE_REPAINT_PAD * 2.0,
                template.line_bbox.height + FOCUSED_PAGE_REPAINT_PAD * 2.0,
            ),
        })
    }

    /// 페이지 렌더 트리 캐시 전체 무효화.
    pub(crate) fn invalidate_page_tree_cache(&self) {
        self.page_tree_cache.borrow_mut().clear();
        self.header_footer_preview_tree_cache.borrow_mut().take();
        self.layer_tree_json_cache.borrow_mut().clear();
        self.page_layer_tree_cache.borrow_mut().clear();
        // [Task #1949] IR 이 바뀌는 재조판 경계에서 셀 단위 레이아웃 캐시(포인터 키)도
        // 함께 비워 다른 IR 의 셀 포인터 재사용으로 인한 오재사용을 방지한다.
        self.layout_engine.clear_layout_caches();
    }

    /// 캐시된 페이지 렌더 트리를 반환한다 (캐시 미스 시 빌드 후 캐시).
    pub(crate) fn build_page_tree_cached(&self, page_num: u32) -> Result<PageRenderTree, HwpError> {
        let idx = page_num as usize;

        // 캐시 크기 확보 + 히트 확인
        {
            let mut cache = self.page_tree_cache.borrow_mut();
            if cache.len() <= idx {
                cache.resize_with(idx + 1, || None);
            }
            if let Some(ref tree) = cache[idx] {
                return Ok(tree.clone());
            }
        }

        // 캐시 미스 → 빌드
        let tree = self.build_page_tree(page_num)?;
        let cloned = tree.clone();

        {
            let mut cache = self.page_tree_cache.borrow_mut();
            if cache.len() <= idx {
                cache.resize_with(idx + 1, || None);
            }
            cache[idx] = Some(cloned);
        }

        Ok(tree)
    }

    /// 캐시된 페이지 렌더 트리를 참조로 사용한다.
    ///
    /// 레이어 tree 생성은 페이지 tree를 소유할 필요가 없다. Canvas2D의 layer summary와
    /// 실제 재생은 같은 페이지를 연속 조회하므로, 캐시 히트마다 큰 tree를 복제하지 않는다.
    pub(crate) fn with_page_tree_cached<T>(
        &self,
        page_num: u32,
        build: impl FnOnce(&PageRenderTree) -> Result<T, HwpError>,
    ) -> Result<T, HwpError> {
        let idx = page_num as usize;
        let cached = self
            .page_tree_cache
            .borrow()
            .get(idx)
            .is_some_and(Option::is_some);

        if !cached {
            let tree = self.build_page_tree(page_num)?;
            let mut cache = self.page_tree_cache.borrow_mut();
            if cache.len() <= idx {
                cache.resize_with(idx + 1, || None);
            }
            cache[idx] = Some(tree);
        }

        let cache = self.page_tree_cache.borrow();
        let tree = cache[idx]
            .as_ref()
            .expect("페이지 tree cache는 채운 뒤에 참조해야 한다");
        build(tree)
    }

    /// 머리말/꼬리말 정의가 속한 구역의 대표 편집 페이지를 반환한다.
    ///
    /// 대표 페이지는 구역 첫 페이지다. 물리 홀짝과 무관한 편집 표면일 뿐 pagination의
    /// active_header/active_footer나 문서 IR을 바꾸지 않는다.
    pub(crate) fn header_footer_preview_page_for_section(
        &self,
        section_idx: usize,
    ) -> Result<u32, HwpError> {
        let result = self
            .pagination
            .get(section_idx)
            .ok_or_else(|| HwpError::RenderError(format!("구역 {} 범위 초과", section_idx)))?;
        result
            .pages
            .first()
            .map(|page| page.page_index)
            .ok_or_else(|| {
                HwpError::RenderError(format!("구역 {}에 편집할 페이지가 없습니다", section_idx))
            })
    }

    fn header_footer_ref_for_edit_target(
        &self,
        section_idx: usize,
        is_header: bool,
        apply_to: u8,
    ) -> Result<HeaderFooterRef, HwpError> {
        let apply = header_footer_apply_from_u8(apply_to);
        let (para_index, control_index) = self
            .find_header_footer_control(section_idx, is_header, apply)
            .ok_or_else(|| {
                HwpError::RenderError(format!(
                    "머리말/꼬리말 편집 target을 찾을 수 없습니다: sec={}, is_header={}, apply_to={}",
                    section_idx, is_header, apply_to
                ))
            })?;
        Ok(HeaderFooterRef {
            para_index,
            control_index,
            source_section_index: section_idx,
            table_path: Vec::new(),
        })
    }

    /// 구역 첫 페이지에 요청한 HF 정의를 임시로 투영한 렌더 트리.
    ///
    /// 실제 page tree cache와 섞지 않고 마지막 편집 target 한 건만 재사용한다. 선택
    /// 드래그는 hit-test와 selection geometry를 프레임마다 연속 조회하므로, 캐시가
    /// 없으면 같은 대표 페이지를 매번 full build하게 된다 (#6452).
    pub(crate) fn build_header_footer_edit_preview_tree(
        &self,
        page_num: u32,
        section_idx: usize,
        is_header: bool,
        apply_to: u8,
    ) -> Result<PageRenderTree, HwpError> {
        if self.header_footer_preview_page_for_section(section_idx)? != page_num {
            return Err(HwpError::RenderError(format!(
                "쪽 {}은 구역 {}의 대표 HF 편집 페이지가 아닙니다",
                page_num, section_idx
            )));
        }
        let key = (page_num, section_idx, is_header, apply_to);
        if let Some((cached_key, tree)) = self.header_footer_preview_tree_cache.borrow().as_ref() {
            if *cached_key == key {
                return Ok(tree.clone());
            }
        }

        let tree = self.build_page_tree_with_header_footer_override(
            page_num,
            Some((section_idx, is_header, apply_to)),
        )?;
        *self.header_footer_preview_tree_cache.borrow_mut() = Some((key, tree.clone()));
        Ok(tree)
    }

    /// 페이지 렌더 트리를 빌드한다.
    pub(crate) fn build_page_tree(&self, page_num: u32) -> Result<PageRenderTree, HwpError> {
        self.build_page_tree_with_header_footer_override(page_num, None)
    }

    fn build_page_tree_with_header_footer_override(
        &self,
        page_num: u32,
        header_footer_override: Option<(usize, bool, u8)>,
    ) -> Result<PageRenderTree, HwpError> {
        use crate::model::style::HeadType;
        use crate::renderer::layout::resolve_numbering_id;
        use crate::renderer::pagination::PageItem;

        // [#4126/#4128 회귀 가드] 콜드 캐럿 질의의 O(pages) 빌드 폭증 판별용 작업량 카운터.
        crate::diagnostics::perf_counters::record_page_tree_build();

        self.layout_engine
            .set_show_transparent_borders(self.show_transparent_borders);
        self.layout_engine.set_clip_enabled(self.clip_enabled);
        self.layout_engine
            .set_show_control_codes(self.show_control_codes);
        // [#2403] 소스분기 파생 일원화 — paginate_pass 와 동일하게 layout_profile
        // 단일 소유 (Issue #1770 규칙 승계). set_layout_profile 의 결합 부수효과
        // (variant → flow spacing_before)는 다음 줄이 종전 순서대로 덮어쓴다.
        self.layout_engine
            .set_layout_profile(self.effective_layout_profile());
        self.layout_engine.set_hwp3_origin_flow_spacing_before(
            uses_hwp3_origin_flow_spacing_before(&self.document),
        );
        self.layout_engine.set_hwpx_page_preview(
            self.document
                .hwpx_aux_entry("Preview/PrvImage.png")
                .filter(|_| matches!(self.source_format, crate::parser::FileFormat::Hwpx)),
        );
        // 활성 필드 정보를 레이아웃 엔진에 전달 (안내문 숨김용)
        self.layout_engine
            .set_active_field(self.active_field.as_ref().map(|af| {
                (
                    af.section_idx,
                    af.para_idx,
                    af.control_idx,
                    af.cell_path.clone(),
                )
            }));
        let (base_page_content, paragraphs, composed) = self.find_page(page_num)?;
        let overridden_page_content =
            if let Some((section_idx, is_header, apply_to)) = header_footer_override {
                let mut page_content = base_page_content.clone();
                let target =
                    self.header_footer_ref_for_edit_target(section_idx, is_header, apply_to)?;
                if is_header {
                    page_content.active_header = Some(target);
                } else {
                    page_content.active_footer = Some(target);
                }
                Some(page_content)
            } else {
                None
            };
        let page_content = overridden_page_content
            .as_ref()
            .unwrap_or(base_page_content);
        // 구역의 각주 모양 정보
        let footnote_shape = if page_content.section_index < self.document.sections.len() {
            &self.document.sections[page_content.section_index]
                .section_def
                .footnote_shape
        } else {
            &crate::model::footnote::FootnoteShape::default()
        };
        // 활성 바탕쪽 조회
        let active_mp = page_content.active_master_page.as_ref().and_then(|mp_ref| {
            self.document
                .sections
                .get(mp_ref.section_index)
                .and_then(|s| s.section_def.master_pages.get(mp_ref.master_page_index))
        });
        // 확장 바탕쪽 조회
        let extra_mps: Vec<&crate::model::header_footer::MasterPage> = page_content
            .extra_master_pages
            .iter()
            .filter_map(|mp_ref| {
                self.document
                    .sections
                    .get(mp_ref.section_index)
                    .and_then(|s| s.section_def.master_pages.get(mp_ref.master_page_index))
            })
            .collect();
        let sec_measured = self
            .measured_tables
            .get(page_content.section_index)
            .map(|v| v.as_slice())
            .unwrap_or(&[]);
        // 쪽 테두리/배경 조회
        let page_border_fill = self
            .document
            .sections
            .get(page_content.section_index)
            .map(|s| &s.section_def.page_border_fill);
        let outline_num_id = self
            .document
            .sections
            .get(page_content.section_index)
            .map(|s| s.section_def.outline_numbering_id)
            .unwrap_or(0);

        // 번호 상태 리셋 후, 이 페이지 이전의 번호 문단을 재계산하여 카운터 복원
        // (이전 구역 + 현재 구역의 이전 페이지 모두 포함하여 구역 간 번호 연속 지원)
        self.layout_engine.reset_numbering_state();
        let sec_idx = page_content.section_index;
        let sec_page_offset: usize = self
            .pagination
            .iter()
            .take(sec_idx)
            .map(|p| p.pages.len())
            .sum();
        let local_idx = (page_num as usize).saturating_sub(sec_page_offset);
        {
            let mut replayed_partial: std::collections::HashSet<(usize, usize)> =
                std::collections::HashSet::new();
            // 이전 구역들의 모든 페이지 replay
            for prev_sec in 0..sec_idx {
                if let Some(pr) = self.pagination.get(prev_sec) {
                    let prev_paras = &self.document.sections[prev_sec].paragraphs;
                    let prev_outline_id = self.document.sections[prev_sec]
                        .section_def
                        .outline_numbering_id;
                    for pg in &pr.pages {
                        self.replay_numbering_page(
                            pg,
                            prev_paras,
                            prev_outline_id,
                            &mut replayed_partial,
                            prev_sec,
                        );
                    }
                }
            }
            // 현재 구역의 이전 페이지들 replay
            if let Some(pr) = self.pagination.get(sec_idx) {
                for prev_local in 0..local_idx {
                    if let Some(prev_page) = pr.pages.get(prev_local) {
                        self.replay_numbering_page(
                            prev_page,
                            paragraphs,
                            outline_num_id,
                            &mut replayed_partial,
                            sec_idx,
                        );
                    }
                }
            }
        }

        // 머리말/꼬리말이 상속된 경우 원본 구역의 문단을 조회 (source_section_index 기반)
        let header_paragraphs: &[crate::model::paragraph::Paragraph] = page_content
            .active_header
            .as_ref()
            .and_then(|hf| self.document.sections.get(hf.source_section_index))
            .map(|s| s.paragraphs.as_slice())
            .unwrap_or(paragraphs);
        let footer_paragraphs: &[crate::model::paragraph::Paragraph] = page_content
            .active_footer
            .as_ref()
            .and_then(|hf| self.document.sections.get(hf.source_section_index))
            .map(|s| s.paragraphs.as_slice())
            .unwrap_or(paragraphs);

        // 머리말/꼬리말 감추기 세트를 레이아웃 엔진에 전달
        self.layout_engine
            .set_hidden_header_footer(&self.hidden_header_footer);

        // 총 쪽수·파일 이름을 레이아웃 엔진에 전달 (머리말/꼬리말 필드 치환용)
        let total_pages: u32 = self.pagination.iter().map(|p| p.pages.len() as u32).sum();
        self.layout_engine.set_total_pages(total_pages);
        self.layout_engine.set_file_name(&self.file_name);

        // [Task #2102] 쪽 배경 이미지 채우기는 구역 첫 쪽에만 적용한다.
        // 현재 페이지가 소속 구역의 첫 글로벌 페이지인지 판정하여 엔진에 전달.
        let is_section_first_page = self
            .pagination
            .get(page_content.section_index)
            .and_then(|pr| pr.pages.first())
            .map(|first| first.page_index == page_content.page_index)
            .unwrap_or(true);
        self.layout_engine
            .set_current_page_is_section_first(is_section_first_page);

        // [#5717] 구역정의 "첫 쪽에만 테두리/배경 표시" (flags bit 8/9,
        // HWPX visibility SHOW_FIRST) — 켜진 구역은 첫 쪽 밖에서 억제한다.
        let (first_page_border, first_page_fill) = self
            .document
            .sections
            .get(page_content.section_index)
            .map(|s| {
                (
                    s.section_def.first_page_border,
                    s.section_def.first_page_fill,
                )
            })
            .unwrap_or((false, false));
        self.layout_engine
            .set_page_border_fill_first_page_only(first_page_border, first_page_fill);

        let wrap_around_paras = self
            .pagination
            .get(sec_idx)
            .map(|pr| pr.wrap_around_paras.as_slice())
            .unwrap_or(&[]);

        // 빈 줄 감추기 문단 집합을 레이아웃 엔진에 전달
        if let Some(pr) = self.pagination.get(sec_idx) {
            self.layout_engine
                .set_hidden_empty_paras(&pr.hidden_empty_paras);
            // [Task #1755] pre-emit 된 host 문단 → fragment 쪽 host 렌더 억제.
            self.layout_engine
                .set_pre_emitted_host_paras(&pr.pre_emitted_host_paras);
            // [#2015] pre-emit host 높이 → layout vert_offset 이중계상 보정.
            self.layout_engine
                .set_pre_emitted_host_heights(&pr.pre_emitted_host_heights);
            self.layout_engine
                .set_endnote_para_sources(paragraphs.len(), &pr.endnote_para_sources);
            // 섹션 미주 모양의 정규화 여백 전달 → HeightCursor min-gap 및 renderer overflow 판정.
            self.layout_engine.set_endnote_shape_margins_hu(
                pr.endnote_separator_above_hu,
                pr.endnote_between_notes_hu,
                pr.endnote_separator_below_hu,
            );
        }

        // [Task #836] 미주 paragraphs를 본문 paragraphs 뒤에 합쳐서 전달
        // endnote para_index = paragraphs.len() + idx → combined에서 접근 가능
        let en_paras = self
            .pagination
            .get(sec_idx)
            .map(|pr| pr.endnote_paragraphs.as_slice())
            .unwrap_or(&[]);
        let combined_paragraphs: Vec<Paragraph>;
        let combined_composed: Vec<crate::renderer::composer::ComposedParagraph>;
        let (render_paragraphs, render_composed): (
            &[Paragraph],
            &[crate::renderer::composer::ComposedParagraph],
        ) = if en_paras.is_empty() {
            (paragraphs, composed)
        } else {
            combined_paragraphs = paragraphs.iter().chain(en_paras.iter()).cloned().collect();
            let en_composed: Vec<_> = en_paras
                .iter()
                .map(|p| crate::renderer::composer::compose_paragraph(p))
                .collect();
            combined_composed = composed
                .iter()
                .cloned()
                .chain(en_composed.into_iter())
                .collect();
            (&combined_paragraphs, &combined_composed)
        };

        let mut tree = self.layout_engine.build_render_tree(
            page_content,
            render_paragraphs,
            header_paragraphs,
            footer_paragraphs,
            render_composed,
            &self.styles,
            footnote_shape,
            &self.document.bin_data_content,
            active_mp,
            sec_measured,
            page_border_fill,
            outline_num_id,
            wrap_around_paras,
        );
        // 확장 바탕쪽 추가 렌더링
        for ext_mp in &extra_mps {
            self.layout_engine.build_master_page_into(
                &mut tree,
                Some(*ext_mp),
                &page_content.layout,
                composed,
                &self.styles,
                &self.document.bin_data_content,
                page_content.section_index,
                page_content.page_number,
            );
        }
        // Task #1154: 동일 bin_data_id Pic 컨트롤이 수직으로 인접 겹쳐 그려질 때
        // 두 그림의 미세한 세로 스케일 차이로 인한 잔상(이중 라인) 제거.
        // build 직후 1회만 적용 — 모든 렌더러(SVG/Canvas/Skia/HTML/Layer) 공통.
        tree.clip_overlapping_same_bin_images();
        Ok(tree)
    }

    /// 한 페이지의 번호 문단을 replay하여 카운터를 전진시킨다.
    fn replay_numbering_page(
        &self,
        page: &crate::renderer::pagination::PageContent,
        paras: &[crate::model::paragraph::Paragraph],
        outline_num_id: u16,
        replayed: &mut std::collections::HashSet<(usize, usize)>,
        sec_idx: usize,
    ) {
        use crate::model::style::HeadType;
        use crate::renderer::pagination::PageItem;
        for col in &page.column_contents {
            for item in &col.items {
                let pi = match item {
                    PageItem::FullParagraph { para_index }
                    | PageItem::PartialParagraph { para_index, .. }
                    | PageItem::Table { para_index, .. } => {
                        if replayed.insert((sec_idx, *para_index)) {
                            Some(*para_index)
                        } else {
                            None
                        }
                    }
                    _ => None,
                };
                if let Some(pi) = pi {
                    if let Some(para) = paras.get(pi) {
                        if let Some(ps) = self.styles.para_styles.get(para.para_shape_id as usize) {
                            if ps.head_type == HeadType::Outline || ps.head_type == HeadType::Number
                            {
                                let nid = crate::renderer::layout::resolve_numbering_id(
                                    ps.head_type,
                                    ps.numbering_id,
                                    outline_num_id,
                                );
                                if nid > 0 {
                                    self.layout_engine.advance_numbering(nid, ps.para_level);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pub(crate) fn rebuild_section(&mut self, section_idx: usize) {
        self.rebuild_resolved_styles();
        self.recompose_section(section_idx);
        self.paginate();
    }

    /// 페이지에 렌더된 텍스트를 줄 단위로 추출한다.
    ///
    /// TextLine 노드의 시각적 순서를 유지하며 TextRun/각주 마커/양식 텍스트를 합친다.
    pub fn extract_page_text_native(&self, page_num: u32) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        fn collect_line_text(node: &RenderNode, out: &mut String, has_token: &mut bool) {
            match &node.node_type {
                RenderNodeType::TextRun(tr) => {
                    // 사람이 읽을 문자열이므로 표시 텍스트를 쓴다 — 머리말 필드는
                    // 모델에 제어문자 1자라 그대로 내보내면 값이 사라진다 (Task #3216).
                    // [#3385] 렌더가 폰트 정합을 위해 원문으로 흘리는 PUA 는 텍스트
                    // 표면에서만 읽을 수 있는 문자로 바꾼다 (렌더 결정은 불변).
                    out.push_str(&crate::renderer::composer::pua_to_text_surface(
                        tr.display_or_text(),
                    ));
                    *has_token = true;
                }
                RenderNodeType::FootnoteMarker(marker) => {
                    out.push_str(&marker.text);
                    *has_token = true;
                }
                RenderNodeType::FormObject(form) => {
                    if !form.text.is_empty() {
                        out.push_str(&form.text);
                        *has_token = true;
                    } else if !form.caption.is_empty() {
                        out.push_str(&form.caption);
                        *has_token = true;
                    }
                }
                // [#3413] 수식은 렌더에만 존재하고 평문에서 조용히 사라졌다. 수학·과학
                // 문서에서는 선택지 값과 발문 수식이 통째로 비어(exit 0, 경고 없음)
                // RAG·검색 파이프라인이 의미 없는 텍스트를 받는다. 원본 스크립트를
                // 그대로 방출한다 — HWP 수식 문법은 사람이 읽을 수 있는 형식이다.
                RenderNodeType::Equation(eq) => {
                    let script = eq.script.trim();
                    if !script.is_empty() {
                        out.push_str(script);
                        *has_token = true;
                    }
                }
                _ => {}
            }

            for child in &node.children {
                collect_line_text(child, out, has_token);
            }
        }

        fn collect_page_lines(node: &RenderNode, lines: &mut Vec<String>) {
            if matches!(node.node_type, RenderNodeType::TextLine(_)) {
                let mut line = String::new();
                let mut has_token = false;

                for child in &node.children {
                    collect_line_text(child, &mut line, &mut has_token);
                }

                if has_token {
                    lines.push(line);
                }
                return;
            }

            for child in &node.children {
                collect_page_lines(child, lines);
            }
        }

        let tree = self.build_page_tree(page_num)?;
        let mut lines = Vec::new();
        collect_page_lines(&tree.root, &mut lines);
        Ok(lines.join("\n"))
    }

    /// 페이지를 Markdown으로 추출한다.
    ///
    /// - 일반 텍스트는 줄 단위로 추출
    /// - 표 컨트롤은 Markdown table(`| ... |`)로 변환
    /// - 표/이미지는 내부 텍스트 중복 추출을 방지하기 위해 하위 순회를 생략
    /// - 이미지는 `[[RHWP_IMAGE:n]]` 토큰으로 출력되며,
    ///   반환 벡터에 같은 순서로 `(sec_idx, para_idx, control_idx, bin_data_id)`가 담긴다.
    ///   (sec/para/ctrl은 없을 수 있으며, 이 경우 bin_data_id로 추출한다)
    pub fn extract_page_markdown_with_images_native(
        &self,
        page_num: u32,
    ) -> Result<
        (
            String,
            Vec<(Option<usize>, Option<usize>, Option<usize>, u16)>,
        ),
        HwpError,
    > {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        #[derive(Debug)]
        enum MarkdownItem {
            Line(String),
            Table(String),
            Image {
                sec_idx: Option<usize>,
                para_idx: Option<usize>,
                control_idx: Option<usize>,
                bin_data_id: u16,
            },
        }

        fn collect_line_text(node: &RenderNode, out: &mut String, has_token: &mut bool) {
            match &node.node_type {
                RenderNodeType::TextRun(tr) => {
                    // 사람이 읽을 문자열이므로 표시 텍스트를 쓴다 — 머리말 필드는
                    // 모델에 제어문자 1자라 그대로 내보내면 값이 사라진다 (Task #3216).
                    out.push_str(tr.display_or_text());
                    *has_token = true;
                }
                RenderNodeType::FootnoteMarker(marker) => {
                    out.push_str(&marker.text);
                    *has_token = true;
                }
                RenderNodeType::FormObject(form) => {
                    if !form.text.is_empty() {
                        out.push_str(&form.text);
                        *has_token = true;
                    } else if !form.caption.is_empty() {
                        out.push_str(&form.caption);
                        *has_token = true;
                    }
                }
                // [#3413] 수식은 렌더에만 존재하고 평문에서 조용히 사라졌다. 수학·과학
                // 문서에서는 선택지 값과 발문 수식이 통째로 비어(exit 0, 경고 없음)
                // RAG·검색 파이프라인이 의미 없는 텍스트를 받는다. 원본 스크립트를
                // 그대로 방출한다 — HWP 수식 문법은 사람이 읽을 수 있는 형식이다.
                RenderNodeType::Equation(eq) => {
                    let script = eq.script.trim();
                    if !script.is_empty() {
                        out.push_str(script);
                        *has_token = true;
                    }
                }
                _ => {}
            }

            for child in &node.children {
                collect_line_text(child, out, has_token);
            }
        }

        fn markdown_escape_cell(s: &str) -> String {
            s.replace('|', "\\|")
                .replace('\r', "")
                .replace('\n', " ")
                .trim()
                .to_string()
        }

        fn table_cell_text(cell: &crate::model::table::Cell) -> String {
            let mut parts: Vec<String> = Vec::new();
            for para in &cell.paragraphs {
                let text_with_equations = paragraph_text_with_equations(para);
                let txt = text_with_equations.trim();
                if !txt.is_empty() {
                    parts.push(markdown_escape_cell(txt));
                }
            }
            parts.join(" <br> ")
        }

        fn table_to_markdown(table: &crate::model::table::Table) -> String {
            let rows = table.row_count as usize;
            let cols = table.col_count as usize;
            if rows == 0 || cols == 0 {
                return String::new();
            }

            let mut grid = vec![vec![String::new(); cols]; rows];

            for cell in &table.cells {
                let r = cell.row as usize;
                let c = cell.col as usize;
                if r >= rows || c >= cols {
                    continue;
                }
                grid[r][c] = table_cell_text(cell);
            }

            let make_row = |cells: &[String]| -> String { format!("| {} |", cells.join(" | ")) };

            let header = make_row(&grid[0]);
            let separator = format!(
                "| {} |",
                std::iter::repeat("---")
                    .take(cols)
                    .collect::<Vec<_>>()
                    .join(" | ")
            );

            let mut lines = vec![header, separator];
            for row in grid.iter().skip(1) {
                lines.push(make_row(row));
            }
            lines.join("\n")
        }

        fn lookup_table<'a>(
            doc: &'a crate::model::document::Document,
            sec_idx: usize,
            para_idx: usize,
            ctrl_idx: usize,
        ) -> Option<&'a crate::model::table::Table> {
            let para = doc.sections.get(sec_idx)?.paragraphs.get(para_idx)?;
            match para.controls.get(ctrl_idx)? {
                crate::model::control::Control::Table(table) => Some(table.as_ref()),
                _ => None,
            }
        }

        fn collect_markdown_items(
            node: &RenderNode,
            doc: &crate::model::document::Document,
            items: &mut Vec<MarkdownItem>,
        ) {
            fn collect_images_only(node: &RenderNode, items: &mut Vec<MarkdownItem>) {
                if let RenderNodeType::Image(image_node) = &node.node_type {
                    items.push(MarkdownItem::Image {
                        sec_idx: image_node.section_index,
                        para_idx: image_node.para_index,
                        control_idx: image_node.control_index,
                        bin_data_id: image_node.bin_data_id,
                    });
                    return;
                }
                for child in &node.children {
                    collect_images_only(child, items);
                }
            }

            match &node.node_type {
                RenderNodeType::Table(table_node) => {
                    if let (Some(si), Some(pi), Some(ci)) = (
                        table_node.section_index,
                        table_node.para_index,
                        table_node.control_index,
                    ) {
                        if let Some(table) = lookup_table(doc, si, pi, ci) {
                            let md = table_to_markdown(table);
                            if !md.is_empty() {
                                items.push(MarkdownItem::Table(md));
                            }
                            // 표 텍스트는 table_to_markdown으로 처리하고,
                            // 표 내부 Image 노드만 별도로 수집한다.
                            for child in &node.children {
                                collect_images_only(child, items);
                            }
                            return;
                        }
                    }
                }
                RenderNodeType::Image(image_node) => {
                    items.push(MarkdownItem::Image {
                        sec_idx: image_node.section_index,
                        para_idx: image_node.para_index,
                        control_idx: image_node.control_index,
                        bin_data_id: image_node.bin_data_id,
                    });
                    return;
                }
                RenderNodeType::TextLine(_) => {
                    let mut line = String::new();
                    let mut has_token = false;
                    for child in &node.children {
                        collect_line_text(child, &mut line, &mut has_token);
                    }
                    if has_token {
                        items.push(MarkdownItem::Line(line));
                    }
                    return;
                }
                _ => {}
            }

            for child in &node.children {
                collect_markdown_items(child, doc, items);
            }
        }

        let tree = self.build_page_tree(page_num)?;
        let mut items: Vec<MarkdownItem> = Vec::new();
        collect_markdown_items(&tree.root, &self.document, &mut items);

        let mut out = String::new();
        let mut images: Vec<(Option<usize>, Option<usize>, Option<usize>, u16)> = Vec::new();
        for item in items {
            match item {
                MarkdownItem::Line(line) => {
                    out.push_str(&line);
                    out.push('\n');
                }
                MarkdownItem::Table(table_md) => {
                    if !out.is_empty() && !out.ends_with("\n\n") {
                        out.push('\n');
                    }
                    out.push_str(&table_md);
                    out.push_str("\n\n");
                }
                MarkdownItem::Image {
                    sec_idx,
                    para_idx,
                    control_idx,
                    bin_data_id,
                } => {
                    if !out.is_empty() && !out.ends_with("\n\n") {
                        out.push('\n');
                    }
                    let image_idx = images.len() + 1;
                    out.push_str(&format!("[[RHWP_IMAGE:{}]]\n\n", image_idx));
                    images.push((sec_idx, para_idx, control_idx, bin_data_id));
                }
            }
        }

        Ok((out.trim_end().to_string(), images))
    }

    /// 페이지를 Markdown으로 추출한다 (이미지 토큰 포함).
    pub fn extract_page_markdown_native(&self, page_num: u32) -> Result<String, HwpError> {
        self.extract_page_markdown_with_images_native(page_num)
            .map(|(md, _)| md)
    }

    // =====================================================================
    // 클립보드 API (내부)
    // =====================================================================
}

/// [#3697] dump-pages 텍스트/JSON 두 출력이 공유하는 구역 전처리 결과.
struct PageDumpSectionCtx<'a> {
    /// 본문(+미주 #1082) 문단. 미주가 없으면 원본 슬라이스 차용.
    paragraphs: std::borrow::Cow<'a, [Paragraph]>,
    /// 본문 문단 수 — 이 인덱스 이상은 미주 문단.
    body_len: usize,
    /// 표시 페이지(global+1) → (para_index, 어울림 여부, 앵커 표 para_index) — #1700 계열.
    extra_by_page: std::collections::HashMap<u32, Vec<(usize, bool, usize)>>,
}

/// [#3697] dump-pages JSON 의 문단 미리보기 — 텍스트 덤프와 같은 제어문자 제거 + 40자.
/// 기계 소비자용이므로 텍스트 덤프의 "(빈)" 대체 표기는 쓰지 않는다 (빈 문단 = "").
///
/// [세션 노드 경로 확장] `mcp_serve::session_doc_tree` 의 문단 노드 미리보기도 이 함수를
/// 그대로 쓴다 — 같은 문서에서 미리보기 규칙(제어문자 제거·40자 절단)이 갈리면 안 된다.
pub fn para_text_preview(para: Option<&Paragraph>) -> String {
    para.map(|p| {
        p.text
            .chars()
            .filter(|c| *c > '\u{001F}')
            .take(40)
            .collect()
    })
    .unwrap_or_default()
}

/// [#3697] dump-pages JSON 의 표 컨트롤 요약.
/// `with_geometry` 는 전체 표 항목에서만 true (텍스트 덤프와 같은 정보 범위).
fn table_summary_json(
    paragraphs: &[Paragraph],
    para_index: usize,
    control_index: usize,
    dpi: f64,
    with_geometry: bool,
) -> serde_json::Value {
    use crate::model::control::Control;
    use crate::renderer::hwpunit_to_px;

    paragraphs
        .get(para_index)
        .and_then(|p| p.controls.get(control_index))
        .and_then(|c| {
            if let Control::Table(t) = c {
                let mut v = serde_json::json!({
                    "rowCount": t.row_count,
                    "colCount": t.col_count,
                });
                if with_geometry {
                    if let Some(obj) = v.as_object_mut() {
                        obj.insert(
                            "widthPx".into(),
                            serde_json::json!(hwpunit_to_px(t.common.width as i32, dpi)),
                        );
                        obj.insert(
                            "heightPx".into(),
                            serde_json::json!(hwpunit_to_px(t.common.height as i32, dpi)),
                        );
                        obj.insert(
                            "textWrap".into(),
                            serde_json::json!(format!("{:?}", t.common.text_wrap)),
                        );
                        obj.insert(
                            "treatAsChar".into(),
                            serde_json::json!(t.common.treat_as_char),
                        );
                    }
                }
                Some(v)
            } else {
                None
            }
        })
        .unwrap_or(serde_json::Value::Null)
}

/// 단이 HWP 원본 layout 에서 사용했을 높이를 LINE_SEG vpos 기준으로 추정 (px).
///
/// 알고리즘:
/// 1. 단의 항목들을 순회하며 첫 vpos-reset (line>0, vertical_pos==0) 발견 지점을 찾는다.
/// 2. reset 발견: reset 직전 줄의 vpos + line_height (HWP 가 단을 끊은 위치)
/// 3. reset 미발견: 단의 마지막 처리 줄 (FullParagraph: 마지막, PartialParagraph: end_line-1)
/// 4. Table/Shape 만 있는 항목은 추정 불가 (None)
fn compute_hwp_used_height(
    cc: &crate::renderer::pagination::ColumnContent,
    paragraphs: &[Paragraph],
    dpi: f64,
) -> Option<f64> {
    use crate::renderer::hwpunit_to_px;
    use crate::renderer::pagination::PageItem;

    // [Task #1612] vpos 는 다페이지에서 누적값(예: page2 vpos≈66568~127587 HU)이므로, per-page
    // `used_height` 와 비교하려면 이 페이지 시작 오프셋을 빼야 한다. 차감하지 않으면 페이지마다
    // diff 가 ~수백px 누적 증가해 "대형 표 과소측정" 으로 오판된다(#1612). 페이지 첫 문단 항목의
    // top vpos 를 기준선으로 삼는다(문단 항목이 없으면 0).
    let base_top: i32 =
        cc.items
            .iter()
            .find_map(|item| {
                let (para_index, line) = match item {
                    PageItem::FullParagraph { para_index } => (*para_index, 0usize),
                    PageItem::PartialParagraph {
                        para_index,
                        start_line,
                        ..
                    } => (*para_index, *start_line),
                    PageItem::Table { para_index, .. }
                    | PageItem::PartialTable { para_index, .. } => (*para_index, 0usize),
                    _ => return None,
                };
                paragraphs
                    .get(para_index)?
                    .line_segs
                    .get(line)
                    .map(|s| s.vertical_pos)
            })
            .unwrap_or(0);

    // 1) 단 항목 내 첫 vpos-reset 검색
    for item in &cc.items {
        let (para_idx, range_start, range_end) = match item {
            PageItem::FullParagraph { para_index } => {
                let p = match paragraphs.get(*para_index) {
                    Some(p) => p,
                    None => continue,
                };
                (*para_index, 0usize, p.line_segs.len())
            }
            PageItem::PartialParagraph {
                para_index,
                start_line,
                end_line,
            } => {
                let p = match paragraphs.get(*para_index) {
                    Some(p) => p,
                    None => continue,
                };
                (*para_index, *start_line, (*end_line).min(p.line_segs.len()))
            }
            _ => continue,
        };
        let p = match paragraphs.get(para_idx) {
            Some(p) => p,
            None => continue,
        };
        // line>0 인 줄 중 vertical_pos==0 첫 줄 찾기
        for i in range_start.max(1)..range_end {
            if let Some(seg) = p.line_segs.get(i) {
                if seg.vertical_pos == 0 {
                    if let Some(prev) = p.line_segs.get(i.saturating_sub(1)) {
                        let bottom_hwpu = prev.vertical_pos + prev.line_height + prev.line_spacing;
                        return Some(hwpunit_to_px((bottom_hwpu - base_top).max(0), dpi));
                    }
                }
            }
        }
    }

    // 2) reset 미발견: 단 마지막 항목의 마지막 줄
    let last_item = cc.items.last()?;
    let (para_idx, line_idx) = match last_item {
        PageItem::FullParagraph { para_index } => {
            let p = paragraphs.get(*para_index)?;
            if p.line_segs.is_empty() {
                return None;
            }
            (*para_index, p.line_segs.len() - 1)
        }
        PageItem::PartialParagraph {
            para_index,
            end_line,
            ..
        } => {
            let p = paragraphs.get(*para_index)?;
            if p.line_segs.is_empty() {
                return None;
            }
            (
                *para_index,
                end_line.saturating_sub(1).min(p.line_segs.len() - 1),
            )
        }
        _ => return None,
    };
    let p = paragraphs.get(para_idx)?;
    let seg = p.line_segs.get(line_idx)?;
    let bottom_hwpu = seg.vertical_pos + seg.line_height + seg.line_spacing;
    Some(hwpunit_to_px((bottom_hwpu - base_top).max(0), dpi))
}

/// [#3697] vpos 범위 분석 결과 — 텍스트(`format_vpos_range`)/JSON(`vpos_range_json`)
/// 두 표현이 같은 판정(리셋/되감기)을 공유하기 위한 중간 형태.
struct VposRange {
    first: i32,
    last: i32,
    /// 요청 범위가 한 줄이면 true (텍스트 표현이 단일값으로 축약).
    single: bool,
    resets: Vec<usize>,
    rewinds: Vec<usize>,
}

/// LINE_SEG vertical_pos 범위 분석.
///
/// `start_line..end_line` 가 None 이면 문단 전체 범위.
/// `vertical_pos == 0` 인 줄(문단 첫 줄 제외)을 vpos-reset 으로 마킹.
fn vpos_range(
    para: Option<&Paragraph>,
    start_line: Option<usize>,
    end_line: Option<usize>,
) -> Option<VposRange> {
    let p = para?;
    if p.line_segs.is_empty() {
        return None;
    }
    let total = p.line_segs.len();
    let s = start_line.unwrap_or(0).min(total.saturating_sub(1));
    let end_exclusive = end_line.unwrap_or(total).min(total);
    if s >= end_exclusive {
        return None;
    }
    let e = end_exclusive - 1;

    let mut resets: Vec<usize> = Vec::new();
    let mut rewinds: Vec<usize> = Vec::new();
    for i in s..=e {
        // 문단 첫 줄(line 0)의 vpos는 자연 시작점이므로 제외
        if i > 0 && p.line_segs[i].vertical_pos == 0 {
            resets.push(i);
        }
        if i > s && p.line_segs[i].vertical_pos < p.line_segs[i - 1].vertical_pos {
            rewinds.push(i);
        }
    }
    Some(VposRange {
        first: p.line_segs[s].vertical_pos,
        last: p.line_segs[e].vertical_pos,
        single: s == e,
        resets,
        rewinds,
    })
}

/// LINE_SEG vertical_pos 범위를 문자열로 포맷.
fn format_vpos_range(
    para: Option<&Paragraph>,
    start_line: Option<usize>,
    end_line: Option<usize>,
) -> String {
    let Some(r) = vpos_range(para, start_line, end_line) else {
        return String::new();
    };
    let mut s_out = if r.single {
        format!("vpos={}", r.first)
    } else {
        format!("vpos={}..{}", r.first, r.last)
    };
    for i in r.resets {
        s_out.push_str(&format!(" [vpos-reset@line{}]", i));
    }
    for i in r.rewinds {
        s_out.push_str(&format!(" [vpos-rewind@line{}]", i));
    }
    s_out
}

/// [#3697] `format_vpos_range` 와 같은 분석(`vpos_range`)의 JSON 표현.
fn vpos_range_json(
    para: Option<&Paragraph>,
    start_line: Option<usize>,
    end_line: Option<usize>,
) -> serde_json::Value {
    match vpos_range(para, start_line, end_line) {
        Some(r) => serde_json::json!({
            "first": r.first,
            "last": r.last,
            "resets": r.resets,
            "rewinds": r.rewinds,
        }),
        None => serde_json::Value::Null,
    }
}

/// [#3697] `format_line_seg_brief` 와 같은 요약(첫/마지막 줄)의 JSON 표현.
fn line_seg_brief_json(para: Option<&Paragraph>) -> serde_json::Value {
    fn seg_json(seg: &crate::model::paragraph::LineSeg) -> serde_json::Value {
        serde_json::json!({
            "textStart": seg.text_start,
            "lineHeight": seg.line_height,
            "textHeight": seg.text_height,
            "baselineDistance": seg.baseline_distance,
            "lineSpacing": seg.line_spacing,
            "columnStart": seg.column_start,
            "segmentWidth": seg.segment_width,
        })
    }
    let Some(p) = para else {
        return serde_json::Value::Null;
    };
    if p.line_segs.is_empty() {
        return serde_json::json!({ "count": 0 });
    }
    let first = &p.line_segs[0];
    let last = p.line_segs.last().unwrap_or(first);
    serde_json::json!({
        "count": p.line_segs.len(),
        "first": seg_json(first),
        "last": seg_json(last),
    })
}

/// dump-pages에서 line_seg 계약을 빠르게 대조하기 위한 한 줄 요약.
fn format_line_seg_brief(para: Option<&Paragraph>) -> String {
    let Some(p) = para else {
        return String::new();
    };
    if p.line_segs.is_empty() {
        return "ls=0".to_string();
    }
    let first = &p.line_segs[0];
    let last = p.line_segs.last().unwrap_or(first);
    if p.line_segs.len() == 1 {
        format!(
            "ls=1[ts={} lh={} th={} bl={} gap={} cs={} sw={}]",
            first.text_start,
            first.line_height,
            first.text_height,
            first.baseline_distance,
            first.line_spacing,
            first.column_start,
            first.segment_width
        )
    } else {
        format!(
            "ls={}[first ts={} lh={} th={} bl={} gap={} cs={} sw={}; last ts={} lh={} th={} bl={} gap={} cs={} sw={}]",
            p.line_segs.len(),
            first.text_start,
            first.line_height,
            first.text_height,
            first.baseline_distance,
            first.line_spacing,
            first.column_start,
            first.segment_width,
            last.text_start,
            last.line_height,
            last.text_height,
            last.baseline_distance,
            last.line_spacing,
            last.column_start,
            last.segment_width
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::bin_data::BinDataContent;
    use crate::renderer::render_tree::RenderNodeType;

    #[test]
    fn issue3137_focused_partial_repaint_rejects_unsafe_justify_and_extra_spacing() {
        assert!(focused_partial_repaint_alignment_is_safe(
            Alignment::Left,
            false,
            false
        ));
        assert!(focused_partial_repaint_alignment_is_safe(
            Alignment::Justify,
            true,
            false
        ));
        assert!(!focused_partial_repaint_alignment_is_safe(
            Alignment::Justify,
            false,
            false
        ));
        assert!(!focused_partial_repaint_alignment_is_safe(
            Alignment::Justify,
            true,
            true
        ));

        let plain = TextStyle::default();
        assert!(focused_partial_repaint_style_is_safe(&plain));

        for (label, style) in [
            (
                "word spacing",
                TextStyle {
                    extra_word_spacing: 1.0,
                    ..plain.clone()
                },
            ),
            (
                "character spacing",
                TextStyle {
                    extra_char_spacing: 1.0,
                    ..plain.clone()
                },
            ),
            (
                "dash advance",
                TextStyle {
                    extra_dash_advance: 1.0,
                    ..plain.clone()
                },
            ),
            (
                "negative letter spacing",
                TextStyle {
                    letter_spacing: -0.02,
                    ..plain.clone()
                },
            ),
        ] {
            assert!(
                !focused_partial_repaint_style_is_safe(&style),
                "{label} must use full repaint"
            );
        }
    }

    #[test]
    fn issue3137_focused_partial_repaint_rejects_extended_ink_styles() {
        let plain = TextStyle::default();
        let styled = [
            (
                "outline",
                TextStyle {
                    outline_type: 1,
                    ..plain.clone()
                },
            ),
            (
                "shadow",
                TextStyle {
                    shadow_type: 1,
                    shadow_offset_x: 8.0,
                    ..plain.clone()
                },
            ),
            (
                "emboss",
                TextStyle {
                    emboss: true,
                    ..plain.clone()
                },
            ),
            (
                "engrave",
                TextStyle {
                    engrave: true,
                    ..plain.clone()
                },
            ),
            (
                "emphasis",
                TextStyle {
                    emphasis_dot: 1,
                    ..plain.clone()
                },
            ),
            (
                "underline",
                TextStyle {
                    underline: crate::model::style::UnderlineType::Bottom,
                    ..plain.clone()
                },
            ),
            (
                "strike",
                TextStyle {
                    strikethrough: true,
                    ..plain.clone()
                },
            ),
            (
                "superscript",
                TextStyle {
                    superscript: true,
                    ..plain.clone()
                },
            ),
            (
                "subscript",
                TextStyle {
                    subscript: true,
                    ..plain.clone()
                },
            ),
        ];

        for (label, style) in styled {
            assert!(
                !focused_partial_repaint_style_is_safe(&style),
                "{label} must use full repaint"
            );
        }
    }

    #[test]
    fn markdown_table_paragraph_preserves_equation_script() {
        let mut paragraph = Paragraph {
            text: "앞뒤".to_string(),
            ..Default::default()
        };
        paragraph.controls.push(Control::Equation(Box::new(
            crate::model::control::Equation {
                script: "lim _{x rarrow 0}".to_string(),
                ..Default::default()
            },
        )));

        let text = paragraph_text_with_equations(&paragraph);
        assert!(text.contains("앞"));
        assert!(text.contains("lim _{x rarrow 0}"));
        assert!(text.contains("뒤"));
    }

    fn assert_send<T: Send>() {}

    #[test]
    fn issue_2308_document_core_remains_send() {
        assert_send::<DocumentCore>();
    }

    #[test]
    fn issue_2308_stable_compat_projection_reuses_arc_identity() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("samples/issue2004_cell_image_stack.hwp");
        let bytes = std::fs::read(path).expect("read #2004 fixture");
        let mut document =
            crate::wasm_api::HwpDocument::from_bytes(&bytes).expect("parse #2004 fixture");
        let first = document
            .render_normalization
            .sections
            .iter()
            .flatten()
            .next()
            .map(|section| std::sync::Arc::clone(&section.paragraphs))
            .expect("#2004 compatibility projection");

        document.compute_render_normalized();

        let second = document
            .render_normalization
            .sections
            .iter()
            .flatten()
            .next()
            .map(|section| std::sync::Arc::clone(&section.paragraphs))
            .expect("stable #2004 compatibility projection");
        assert!(
            std::sync::Arc::ptr_eq(&first, &second),
            "same section revision must reuse the immutable compatibility projection"
        );
    }

    #[test]
    fn issue_2308_edit_paths_use_explicit_revision_keys() {
        use crate::model::control::Control;
        use crate::model::document::{Document, Section};
        use crate::model::image::Picture;
        use crate::model::paragraph::Paragraph;
        use crate::model::shape::{Caption, DrawingObjAttr, RectangleShape, ShapeObject, TextBox};
        use crate::model::table::{Cell, Table};
        use crate::renderer::render_normalization::RenderPathEntry;

        let caption = || Caption {
            paragraphs: vec![Paragraph::default()],
            ..Default::default()
        };
        let table = Table {
            cells: vec![Cell {
                paragraphs: vec![Paragraph::default()],
                ..Default::default()
            }],
            caption: Some(caption()),
            ..Default::default()
        };
        let shape = ShapeObject::Rectangle(RectangleShape {
            drawing: DrawingObjAttr {
                text_box: Some(TextBox {
                    paragraphs: vec![Paragraph::default()],
                    ..Default::default()
                }),
                ..Default::default()
            },
            ..Default::default()
        });
        let picture = Picture {
            caption: Some(caption()),
            ..Default::default()
        };
        let document = Document {
            sections: vec![Section {
                paragraphs: vec![Paragraph {
                    controls: vec![
                        Control::Table(Box::new(table)),
                        Control::Shape(Box::new(shape)),
                        Control::Picture(Box::new(picture)),
                    ],
                    ..Default::default()
                }],
                ..Default::default()
            }],
            ..Default::default()
        };
        let mut core = DocumentCore::new_empty();
        core.set_document(document);

        core.mark_render_normalization_path_dirty(0, 0, 0, 0, 0)
            .expect("table cell path");
        core.mark_render_normalization_path_dirty(
            0,
            0,
            0,
            crate::document_core::TABLE_CAPTION_CELL_SENTINEL,
            0,
        )
        .expect("table caption path");
        core.mark_render_normalization_path_dirty(0, 0, 1, 0, 0)
            .expect("shape textbox path");
        core.mark_render_normalization_path_dirty(0, 0, 2, 0, 0)
            .expect("picture caption path");

        let entries = core
            .render_normalization
            .path_revisions
            .keys()
            .filter_map(|path| path.entries.first())
            .collect::<Vec<_>>();
        assert!(entries.iter().any(|entry| matches!(
            entry,
            RenderPathEntry::TableCell {
                control_index: 0,
                cell_index: 0,
                paragraph_index: 0
            }
        )));
        assert!(entries.iter().any(|entry| matches!(
            entry,
            RenderPathEntry::TableCaption {
                control_index: 0,
                paragraph_index: 0
            }
        )));
        assert!(entries.iter().any(|entry| matches!(
            entry,
            RenderPathEntry::ShapeTextBox {
                control_index: 1,
                paragraph_index: 0
            }
        )));
        assert!(entries.iter().any(|entry| matches!(
            entry,
            RenderPathEntry::PictureCaption {
                control_index: 2,
                paragraph_index: 0
            }
        )));
    }

    #[test]
    fn print_profile_suppresses_interactive_output_options_without_mutating_state() {
        let bytes = include_bytes!("../../../samples/render-p35-font-native-bitmap.hwpx");
        let mut core = DocumentCore::from_bytes(bytes).expect("fixture parses");
        core.show_paragraph_marks = true;
        core.show_control_codes = true;
        core.show_transparent_borders = true;
        core.debug_overlay = true;

        let screen = core
            .build_page_layer_tree_with_profile(0, RenderProfile::Screen)
            .expect("screen layer tree");
        let print = core
            .build_page_layer_tree_with_profile(0, RenderProfile::Print)
            .expect("print layer tree");

        assert!(screen.output_options.show_paragraph_marks);
        assert!(screen.output_options.show_control_codes);
        assert!(screen.output_options.show_transparent_borders);
        assert!(screen.output_options.debug_overlay);
        assert!(!print.output_options.show_paragraph_marks);
        assert!(!print.output_options.show_control_codes);
        assert!(!print.output_options.show_transparent_borders);
        assert!(!print.output_options.debug_overlay);
        assert!(core.show_paragraph_marks);
        assert!(core.show_control_codes);
        assert!(core.show_transparent_borders);
        assert!(core.debug_overlay);
    }

    #[test]
    fn embedded_font_loading_enforces_per_page_cumulative_limit() {
        let contents = vec![
            BinDataContent {
                id: 1,
                data: vec![1; 4].into(),
                extension: "ttf".to_string(),
            },
            BinDataContent {
                id: 2,
                data: vec![2; 4].into(),
                extension: "ttf".to_string(),
            },
            BinDataContent {
                id: 3,
                data: vec![3; 2].into(),
                extension: "ttf".to_string(),
            },
        ];

        let loaded = load_bounded_embedded_font_bytes(&contents, &[1, 2, 3, 1], 4, 6);

        assert_eq!(loaded.len(), 2);
        assert_eq!(loaded.get(&1).map(Vec::len), Some(4));
        assert!(!loaded.contains_key(&2));
        assert_eq!(loaded.get(&3).map(Vec::len), Some(2));
        assert_eq!(loaded.values().map(Vec::len).sum::<usize>(), 6);
    }

    #[test]
    fn embedded_font_loading_rejects_oversized_lazy_data_without_unbounded_load() {
        use crate::model::bin_data::{BinDataBytes, BinDataResolver};
        use std::sync::atomic::{AtomicUsize, Ordering};

        #[derive(Debug)]
        struct OversizedLazyFontResolver {
            bounded_limit: AtomicUsize,
        }

        impl BinDataResolver for OversizedLazyFontResolver {
            fn resolve(&self, key: &str) -> Vec<u8> {
                panic!("font loading must remain bounded: {key}")
            }

            fn resolve_limited(&self, _key: &str, max_bytes: usize) -> Option<Vec<u8>> {
                self.bounded_limit.store(max_bytes, Ordering::SeqCst);
                None
            }
        }

        let resolver = std::sync::Arc::new(OversizedLazyFontResolver {
            bounded_limit: AtomicUsize::new(0),
        });
        let contents = vec![BinDataContent {
            id: 1,
            data: BinDataBytes::Lazy {
                resolver: resolver.clone(),
                key: "compressed-oversized-font".to_string(),
            },
            extension: "ttf".to_string(),
        }];

        let loaded = load_bounded_embedded_font_bytes(&contents, &[1, 1], 32, 24);

        assert!(loaded.is_empty());
        assert_eq!(resolver.bounded_limit.load(Ordering::SeqCst), 24);
    }

    /// [Task #1612] `compute_hwp_used_height` 는 per-page 높이를 내야 한다. vpos 는
    /// 다페이지에서 누적값이므로 페이지 시작 오프셋을 차감하지 않으면 page N>1 에서
    /// 누적값(수백~수천px)을 반환해 dump-pages diff 가 "대형 표 과소측정" 으로 오판된다.
    #[test]
    fn task1612_hwp_used_height_is_per_page_not_cumulative() {
        use crate::model::paragraph::{LineSeg, Paragraph};
        use crate::renderer::pagination::{ColumnContent, PageItem};

        let seg = |vpos: i32| LineSeg {
            vertical_pos: vpos,
            line_height: 1700,
            line_spacing: 0,
            ..Default::default()
        };
        // para 0 = page-1 콘텐츠(vpos 0..), para 1 = page-2 콘텐츠(vpos 누적값 66568..).
        let p0 = Paragraph {
            line_segs: vec![seg(0), seg(1700)],
            ..Default::default()
        };
        let p1 = Paragraph {
            line_segs: vec![seg(66568), seg(68268)],
            ..Default::default()
        };
        let paragraphs = vec![p0, p1];

        // "page 2" 단: para 1 만 포함.
        let cc = ColumnContent {
            column_index: 0,
            start_height: 0.0,
            endnote_flow: false,
            items: vec![PageItem::FullParagraph { para_index: 1 }],
            zone_layout: None,
            zone_y_offset: 0.0,
            wrap_around_paras: vec![],
            used_height: 0.0,
            wrap_anchors: std::collections::HashMap::new(),
            overlay_continuations: Vec::new(),
            overlay_cuts: Vec::new(),
        };

        let h = compute_hwp_used_height(&cc, &paragraphs, 96.0).expect("값이 있어야 함");
        // per-page: (68268+1700) − 66568 = 3400 HU ≈ 45.3px. 누적이면 ≈ 933px.
        assert!(
            h < 100.0,
            "per-page 높이(누적 vpos 차감)여야 하는데 {h:.1}px (누적값 미차감 의심)"
        );
    }

    #[test]
    fn build_page_render_tree_exposes_public_page_tree() {
        let mut core = DocumentCore::new_empty();
        core.paginate();

        let tree = core
            .build_page_render_tree(0)
            .expect("empty document should expose page render tree");

        match tree.root.node_type {
            RenderNodeType::Page(page) => {
                assert_eq!(page.page_index, 0);
            }
            other => panic!("root should be Page node, got {:?}", other),
        }
    }

    #[test]
    fn normal_page_layer_export_selects_verified_embedded_bitmap_glyph_sidecar() {
        use crate::model::bin_data::{BinDataBytes, BinDataResolver};
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::page::PageDef;
        use crate::model::paragraph::{CharShapeRef, LineSeg, Paragraph};
        use crate::model::style::{CharShape, Font};
        use crate::renderer::canvaskit_policy::{
            analyze_canvaskit_replay_plan, CanvasKitReplayMode,
        };

        #[derive(Debug)]
        struct UnexpectedFontResolver;

        impl BinDataResolver for UnexpectedFontResolver {
            fn resolve(&self, key: &str) -> Vec<u8> {
                panic!("unused embedded font must remain lazy: {key}")
            }
        }

        let mut document = Document::default();
        document.doc_info.font_faces = vec![Vec::new(); 7];
        document.doc_info.font_faces[0].push(Font {
            name: "RHWP Bitmap SVG Glyph Smoke".to_string(),
            alt_type: 1,
            is_embedded: true,
            bin_item_id_ref: "font-smoke".to_string(),
            resolved_bin_data_id: Some(1),
            ..Default::default()
        });
        document.doc_info.font_faces[0].push(Font {
            name: "Unused embedded font".to_string(),
            alt_type: 1,
            is_embedded: true,
            bin_item_id_ref: "font-unused".to_string(),
            resolved_bin_data_id: Some(2),
            ..Default::default()
        });
        document.doc_info.char_shapes.push(CharShape {
            font_ids: [0; 7],
            ratios: [100; 7],
            relative_sizes: [100; 7],
            base_size: 1200,
            text_color: 0x0000_0000,
            shade_color: 0x00FF_FFFF,
            ..Default::default()
        });
        document.bin_data_content.push(BinDataContent {
            id: 1,
            data: include_bytes!("../../../tests/fixtures/fonts/RHWPBitmapSvgGlyphSmoke.ttf")
                .to_vec()
                .into(),
            extension: "ttf".to_string(),
        });
        document.bin_data_content.push(BinDataContent {
            id: 2,
            data: BinDataBytes::Lazy {
                resolver: std::sync::Arc::new(UnexpectedFontResolver),
                key: "font-unused".to_string(),
            },
            extension: "ttf".to_string(),
        });
        document.sections.push(Section {
            section_def: SectionDef {
                page_def: PageDef {
                    width: 59_528,
                    height: 84_188,
                    margin_left: 8_504,
                    margin_right: 8_504,
                    margin_top: 5_668,
                    margin_bottom: 4_252,
                    ..Default::default()
                },
                ..Default::default()
            },
            paragraphs: vec![Paragraph {
                char_count: 2,
                text: "\u{E100}".to_string(),
                char_offsets: vec![0],
                char_shapes: vec![CharShapeRef {
                    start_pos: 0,
                    char_shape_id: 0,
                }],
                line_segs: vec![LineSeg {
                    text_start: 0,
                    line_height: 1_500,
                    text_height: 1_200,
                    baseline_distance: 1_200,
                    segment_width: 40_000,
                    ..Default::default()
                }],
                has_para_text: true,
                ..Default::default()
            }],
            raw_stream: None,
            raw_provenance: None,
        });

        let mut core = DocumentCore::new_empty();
        core.set_document(document);
        let tree = core
            .build_page_layer_tree_with_profile(0, RenderProfile::Screen)
            .expect("normal page layer export succeeds");
        let json = tree.to_json();
        assert!(json.contains("\"type\":\"textRun\""));
        assert!(json.contains("\"payloadKind\":\"bitmapGlyph\""));
        assert!(json.contains("\"imageKeys\":[\"img:blake3:"));

        let plan = analyze_canvaskit_replay_plan(&tree, CanvasKitReplayMode::Default);
        assert_eq!(plan.text_variants.len(), 1);
        assert_eq!(
            plan.text_variants[0].selected_variant_kind,
            Some("glyphOutline")
        );
        assert!(!plan.text_variants[0].fallback_required);
    }

    #[test]
    fn hwpx_font_native_fixture_reaches_public_layer_export() {
        use crate::renderer::canvaskit_policy::{
            analyze_canvaskit_replay_plan, CanvasKitReplayMode,
        };

        let bytes = include_bytes!("../../../samples/render-p35-font-native-bitmap.hwpx");
        let mut core = DocumentCore::from_bytes(bytes).expect("font-native HWPX fixture parses");
        core.paginate();

        let tree = core
            .build_page_layer_tree_with_profile(0, RenderProfile::Screen)
            .expect("public layer export succeeds");
        let json = tree.to_json();
        assert!(json.contains("\"payloadKind\":\"bitmapGlyph\""));
        assert!(json.contains("\"imageKeys\":[\"img:blake3:"));

        let plan = analyze_canvaskit_replay_plan(&tree, CanvasKitReplayMode::Default);
        assert_eq!(plan.text_variants.len(), 1);
        assert_eq!(
            plan.text_variants[0].selected_variant_kind,
            Some("glyphOutline")
        );
        assert!(!plan.text_variants[0].fallback_required);
    }

    /// [Task #1280 v2] 레이아웃 쿼리가 컨트롤별 plane/zOrder/stableIndex 를 노출하고,
    /// 렌더 정렬키(`paper_node_sort_key`)와 동일하게 한컴 권위 샘플
    /// (글상자=InFrontOfText plane 3, 이미지=Square plane 2)을 산출하는지 검증.
    /// 이미지가 글상자 뒤(plane 2 < 3)로 가는 한컴 정합의 근거.
    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn task1280_v2_control_layout_exposes_plane_z_order_stable_index() {
        // "type":"<name>" 다음 처음 나오는 "<key>": 정수값 추출(plane 은 컨트롤 객체 끝에 부착).
        fn field_after_type(json: &str, type_name: &str, key: &str) -> Option<i64> {
            let tstart = json.find(&format!("\"type\":\"{}\"", type_name))?;
            let needle = format!("\"{}\":", key);
            let kstart = json[tstart..].find(&needle)? + tstart + needle.len();
            let kend = json[kstart..].find(|c| c == ',' || c == '}')? + kstart;
            json[kstart..kend].trim().parse().ok()
        }

        let data = std::fs::read("samples/textbox-under-image.hwp")
            .expect("read samples/textbox-under-image.hwp");
        let mut core = DocumentCore::from_bytes(&data).expect("load textbox-under-image.hwp");
        core.paginate();
        let json = core
            .get_page_control_layout_native(0)
            .expect("control layout for page 0");

        // 신규 필드가 노출됨
        assert!(json.contains("\"plane\":"), "plane 필드 누락: {json}");
        assert!(json.contains("\"zOrder\":"), "zOrder 필드 누락: {json}");
        assert!(
            json.contains("\"stableIndex\":"),
            "stableIndex 필드 누락: {json}"
        );

        // 권위 샘플: 글상자(shape)=InFrontOfText plane 3, 이미지=Square plane 2.
        let shape_plane = field_after_type(&json, "shape", "plane")
            .unwrap_or_else(|| panic!("shape plane 추출 실패: {json}"));
        let image_plane = field_after_type(&json, "image", "plane")
            .unwrap_or_else(|| panic!("image plane 추출 실패: {json}"));
        assert_eq!(shape_plane, 3, "글상자는 InFrontOfText(plane 3): {json}");
        assert_eq!(image_plane, 2, "이미지는 Square(plane 2): {json}");
        // 핵심 불변식: 이미지가 글상자 뒤(plane 작음) — 한컴 동일.
        assert!(
            image_plane < shape_plane,
            "이미지가 글상자 뒤여야 함(plane {image_plane} < {shape_plane}): {json}"
        );
    }

    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    #[test]
    fn render_page_png_native_uses_document_core_skia_layer_path() {
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::page::PageDef;
        use crate::model::paragraph::Paragraph;

        let mut document = Document::default();
        document.sections.push(Section {
            section_def: SectionDef {
                page_def: PageDef {
                    width: 59528,
                    height: 84188,
                    margin_left: 8504,
                    margin_right: 8504,
                    margin_top: 5668,
                    margin_bottom: 4252,
                    margin_header: 4252,
                    margin_footer: 4252,
                    ..Default::default()
                },
                ..Default::default()
            },
            paragraphs: vec![Paragraph::default()],
            raw_stream: None,
            raw_provenance: None,
        });

        let mut core = DocumentCore::new_empty();
        core.set_document(document);

        let png = core
            .render_page_png_native(0)
            .expect("empty document should render through native Skia");

        assert!(png.starts_with(b"\x89PNG\r\n\x1a\n"));
        let decoded = image::load_from_memory(&png).expect("decode native Skia PNG");
        assert!(decoded.width() > 0);
        assert!(decoded.height() > 0);
    }

    #[test]
    fn get_bin_data_returns_zero_based_content_slice() {
        let mut core = DocumentCore::new_empty();
        core.document.bin_data_content.push(BinDataContent {
            id: 1,
            data: vec![0x01, 0x02, 0x03].into(),
            extension: "png".to_string(),
        });
        core.document.bin_data_content.push(BinDataContent {
            id: 2,
            data: vec![0xAA, 0xBB].into(),
            extension: "jpg".to_string(),
        });

        assert_eq!(core.get_bin_data(0), Some(vec![0x01, 0x02, 0x03]));
        assert_eq!(core.get_bin_data(1), Some(vec![0xAA, 0xBB]));
        assert_eq!(core.get_bin_data(2), None);
    }

    #[test]
    fn master_page_selection_uses_final_carried_page_number_parity() {
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::header_footer::{HeaderFooterApply, MasterPage};
        use crate::model::page::PageDef;
        use crate::model::paragraph::Paragraph;

        fn a4_section(section_def: SectionDef) -> Section {
            Section {
                section_def,
                paragraphs: vec![Paragraph::default()],
                raw_stream: None,
                raw_provenance: None,
            }
        }

        let page_def = PageDef {
            width: 59528,
            height: 84188,
            margin_left: 8504,
            margin_right: 8504,
            margin_top: 5668,
            margin_bottom: 4252,
            margin_header: 4252,
            margin_footer: 4252,
            ..Default::default()
        };

        let mut document = Document::default();
        document.sections.push(a4_section(SectionDef {
            page_def: page_def.clone(),
            ..Default::default()
        }));
        document.sections.push(a4_section(SectionDef {
            page_def,
            master_pages: vec![
                MasterPage {
                    apply_to: HeaderFooterApply::Odd,
                    ..Default::default()
                },
                MasterPage {
                    apply_to: HeaderFooterApply::Even,
                    ..Default::default()
                },
            ],
            ..Default::default()
        }));

        let mut core = DocumentCore::new_empty();
        core.set_document(document);
        core.paginate();

        let page = core
            .pagination
            .get(1)
            .and_then(|result| result.pages.first())
            .expect("section 1 first page");
        assert_eq!(
            page.page_number, 2,
            "section 1 first page should carry section 0 page number"
        );
        let active = page
            .active_master_page
            .as_ref()
            .expect("section 1 page should have an active master page");
        assert_eq!(
            active.master_page_index, 1,
            "final page_number=2 must select the Even master page, not the section-local Odd page"
        );
    }

    #[test]
    fn missing_even_master_page_inherits_previous_even_master() {
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::header_footer::{HeaderFooterApply, MasterPage};
        use crate::model::page::PageDef;
        use crate::model::paragraph::Paragraph;

        fn a4_section(section_def: SectionDef) -> Section {
            Section {
                section_def,
                paragraphs: vec![Paragraph::default()],
                raw_stream: None,
                raw_provenance: None,
            }
        }

        let page_def = PageDef {
            width: 59528,
            height: 84188,
            margin_left: 8504,
            margin_right: 8504,
            margin_top: 5668,
            margin_bottom: 4252,
            margin_header: 4252,
            margin_footer: 4252,
            ..Default::default()
        };

        let mut document = Document::default();
        document.sections.push(a4_section(SectionDef {
            page_def: page_def.clone(),
            master_pages: vec![MasterPage {
                apply_to: HeaderFooterApply::Even,
                ..Default::default()
            }],
            ..Default::default()
        }));
        document.sections.push(a4_section(SectionDef {
            page_def,
            master_pages: vec![MasterPage {
                apply_to: HeaderFooterApply::Odd,
                ..Default::default()
            }],
            ..Default::default()
        }));

        let mut core = DocumentCore::new_empty();
        core.set_document(document);
        core.paginate();

        let page = core
            .pagination
            .get(1)
            .and_then(|result| result.pages.first())
            .expect("section 1 first page");
        assert_eq!(page.page_number, 2);
        let active = page
            .active_master_page
            .as_ref()
            .expect("section 1 even page should inherit previous even master page");
        assert_eq!(active.section_index, 0);
        assert_eq!(active.master_page_index, 0);
    }

    #[test]
    fn single_base_master_page_applies_when_matching_parity_is_absent() {
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::header_footer::{HeaderFooterApply, MasterPage};
        use crate::model::page::PageDef;
        use crate::model::paragraph::Paragraph;

        fn a4_section(section_def: SectionDef) -> Section {
            Section {
                section_def,
                paragraphs: vec![Paragraph::default()],
                raw_stream: None,
                raw_provenance: None,
            }
        }

        let page_def = PageDef {
            width: 59528,
            height: 84188,
            margin_left: 8504,
            margin_right: 8504,
            margin_top: 5668,
            margin_bottom: 4252,
            margin_header: 4252,
            margin_footer: 4252,
            ..Default::default()
        };

        let mut document = Document::default();
        document.sections.push(a4_section(SectionDef {
            page_def: page_def.clone(),
            ..Default::default()
        }));
        document.sections.push(a4_section(SectionDef {
            page_def,
            master_pages: vec![MasterPage {
                apply_to: HeaderFooterApply::Odd,
                ..Default::default()
            }],
            ..Default::default()
        }));

        let mut core = DocumentCore::new_empty();
        core.set_document(document);
        core.paginate();

        let page = core
            .pagination
            .get(1)
            .and_then(|result| result.pages.first())
            .expect("section 1 first page");
        assert_eq!(page.page_number, 2);
        let active = page
            .active_master_page
            .as_ref()
            .expect("single base master should apply to carried even page");
        assert_eq!(active.master_page_index, 0);
    }

    #[test]
    fn page_border_fill_api_updates_basis_spacing_and_border() {
        use crate::model::document::{Document, Section, SectionDef};
        use crate::model::paragraph::Paragraph;

        let mut core = DocumentCore::new_empty();
        let mut document = Document::default();
        document.sections.push(Section {
            section_def: SectionDef::default(),
            paragraphs: vec![Paragraph::default()],
            raw_stream: None,
            raw_provenance: None,
        });
        core.set_document(document);
        core.paginate();

        let result = core
            .set_page_border_fill_native(
                0,
                r##"{"basis":"page","spacingLeft":567,"spacingRight":567,"spacingTop":567,"spacingBottom":567,
                "borderLeft":{"type":1,"width":1,"color":"#000000"},
                "borderRight":{"type":1,"width":1,"color":"#000000"},
                "borderTop":{"type":1,"width":1,"color":"#000000"},
                "borderBottom":{"type":1,"width":1,"color":"#000000"},
                "fillType":"solid","fillColor":"#ffffff","patternColor":"#000000","patternType":0,
                "fillArea":"paper","applyPage":"all"}"##,
            )
            .expect("page border fill should update");
        assert!(result.contains("\"ok\":true"));

        let json = core
            .get_page_border_fill_native(0)
            .expect("page border fill should be queryable");
        assert!(json.contains("\"basis\":\"page\""));
        assert!(json.contains("\"spacingTop\":567"));
        assert!(json.contains("\"borderFillId\":"));
        assert!(json.contains("\"borderTop\":{\"type\":1"));

        let info = core
            .get_page_info_native(0)
            .expect("page info should reflect updated page border");
        assert!(info.contains("\"pageBorderTop\":"));
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn page_border_fill_sample_basis_matches_hancom_ui() {
        use crate::model::page::PageBorderBasis;

        fn json_number(json: &str, key: &str) -> f64 {
            let needle = format!("\"{}\":", key);
            let start = json
                .find(&needle)
                .unwrap_or_else(|| panic!("{key} missing in {json}"))
                + needle.len();
            let end = json[start..]
                .find(|c| c == ',' || c == '}')
                .map(|idx| start + idx)
                .unwrap_or(json.len());
            json[start..end].trim().parse().unwrap()
        }

        fn assert_basis(path: &str, expected: &str, expected_render_basis: PageBorderBasis) -> f64 {
            let data = std::fs::read(path).unwrap_or_else(|e| panic!("read {path}: {e}"));
            let core =
                DocumentCore::from_bytes(&data).unwrap_or_else(|e| panic!("load {path}: {e}"));
            let json = core
                .get_page_border_fill_native(0)
                .unwrap_or_else(|e| panic!("query {path}: {e}"));
            assert!(
                json.contains(&format!("\"basis\":\"{}\"", expected)),
                "{path} expected basis={expected}, got {json}"
            );
            assert_eq!(
                core.document.sections[0].section_def.page_border_fill.basis,
                expected_render_basis
            );
            let info = core
                .get_page_info_native(0)
                .unwrap_or_else(|e| panic!("page info {path}: {e}"));
            json_number(&info, "pageBorderTop")
        }

        let paper_hwp_top =
            assert_basis("samples/종이기준.hwp", "paper", PageBorderBasis::PaperBased);
        assert_basis(
            "samples/종이기준.hwpx",
            "paper",
            PageBorderBasis::PaperBased,
        );
        let page_hwp_top = assert_basis("samples/쪽기준.hwp", "page", PageBorderBasis::BodyBased);
        assert_basis("samples/쪽기준.hwpx", "page", PageBorderBasis::BodyBased);
        let sample16_top = assert_basis(
            "samples/hwp3-sample16-hwp5.hwp",
            "page",
            PageBorderBasis::BodyBased,
        );
        assert!(
            page_hwp_top > paper_hwp_top,
            "쪽 기준 border top should be inside paper 기준: paper={paper_hwp_top}, page={page_hwp_top}"
        );
        assert!(
            (sample16_top - 49.2).abs() < 0.2,
            "sample16 page-basis UI should use body top minus spacing and double-line outset: top={sample16_top}"
        );
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn inject_png_phys_inserts_after_ihdr() {
        // 최소 PNG: 8-byte signature + IHDR chunk (13 bytes data)
        let mut png = Vec::new();
        png.extend_from_slice(&[0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]); // signature
                                                                                  // IHDR: length=13
        png.extend_from_slice(&13u32.to_be_bytes());
        png.extend_from_slice(b"IHDR");
        png.extend_from_slice(&[0u8; 13]); // dummy IHDR data
        let ihdr_crc = super::png_crc32(&{
            let mut v = Vec::new();
            v.extend_from_slice(b"IHDR");
            v.extend_from_slice(&[0u8; 13]);
            v
        });
        png.extend_from_slice(&ihdr_crc.to_be_bytes());
        let ihdr_end = png.len(); // 8 + 4 + 4 + 13 + 4 = 33
                                  // IDAT dummy
        png.extend_from_slice(&4u32.to_be_bytes());
        png.extend_from_slice(b"IDAT");
        png.extend_from_slice(&[0xDE, 0xAD, 0xBE, 0xEF]);
        let idat_crc = super::png_crc32(&{
            let mut v = Vec::new();
            v.extend_from_slice(b"IDAT");
            v.extend_from_slice(&[0xDE, 0xAD, 0xBE, 0xEF]);
            v
        });
        png.extend_from_slice(&idat_crc.to_be_bytes());

        let result = super::inject_png_phys(png.clone(), 300.0);

        // pHYs chunk 삽입 확인: IHDR 직후에 pHYs 가 위치
        assert_eq!(&result[ihdr_end + 4..ihdr_end + 8], b"pHYs");
        // pHYs data length = 9
        let phys_len = u32::from_be_bytes([
            result[ihdr_end],
            result[ihdr_end + 1],
            result[ihdr_end + 2],
            result[ihdr_end + 3],
        ]);
        assert_eq!(phys_len, 9);
        // 300 DPI → 11811 ppm (300 / 0.0254 = 11811.02...)
        let ppm = u32::from_be_bytes([
            result[ihdr_end + 8],
            result[ihdr_end + 9],
            result[ihdr_end + 10],
            result[ihdr_end + 11],
        ]);
        assert_eq!(ppm, 11811);
        // unit = 1 (meter)
        assert_eq!(result[ihdr_end + 16], 1);
        // IDAT 는 pHYs 뒤에 보존
        let phys_chunk_size = 4 + 4 + 9 + 4; // 21
        let idat_pos = ihdr_end + phys_chunk_size;
        assert_eq!(&result[idat_pos + 4..idat_pos + 8], b"IDAT");
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn png_crc32_known_value() {
        let crc = super::png_crc32(b"IHDR");
        assert_eq!(crc, 0xA8A1_AE0A);
    }

    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    #[test]
    fn vlm_target_from_str_all_variants() {
        use super::VlmTarget;
        assert_eq!(VlmTarget::from_str("claude"), Some(VlmTarget::Claude));
        assert_eq!(VlmTarget::from_str("gpt4v-low"), Some(VlmTarget::Gpt4vLow));
        assert_eq!(VlmTarget::from_str("gpt4v_low"), Some(VlmTarget::Gpt4vLow));
        assert_eq!(
            VlmTarget::from_str("gpt4v-high"),
            Some(VlmTarget::Gpt4vHigh)
        );
        assert_eq!(VlmTarget::from_str("gpt4v"), Some(VlmTarget::Gpt4vHigh));
        assert_eq!(VlmTarget::from_str("gemini"), Some(VlmTarget::Gemini));
        assert_eq!(VlmTarget::from_str("qwen-vl"), Some(VlmTarget::QwenVl));
        assert_eq!(VlmTarget::from_str("qwen_vl"), Some(VlmTarget::QwenVl));
        assert_eq!(VlmTarget::from_str("qwen"), Some(VlmTarget::QwenVl));
        assert_eq!(VlmTarget::from_str("llava"), Some(VlmTarget::Llava));
        assert_eq!(VlmTarget::from_str("CLAUDE"), Some(VlmTarget::Claude));
        assert_eq!(VlmTarget::from_str("unknown"), None);
    }

    #[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
    #[test]
    fn vlm_target_constraints_are_sane() {
        use super::VlmTarget;
        let targets = [
            VlmTarget::Claude,
            VlmTarget::Gpt4vLow,
            VlmTarget::Gpt4vHigh,
            VlmTarget::Gemini,
            VlmTarget::QwenVl,
            VlmTarget::Llava,
        ];
        for t in &targets {
            let (edge, pixels) = t.constraints();
            assert!(edge > 0, "{:?} edge should be positive", t);
            assert!(pixels > 0, "{:?} pixels should be positive", t);
            assert!(
                (edge as u64) * (edge as u64) >= pixels,
                "{:?} max_pixels should be reachable within edge",
                t
            );
        }
    }
}
