//! 표 테두리 수집/렌더링 + 문단 테두리 라인 생성

use super::super::render_tree::*;
use super::super::style_resolver::ResolvedBorderStyle;
use super::super::{LineStyle, StrokeDash};
use crate::model::style::{BorderLine, BorderLineType, CenterLine};
use crate::model::table::{Cell, Table, MAX_TABLE_GRID_CELLS};

/// [#4287] `build_row_col_x` 가 `row_count × col_count` 2D 그리드를 예약하지 않는 이유.
///
/// 파일에서 온 `u16` 행/열 수를 그대로 곱하면 65535×65535 `Option<f64>` (~68GB) 를
/// 예약해 `handle_alloc_error` / wasm 트랩으로 죽는다. `Table::rebuild_grid()` 와
/// 같은 `MAX_TABLE_GRID_CELLS` 를 넘기면 할당 없이 오류를 돌린다.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct TableGridTooLarge {
    pub row_count: usize,
    pub col_count: usize,
}

impl TableGridTooLarge {
    fn check(row_count: usize, col_count: usize) -> Result<(), Self> {
        if row_count.saturating_mul(col_count) > MAX_TABLE_GRID_CELLS {
            Err(Self {
                row_count,
                col_count,
            })
        } else {
            Ok(())
        }
    }
}

fn merge_border(a: &BorderLine, b: &BorderLine) -> BorderLine {
    if a.line_type == BorderLineType::None {
        return *b;
    }
    if b.line_type == BorderLineType::None {
        return *a;
    }

    let a_w = border_width_to_px(a.width);
    let b_w = border_width_to_px(b.width);
    if (a_w - b_w).abs() > 0.01 {
        return if a_w > b_w { *a } else { *b };
    }

    let priority = |lt: BorderLineType| -> u8 {
        match lt {
            BorderLineType::None => 0,
            BorderLineType::ThinThickThinTriple => 4,
            BorderLineType::Double
            | BorderLineType::ThinThickDouble
            | BorderLineType::ThickThinDouble => 3,
            BorderLineType::Wave | BorderLineType::DoubleWave => 2,
            _ => 1,
        }
    };
    if priority(a.line_type) >= priority(b.line_type) {
        *a
    } else {
        *b
    }
}

/// 병합/숨김 등으로 편집된 셀의 span 내부 위치를 "이미 처리됨"으로 표시한다.
/// h_edges/v_edges 그리드는 각 셀의 자기 span 경계에만 채워지므로, 병합된 셀 내부의
/// 미기록 슬롯(`None`)은 "실제로 선이 없음"과 "병합으로 사라진 경계"를 구분하지 못한다.
/// 투명선 가이드가 후자에도 그려지는 것을 막기 위해 별도 커버리지 그리드에 기록한다.
pub(crate) fn mark_cell_span_interior_covered(
    h_covered: &mut [Vec<bool>],
    v_covered: &mut [Vec<bool>],
    col: usize,
    row: usize,
    col_span: usize,
    row_span: usize,
) {
    let h_rows = h_covered.len();
    let v_cols = v_covered.len();
    let col_count = if h_rows > 0 {
        h_covered[0].len()
    } else {
        return;
    };
    let row_count = if v_cols > 0 {
        v_covered[0].len()
    } else {
        return;
    };
    let end_col = (col + col_span).min(col_count);
    let end_row = (row + row_span).min(row_count);
    if row_span > 1 {
        for r in (row + 1)..end_row {
            if r < h_rows {
                for c in col..end_col {
                    h_covered[r][c] = true;
                }
            }
        }
    }
    if col_span > 1 {
        for c in (col + 1)..end_col {
            if c < v_cols {
                for r in row..end_row {
                    v_covered[c][r] = true;
                }
            }
        }
    }
}

/// 엣지 그리드 슬롯에 테두리를 병합 저장
fn merge_edge_slot(slot: &mut Option<BorderLine>, border: &BorderLine) {
    if border.line_type == BorderLineType::None {
        return;
    }
    *slot = Some(match *slot {
        Some(existing) => merge_border(&existing, border),
        None => *border,
    });
}

/// 행별 열 누적 위치를 계산한다.
/// HWP에서는 각 셀이 독립적인 너비를 가질 수 있어, 같은 열이라도 행마다 열 경계 위치가 다를 수 있다.
/// col_span==1인 셀의 실제 너비를 사용하고, 해당 위치에 셀이 없으면 전역 col_widths를 폴백한다.
pub(crate) fn build_row_col_x(
    table: &Table,
    col_widths: &[f64],
    col_count: usize,
    row_count: usize,
    cell_spacing: f64,
    dpi: f64,
    width_scale: f64,
) -> Result<Vec<Vec<f64>>, TableGridTooLarge> {
    use super::super::hwpunit_to_px;
    TableGridTooLarge::check(row_count, col_count)?;
    // 셀 너비 그리드 구축 (O(cells) 탐색 1회)
    let mut cell_width_grid = vec![vec![None::<f64>; col_count]; row_count];
    for cell in &table.cells {
        if cell.col_span != 1 || cell.width == 0 {
            continue;
        }
        let r = cell.row as usize;
        let c = cell.col as usize;
        if r >= row_count || c >= col_count {
            continue;
        }
        if let Some(row) = cell_width_grid.get_mut(r) {
            if let Some(slot) = row.get_mut(c) {
                *slot = Some(hwpunit_to_px(cell.width as i32, dpi) * width_scale);
            }
        }
    }
    let mut base_rx = vec![0.0f64; col_count + 1];
    for c in 0..col_count {
        base_rx[c + 1] =
            base_rx[c] + col_widths[c] + if c + 1 < col_count { cell_spacing } else { 0.0 };
    }

    let target_total = if table.common.width > 0 {
        hwpunit_to_px(table.common.width as i32, dpi) * width_scale
            + cell_spacing * col_count.saturating_sub(1) as f64
    } else {
        base_rx.last().copied().unwrap_or(0.0)
    };

    // [Issue #5590] 행마다 다른 열 구획을 선언한 표.
    //
    // 전역 열 grid 하나로 모든 행을 그리면, 행별 선언 구획이 서로 어긋나는 표에서
    // 어느 행인가는 반드시 진다. 실제로 00288(약장 배치표)은 **모든 행의 셀 폭 합이
    // 표 폭과 정확히 같은데도** 마지막 열이 1,006HU(13.4px) 깎여 격자가 어긋났다 —
    // 전역 grid 가 앞 열들을 다른 행 기준으로 풀고 남은 폭을 마지막 열에 떠넘긴 결과다.
    //
    // 그 행의 셀이 (1) 0열부터 빈틈없이 (2) 마지막 열까지 덮고 (3) 선언 폭 합이 표 폭과
    // 일치하면, 그 행은 자기 구획을 스스로 완결한 것이다. 이때는 전역 grid 대신 선언
    // 구획을 그대로 쓴다. 셋 중 하나라도 어긋나는 행은 종전대로 전역 grid 를 따른다.
    //
    // 아래 Studio 명시 힌트(`local_resize_rows`) 경로는 `local_resize_cell_widths` 라는
    // 별도 폭 원본을 쓰므로 건드리지 않는다.
    // 전역 grid 가 표 선언 폭과 이미 맞는 표는 건드리지 않는다. 그런 표에서는 행별
    // 구획을 다시 세울 근거가 없고(한컴 정합 픽스처 form-002 의 부분 가로선이 짧아진다),
    // 이 결함은 전역 grid 가 선언 폭과 어긋난 표에서만 나타난다.
    let global_grid_matches_declared =
        (base_rx.last().copied().unwrap_or(0.0) - target_total).abs() <= 0.5;
    if table.local_resize_rows.is_empty() && !global_grid_matches_declared {
        let mut declared = vec![base_rx.clone(); row_count];
        let mut any_declared_row = false;
        for (r, row_x) in declared.iter_mut().enumerate().take(row_count) {
            let Some(candidate) = declared_row_col_x(
                table,
                r,
                col_count,
                cell_spacing,
                dpi,
                width_scale,
                target_total,
            ) else {
                continue;
            };
            // 전역 grid 와 사실상 같은 행은 그대로 둔다. 누적 순서만 다른 값으로
            // 갈아끼우면 부동소수 끝자리가 흔들려 SVG 골든이 의미 없이 깨진다.
            if candidate
                .iter()
                .zip(base_rx.iter())
                .all(|(a, b)| (a - b).abs() <= 0.01)
            {
                continue;
            }
            any_declared_row = true;
            *row_x = candidate;
        }
        if any_declared_row {
            // [#5720] 선언 완결 행이 있는 표에서, 전역 grid 폴백으로 남은 행
            // (세로 병합에 덮인 불완전 행 등)의 경계가 표 선언 폭을 넘으면 선언
            // 폭으로 비례 축소한다. 행별 선언이 서로 어긋나는 표는 병합 셀 제약이
            // 모순이라 전역 grid 의 결핍 보정("뒤쪽 열 확장")이 누적돼 선언 폭을
            // 넘는데(2734559: 638.7px 선언 → 726.9px, 용지 밖 10.7px), 한글 2022
            // 는 표를 선언 폭 그대로 그린다(COM PDF 실측 76.4~716.7px). 선언 완결
            // 행은 그대로 두고 폴백 행만 줄여, 표 상자 폭 판정(#5590)이 선언 폭에
            // 수렴하게 한다.
            let base_total = base_rx.last().copied().unwrap_or(0.0);
            if target_total > 0.0 && base_total > target_total + 0.5 {
                let scale = target_total / base_total;
                for row_x in declared.iter_mut() {
                    let is_base_fallback = row_x
                        .iter()
                        .zip(base_rx.iter())
                        .all(|(a, b)| (a - b).abs() <= 0.01);
                    if is_base_fallback {
                        for x in row_x.iter_mut() {
                            *x *= scale;
                        }
                    }
                }
            }
            return Ok(declared);
        }
    }

    if table.common.treat_as_char {
        return Ok(vec![base_rx; row_count]);
    }

    let inferred_local_resize_rows = table.inferred_local_resize_rows();
    if !table.local_resize_rows.is_empty() || !inferred_local_resize_rows.is_empty() {
        let mut row_col_x_from_cells = vec![base_rx.clone(); row_count];
        let mut has_cell_order_row = false;
        for (r, row_x) in row_col_x_from_cells.iter_mut().enumerate().take(row_count) {
            let row_idx = r as u16;
            let is_explicit_local_resize = table.local_resize_rows.contains(&row_idx);
            let is_inferred_local_resize = inferred_local_resize_rows.contains(&row_idx);
            if !is_explicit_local_resize && !is_inferred_local_resize {
                continue;
            }
            let mut row_cells: Vec<_> = table
                .cells
                .iter()
                .enumerate()
                .filter(|(_, cell)| cell.row as usize == r && cell.row_span == 1)
                .collect();
            row_cells.sort_by_key(|(_, cell)| cell.col);
            let has_width_overrides = row_cells.iter().any(|(cell_idx, _)| {
                table
                    .local_resize_cell_widths
                    .iter()
                    .any(|(idx, _)| idx == cell_idx)
            });

            let mut cursor = 0.0;
            let mut next_col = 0usize;
            let mut candidate = vec![0.0f64; col_count + 1];
            let mut valid = !row_cells.is_empty();
            for (cell_idx, cell) in row_cells {
                let c = cell.col as usize;
                let span = cell.col_span.max(1) as usize;
                let end = (c + span).min(col_count);
                if c != next_col || end <= c {
                    valid = false;
                    break;
                }

                candidate[c] = cursor;
                let cell_w = table
                    .local_resize_cell_widths
                    .iter()
                    .find(|(idx, _)| *idx == cell_idx)
                    .map(|(_, width)| hwpunit_to_px(*width as i32, dpi))
                    .unwrap_or_else(|| {
                        if has_width_overrides {
                            (base_rx[end] - base_rx[c]).max(0.0)
                        } else {
                            hwpunit_to_px(cell.width as i32, dpi) * width_scale
                        }
                    });
                let end_x = cursor + cell_w;
                for inner_col in c + 1..end {
                    let ratio = (inner_col - c) as f64 / span as f64;
                    candidate[inner_col] = cursor + cell_w * ratio;
                }
                candidate[end] = end_x;
                cursor = end_x + if end < col_count { cell_spacing } else { 0.0 };
                next_col = end;
            }

            if valid && next_col == col_count {
                let residual = target_total - cursor;
                if residual < -0.5 {
                    valid = false;
                } else if residual > 0.5 {
                    if is_explicit_local_resize {
                        // Studio 런타임의 명시적 힌트는 기존 동작을 보존한다.
                        candidate[col_count] += residual;
                    } else {
                        // 자동 추론 행의 부족 폭을 마지막 셀에 몰아주면 퇴화한
                        // 앞 셀 폭이 그대로 노출된다. 추론이 불완전하면 base grid로
                        // 폴백하고 마지막 셀의 경계를 임의로 늘리지 않는다.
                        valid = false;
                    }
                }
            }

            if valid && next_col == col_count {
                *row_x = candidate;
                has_cell_order_row = true;
            }
        }

        if has_cell_order_row
            && row_col_x_from_cells.iter().any(|rx| {
                rx.iter()
                    .zip(base_rx.iter())
                    .any(|(a, b)| (a - b).abs() > 0.01)
            })
        {
            return Ok(row_col_x_from_cells);
        }
    }

    let has_independent_widths = cell_width_grid.iter().any(|row| {
        row.iter().enumerate().any(|(c, w)| {
            w.map(|actual| (actual - col_widths.get(c).copied().unwrap_or(actual)).abs() > 0.01)
                .unwrap_or(false)
        })
    });
    if !has_independent_widths {
        return Ok(vec![base_rx; row_count]);
    }

    let fallback_w = hwpunit_to_px(1800, dpi);
    let mut row_col_x = vec![vec![0.0f64; col_count + 1]; row_count];
    for r in 0..row_count {
        for c in 0..col_count {
            let w = cell_width_grid[r][c]
                .or_else(|| col_widths.get(c).copied())
                .unwrap_or(fallback_w);
            row_col_x[r][c + 1] =
                row_col_x[r][c] + w + if c + 1 < col_count { cell_spacing } else { 0.0 };
        }
        // 저장 파일의 cell.width는 병합 제약을 풀기 전 보조값일 수 있다.
        // 행별 누적 폭이 표 외곽 폭과 맞지 않으면 독립 segment가 아니라 전역 grid를 따른다.
        // Stage 12의 로컬 segment 리사이즈는 보상 리사이즈로 행 전체 폭을 유지하므로 이 조건을 통과한다.
        if (row_col_x[r][col_count] - target_total).abs() > 0.5 {
            row_col_x[r].clone_from_slice(&base_rx);
        }
    }
    Ok(row_col_x)
}

/// [Issue #5590] 한 행이 자기 열 구획을 스스로 완결했는지 보고, 그렇다면 그 행의 x 경계를 만든다.
///
/// 조건 셋을 모두 만족해야 한다.
/// 1. 그 행에서 시작하는(`row_span == 1`) 셀만으로 0열부터 빈틈없이 이어진다.
/// 2. 마지막 열까지 덮는다.
/// 3. 선언 폭 합이 표 폭(`target_total`)과 일치한다.
///
/// 병합 셀 안쪽 열 경계는 span 비율로 나눈다 — 그 경계를 쓰는 셀이 이 행에는 없고,
/// 세로선 그리드가 열 개수를 맞춰야 하기 때문이다(기존 local-resize 경로와 같은 규약).
#[allow(clippy::too_many_arguments)]
fn declared_row_col_x(
    table: &Table,
    row: usize,
    col_count: usize,
    cell_spacing: f64,
    dpi: f64,
    width_scale: f64,
    target_total: f64,
) -> Option<Vec<f64>> {
    use super::super::hwpunit_to_px;
    let mut row_cells: Vec<_> = table
        .cells
        .iter()
        .filter(|cell| cell.row as usize == row && cell.row_span == 1 && cell.width > 0)
        .collect();
    if row_cells.is_empty() {
        return None;
    }
    row_cells.sort_by_key(|cell| cell.col);

    let mut candidate = vec![0.0f64; col_count + 1];
    let mut cursor = 0.0f64;
    let mut next_col = 0usize;
    for cell in row_cells {
        let c = cell.col as usize;
        let span = cell.col_span.max(1) as usize;
        let end = c + span;
        if c != next_col || end > col_count {
            return None;
        }
        candidate[c] = cursor;
        let cell_w = hwpunit_to_px(cell.width as i32, dpi) * width_scale;
        for inner_col in c + 1..end {
            let ratio = (inner_col - c) as f64 / span as f64;
            candidate[inner_col] = cursor + cell_w * ratio;
        }
        cursor += cell_w;
        candidate[end] = cursor;
        if end < col_count {
            cursor += cell_spacing;
        }
        next_col = end;
    }
    if next_col != col_count {
        return None;
    }
    let mismatch = cursor - target_total;
    if mismatch.abs() > 0.5 {
        // [#5720] 행 선언 폭 합이 표 폭과 근소하게(1% 이내) 어긋나는 행도 자기
        // 구획으로 인정하고 표 폭에 맞춰 비례 정규화한다. 2734559 실측 — 0~18행
        // 합 634.96px vs 표 638.72px(0.6%): 한글은 이 행들의 구획을 표 전폭으로
        // 늘려 그린다(COM PDF 세로선 76.4~716.7px). 엄격 일치만 받으면 이 행들이
        // 모순된 전역 grid 로 떨어져 표가 선언 밖으로 벌어진다.
        if target_total <= 0.0 || cursor <= 0.0 || mismatch.abs() > target_total * 0.01 {
            return None;
        }
        let scale = target_total / cursor;
        for x in candidate.iter_mut() {
            *x *= scale;
        }
    }
    Some(candidate)
}

/// 셀 테두리를 엣지 그리드에 수집
/// h_edges[row_boundary][col]: 수평 엣지 (row_boundary 0..=row_count, col 0..col_count)
/// v_edges[col_boundary][row]: 수직 엣지 (col_boundary 0..=col_count, row 0..row_count)
/// borders: [좌, 우, 상, 하]
pub(crate) fn collect_cell_borders(
    h_edges: &mut [Vec<Option<BorderLine>>],
    v_edges: &mut [Vec<Option<BorderLine>>],
    col: usize,
    row: usize,
    col_span: usize,
    row_span: usize,
    borders: &[BorderLine; 4],
) {
    let h_rows = h_edges.len();
    let v_cols = v_edges.len();
    let col_count = if h_rows > 0 { h_edges[0].len() } else { return };
    let row_count = if v_cols > 0 { v_edges[0].len() } else { return };

    let end_col = (col + col_span).min(col_count);
    let end_row = (row + row_span).min(row_count);

    // 상 테두리
    if row < h_rows {
        for c in col..end_col {
            merge_edge_slot(&mut h_edges[row][c], &borders[2]);
        }
    }
    // 하 테두리
    if end_row < h_rows {
        for c in col..end_col {
            merge_edge_slot(&mut h_edges[end_row][c], &borders[3]);
        }
    }
    // 좌 테두리
    if col < v_cols {
        for r in row..end_row {
            merge_edge_slot(&mut v_edges[col][r], &borders[0]);
        }
    }
    // 우 테두리
    if end_col < v_cols {
        for r in row..end_row {
            merge_edge_slot(&mut v_edges[end_col][r], &borders[1]);
        }
    }
}

/// 표 자신의 `borderFillIDRef` 를 바깥 네 변의 **빈 슬롯**에만 보충한다.
///
/// 칸 occupancy 만으로 막으면 일러두기 틀처럼 바깥 칸이 NONE 인 변
/// (왼쪽·아래·제목왼쪽)이 사라진다 (#6311). 반대로 바깥 SOLID 가 하나라도
/// 있는 일반 표까지 빈 칸을 메우면 #469 단 침범·KTX TOC·#6030 행 괘선이
/// 깨진다. 제목 칸만 바깥 SOLID 를 일부 그린 **일러두기 부분 프레임**만
/// occupancy+NONE 슬롯을 메우고, 칸이 안 덮는 구멍은 종전 fallback 을 둔다.
pub(crate) fn apply_table_outer_border_fill(
    h_edges: &mut [Vec<Option<BorderLine>>],
    v_edges: &mut [Vec<Option<BorderLine>>],
    table_borders: &[BorderLine; 4],
    cells: &[Cell],
) {
    if h_edges.is_empty() || v_edges.is_empty() {
        return;
    }
    let col_count = h_edges[0].len();
    let row_count = v_edges[0].len();
    if h_edges.len() != row_count + 1 || v_edges.len() != col_count + 1 {
        return;
    }

    let mut h_occupied = vec![vec![false; col_count]; row_count + 1];
    let mut v_occupied = vec![vec![false; row_count]; col_count + 1];
    for cell in cells {
        let c = cell.col as usize;
        let r = cell.row as usize;
        if c >= col_count || r >= row_count {
            continue;
        }
        let ec = (c + cell.col_span as usize).min(col_count);
        let er = (r + cell.row_span as usize).min(row_count);
        if r == 0 {
            for cc in c..ec {
                h_occupied[0][cc] = true;
            }
        }
        if er == row_count {
            for cc in c..ec {
                h_occupied[row_count][cc] = true;
            }
        }
        if c == 0 {
            for rr in r..er {
                v_occupied[0][rr] = true;
            }
        }
        if ec == col_count {
            for rr in r..er {
                v_occupied[col_count][rr] = true;
            }
        }
    }

    let fill_occupied = is_callout_partial_frame(h_edges, v_edges, &h_occupied);

    let fill = |slot: &mut Option<BorderLine>, border: &BorderLine, occupied: bool| {
        if slot.is_none()
            && border.line_type != BorderLineType::None
            && (!occupied || fill_occupied)
        {
            *slot = Some(*border);
        }
    };

    for c in 0..col_count {
        fill(&mut h_edges[0][c], &table_borders[2], h_occupied[0][c]);
        fill(
            &mut h_edges[row_count][c],
            &table_borders[3],
            h_occupied[row_count][c],
        );
    }
    for r in 0..row_count {
        fill(&mut v_edges[0][r], &table_borders[0], v_occupied[0][r]);
        fill(
            &mut v_edges[col_count][r],
            &table_borders[1],
            v_occupied[col_count][r],
        );
    }
}

fn outer_slot_drawn(slot: &Option<BorderLine>) -> bool {
    slot.as_ref()
        .is_some_and(|border| border.line_type != BorderLineType::None)
}

/// 일러두기 틀: 첫 행 제목 칸만 바깥 SOLID 를 일부 그리고, 아래·본문 좌우는
/// 칸이 NONE 이다. 일반 박스(좌우·아래가 이미 있는 부분 시작 표)는 제외한다.
fn is_callout_partial_frame(
    h_edges: &[Vec<Option<BorderLine>>],
    v_edges: &[Vec<Option<BorderLine>>],
    h_occupied: &[Vec<bool>],
) -> bool {
    let col_count = h_edges[0].len();
    let row_count = v_edges[0].len();
    if row_count < 2 || col_count < 2 {
        return false;
    }

    let mut top_drawn = false;
    let mut top_empty_occupied = false;
    for c in 0..col_count {
        if outer_slot_drawn(&h_edges[0][c]) {
            top_drawn = true;
        } else if h_occupied[0][c] {
            top_empty_occupied = true;
        }
    }
    if !top_drawn || !top_empty_occupied {
        return false;
    }

    if (0..col_count).any(|c| outer_slot_drawn(&h_edges[row_count][c])) {
        return false;
    }

    // 본문 행의 좌·우 바깥 SOLID 가 있으면 일반 박스다. 제목 행(row 0) 토막만 허용.
    for r in 1..row_count {
        if outer_slot_drawn(&v_edges[0][r]) || outer_slot_drawn(&v_edges[col_count][r]) {
            return false;
        }
    }

    true
}

/// 엣지 그리드에서 테두리 Line 노드를 생성
/// 연속된 같은 스타일의 엣지 세그먼트는 하나의 Line으로 병합하여
/// 이중선/삼중선의 교차점 렌더링을 깔끔하게 처리한다.
/// row_col_x: 행별 열 누적 위치 (셀별 독립 너비 지원)
pub(crate) fn render_edge_borders(
    tree: &mut PageLayoutContext,
    h_edges: &[Vec<Option<BorderLine>>],
    v_edges: &[Vec<Option<BorderLine>>],
    row_col_x: &[Vec<f64>],
    row_y: &[f64],
    table_x: f64,
    table_y: f64,
    top_clip_y: Option<f64>,
) -> Vec<RenderNode> {
    let mut nodes = Vec::new();
    let row_count = if row_y.len() > 1 { row_y.len() - 1 } else { 0 };

    // 수평 엣지 렌더링
    for (ri, h_row) in h_edges.iter().enumerate() {
        let row_node_start = nodes.len();
        let y = table_y + row_y.get(ri).copied().unwrap_or(0.0);
        // 행 경계의 열 위치: 경계 아래 행 (또는 마지막 행) 기준
        let ref_row = ri.min(row_count.saturating_sub(1));
        let ref_cx = &row_col_x[ref_row.min(row_col_x.len() - 1)];
        let mut seg_start: Option<usize> = None;
        let mut seg_border: Option<BorderLine> = None;

        for (ci, edge_opt) in h_row.iter().enumerate() {
            let same_style = match (edge_opt, &seg_border) {
                (Some(e), Some(s)) => {
                    e.line_type == s.line_type && e.width == s.width && e.color == s.color
                }
                _ => false,
            };

            if let Some(border) = edge_opt {
                if same_style {
                    // 같은 스타일 → 세그먼트 연장
                } else {
                    // 다른 스타일 → 이전 세그먼트 마무리
                    if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
                        let x1 = table_x + ref_cx[start];
                        let x2 = table_x + ref_cx[ci];
                        nodes.extend(create_border_line_nodes(tree, &sb, x1, y, x2, y));
                    }
                    seg_start = Some(ci);
                    seg_border = Some(*border);
                }
            } else {
                if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
                    let x1 = table_x + ref_cx[start];
                    let x2 = table_x + ref_cx[ci];
                    nodes.extend(create_border_line_nodes(tree, &sb, x1, y, x2, y));
                }
                seg_start = None;
                seg_border = None;
            }
        }
        // 마지막 세그먼트
        if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
            let x1 = table_x + ref_cx[start];
            let x2 = table_x + ref_cx.get(h_row.len()).copied().unwrap_or(ref_cx[start]);
            nodes.extend(create_border_line_nodes(tree, &sb, x1, y, x2, y));
        }
        if ri == 0 {
            if let Some(clip_y) = top_clip_y {
                inset_horizontal_border_group_at_top_clip(&mut nodes[row_node_start..], clip_y);
            }
        }
    }

    // 수직 엣지 렌더링 (행별로 x 위치가 다를 수 있음)
    for (ci, v_col) in v_edges.iter().enumerate() {
        let mut seg_start: Option<usize> = None;
        let mut seg_border: Option<BorderLine> = None;
        let mut seg_x: f64 = 0.0;

        for (ri, edge_opt) in v_col.iter().enumerate() {
            let x = table_x
                + row_col_x
                    .get(ri)
                    .and_then(|rx| rx.get(ci).copied())
                    .unwrap_or(0.0);
            let same_style = match (edge_opt, &seg_border) {
                (Some(e), Some(s)) => {
                    e.line_type == s.line_type
                        && e.width == s.width
                        && e.color == s.color
                        && (x - seg_x).abs() < 0.01
                }
                _ => false,
            };

            if let Some(border) = edge_opt {
                if same_style {
                    // 같은 스타일 + 같은 x → 세그먼트 연장
                } else {
                    if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
                        let y1 = table_y + row_y[start];
                        let y2 = table_y + row_y[ri];
                        nodes.extend(create_border_line_nodes(tree, &sb, seg_x, y1, seg_x, y2));
                    }
                    seg_start = Some(ri);
                    seg_border = Some(*border);
                    seg_x = x;
                }
            } else {
                if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
                    let y1 = table_y + row_y[start];
                    let y2 = table_y + row_y[ri];
                    nodes.extend(create_border_line_nodes(tree, &sb, seg_x, y1, seg_x, y2));
                }
                seg_start = None;
                seg_border = None;
            }
        }
        if let (Some(start), Some(ref sb)) = (seg_start, seg_border) {
            let y1 = table_y + row_y[start];
            let y2 = table_y + row_y.get(v_col.len()).copied().unwrap_or(row_y[start]);
            nodes.extend(create_border_line_nodes(tree, &sb, seg_x, y1, seg_x, y2));
        }
    }

    nodes
}

/// Keep only a table's physical top-frame paint inside an owning Body clip.
///
/// SVG, Web Canvas, and native Canvas all clip a stroke by its painted extent.
/// A horizontal centreline exactly on the Body top therefore loses half of its
/// stroke.  Move the complete top-border group by one common delta so compound
/// borders retain their internal spacing.  The caller passes only the nodes
/// emitted for row boundary 0; table/cell boxes and every non-table line remain
/// unchanged.
fn inset_horizontal_border_group_at_top_clip(nodes: &mut [RenderNode], clip_y: f64) {
    const PAINT_INSET_EPSILON_PX: f64 = 0.05;

    let painted_top = nodes
        .iter()
        .filter_map(|node| match &node.node_type {
            RenderNodeType::Line(line) if (line.y1 - line.y2).abs() <= 0.01 => {
                Some(line.y1.min(line.y2) - line.style.width.max(0.0) / 2.0)
            }
            _ => None,
        })
        .fold(f64::INFINITY, f64::min);
    if !painted_top.is_finite() || painted_top >= clip_y + PAINT_INSET_EPSILON_PX {
        return;
    }

    let delta_y = clip_y + PAINT_INSET_EPSILON_PX - painted_top;
    for node in nodes {
        let RenderNodeType::Line(line) = &mut node.node_type else {
            continue;
        };
        if (line.y1 - line.y2).abs() > 0.01 {
            continue;
        }
        line.y1 += delta_y;
        line.y2 += delta_y;
        node.bbox.y += delta_y;
    }
}

/// 투명 테두리를 빨간색 점선 Line 노드로 생성한다.
/// 엣지 그리드에서 None 슬롯(투명 테두리)을 찾아 연속 구간을 병합한다.
pub(crate) fn render_transparent_borders(
    tree: &mut PageLayoutContext,
    h_edges: &[Vec<Option<BorderLine>>],
    v_edges: &[Vec<Option<BorderLine>>],
    h_covered: &[Vec<bool>],
    v_covered: &[Vec<bool>],
    row_col_x: &[Vec<f64>],
    row_y: &[f64],
    table_x: f64,
    table_y: f64,
) -> Vec<RenderNode> {
    let mut nodes = Vec::new();
    let color: u32 = 0x0000FF; // BGR: Red
    let width = 0.4_f64;
    let dash = StrokeDash::Dot;
    let row_count = if row_y.len() > 1 { row_y.len() - 1 } else { 0 };
    let is_h_covered = |ri: usize, ci: usize| -> bool {
        h_covered
            .get(ri)
            .and_then(|row| row.get(ci).copied())
            .unwrap_or(false)
    };
    let is_v_covered = |ci: usize, ri: usize| -> bool {
        v_covered
            .get(ci)
            .and_then(|col| col.get(ri).copied())
            .unwrap_or(false)
    };

    // 수평 투명 엣지
    for (ri, h_row) in h_edges.iter().enumerate() {
        let y = table_y + row_y.get(ri).copied().unwrap_or(0.0);
        let ref_row = ri.min(row_count.saturating_sub(1));
        let ref_cx = &row_col_x[ref_row.min(row_col_x.len() - 1)];
        let mut seg_start: Option<usize> = None;

        for (ci, edge_opt) in h_row.iter().enumerate() {
            if edge_opt.is_none() && !is_h_covered(ri, ci) {
                if seg_start.is_none() {
                    seg_start = Some(ci);
                }
            } else if let Some(start) = seg_start {
                let x1 = table_x + ref_cx[start];
                let x2 = table_x + ref_cx[ci];
                nodes.extend(create_editor_only_line(
                    tree, color, width, dash, x1, y, x2, y,
                ));
                seg_start = None;
            }
        }
        if let Some(start) = seg_start {
            let x1 = table_x + ref_cx[start];
            let x2 = table_x + ref_cx.get(h_row.len()).copied().unwrap_or(ref_cx[start]);
            nodes.extend(create_editor_only_line(
                tree, color, width, dash, x1, y, x2, y,
            ));
        }
    }

    // 수직 투명 엣지 (행별 x 위치)
    for (ci, v_col) in v_edges.iter().enumerate() {
        let mut seg_start: Option<usize> = None;
        let mut seg_x: f64 = 0.0;

        for (ri, edge_opt) in v_col.iter().enumerate() {
            let x = table_x
                + row_col_x
                    .get(ri)
                    .and_then(|rx| rx.get(ci).copied())
                    .unwrap_or(0.0);
            if edge_opt.is_none() && !is_v_covered(ci, ri) {
                if seg_start.is_none() {
                    seg_start = Some(ri);
                    seg_x = x;
                } else if (x - seg_x).abs() >= 0.01 {
                    // x가 바뀌면 이전 세그먼트 마무리 후 새 세그먼트 시작
                    let y1 = table_y + row_y[seg_start.unwrap()];
                    let y2 = table_y + row_y[ri];
                    nodes.extend(create_editor_only_line(
                        tree, color, width, dash, seg_x, y1, seg_x, y2,
                    ));
                    seg_start = Some(ri);
                    seg_x = x;
                }
            } else if let Some(start) = seg_start {
                let y1 = table_y + row_y[start];
                let y2 = table_y + row_y[ri];
                nodes.extend(create_editor_only_line(
                    tree, color, width, dash, seg_x, y1, seg_x, y2,
                ));
                seg_start = None;
            }
        }
        if let Some(start) = seg_start {
            let y1 = table_y + row_y[start];
            let y2 = table_y + row_y.get(v_col.len()).copied().unwrap_or(row_y[start]);
            nodes.extend(create_editor_only_line(
                tree, color, width, dash, seg_x, y1, seg_x, y2,
            ));
        }
    }

    nodes
}

/// 테두리선 Line 노드 생성 (이중선/삼중선 지원)
/// None 타입이면 빈 벡터 반환
pub(crate) fn create_border_line_nodes(
    tree: &mut PageLayoutContext,
    border: &BorderLine,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
) -> Vec<RenderNode> {
    if border.line_type == BorderLineType::None {
        return vec![];
    }

    let base_width = border_width_to_px(border.width);

    match border.line_type {
        BorderLineType::None => vec![],

        // 이중선 (동일 굵기)
        BorderLineType::Double => {
            let total = base_width.max(3.0);
            let sub_w = (total * 0.3).max(0.4);
            let gap = (total * 0.4).max(1.0);
            let offset = (gap + sub_w) / 2.0;
            create_parallel_lines(
                tree,
                border.color,
                x1,
                y1,
                x2,
                y2,
                &[(-offset, sub_w), (offset, sub_w)],
                StrokeDash::Solid,
            )
        }

        // 가는선-굵은선 이중선
        BorderLineType::ThinThickDouble => {
            let total = base_width.max(3.0);
            let thin_w = (total * 0.2).max(0.4);
            let thick_w = (total * 0.4).max(0.6);
            let gap = (total * 0.4).max(1.0);
            let thin_offset = -(gap + thin_w) / 2.0;
            let thick_offset = (gap + thick_w) / 2.0;
            create_parallel_lines(
                tree,
                border.color,
                x1,
                y1,
                x2,
                y2,
                &[(thin_offset, thin_w), (thick_offset, thick_w)],
                StrokeDash::Solid,
            )
        }

        // 굵은선-가는선 이중선
        BorderLineType::ThickThinDouble => {
            let total = base_width.max(3.0);
            let thick_w = (total * 0.4).max(0.6);
            let thin_w = (total * 0.2).max(0.4);
            let gap = (total * 0.4).max(1.0);
            let thick_offset = -(gap + thick_w) / 2.0;
            let thin_offset = (gap + thin_w) / 2.0;
            create_parallel_lines(
                tree,
                border.color,
                x1,
                y1,
                x2,
                y2,
                &[(thick_offset, thick_w), (thin_offset, thin_w)],
                StrokeDash::Solid,
            )
        }

        // 가는선-굵은선-가는선 삼중선
        BorderLineType::ThinThickThinTriple => {
            let total = base_width.max(4.0);
            let thin_w = (total * 0.15).max(0.4);
            let thick_w = (total * 0.3).max(0.6);
            let gap = (total * 0.15).max(0.8);
            let outer_offset = thick_w / 2.0 + gap + thin_w / 2.0;
            create_parallel_lines(
                tree,
                border.color,
                x1,
                y1,
                x2,
                y2,
                &[
                    (-outer_offset, thin_w),
                    (0.0, thick_w),
                    (outer_offset, thin_w),
                ],
                StrokeDash::Solid,
            )
        }

        // 단일선 타입들
        _ => {
            if let Some(dash) = border_line_type_to_dash(border.line_type) {
                create_single_line(tree, border.color, base_width, dash, x1, y1, x2, y2)
            } else {
                vec![]
            }
        }
    }
}

/// 평행선 노드 생성 (이중선/삼중선용)
/// lines: &[(offset, width)] — offset은 선 중심의 수직 이동량
fn create_parallel_lines(
    tree: &mut PageLayoutContext,
    color: u32,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    lines: &[(f64, f64)],
    dash: StrokeDash,
) -> Vec<RenderNode> {
    let is_horizontal = (y2 - y1).abs() < (x2 - x1).abs();
    let mut nodes = Vec::with_capacity(lines.len());

    for &(offset, width) in lines {
        let (lx1, ly1, lx2, ly2) = if is_horizontal {
            (x1, y1 + offset, x2, y2 + offset)
        } else {
            (x1 + offset, y1, x2 + offset, y2)
        };

        let id = tree.next_id();
        let line = LineNode::new(
            lx1,
            ly1,
            lx2,
            ly2,
            LineStyle {
                color,
                width,
                dash,
                ..Default::default()
            },
        );
        let bbox = line.ink_bbox();
        nodes.push(RenderNode::new(id, RenderNodeType::Line(line), bbox));
    }

    nodes
}

/// 임의 방향 평행선 노드 생성 (대각선 이중선/삼중선용)
fn create_parallel_lines_perpendicular(
    tree: &mut PageLayoutContext,
    color: u32,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    lines: &[(f64, f64)],
    dash: StrokeDash,
) -> Vec<RenderNode> {
    let dx = x2 - x1;
    let dy = y2 - y1;
    let len = (dx * dx + dy * dy).sqrt();
    if len < 0.01 {
        return vec![];
    }
    let nx = -dy / len;
    let ny = dx / len;
    let mut nodes = Vec::with_capacity(lines.len());

    for &(offset, width) in lines {
        let lx1 = x1 + nx * offset;
        let ly1 = y1 + ny * offset;
        let lx2 = x2 + nx * offset;
        let ly2 = y2 + ny * offset;

        let id = tree.next_id();
        let line = LineNode::new(
            lx1,
            ly1,
            lx2,
            ly2,
            LineStyle {
                color,
                width,
                dash,
                ..Default::default()
            },
        );
        let bbox = line.ink_bbox();
        nodes.push(RenderNode::new(id, RenderNodeType::Line(line), bbox));
    }

    nodes
}

/// 단일선 노드 생성
fn create_single_line(
    tree: &mut PageLayoutContext,
    color: u32,
    width: f64,
    dash: StrokeDash,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
) -> Vec<RenderNode> {
    let id = tree.next_id();
    let line = LineNode::new(
        x1,
        y1,
        x2,
        y2,
        LineStyle {
            color,
            width,
            dash,
            ..Default::default()
        },
    );
    let bbox = line.ink_bbox();
    vec![RenderNode::new(id, RenderNodeType::Line(line), bbox)]
}

fn create_editor_only_line(
    tree: &mut PageLayoutContext,
    color: u32,
    width: f64,
    dash: StrokeDash,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
) -> Vec<RenderNode> {
    create_single_line(tree, color, width, dash, x1, y1, x2, y2)
        .into_iter()
        .map(RenderNode::with_editor_only)
        .collect()
}

fn border_line_type_from_code(code: u8) -> BorderLineType {
    match code {
        0 => BorderLineType::None,
        1 => BorderLineType::Solid,
        2 => BorderLineType::Dash,
        3 => BorderLineType::Dot,
        4 => BorderLineType::DashDot,
        5 => BorderLineType::DashDotDot,
        6 => BorderLineType::LongDash,
        7 => BorderLineType::Circle,
        8 => BorderLineType::Double,
        9 => BorderLineType::ThinThickDouble,
        10 => BorderLineType::ThickThinDouble,
        11 => BorderLineType::ThinThickThinTriple,
        12 => BorderLineType::Wave,
        13 => BorderLineType::DoubleWave,
        14 => BorderLineType::Thick3D,
        15 => BorderLineType::Thick3DReverse,
        16 => BorderLineType::Thin3D,
        17 => BorderLineType::Thin3DReverse,
        _ => BorderLineType::Solid,
    }
}

fn create_diagonal_line_nodes(
    tree: &mut PageLayoutContext,
    line_type: BorderLineType,
    color: u32,
    width_index: u8,
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
) -> Vec<RenderNode> {
    if line_type == BorderLineType::None {
        return vec![];
    }

    let base_width = border_width_to_px(width_index);
    match line_type {
        BorderLineType::None => vec![],
        BorderLineType::Double => {
            let total = base_width.max(3.0);
            let sub_w = (total * 0.3).max(0.4);
            let gap = (total * 0.4).max(1.0);
            let offset = (gap + sub_w) / 2.0;
            create_parallel_lines_perpendicular(
                tree,
                color,
                x1,
                y1,
                x2,
                y2,
                &[(-offset, sub_w), (offset, sub_w)],
                StrokeDash::Solid,
            )
        }
        BorderLineType::ThinThickDouble => {
            let total = base_width.max(3.0);
            let thin_w = (total * 0.2).max(0.4);
            let thick_w = (total * 0.4).max(0.6);
            let gap = (total * 0.4).max(1.0);
            let thin_offset = -(gap + thin_w) / 2.0;
            let thick_offset = (gap + thick_w) / 2.0;
            create_parallel_lines_perpendicular(
                tree,
                color,
                x1,
                y1,
                x2,
                y2,
                &[(thin_offset, thin_w), (thick_offset, thick_w)],
                StrokeDash::Solid,
            )
        }
        BorderLineType::ThickThinDouble => {
            let total = base_width.max(3.0);
            let thick_w = (total * 0.4).max(0.6);
            let thin_w = (total * 0.2).max(0.4);
            let gap = (total * 0.4).max(1.0);
            let thick_offset = -(gap + thick_w) / 2.0;
            let thin_offset = (gap + thin_w) / 2.0;
            create_parallel_lines_perpendicular(
                tree,
                color,
                x1,
                y1,
                x2,
                y2,
                &[(thick_offset, thick_w), (thin_offset, thin_w)],
                StrokeDash::Solid,
            )
        }
        BorderLineType::ThinThickThinTriple => {
            let total = base_width.max(4.0);
            let thin_w = (total * 0.15).max(0.4);
            let thick_w = (total * 0.3).max(0.6);
            let gap = (total * 0.15).max(0.8);
            let outer_offset = thick_w / 2.0 + gap + thin_w / 2.0;
            create_parallel_lines_perpendicular(
                tree,
                color,
                x1,
                y1,
                x2,
                y2,
                &[
                    (-outer_offset, thin_w),
                    (0.0, thick_w),
                    (outer_offset, thin_w),
                ],
                StrokeDash::Solid,
            )
        }
        _ => {
            if let Some(dash) = border_line_type_to_dash(line_type) {
                create_single_line(tree, color, base_width, dash, x1, y1, x2, y2)
            } else {
                vec![]
            }
        }
    }
}

fn create_crooked_diagonal_line_nodes(
    tree: &mut PageLayoutContext,
    line_type: BorderLineType,
    color: u32,
    width_index: u8,
    points: &[(f64, f64)],
) -> Vec<RenderNode> {
    let mut nodes = Vec::new();
    for pair in points.windows(2) {
        let (x1, y1) = pair[0];
        let (x2, y2) = pair[1];
        nodes.extend(create_diagonal_line_nodes(
            tree,
            line_type,
            color,
            width_index,
            x1,
            y1,
            x2,
            y2,
        ));
    }
    nodes
}

/// BorderLine이 시각적으로 차지하는 전체 폭(px).
///
/// `create_border_line_nodes`의 이중선/삼중선 분해 규칙과 같은 값을 써서,
/// 쪽 기준 테두리 박스를 바깥쪽으로 확장할 때 렌더된 선 묶음이 본문 쪽으로
/// 파고들지 않게 한다.
pub(crate) fn border_line_visual_span(border: &BorderLine) -> f64 {
    if border.line_type == BorderLineType::None {
        return 0.0;
    }

    let base_width = border_width_to_px(border.width);
    match border.line_type {
        BorderLineType::Double
        | BorderLineType::ThinThickDouble
        | BorderLineType::ThickThinDouble => base_width.max(3.0),
        BorderLineType::ThinThickThinTriple => base_width.max(4.0),
        _ => base_width,
    }
}

/// 쪽 기준 페이지 테두리를 본문 영역 바깥쪽에 배치할 때 쓰는 보정 폭(px).
///
/// 한컴오피스는 `쪽 기준` 이중선 페이지 테두리에서 저장된 간격값에 선 묶음의
/// 시각 폭을 한 번 더 반영해, 테두리가 본문/객체 쪽으로 파고들지 않게 그린다.
/// 표/문단 테두리의 선 자체 분해 규칙은 그대로 두고, 페이지 테두리 위치 계산에만
/// 이 값을 사용한다.
pub(crate) fn body_page_border_outset(border: &BorderLine) -> f64 {
    const BODY_PAGE_DOUBLE_LINE_OUTSET_FACTOR: f64 = 2.5;
    let span = border_line_visual_span(border);
    match border.line_type {
        BorderLineType::Double
        | BorderLineType::ThinThickDouble
        | BorderLineType::ThickThinDouble
        | BorderLineType::ThinThickThinTriple => span * BODY_PAGE_DOUBLE_LINE_OUTSET_FACTOR,
        _ => span,
    }
}

/// HWP 테두리 굵기 인덱스 → 픽셀 변환
/// HWP 스펙 (표 28): mm 값을 96dpi 기준 px로 변환
pub(crate) fn border_width_to_px(width: u8) -> f64 {
    const WIDTHS_PX: [f64; 16] = [
        0.4,  // 0: 0.1mm
        0.5,  // 1: 0.12mm
        0.6,  // 2: 0.15mm
        0.75, // 3: 0.2mm
        1.0,  // 4: 0.25mm
        1.1,  // 5: 0.3mm
        1.5,  // 6: 0.4mm
        1.9,  // 7: 0.5mm
        2.3,  // 8: 0.6mm
        2.6,  // 9: 0.7mm
        3.8,  // 10: 1.0mm
        5.7,  // 11: 1.5mm
        7.6,  // 12: 2.0mm
        11.3, // 13: 3.0mm
        15.1, // 14: 4.0mm
        18.9, // 15: 5.0mm
    ];
    if let Some(&px) = WIDTHS_PX.get(width as usize) {
        px
    } else {
        (width as f64 * 1.2).max(0.4).min(20.0)
    }
}

/// BorderLineType → StrokeDash 변환 (None이면 None 반환)
fn border_line_type_to_dash(lt: BorderLineType) -> Option<StrokeDash> {
    match lt {
        BorderLineType::None => None,
        BorderLineType::Solid => Some(StrokeDash::Solid),
        BorderLineType::Dash | BorderLineType::LongDash => Some(StrokeDash::Dash),
        BorderLineType::Dot | BorderLineType::Circle => Some(StrokeDash::Dot),
        BorderLineType::DashDot => Some(StrokeDash::DashDot),
        BorderLineType::DashDotDot => Some(StrokeDash::DashDotDot),
        _ => Some(StrokeDash::Solid), // Double, Wave 등은 Solid로 대체
    }
}

/// 셀 대각선 렌더링
/// HWP BorderFill.attr 비트:
///   bit 2~4: Slash(`/`) 대각선 모양
///     000=none, 그 외=slash
///   bit 5~7: BackSlash(`\`) 대각선 모양
///     000=none, 그 외=backslash
///   bit 8~9: Slash 대각선 꺾은선
///   bit 10: BackSlash 대각선 꺾은선
///   bit 13: 중심선
pub(crate) fn render_cell_diagonal(
    tree: &mut PageLayoutContext,
    border_style: &ResolvedBorderStyle,
    cell_x: f64,
    cell_y: f64,
    cell_w: f64,
    cell_h: f64,
) -> Vec<RenderNode> {
    let attr = border_style.diagonal_attr;
    let slash_bits = (attr >> 2) & 0x07;
    let backslash_bits = (attr >> 5) & 0x07;
    let slash_crooked = (attr >> 8) & 0x03;
    let backslash_crooked = (attr >> 10) & 0x01;
    let center_line = border_style.center_line;

    if slash_bits == 0 && backslash_bits == 0 && center_line == CenterLine::None {
        return vec![];
    }

    let diag = &border_style.diagonal;
    // diagonal_type 0 = 선 종류 없음 → 대각선 그리지 않음
    if diag.diagonal_type == 0 {
        return vec![];
    }
    let color = diag.color;
    let line_type = border_line_type_from_code(diag.diagonal_type);

    let mut nodes = Vec::new();

    let x1 = cell_x;
    let y1 = cell_y;
    let x2 = cell_x + cell_w;
    let y2 = cell_y + cell_h;
    let cx = cell_x + cell_w / 2.0;
    let cy = cell_y + cell_h / 2.0;

    match center_line {
        CenterLine::Vertical => {
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, x1, cy, x2, cy,
            ));
        }
        CenterLine::Horizontal => {
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, cx, y1, cx, y2,
            ));
        }
        CenterLine::Cross => {
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, cx, y1, cx, y2,
            ));
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, x1, cy, x2, cy,
            ));
        }
        CenterLine::None => {}
    }

    if slash_bits != 0 {
        if slash_crooked != 0 {
            let p1 = (x1, y2);
            let p2 = (cell_x + cell_w * 0.4, cy);
            let p3 = (cell_x + cell_w * 0.6, cy);
            let p4 = (x2, y1);
            nodes.extend(create_crooked_diagonal_line_nodes(
                tree,
                line_type,
                color,
                diag.width,
                &[p1, p2, p3, p4],
            ));
        } else {
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, x1, y2, x2, y1,
            ));
        }
    }

    if backslash_bits != 0 {
        let use_crooked = backslash_crooked != 0 || (slash_bits == 0 && slash_crooked != 0);
        if use_crooked {
            let p1 = (x1, y1);
            let p2 = (cell_x + cell_w * 0.4, cy);
            let p3 = (cell_x + cell_w * 0.6, cy);
            let p4 = (x2, y2);
            nodes.extend(create_crooked_diagonal_line_nodes(
                tree,
                line_type,
                color,
                diag.width,
                &[p1, p2, p3, p4],
            ));
        } else {
            nodes.extend(create_diagonal_line_nodes(
                tree, line_type, color, diag.width, x1, y1, x2, y2,
            ));
        }
    }

    nodes
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::style::DiagonalLine;
    use crate::model::table::Cell;

    fn independent_width_table(rows: &[[u32; 3]]) -> Table {
        let mut cells = Vec::new();
        for (row, widths) in rows.iter().enumerate() {
            for (col, width) in widths.iter().enumerate() {
                cells.push(Cell {
                    row: row as u16,
                    col: col as u16,
                    row_span: 1,
                    col_span: 1,
                    width: *width,
                    ..Default::default()
                });
            }
        }
        Table {
            row_count: rows.len() as u16,
            col_count: 3,
            cells,
            ..Default::default()
        }
    }

    #[test]
    fn degenerate_inferred_row_uses_base_grid_instead_of_expanding_last_cell() {
        const DPI: f64 = 96.0;
        let base_widths_hu = [12_698u32, 1_940, 5_421];
        let mut table =
            independent_width_table(&[[1, 1_940, 5_421], base_widths_hu, base_widths_hu]);
        table.common.width = base_widths_hu.into_iter().sum();
        let col_widths =
            base_widths_hu.map(|width| crate::renderer::hwpunit_to_px(width as i32, DPI));

        let row_col_x =
            build_row_col_x(&table, &col_widths, 3, 3, 0.0, DPI, 1.0).expect("3×3 표는 상한 안");
        let expected_first_boundary = col_widths[0];
        let expected_last_width = col_widths[2];

        assert!(
            (row_col_x[0][1] - expected_first_boundary).abs() <= 0.01,
            "퇴화한 첫 셀은 기준 grid 폭을 따라야 함: {:?}",
            row_col_x[0]
        );
        assert!(
            ((row_col_x[0][3] - row_col_x[0][2]) - expected_last_width).abs() <= 0.01,
            "부족 폭을 마지막 셀에 몰아주면 안 됨: {:?}",
            row_col_x[0]
        );
        assert_eq!(row_col_x[0], row_col_x[1]);
        assert_oversized_declared_grid_is_rejected();
    }

    fn assert_oversized_declared_grid_is_rejected() {
        // [#4287] 가드가 사라지면 2100×2100 × Option<f64> ≈ 70MB 를 예약한다.
        // 65535×65535 는 회귀 시 CI 러너가 OOM 으로 죽으므로 쓰지 않는다 (#2722 보정과 동일).
        const ROWS: usize = 2100;
        const COLS: usize = 2100;
        assert!(
            ROWS.saturating_mul(COLS) > MAX_TABLE_GRID_CELLS,
            "재현 입력이 상한을 넘어야 의미가 있다"
        );

        let table = Table {
            row_count: ROWS as u16,
            col_count: COLS as u16,
            cells: vec![Cell {
                row: 0,
                col: 0,
                row_span: 1,
                col_span: 1,
                width: 1000,
                ..Default::default()
            }],
            ..Default::default()
        };
        let err = build_row_col_x(&table, &[1.0], COLS, ROWS, 0.0, 96.0, 1.0)
            .expect_err("상한 초과 그리드는 할당하지 않고 오류여야 함");
        assert_eq!(err.row_count, ROWS);
        assert_eq!(err.col_count, COLS);
    }

    fn center_line_style(center_line: CenterLine) -> ResolvedBorderStyle {
        ResolvedBorderStyle {
            diagonal_attr: if center_line == CenterLine::None {
                0
            } else {
                1 << 13
            },
            diagonal: DiagonalLine {
                diagonal_type: 1,
                width: 0,
                color: 0x00F4_C741,
            },
            center_line,
            ..Default::default()
        }
    }

    fn diagonal_style(attr: u16) -> ResolvedBorderStyle {
        ResolvedBorderStyle {
            diagonal_attr: attr,
            diagonal: DiagonalLine {
                diagonal_type: 1,
                width: 0,
                color: 0,
            },
            ..Default::default()
        }
    }

    fn line_node(node: &RenderNode) -> &LineNode {
        match &node.node_type {
            RenderNodeType::Line(line) => line,
            other => panic!("Line 노드가 아님: {other:?}"),
        }
    }

    #[test]
    fn render_hwpx_vertical_center_line_as_horizontal_bar() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let nodes = render_cell_diagonal(
            &mut tree,
            &center_line_style(CenterLine::Vertical),
            10.0,
            20.0,
            100.0,
            40.0,
        );

        assert_eq!(nodes.len(), 1);
        let line = line_node(&nodes[0]);
        assert_eq!(
            (line.x1, line.y1, line.x2, line.y2),
            (10.0, 40.0, 110.0, 40.0)
        );
        assert_eq!(line.style.color, 0x00F4_C741);
    }

    #[test]
    fn render_hwpx_horizontal_center_line_as_vertical_bar() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let nodes = render_cell_diagonal(
            &mut tree,
            &center_line_style(CenterLine::Horizontal),
            10.0,
            20.0,
            100.0,
            40.0,
        );

        assert_eq!(nodes.len(), 1);
        let line = line_node(&nodes[0]);
        assert_eq!(
            (line.x1, line.y1, line.x2, line.y2),
            (60.0, 20.0, 60.0, 60.0)
        );
    }

    #[test]
    fn render_cross_center_line_creates_vertical_and_horizontal_lines() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let nodes = render_cell_diagonal(
            &mut tree,
            &center_line_style(CenterLine::Cross),
            10.0,
            20.0,
            100.0,
            40.0,
        );

        assert_eq!(nodes.len(), 2);
        let vertical = line_node(&nodes[0]);
        let horizontal = line_node(&nodes[1]);
        assert_eq!(
            (vertical.x1, vertical.y1, vertical.x2, vertical.y2),
            (60.0, 20.0, 60.0, 60.0)
        );
        assert_eq!(
            (horizontal.x1, horizontal.y1, horizontal.x2, horizontal.y2),
            (10.0, 40.0, 110.0, 40.0)
        );
    }

    #[test]
    fn render_nonzero_diagonal_shape_codes_as_basic_x() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let nodes = render_cell_diagonal(
            &mut tree,
            &diagonal_style((0b111 << 2) | (0b111 << 5)),
            10.0,
            20.0,
            100.0,
            40.0,
        );

        assert_eq!(nodes.len(), 2);
        let slash = line_node(&nodes[0]);
        let backslash = line_node(&nodes[1]);
        assert_eq!(
            (slash.x1, slash.y1, slash.x2, slash.y2),
            (10.0, 60.0, 110.0, 20.0)
        );
        assert_eq!(
            (backslash.x1, backslash.y1, backslash.x2, backslash.y2),
            (10.0, 20.0, 110.0, 60.0)
        );
    }

    #[test]
    fn render_slash_crooked_with_backslash_as_bent_backslash() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let nodes = render_cell_diagonal(
            &mut tree,
            &diagonal_style((2 << 8) | (0b010 << 5)),
            10.0,
            20.0,
            100.0,
            40.0,
        );

        assert_eq!(nodes.len(), 3);
        let first = line_node(&nodes[0]);
        let middle = line_node(&nodes[1]);
        let last = line_node(&nodes[2]);
        assert_eq!(
            (first.x1, first.y1, first.x2, first.y2),
            (10.0, 20.0, 50.0, 40.0)
        );
        assert_eq!(
            (middle.x1, middle.y1, middle.x2, middle.y2),
            (50.0, 40.0, 70.0, 40.0)
        );
        assert_eq!(
            (last.x1, last.y1, last.x2, last.y2),
            (70.0, 40.0, 110.0, 60.0)
        );
    }

    #[test]
    fn render_thick_slim_diagonal_as_parallel_lines() {
        let mut tree = PageLayoutContext::new(0, 200.0, 100.0);
        let mut style = diagonal_style(0b010 << 2);
        style.diagonal.diagonal_type = 10;
        style.diagonal.width = 13;
        let nodes = render_cell_diagonal(&mut tree, &style, 10.0, 20.0, 100.0, 40.0);

        assert_eq!(nodes.len(), 2);
        let thick = line_node(&nodes[0]);
        let thin = line_node(&nodes[1]);
        assert!(thick.style.width > thin.style.width);
        assert_ne!((thick.x1, thick.y1), (thin.x1, thin.y1));
        assert_ne!((thick.x2, thick.y2), (thin.x2, thin.y2));
    }

    fn table_border_grid(
        border: BorderLine,
    ) -> (
        Vec<Vec<Option<BorderLine>>>,
        Vec<Vec<Option<BorderLine>>>,
        Vec<Vec<f64>>,
        Vec<f64>,
    ) {
        (
            vec![vec![Some(border)], vec![Some(border)]],
            vec![vec![None], vec![None]],
            vec![vec![0.0, 100.0]],
            vec![0.0, 20.0],
        )
    }

    #[test]
    fn body_top_table_frame_keeps_compound_strokes_inside_clip_with_one_delta() {
        let border = BorderLine {
            line_type: BorderLineType::Double,
            width: 6,
            color: 0,
        };
        let (h_edges, v_edges, row_col_x, row_y) = table_border_grid(border);
        let mut baseline_tree = PageRenderTree::new(0, 200.0, 100.0);
        let baseline = render_edge_borders(
            &mut baseline_tree,
            &h_edges,
            &v_edges,
            &row_col_x,
            &row_y,
            10.0,
            30.0,
            None,
        );
        let mut clipped_tree = PageRenderTree::new(0, 200.0, 100.0);
        let clipped = render_edge_borders(
            &mut clipped_tree,
            &h_edges,
            &v_edges,
            &row_col_x,
            &row_y,
            10.0,
            30.0,
            Some(30.0),
        );

        assert_eq!(baseline.len(), clipped.len());
        let mut top_deltas = Vec::new();
        for (before, after) in baseline.iter().zip(&clipped) {
            let (RenderNodeType::Line(before_line), RenderNodeType::Line(after_line)) =
                (&before.node_type, &after.node_type)
            else {
                panic!("table border output must contain only Line nodes");
            };
            if before_line.y1 < 40.0 {
                top_deltas.push(after_line.y1 - before_line.y1);
                assert!(
                    after_line.y1 - after_line.style.width / 2.0 >= 30.0,
                    "top border paint must stay inside Body clip: {:?}",
                    after_line,
                );
            } else {
                assert_eq!(after_line.y1, before_line.y1, "bottom frame must not move");
                assert_eq!(after.bbox.y, before.bbox.y, "bottom bbox must not move");
            }
        }
        assert!(!top_deltas.is_empty());
        let common_delta = top_deltas[0];
        assert!(common_delta > 0.0);
        assert!(
            top_deltas
                .iter()
                .all(|delta| (*delta - common_delta).abs() <= f64::EPSILON),
            "compound top-border lines must retain spacing with one common delta: {top_deltas:?}",
        );
    }

    #[test]
    fn body_top_table_frame_inset_changes_only_emitted_lines_not_owner_boxes() {
        let border = BorderLine {
            line_type: BorderLineType::Solid,
            width: 6,
            color: 0,
        };
        let (h_edges, v_edges, row_col_x, row_y) = table_border_grid(border);
        let mut tree = PageRenderTree::new(0, 200.0, 100.0);
        let table_bbox = BoundingBox::new(10.0, 30.0, 100.0, 20.0);
        let cell_bbox = BoundingBox::new(10.0, 30.0, 100.0, 20.0);
        let table_bbox_before = table_bbox;
        let cell_bbox_before = cell_bbox;

        let nodes = render_edge_borders(
            &mut tree,
            &h_edges,
            &v_edges,
            &row_col_x,
            &row_y,
            table_bbox.x,
            table_bbox.y,
            Some(table_bbox.y),
        );
        let top = nodes
            .iter()
            .find_map(|node| match &node.node_type {
                RenderNodeType::Line(line) if line.y1 < 40.0 => Some(line),
                _ => None,
            })
            .expect("top border line");

        assert!(
            top.y1 > table_bbox.y,
            "only the paint centreline moves inward"
        );
        assert_eq!(table_bbox.x, table_bbox_before.x);
        assert_eq!(table_bbox.y, table_bbox_before.y);
        assert_eq!(table_bbox.width, table_bbox_before.width);
        assert_eq!(table_bbox.height, table_bbox_before.height);
        assert_eq!(cell_bbox.x, cell_bbox_before.x);
        assert_eq!(cell_bbox.y, cell_bbox_before.y);
        assert_eq!(cell_bbox.width, cell_bbox_before.width);
        assert_eq!(cell_bbox.height, cell_bbox_before.height);
    }
}
