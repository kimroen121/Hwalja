//! OLE 컨테이너 내부 CFB 파싱 (Task #195 단계 7)
//!
//! BinData/BIN000N.OLE 스트림의 압축 해제 후 바이트는 표준 CFB(Compound File Binary) 컨테이너이다.
//! 이 모듈은 그 내부 스트림(`\x02OlePres000`, `OOXMLChartContents`, `Contents`)을 추출한다.

use cfb::CompoundFile;
use std::io::{Cursor, Read};

/// OLE 컨테이너에서 추출한 네이티브 이미지 종류
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NativeImageKind {
    Bmp,
    Png,
    Jpeg,
    Gif,
}

impl NativeImageKind {
    pub fn mime(&self) -> &'static str {
        match self {
            Self::Bmp => "image/bmp",
            Self::Png => "image/png",
            Self::Jpeg => "image/jpeg",
            Self::Gif => "image/gif",
        }
    }
}

/// OLE 컨테이너 내용
#[derive(Debug, Clone, Default)]
pub struct OleContainer {
    /// `\x02OlePres000` 스트림에서 추출한 EMF 바이트 (OLE Presentation Stream 헤더 스킵됨)
    pub preview_emf: Option<Vec<u8>>,
    /// [#3363] `\x02OlePres000` 스트림에서 추출한 WMF 바이트 — EMF 부재 시 폴백.
    /// HWP3 내장 OLE(글맵시 등)의 프레젠테이션은 표준 WMF 다 (SO-SUEOP 실측:
    /// 40바이트 헤더 뒤 `01 00 09 00 03` 표준 WMF).
    pub preview_wmf: Option<Vec<u8>>,
    /// `OOXMLChartContents` 원본 바이트 (OOXML 차트 XML)
    pub ooxml_chart: Option<Vec<u8>>,
    /// `Contents` 원본 바이트 (내부 OLE 데이터)
    pub raw_contents: Option<Vec<u8>>,
    /// `\x01Ole10Native` 스트림에서 추출한 네이티브 임베딩 바이트 (BMP/PNG/JPEG 등)
    pub native_image: Option<(NativeImageKind, Vec<u8>)>,
}

impl OleContainer {
    /// OOXML 차트 XML을 포함하는지 여부
    pub fn has_ooxml_chart(&self) -> bool {
        self.ooxml_chart.as_ref().is_some_and(|b| !b.is_empty())
    }

    /// 메타파일(EMF/WMF) 프리뷰를 포함하는지 여부
    pub fn has_preview(&self) -> bool {
        self.preview_emf.as_ref().is_some_and(|b| !b.is_empty())
            || self.preview_wmf.as_ref().is_some_and(|b| !b.is_empty())
    }
}

/// 해제된 BinData 바이트(CFB 컨테이너)에서 주요 스트림 추출
///
/// 입력: CFB 매직(`D0CF11E0...`)로 시작하는 바이트 슬라이스
/// 반환: 내부 스트림이 하나라도 존재하면 `Some(container)`, CFB 파싱 실패 시 `None`
pub fn parse_ole_container(cfb_bytes: &[u8]) -> Option<OleContainer> {
    if cfb_bytes.len() < 8 {
        return None;
    }
    // [#5582] HWPX 의 `BinData/*.ole` 는 CFB 앞에 u32 LE 길이 프리픽스를 붙인다
    // (00128 실측: `00 B8 02 00` = 178,176 = 뒤따르는 CFB 크기). HWPX 적재 경로는
    // `normalize_ole_bytes`(#2263)가 이미 벗기지만, 이 함수는 다른 유입 경로
    // (HWP5 bindata·도구성 호출)도 받으므로 방어적으로 같은 정규화를 둔다.
    // 선언 길이가 실제 잔여 길이와 일치할 때만 벗긴다 — 우연히 D0CF 로 이어지는
    // 다른 형식을 오인하지 않게.
    const CFB_MAGIC: [u8; 4] = [0xD0, 0xCF, 0x11, 0xE0];
    let cfb_bytes = if cfb_bytes[0..4] != CFB_MAGIC
        && cfb_bytes.len() >= 12
        && cfb_bytes[4..8] == CFB_MAGIC
        && u32::from_le_bytes([cfb_bytes[0], cfb_bytes[1], cfb_bytes[2], cfb_bytes[3]]) as usize
            == cfb_bytes.len() - 4
    {
        &cfb_bytes[4..]
    } else {
        cfb_bytes
    };
    let cursor = Cursor::new(cfb_bytes);
    let mut comp = CompoundFile::open(cursor).ok()?;

    let mut container = OleContainer::default();

    // 최상위 스트림 목록 수집
    let entries: Vec<String> = comp
        .walk()
        .filter(|e| e.is_stream())
        .map(|e| e.path().to_string_lossy().to_string())
        .collect();

    for path in entries {
        let name = path.trim_start_matches('/');
        if name == "\u{0002}OlePres000" || name.ends_with("OlePres000") {
            if let Ok(mut s) = comp.open_stream(&path) {
                let mut buf = Vec::new();
                if s.read_to_end(&mut buf).is_ok() {
                    container.preview_emf = strip_ole_presentation_header(&buf);
                    // [#3363] EMF 부재 시 WMF 프레젠테이션 폴백 (HWP3 내장 OLE·글맵시)
                    if container.preview_emf.is_none() {
                        container.preview_wmf = strip_ole_presentation_header_wmf(&buf);
                    }
                }
            }
        } else if name == "OOXMLChartContents" {
            if let Ok(mut s) = comp.open_stream(&path) {
                let mut buf = Vec::new();
                if s.read_to_end(&mut buf).is_ok() && !buf.is_empty() {
                    container.ooxml_chart = Some(buf);
                }
            }
        } else if name.eq_ignore_ascii_case("contents") {
            // [#5582] 한컴 산출 변형은 대문자 `CONTENTS` 도 쓴다(00128 실측). 차트가
            // 아닌 일반 내장 개체의 CONTENTS 는 차트 파싱이 실패하고, 렌더 경로가
            // 그 실패를 폴백 사유로 강등해 EMF/WMF 미리보기로 내려간다.
            if let Ok(mut s) = comp.open_stream(&path) {
                let mut buf = Vec::new();
                if s.read_to_end(&mut buf).is_ok() && !buf.is_empty() {
                    container.raw_contents = Some(buf);
                }
            }
        } else if name == "\u{0001}Ole10Native" || name.ends_with("Ole10Native") {
            if let Ok(mut s) = comp.open_stream(&path) {
                let mut buf = Vec::new();
                if s.read_to_end(&mut buf).is_ok() && buf.len() > 4 {
                    // Ole10Native: [u32 LE length][payload] — payload가 BMP/PNG/JPEG 등 네이티브 바이트
                    let inner = &buf[4..];
                    if let Some(img) = detect_native_image(inner) {
                        container.native_image = Some(img);
                    }
                }
            }
        }
    }

    // preview_emf가 없으면 OlePres000에서 DIB 추출 시도 → BMP로 포장
    if container.preview_emf.is_none() && container.native_image.is_none() {
        // OlePres000을 다시 읽어 DIB 헤더를 찾아본다
        // (이미 preview_emf가 None인 경우만)
        if let Ok(entries) = std::panic::catch_unwind(|| {
            let cursor = Cursor::new(cfb_bytes);
            CompoundFile::open(cursor).ok().map(|comp| {
                comp.walk()
                    .filter(|e| e.is_stream())
                    .map(|e| e.path().to_string_lossy().to_string())
                    .collect::<Vec<_>>()
            })
        }) {
            if let Some(Some(paths)) = Some(entries) {
                let cursor = Cursor::new(cfb_bytes);
                if let Ok(mut comp2) = CompoundFile::open(cursor) {
                    for path in &paths {
                        let name = path.trim_start_matches('/');
                        if name == "\u{0002}OlePres000" || name.ends_with("OlePres000") {
                            if let Ok(mut s) = comp2.open_stream(path) {
                                let mut buf = Vec::new();
                                if s.read_to_end(&mut buf).is_ok() {
                                    if let Some(bmp) = extract_dib_as_bmp(&buf) {
                                        container.native_image = Some((NativeImageKind::Bmp, bmp));
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if container.preview_emf.is_some()
        || container.preview_wmf.is_some()
        || container.ooxml_chart.is_some()
        || container.raw_contents.is_some()
        || container.native_image.is_some()
    {
        Some(container)
    } else {
        None
    }
}

/// 한글 글맵시(HMapsi) 계열 OLE 컨테이너인지 빠르게 판별한다.
///
/// 구형/변환 HWPX의 글맵시 OLE는 일반 EMF/DIB preview 없이 `HMapsi`/`Hmapsi file`
/// 네이티브 스트림만 가진다. 현재는 전용 parser가 없으므로 렌더러의 preview clip
/// fallback 대상인지 판정하는 용도로 사용한다.
pub fn is_hmapsi_ole_container(cfb_bytes: &[u8]) -> bool {
    contains_bytes(cfb_bytes, b"HMapsi") || contains_bytes(cfb_bytes, b"Hmapsi file")
}

/// 중첩 OLE CFB 의 루트 CLSID(= OLE 서버 클래스 ID)를 읽는다. (#4097)
///
/// `parse_ole_container` 는 스트림 **이름**으로만 개체를 판별하므로 CLSID 를 보지 않는다.
/// 그래서 재포장에서 CLSID 가 사라져도 rhwp 의 왕복 검증·조립 검증은 전부 통과했고
/// **한컴에서만** 드러났다. 중첩 CFB 를 다시 쓸 때는 이 값을 읽어
/// `serializer::mini_cfb::build_cfb_with_root_clsid` 에 넘겨야 한다.
///
/// 바이트 해석은 `cfb_reader::root_clsid` 한 곳에서만 한다 — 오프셋 지식을 복제하지 않는다.
pub fn ole_root_clsid(cfb_bytes: &[u8]) -> Option<[u8; 16]> {
    crate::parser::cfb_reader::root_clsid(cfb_bytes)
}

/// 중첩 OLE CFB 의 **모든** 스트림을 `(경로, 바이트)` 로 열거한다. (#4100)
///
/// [`parse_ole_container`] 는 아는 이름 4종만 뽑으므로 **재포장에 쓸 수 없다** — 나머지가
/// 소실된다. 차트 편집은 `OOXMLChartContents` 하나만 갈고 나머지(레거시 `Contents`,
/// `\x02OlePres000` EMF)는 바이트 그대로 되실어야 하므로 전수 열거가 필요하다.
///
/// 경로는 플랫폼 무관 표기로 정규화한다 — Windows 의 `cfb` 는 `/BinData\BIN0001.OLE`
/// 처럼 구분자를 섞어 돌려주는데, 반환값을 **이름으로 비교**하는 소비자가 있다.
///
/// #4055 스파이크가 코퍼스 28종에서 "아는 4종 밖 스트림 0건"을 실측했다. 그래도 이름을
/// 고정하지 않고 전수로 도는 이유는, 그 관찰이 코퍼스의 성질이지 포맷의 보장이 아니라서다.
pub fn all_ole_streams(cfb_bytes: &[u8]) -> Option<Vec<(String, Vec<u8>)>> {
    if cfb_bytes.len() < 8 {
        return None;
    }
    let mut comp = CompoundFile::open(Cursor::new(cfb_bytes)).ok()?;
    let paths: Vec<std::path::PathBuf> = comp
        .walk()
        .filter(|e| e.is_stream())
        .map(|e| e.path().to_path_buf())
        .collect();

    let mut out = Vec::with_capacity(paths.len());
    for path in paths {
        let mut buf = Vec::new();
        let mut stream = comp.open_stream(&path).ok()?;
        stream.read_to_end(&mut buf).ok()?;
        out.push((path.to_string_lossy().replace('\\', "/"), buf));
    }
    Some(out)
}

fn contains_bytes(haystack: &[u8], needle: &[u8]) -> bool {
    !needle.is_empty() && haystack.windows(needle.len()).any(|w| w == needle)
}

/// [#5725] `Contents` 가 한글 수식 편집기 봉투면 수식 스크립트를 꺼낸다.
///
/// 봉투 구조 (2921145 `BinData/ole1.ole` 실측):
/// - offset 0..32: 시그니처 `Hwp 5.0 Equation Editor(HwpEq5x)` (정확히 32바이트)
/// - offset 52: u32 LE 버전 (실측 5)
/// - offset 68: u32 LE 스크립트 바이트 길이
/// - offset 72: UTF-16LE 수식 스크립트
///
/// 이 OLE 들의 `\x02OlePres000` 은 전부 28바이트 스텁(헤더만)이라 미리보기
/// 폴백으로는 그릴 것이 없다 — 스크립트가 유일한 출처다.
pub fn parse_equation_contents_script(data: &[u8]) -> Option<String> {
    const SIG: &[u8] = b"Hwp 5.0 Equation Editor";
    if data.len() < 72 || !data.starts_with(SIG) {
        return None;
    }
    let len = u32::from_le_bytes([data[68], data[69], data[70], data[71]]) as usize;
    if len == 0 || !len.is_multiple_of(2) || data.len() < 72 + len {
        return None;
    }
    let units: Vec<u16> = data[72..72 + len]
        .chunks_exact(2)
        .map(|c| u16::from_le_bytes([c[0], c[1]]))
        .collect();
    let script = String::from_utf16_lossy(&units)
        .trim_end_matches('\0')
        .to_string();
    if script.trim().is_empty() {
        None
    } else {
        Some(script)
    }
}

/// [#5724] `Contents` 페이로드가 선두 매직 기준으로 WMF(placeable/표준)인지 판별.
pub fn raw_contents_is_wmf(data: &[u8]) -> bool {
    if data.len() < 18 {
        return false;
    }
    // Aldus placeable metafile
    if data.starts_with(&[0xD7, 0xCD, 0xC6, 0x9A]) {
        return true;
    }
    // 표준 WMF: mtType(1|2) + mtHeaderSize=9 + mtVersion(0x0100|0x0300)
    let mt_type = u16::from_le_bytes([data[0], data[1]]);
    let header_size = u16::from_le_bytes([data[2], data[3]]);
    let version = u16::from_le_bytes([data[4], data[5]]);
    (mt_type == 1 || mt_type == 2) && header_size == 9 && (version == 0x0100 || version == 0x0300)
}

/// [#5724] `Contents` 페이로드가 EMF 인지 판별 (EMR_HEADER: type=1, offset 40 `" EMF"`).
pub fn raw_contents_is_emf(data: &[u8]) -> bool {
    data.len() >= 44
        && u32::from_le_bytes([data[0], data[1], data[2], data[3]]) == 1
        && &data[40..44] == b" EMF"
}

/// 바이트 슬라이스의 선두 매직으로 이미지 포맷을 판별
pub fn detect_native_image(data: &[u8]) -> Option<(NativeImageKind, Vec<u8>)> {
    if data.len() < 4 {
        return None;
    }
    if data.starts_with(b"BM") {
        return Some((NativeImageKind::Bmp, data.to_vec()));
    }
    if data.starts_with(&[0x89, 0x50, 0x4E, 0x47]) {
        return Some((NativeImageKind::Png, data.to_vec()));
    }
    if data.starts_with(&[0xFF, 0xD8, 0xFF]) {
        return Some((NativeImageKind::Jpeg, data.to_vec()));
    }
    if data.starts_with(b"GIF8") {
        return Some((NativeImageKind::Gif, data.to_vec()));
    }
    None
}

/// OlePres000 스트림에서 DIB(Device Independent Bitmap) 데이터를 찾아 BMP 파일 바이트로 재포장한다.
///
/// DIB 시그니처: BITMAPINFOHEADER는 `biSize=40` (0x28 0x00 0x00 0x00)로 시작.
/// 앞에 BMP FILEHEADER(14바이트, "BM"+파일크기+예약+픽셀오프셋)를 합성하여 표준 BMP로 만든다.
fn extract_dib_as_bmp(data: &[u8]) -> Option<Vec<u8>> {
    let scan_limit = data.len().min(4096);
    for i in 0..scan_limit.saturating_sub(40) {
        // BITMAPINFOHEADER.biSize == 40
        let bi_size = u32::from_le_bytes([data[i], data[i + 1], data[i + 2], data[i + 3]]);
        if bi_size != 40 {
            continue;
        }
        // 유효성: width/height가 현실적인 범위
        let w = i32::from_le_bytes([data[i + 4], data[i + 5], data[i + 6], data[i + 7]]);
        let h = i32::from_le_bytes([data[i + 8], data[i + 9], data[i + 10], data[i + 11]]);
        if w <= 0 || w > 100_000 || h.abs() == 0 || h.abs() > 100_000 {
            continue;
        }
        let bit_count = u16::from_le_bytes([data[i + 14], data[i + 15]]);
        if !matches!(bit_count, 1 | 4 | 8 | 16 | 24 | 32) {
            continue;
        }
        let compression =
            u32::from_le_bytes([data[i + 16], data[i + 17], data[i + 18], data[i + 19]]);
        // 색상 테이블 크기 계산
        let clr_used = u32::from_le_bytes([data[i + 32], data[i + 33], data[i + 34], data[i + 35]]);
        let palette_entries = if bit_count <= 8 {
            if clr_used > 0 && clr_used <= 256 {
                clr_used
            } else {
                1u32 << bit_count
            }
        } else {
            0
        };
        let palette_bytes = palette_entries * 4;
        let dib_and_data = &data[i..];
        let offset_to_pixels = 14 + 40 + palette_bytes as usize;
        // 파일 전체 크기 = 14 헤더 + DIB 나머지
        let file_size = 14 + dib_and_data.len() as u32;
        let mut bmp = Vec::with_capacity(file_size as usize);
        bmp.extend_from_slice(b"BM");
        bmp.extend_from_slice(&file_size.to_le_bytes());
        bmp.extend_from_slice(&[0u8; 4]); // reserved
        bmp.extend_from_slice(&(offset_to_pixels as u32).to_le_bytes());
        bmp.extend_from_slice(dib_and_data);
        let _ = compression;
        return Some(bmp);
    }
    None
}

/// OLE Presentation Stream 헤더를 스킵하고 내부 EMF/메타파일 바이트를 반환한다.
///
/// OLE Presentation Stream 대략 구조 (MS-OLEDS):
/// `ULONG ansiClipboardFormat, ULONG tgtDevSize, tgtDev(variable), ULONG aspect,
///  ULONG lindex, ULONG advf, ULONG reserved, DWORD width, DWORD height, DWORD size, bytes[size]`
///
/// 여기서는 EMR_HEADER 매직(record_type=0x00000001 + " EMF" @ offset +40)을
/// 찾아서 그 위치부터 바이트를 반환한다. 매직을 찾지 못하면 `None`.
fn strip_ole_presentation_header(data: &[u8]) -> Option<Vec<u8>> {
    // EMF record header: u32 type=1, u32 size, 16 bytes bounds, 16 bytes frame, u32 signature=" EMF"(0x464D4520)
    // signature(" EMF")는 EMR_HEADER의 offset 40부터
    if data.len() < 64 {
        return None;
    }
    // 스캔 범위 제한 (OLE 헤더가 보통 수십~수백 바이트)
    let scan_limit = data.len().min(4096);
    for i in 0..(scan_limit.saturating_sub(44)) {
        let type_ok = u32::from_le_bytes([data[i], data[i + 1], data[i + 2], data[i + 3]]) == 1;
        if !type_ok {
            continue;
        }
        // " EMF" = 0x20 0x45 0x4D 0x46
        let sig = &data[i + 40..i + 44];
        if sig == b" EMF" {
            return Some(data[i..].to_vec());
        }
    }
    None
}

/// [#3363] OLE Presentation Stream 헤더 뒤의 표준/placeable WMF 를 찾아 반환한다.
/// EMF 스트립과 동일한 스캔 방식 — 표준 WMF 매직(mtType=1|2, mtHeaderSize=9,
/// mtVersion 0x0100|0x0300) 또는 placeable WMF 매직(`D7 CD C6 9A`)을 탐색한다.
fn strip_ole_presentation_header_wmf(data: &[u8]) -> Option<Vec<u8>> {
    if data.len() < 26 {
        return None;
    }
    let scan_limit = data.len().min(4096);
    for i in 0..(scan_limit.saturating_sub(8)) {
        // placeable WMF
        if data[i..i + 4] == [0xD7, 0xCD, 0xC6, 0x9A] {
            return Some(data[i..].to_vec());
        }
        // 표준 WMF: mtType(1=memory, 2=file) u16 + mtHeaderSize=9 u16 + mtVersion u16
        let mt_type = u16::from_le_bytes([data[i], data[i + 1]]);
        let header_size = u16::from_le_bytes([data[i + 2], data[i + 3]]);
        let version = u16::from_le_bytes([data[i + 4], data[i + 5]]);
        if (mt_type == 1 || mt_type == 2)
            && header_size == 9
            && (version == 0x0100 || version == 0x0300)
        {
            return Some(data[i..].to_vec());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_strip_no_emf_magic() {
        let data = vec![0u8; 100];
        assert!(strip_ole_presentation_header(&data).is_none());
    }

    #[test]
    fn test_strip_emf_at_offset() {
        // 헤더 20바이트 + EMR_HEADER(44바이트: type=1, size, 32바이트 bounds/frame, " EMF")
        let mut data = vec![0u8; 20];
        // type = 1
        data.extend_from_slice(&1u32.to_le_bytes());
        // size = 100
        data.extend_from_slice(&100u32.to_le_bytes());
        // bounds(16) + frame(16) = 32 bytes zero
        data.extend_from_slice(&[0u8; 32]);
        // " EMF"
        data.extend_from_slice(b" EMF");
        // 더미 남은 바이트
        data.extend_from_slice(&[0xAA; 20]);

        let stripped = strip_ole_presentation_header(&data).expect("EMF should be found");
        assert_eq!(&stripped[..4], &1u32.to_le_bytes()); // record type
        assert_eq!(&stripped[40..44], b" EMF");
    }

    #[test]
    fn test_parse_empty_bytes() {
        assert!(parse_ole_container(&[]).is_none());
        assert!(parse_ole_container(&[0u8; 4]).is_none());
    }

    #[test]
    fn test_parse_non_cfb() {
        // CFB 매직이 아닌 임의 바이트
        let bytes: Vec<u8> = (0..128u8).collect();
        assert!(parse_ole_container(&bytes).is_none());
    }
}
