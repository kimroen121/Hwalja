//! 그리기 개체 (Shape, Line, Rect, Ellipse, Arc, Polygon, Curve, Group, TextBox)

use super::paragraph::Paragraph;
use super::style::{Fill, ShapeBorderLine};
use super::*;

/// `raw_ctrl_data` (CTRL_HEADER) 바이트 오프셋 상수.
///
/// `parse_common_obj_attr` 및 `serialize_common_obj_attr` 과 일치해야 한다.
/// `table_ops.rs`, `object_ops.rs`, `html_table_import.rs` 등에서 직접 바이트
/// 인덱싱 대신 이 상수를 사용한다.
pub(crate) mod common_obj_offsets {
    pub const FLAGS: std::ops::Range<usize> = 0..4;
    pub const V_OFFSET: std::ops::Range<usize> = 4..8;
    pub const H_OFFSET: std::ops::Range<usize> = 8..12;
    pub const WIDTH: std::ops::Range<usize> = 12..16;
    pub const HEIGHT: std::ops::Range<usize> = 16..20;
    pub const Z_ORDER: std::ops::Range<usize> = 20..24;
    pub const MARGIN_LEFT: std::ops::Range<usize> = 24..26;
    pub const MARGIN_RIGHT: std::ops::Range<usize> = 26..28;
    pub const MARGIN_TOP: std::ops::Range<usize> = 28..30;
    pub const MARGIN_BOTTOM: std::ops::Range<usize> = 30..32;
    pub const INSTANCE_ID: std::ops::Range<usize> = 32..36;
    pub const PREVENT_PAGE_BREAK: std::ops::Range<usize> = 36..40;
    pub const MIN_LEN: usize = INSTANCE_ID.end;
    pub const MIN_LEN_WITH_PREVENT_PAGE_BREAK: usize = PREVENT_PAGE_BREAK.end;
}

/// 개체 공통 속성 (모든 개체에 공통)
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct CommonObjAttr {
    /// 컨트롤 ID
    pub ctrl_id: u32,
    /// 속성 비트 플래그
    pub attr: u32,
    /// 세로 오프셋
    pub vertical_offset: HwpUnit,
    /// 가로 오프셋
    pub horizontal_offset: HwpUnit,
    /// 폭
    pub width: HwpUnit,
    /// 높이
    pub height: HwpUnit,
    /// Z-order
    pub z_order: i32,
    /// 바깥 여백 (좌, 우, 상, 하)
    pub margin: Padding,
    /// 인스턴스 ID
    pub instance_id: u32,
    /// 쪽나눔 방지 (0=off, 1=on)
    pub prevent_page_break: i32,
    /// 글자처럼 취급
    pub treat_as_char: bool,
    /// HWPX `hp:pos@flowWithText`.
    ///
    /// HWP5 GenShape CTRL_HEADER attr bit 13 후보로 보존한다.
    pub flow_with_text: bool,
    /// HWPX `hp:pos@allowOverlap`.
    ///
    /// HWP5 GenShape CTRL_HEADER attr bit 14 후보로 보존한다.
    pub allow_overlap: bool,
    /// HWPX `hp:pos@affectLSpacing` (개체가 줄 간격에 영향을 주는지).
    ///
    /// [#2784] HWP5 개체 공통 속성 attr bit 2 (스펙 표 70). 한컴 원본 파일에서
    /// bit 2 ⟺ affectLSpacing="1" 를 1:1 대조 검증했다. 이 필드가 없어
    /// 그림·도형·표 방출이 "0" 으로 하드코딩되던 유실을 해소한다.
    pub affect_line_spacing: bool,
    /// HWPX 출처 GenShape를 HWP5로 저장할 때 필요한 storage high bit 후보.
    ///
    /// Table adapter의 `0x08000000` 보강과 다른 `0x04000000` bit 26이다.
    pub hwp5_gen_shape_attr_bit26: bool,
    /// VertRelTo가 para일 때 크기 보호 여부 (HWP5 GenShape CTRL_HEADER attr bit 20).
    pub size_protect: bool,
    /// HWPX 출처 GenShape 번호 범주 high bit 후보 (HWP5 GenShape CTRL_HEADER attr bit 28).
    pub hwp5_gen_shape_attr_bit28: bool,
    /// 세로 위치 기준
    pub vert_rel_to: VertRelTo,
    /// 세로 정렬 방식
    pub vert_align: VertAlign,
    /// 가로 위치 기준
    pub horz_rel_to: HorzRelTo,
    /// 가로 정렬 방식
    pub horz_align: HorzAlign,
    /// 텍스트 흐름 방식 (개체 배치 방식 — attr bit 21-23)
    pub text_wrap: TextWrap,
    /// 텍스트가 흐르는 방향 (attr bit 24-25)
    pub text_flow: TextFlow,
    /// 너비 기준 (bit 15-17): 0=Paper, 1=Page, 2=Column, 3=Para, 4=Absolute
    pub width_criterion: SizeCriterion,
    /// 높이 기준 (bit 18-19): 0=Paper, 1=Page, 2=Absolute
    pub height_criterion: SizeCriterion,
    /// 개체 설명문
    pub description: String,
    /// HWPX `numberingType` (캡션 번호 범주) 보존 (#1379).
    ///
    /// HWP5 파서는 설정하지 않는다 (기본 None). HWPX 그리기 개체의
    /// `numberingType="PICTURE"` 등을 라운드트립 보존하기 위한 필드.
    pub numbering_type: ObjectNumberingType,
    /// HWPX `dropcapstyle` (개체를 감싼 단락의 드롭캡 표시 방식) 보존.
    ///
    /// 파서가 읽지 않으면 방출측(picture.rs 등)이 항상 `dropcapstyle="None"`으로
    /// 되돌려, 원본이 `DoubleLine`/`TripleLine`/`Margin` 드롭캡으로 개체를 감싼
    /// 문단이었더라도 저장 시 드롭캡 스타일이 유실된다.
    pub drop_cap_style: DropCapStyle,
    /// 파싱된 필드 이후 추가 바이트 (라운드트립 보존용)
    pub raw_extra: Vec<u8>,
    /// HWPX `lock`(개체 잠금) 속성 보존 (#2840, #2855, #2931).
    ///
    /// 파서가 이 속성을 읽지 않아 직렬화 시 항상 `lock="0"`으로 하드코딩되던 문제
    /// 해소 — 수식·공용 도형·표·차트/OLE 경로에 배선한다.
    pub locked: bool,
}

/// HWPX 개체 `numberingType` (캡션 번호 범주)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum ObjectNumberingType {
    #[default]
    None,
    Picture,
    Table,
    Equation,
}

/// HWPX 개체 `dropcapstyle` (드롭캡 표시 방식). OWPML Core 스키마 `DropCapStyleType`.
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum DropCapStyle {
    #[default]
    None,
    DoubleLine,
    TripleLine,
    Margin,
}

/// 세로 위치 기준
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum VertRelTo {
    #[default]
    Paper,
    Page,
    Para,
}

/// 세로 정렬 방식
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum VertAlign {
    #[default]
    Top,
    Center,
    Bottom,
    Inside,
    Outside,
}

/// 가로 위치 기준
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum HorzRelTo {
    #[default]
    Paper,
    Page,
    Column,
    Para,
}

/// 가로 정렬 방식
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum HorzAlign {
    #[default]
    Left,
    Center,
    Right,
    Inside,
    Outside,
}

/// 크기 기준 (너비/높이)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum SizeCriterion {
    /// 종이 기준 (퍼센트)
    Paper,
    /// 쪽 기준 (퍼센트)
    Page,
    /// 단 기준 (퍼센트, 너비 전용)
    Column,
    /// 문단 기준 (퍼센트, 너비 전용)
    Para,
    /// 절대값 (HWPUNIT)
    #[default]
    Absolute,
}

/// 텍스트 흐름 방식 (개체 배치 — attr bit 21-23)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum TextWrap {
    #[default]
    Square,
    Tight,
    Through,
    TopAndBottom,
    BehindText,
    InFrontOfText,
}

/// 텍스트가 흐르는 방향 (attr bit 24-25)
///
/// HWPX `textFlow` 속성값과 대응한다.
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum TextFlow {
    #[default]
    BothSides,
    LeftOnly,
    RightOnly,
    LargestOnly,
}

/// 개체 요소 속성 (그리기 개체 공통)
#[derive(Debug, Clone, serde::Serialize)]
pub struct ShapeComponentAttr {
    /// SHAPE_COMPONENT 내 ctrl_id (라운드트립 보존용, 0이면 기본값 사용)
    pub ctrl_id: u32,
    /// ctrl_id가 2번 기록되는지 여부
    pub is_two_ctrl_id: bool,
    /// 그룹 내 X 오프셋
    pub offset_x: i32,
    /// 그룹 내 Y 오프셋
    pub offset_y: i32,
    /// 그룹 횟수
    pub group_level: u16,
    /// 로컬 파일 버전 (라운드트립 보존용)
    pub local_file_version: u16,
    /// 초기 폭
    pub original_width: u32,
    /// 초기 높이
    pub original_height: u32,
    /// [#4669] HWPX 원본이 `orgSz width="0"`을 기록했고 HWP 저장 계약을 위해
    /// 유효한 extent로 materialize한 경우 true.
    pub original_width_was_zero: bool,
    /// [#4669] HWPX 원본이 `orgSz height="0"`을 기록했고 HWP 저장 계약을 위해
    /// 유효한 extent로 materialize한 경우 true.
    pub original_height_was_zero: bool,
    /// 현재 폭
    pub current_width: u32,
    /// 현재 높이
    pub current_height: u32,
    /// [#2017] HWPX 원본이 `curSz width="0"`을 기록했고 파싱 시 orgSz로 materialize된 경우 true.
    /// materialize는 렌더/HWP5 저장이 실크기를 필요로 하기 때문에 유지하되, HWPX 재직렬화는
    /// 이 플래그로 원본 `0` sentinel을 복원해 roundtrip 충실도를 보존한다.
    pub current_width_was_zero: bool,
    /// [#2017] HWPX 원본이 `curSz height="0"`을 기록했고 파싱 시 orgSz로 materialize된 경우 true.
    pub current_height_was_zero: bool,
    /// 뒤집기 속성 원본 값 (bit 0: 수평, bit 1: 수직, 상위 비트 보존)
    pub flip: u32,
    /// 수평 뒤집기
    pub horz_flip: bool,
    /// 수직 뒤집기
    pub vert_flip: bool,
    /// 회전각
    pub rotation_angle: HwpUnit16,
    /// HWPX rotationInfo@rotateimage 보존.
    ///
    /// HWP5 SHAPE_COMPONENT offset 36 storage field의 0x0008_0000 bit로 materialize된다.
    pub rotate_image: bool,
    /// 회전 중심 좌표
    pub rotation_center: Point,
    /// 렌더링 정보 원본 바이트 (변환 행렬 등, 라운드트립 보존용)
    pub raw_rendering: Vec<u8>,
    /// 렌더링 변환 합성 결과: 아핀 행렬 [a, b, tx, c, d, ty]
    /// (x', y') = (a*x + b*y + tx, c*x + d*y + ty)
    /// render_sx = a, render_b = b, render_tx = tx
    /// render_c = c, render_sy = d, render_ty = ty
    pub render_tx: f64,
    pub render_ty: f64,
    pub render_sx: f64,
    pub render_sy: f64,
    /// 아핀 행렬 비대각 요소 (회전/전단 성분)
    pub render_b: f64,
    pub render_c: f64,
}

impl Default for ShapeComponentAttr {
    fn default() -> Self {
        Self {
            ctrl_id: 0,
            is_two_ctrl_id: false,
            offset_x: 0,
            offset_y: 0,
            group_level: 0,
            local_file_version: 0,
            original_width: 0,
            original_height: 0,
            original_width_was_zero: false,
            original_height_was_zero: false,
            current_width: 0,
            current_height: 0,
            current_width_was_zero: false,
            current_height_was_zero: false,
            flip: 0,
            horz_flip: false,
            vert_flip: false,
            rotation_angle: 0,
            rotate_image: false,
            rotation_center: Point::default(),
            raw_rendering: Vec::new(),
            render_tx: 0.0,
            render_ty: 0.0,
            render_sx: 1.0,
            render_sy: 1.0,
            render_b: 0.0,
            render_c: 0.0,
        }
    }
}

/// 그리기 개체 공통 속성
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct DrawingObjAttr {
    /// 개체 요소 속성
    pub shape_attr: ShapeComponentAttr,
    /// 테두리 선 정보
    pub border_line: ShapeBorderLine,
    /// 채우기 정보
    pub fill: Fill,
    /// 그림자 종류 (0=없음, 1=왼쪽위, 2=오른쪽위, 3=왼쪽아래, 4=오른쪽아래, 5=뒤쪽등)
    pub shadow_type: u32,
    /// 그림자 색상
    pub shadow_color: u32,
    /// 그림자 가로 오프셋
    pub shadow_offset_x: i32,
    /// 그림자 세로 오프셋
    pub shadow_offset_y: i32,
    /// 인스턴스 ID (instid)
    pub inst_id: u32,
    /// 그림자 투명도
    pub shadow_alpha: u8,
    /// 이 도형이 소유한 내부 문단 영역. 빈 문단/그림 전용 영역도 Some이다.
    /// 배경 이미지(fill)나 캡션의 문단은 이 영역이 아니다.
    pub text_box: Option<TextBox>,
    /// 캡션
    pub caption: Option<Caption>,
}

/// 글상자 (그리기 개체 내 텍스트)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct TextBox {
    /// LIST_HEADER list_attr (라운드트립 보존용)
    pub list_attr: u32,
    /// HWPX `textDirection="VERTICALALL"` 구분 보존 (#1379).
    ///
    /// `list_attr` bit 0~2 는 VERTICAL/VERTICALALL 을 모두 code 1 로 합치므로
    /// (renderer 세로쓰기 분기 호환), HWPX 라운드트립용 구분은 본 필드로 보존한다.
    pub vertical_all: bool,
    /// 세로 정렬 (list_attr bit 5~6: 0=top, 1=center, 2=bottom)
    pub vertical_align: crate::model::table::VerticalAlign,
    /// 왼쪽 여백
    pub margin_left: HwpUnit16,
    /// 오른쪽 여백
    pub margin_right: HwpUnit16,
    /// 위쪽 여백
    pub margin_top: HwpUnit16,
    /// 아래쪽 여백
    pub margin_bottom: HwpUnit16,
    /// 텍스트 최대 폭
    pub max_width: HwpUnit,
    /// LIST_HEADER 레코드의 파싱된 필드 이후 추가 바이트 (라운드트립 보존용)
    pub raw_list_header_extra: Vec<u8>,
    /// 문단 리스트
    pub paragraphs: Vec<Paragraph>,
}

/// 그리기 개체 종류
#[derive(Debug, Clone, serde::Serialize)]
pub enum ShapeObject {
    /// 직선
    Line(LineShape),
    /// 사각형
    Rectangle(RectangleShape),
    /// 타원
    Ellipse(EllipseShape),
    /// 호
    Arc(ArcShape),
    /// 다각형
    Polygon(PolygonShape),
    /// 곡선
    Curve(CurveShape),
    /// 묶음 개체
    Group(GroupShape),
    /// 그림 개체 (묶음 내 자식으로 포함될 때)
    Picture(Box<crate::model::image::Picture>),
    /// 차트 개체 (GSO + HWPTAG_CHART_DATA)
    Chart(Box<ChartShape>),
    /// OLE 개체 (HWPTAG_SHAPE_COMPONENT_OLE)
    Ole(Box<OleShape>),
}

impl ShapeObject {
    /// 공통 속성 참조 반환
    pub fn common(&self) -> &CommonObjAttr {
        match self {
            ShapeObject::Line(s) => &s.common,
            ShapeObject::Rectangle(s) => &s.common,
            ShapeObject::Ellipse(s) => &s.common,
            ShapeObject::Arc(s) => &s.common,
            ShapeObject::Polygon(s) => &s.common,
            ShapeObject::Curve(s) => &s.common,
            ShapeObject::Group(g) => &g.common,
            ShapeObject::Picture(p) => &p.common,
            ShapeObject::Chart(c) => &c.common,
            ShapeObject::Ole(o) => &o.common,
        }
    }

    /// 공통 속성 가변 참조 반환
    pub fn common_mut(&mut self) -> &mut CommonObjAttr {
        match self {
            ShapeObject::Line(s) => &mut s.common,
            ShapeObject::Rectangle(s) => &mut s.common,
            ShapeObject::Ellipse(s) => &mut s.common,
            ShapeObject::Arc(s) => &mut s.common,
            ShapeObject::Polygon(s) => &mut s.common,
            ShapeObject::Curve(s) => &mut s.common,
            ShapeObject::Group(g) => &mut g.common,
            ShapeObject::Picture(p) => &mut p.common,
            ShapeObject::Chart(c) => &mut c.common,
            ShapeObject::Ole(o) => &mut o.common,
        }
    }

    /// 그리기 공통 속성 참조 반환 (Group/Picture/Ole 내용 없는 종류는 None)
    pub fn drawing(&self) -> Option<&DrawingObjAttr> {
        match self {
            ShapeObject::Line(s) => Some(&s.drawing),
            ShapeObject::Rectangle(s) => Some(&s.drawing),
            ShapeObject::Ellipse(s) => Some(&s.drawing),
            ShapeObject::Arc(s) => Some(&s.drawing),
            ShapeObject::Polygon(s) => Some(&s.drawing),
            ShapeObject::Curve(s) => Some(&s.drawing),
            ShapeObject::Chart(c) => Some(&c.drawing),
            ShapeObject::Ole(o) => Some(&o.drawing),
            ShapeObject::Group(_) | ShapeObject::Picture(_) => None,
        }
    }

    /// 그리기 공통 속성 가변 참조 반환 (Group/Picture는 None)
    pub fn drawing_mut(&mut self) -> Option<&mut DrawingObjAttr> {
        match self {
            ShapeObject::Line(s) => Some(&mut s.drawing),
            ShapeObject::Rectangle(s) => Some(&mut s.drawing),
            ShapeObject::Ellipse(s) => Some(&mut s.drawing),
            ShapeObject::Arc(s) => Some(&mut s.drawing),
            ShapeObject::Polygon(s) => Some(&mut s.drawing),
            ShapeObject::Curve(s) => Some(&mut s.drawing),
            ShapeObject::Chart(c) => Some(&mut c.drawing),
            ShapeObject::Ole(o) => Some(&mut o.drawing),
            ShapeObject::Group(_) | ShapeObject::Picture(_) => None,
        }
    }

    /// Z-order 값 반환
    pub fn z_order(&self) -> i32 {
        self.common().z_order
    }

    /// 개체 요소 속성 참조 반환
    pub fn shape_attr(&self) -> &ShapeComponentAttr {
        match self {
            ShapeObject::Line(s) => &s.drawing.shape_attr,
            ShapeObject::Rectangle(s) => &s.drawing.shape_attr,
            ShapeObject::Ellipse(s) => &s.drawing.shape_attr,
            ShapeObject::Arc(s) => &s.drawing.shape_attr,
            ShapeObject::Polygon(s) => &s.drawing.shape_attr,
            ShapeObject::Curve(s) => &s.drawing.shape_attr,
            ShapeObject::Group(g) => &g.shape_attr,
            ShapeObject::Picture(p) => &p.shape_attr,
            ShapeObject::Chart(c) => &c.drawing.shape_attr,
            ShapeObject::Ole(o) => &o.drawing.shape_attr,
        }
    }

    /// 도형이 줄 흐름에서 차지하는 세로 범위 (HWPUNIT).
    ///
    /// 저장 프레임(`common.height`)과 개체 요소의 실제 표시 높이
    /// (`shape_attr.current_height`)는 어긋날 수 있다 — 한글은 둘 중 큰 값을
    /// 조판 높이로 쓴다. 조판·측정·렌더가 각자 이 식을 다시 쓰면 같은 속성에
    /// 정의가 여러 벌 생기므로(#4333) 이 메서드가 유일한 정의다.
    pub fn flow_height_hu(&self) -> i32 {
        (self.common().height as i32).max(self.shape_attr().current_height as i32)
    }

    /// 개체 요소 속성 가변 참조 반환
    pub fn shape_attr_mut(&mut self) -> &mut ShapeComponentAttr {
        match self {
            ShapeObject::Line(s) => &mut s.drawing.shape_attr,
            ShapeObject::Rectangle(s) => &mut s.drawing.shape_attr,
            ShapeObject::Ellipse(s) => &mut s.drawing.shape_attr,
            ShapeObject::Arc(s) => &mut s.drawing.shape_attr,
            ShapeObject::Polygon(s) => &mut s.drawing.shape_attr,
            ShapeObject::Curve(s) => &mut s.drawing.shape_attr,
            ShapeObject::Group(g) => &mut g.shape_attr,
            ShapeObject::Picture(p) => &mut p.shape_attr,
            ShapeObject::Chart(c) => &mut c.drawing.shape_attr,
            ShapeObject::Ole(o) => &mut o.drawing.shape_attr,
        }
    }

    /// 개체 타입명 반환
    pub fn shape_name(&self) -> &'static str {
        match self {
            ShapeObject::Line(_) => "직선",
            ShapeObject::Rectangle(_) => "사각형",
            ShapeObject::Ellipse(_) => "타원",
            ShapeObject::Arc(_) => "호",
            ShapeObject::Polygon(_) => "다각형",
            ShapeObject::Curve(_) => "곡선",
            ShapeObject::Group(_) => "묶음",
            ShapeObject::Picture(_) => "그림(묶음내)",
            ShapeObject::Chart(_) => "차트",
            ShapeObject::Ole(_) => "OLE",
        }
    }
}

/// 직선 개체 (HWPTAG_SHAPE_COMPONENT_LINE)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct LineShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 시작점
    pub start: Point,
    /// 끝점
    pub end: Point,
    /// 오른쪽/아래에서 시작했는지 여부 (hwplib: startedRightOrBottom)
    pub started_right_or_bottom: bool,
    /// 연결선 데이터 (ctrl_id='$col'일 때만 Some)
    pub connector: Option<ConnectorData>,
}

/// 연결선 타입 (9종)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
#[repr(u32)]
pub enum LinkLineType {
    #[default]
    StraightNoArrow = 0,
    StraightOneWay = 1,
    StraightBoth = 2,
    StrokeNoArrow = 3,
    StrokeOneWay = 4,
    StrokeBoth = 5,
    ArcNoArrow = 6,
    ArcOneWay = 7,
    ArcBoth = 8,
}

impl LinkLineType {
    pub fn from_u32(v: u32) -> Self {
        match v {
            0 => Self::StraightNoArrow,
            1 => Self::StraightOneWay,
            2 => Self::StraightBoth,
            3 => Self::StrokeNoArrow,
            4 => Self::StrokeOneWay,
            5 => Self::StrokeBoth,
            6 => Self::ArcNoArrow,
            7 => Self::ArcOneWay,
            8 => Self::ArcBoth,
            _ => Self::StraightNoArrow,
        }
    }

    /// 꺽인 연결선인지
    pub fn is_stroke(&self) -> bool {
        matches!(
            self,
            Self::StrokeNoArrow | Self::StrokeOneWay | Self::StrokeBoth
        )
    }

    /// 곡선 연결선인지
    pub fn is_arc(&self) -> bool {
        matches!(self, Self::ArcNoArrow | Self::ArcOneWay | Self::ArcBoth)
    }
}

/// 연결선 제어점
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct ConnectorControlPoint {
    pub x: i32,
    pub y: i32,
    pub point_type: u16,
}

/// 연결선 추가 데이터 (SC_LINE 확장)
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct ConnectorData {
    /// 연결선 타입
    pub link_type: LinkLineType,
    /// 시작 연결 개체 instance_id
    pub start_subject_id: u32,
    /// 시작 연결점 인덱스
    pub start_subject_index: u32,
    /// 끝 연결 개체 instance_id
    pub end_subject_id: u32,
    /// 끝 연결점 인덱스
    pub end_subject_index: u32,
    /// 제어점 목록 (꺽인/곡선용)
    pub control_points: Vec<ConnectorControlPoint>,
    /// SC_LINE 끝 패딩/추가 바이트 (라운드트립 보존)
    pub raw_trailing: Vec<u8>,
}

/// 사각형 개체 (HWPTAG_SHAPE_COMPONENT_RECTANGLE)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct RectangleShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 모서리 곡률 (%)
    pub round_rate: u8,
    /// 꼭짓점 X 좌표 (4개)
    pub x_coords: [i32; 4],
    /// 꼭짓점 Y 좌표 (4개)
    pub y_coords: [i32; 4],
}

/// 사각형 기하의 구조적 컨트롤 종류. 글자·그림·채움·선 속성과 독립적이다.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub enum RectangleControlKind {
    Rectangle,
    TextBox,
}

impl RectangleShape {
    /// 파서가 보존한 소유 문단 영역으로 식별한다. 구조 파싱 오류를 복구하는 함수가 아니다.
    /// 문단 수가 0이어도 존재하는 영역을 일반 사각형으로 바꾸지 않는다.
    pub fn control_kind(&self) -> RectangleControlKind {
        if self.drawing.text_box.is_some() {
            RectangleControlKind::TextBox
        } else {
            RectangleControlKind::Rectangle
        }
    }
}

/// 타원 개체 (HWPTAG_SHAPE_COMPONENT_ELLIPSE)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct EllipseShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 속성 플래그
    pub attr: u32,
    /// 중심 좌표
    pub center: Point,
    /// 제1축 좌표
    pub axis1: Point,
    /// 제2축 좌표
    pub axis2: Point,
    /// 시작점1
    pub start1: Point,
    /// 끝점1
    pub end1: Point,
    /// 시작점2 (호일 때)
    pub start2: Point,
    /// 끝점2 (호일 때)
    pub end2: Point,
}

/// 호 개체 (HWPTAG_SHAPE_COMPONENT_ARC)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct ArcShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 호 타입 (0: Arc, 1: CircularSector, 2: Bow)
    pub arc_type: u8,
    /// 타원 중심
    pub center: Point,
    /// 제1축 좌표
    pub axis1: Point,
    /// 제2축 좌표
    pub axis2: Point,
}

/// 다각형 개체 (HWPTAG_SHAPE_COMPONENT_POLYGON)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct PolygonShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 꼭짓점 좌표 목록
    pub points: Vec<Point>,
    /// SHAPE_POLYGON 끝 패딩/추가 바이트 (라운드트립 보존)
    pub raw_trailing: Vec<u8>,
}

/// 곡선 개체 (HWPTAG_SHAPE_COMPONENT_CURVE)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct CurveShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 제어점 좌표 목록
    pub points: Vec<Point>,
    /// 세그먼트 타입 목록 (0: line, 1: curve)
    pub segment_types: Vec<u8>,
}

/// 묶음 개체 (HWPTAG_SHAPE_COMPONENT_CONTAINER)
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct GroupShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 개체 요소 속성
    pub shape_attr: ShapeComponentAttr,
    /// 하위 개체 목록
    pub children: Vec<ShapeObject>,
    /// 캡션
    pub caption: Option<Caption>,
}

/// 캡션 정보
#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct Caption {
    /// 방향 (0: left, 1: right, 2: top, 3: bottom)
    pub direction: CaptionDirection,
    /// Left/Right 캡션의 세로 정렬 (위/가운데/아래)
    pub vert_align: CaptionVertAlign,
    /// 캡션 폭 (세로 방향일 때)
    pub width: HwpUnit,
    /// 캡션-틀 간격
    pub spacing: HwpUnit16,
    /// 텍스트 최대 길이
    pub max_width: HwpUnit,
    /// 캡션 폭에 마진 포함 여부 (가로 방향일 때만 사용)
    pub include_margin: bool,
    /// 문단 리스트
    pub paragraphs: Vec<Paragraph>,
}

/// 캡션 방향
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum CaptionDirection {
    Left,
    Right,
    Top,
    #[default]
    Bottom,
}

/// Left/Right 캡션의 세로 정렬
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum CaptionVertAlign {
    #[default]
    Top,
    Center,
    Bottom,
}

// ============================================================
// 차트 개체 (Task #195)
// ============================================================

/// 차트 종류 (1차 범위: Bar/Column/Line/Pie/Area/Scatter)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum ChartType {
    Bar,
    Column,
    Line,
    Pie,
    Area,
    Scatter,
    #[default]
    Unknown,
}

/// 범례 위치
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum LegendPosition {
    #[default]
    Right,
    Left,
    Top,
    Bottom,
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
    Hidden,
}

/// 범례
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Legend {
    pub position: LegendPosition,
    pub visible: bool,
}

/// 축
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Axis {
    pub label: Option<String>,
    pub labels: Vec<String>,
    pub min: Option<f64>,
    pub max: Option<f64>,
}

/// 데이터 시리즈 (한 줄기 막대/선 등)
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct DataSeries {
    /// 시리즈 이름 (범례 표시용)
    pub name: String,
    /// Y값 (또는 파이의 각 조각 값)
    pub values: Vec<f64>,
    /// X축 레이블 (시리즈 간 공유되지만 편의상 각자 보관)
    pub categories: Vec<String>,
    /// RGB 색상 (`0xRRGGBB`)
    pub color: Option<u32>,
}

/// 차트 개체 (GSO + HWPTAG_CHART_DATA)
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct ChartShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 차트 종류
    pub chart_type: ChartType,
    /// 타이틀
    pub title: Option<String>,
    /// 범례
    pub legend: Option<Legend>,
    /// X축
    pub x_axis: Option<Axis>,
    /// Y축
    pub y_axis: Option<Axis>,
    /// 데이터 시리즈 목록
    pub series: Vec<DataSeries>,
    /// CHART_DATA 레코드 원본 바이트(라운드트립 보존용, 하위 태그 전체 병합)
    pub raw_chart_data: Vec<u8>,
    /// 캡션
    pub caption: Option<Caption>,
}

// ============================================================
// OLE 개체 (Task #195)
// ============================================================

/// OLE 프리뷰 이미지 포맷
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize)]
pub enum OlePreviewFormat {
    Wmf,
    Emf,
    Png,
    Bmp,
}

/// OLE 프리뷰 이미지
#[derive(Debug, Clone, serde::Serialize)]
pub struct OlePreview {
    pub format: OlePreviewFormat,
    pub bytes: Vec<u8>,
}

/// OLE 표시 방식 (DrawingAspect)
#[derive(Debug, Clone, Copy, Default, PartialEq, serde::Serialize)]
pub enum OleDrawingAspect {
    #[default]
    Content,
    Icon,
    Thumbnail,
    DocPrint,
}

/// OLE 개체 (HWPTAG_SHAPE_COMPONENT_OLE)
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct OleShape {
    /// 공통 속성
    pub common: CommonObjAttr,
    /// 그리기 공통 속성
    pub drawing: DrawingObjAttr,
    /// 개체 영역 가로 (HWPUNIT)
    pub extent_x: i32,
    /// 개체 영역 세로 (HWPUNIT)
    pub extent_y: i32,
    /// OLE 속성 플래그
    pub flags: u8,
    /// 표시 방식
    pub drawing_aspect: OleDrawingAspect,
    /// BinData 참조 ID (`BinData/BIN000N.OLE`)
    pub bin_data_id: u32,
    /// 프리뷰 이미지 (단계 4 이후 선택적 채움)
    pub preview: Option<OlePreview>,
    /// OLE 레코드 원본 바이트 (라운드트립 보존)
    pub raw_tag_data: Vec<u8>,
    /// [#4495] raw_tag_data 출처 봉인 — 봉인 시점 OLE payload 모델 필드
    /// (extent_x/extent_y/bin_data_id)의 다이제스트. 저장 시 그 필드들이 봉인과
    /// 같을 때만 raw 를 재사용한다. None 은 종전 계약(raw 우선) 유지.
    #[serde(skip)]
    pub raw_tag_seal: Option<[u8; 32]>,
    /// 캡션
    pub caption: Option<Caption>,
    /// [#3546] HWPX `<hp:chart chartIDRef="...">` 출신 표식 — chartIDRef 원문.
    /// HWPX 파서가 차트를 OLE 모델(bin_data_id=60000+N)로 변환할 때 채우며,
    /// Some 이면 HWPX 저장기가 hp:ole 대신 hp:chart 를 원형 구조로 재방출한다.
    pub chart_id_ref: Option<String>,
    /// [#3546] 원본 `<hp:switch>` 의 `<hp:default>` fallback OLE.
    /// 저장 시 switch/case/default 구조 재방출의 재료 — None 이면 bare
    /// `<hp:chart>` 로 되쓴다. default 없는 case-only `<hp:switch>` 도
    /// None 으로 접힌다(둘 다 미관측 변형 — 이 경우 switch 래핑은
    /// 재방출되지 않는다).
    pub chart_switch_fallback: Option<Box<OleShape>>,
    /// [#4669] HWPX `<hp:ole id="...">` 원문 — `instid` 와 별개 값이다(한컴
    /// 원산 파일 실측: id=2141242094 / instid=1067500271). 종전에는 `instid` 만
    /// 파싱해 재방출 `id` 가 instance_id(또는 "0")로 되쓰였다. HWP5 출신은 None.
    pub hwpx_ole_id: Option<u32>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_common_obj_attr_default() {
        let attr = CommonObjAttr::default();
        assert!(!attr.treat_as_char);
        assert_eq!(attr.text_wrap, TextWrap::Square);
    }

    #[test]
    fn test_shape_object_line() {
        let line = ShapeObject::Line(LineShape::default());
        assert!(matches!(line, ShapeObject::Line(_)));
    }

    #[test]
    fn test_text_wrap_variants() {
        assert_eq!(TextWrap::default(), TextWrap::Square);
    }
}
