//! 그리기 개체 파싱 (도형, 그림)
//!
//! GSO(General Shape Object) 컨트롤과 관련 서브타입을 파싱한다.

use super::parse_caption;
use crate::model::control::Control;
use crate::model::image::{ImageEffect, Picture};
use crate::model::shape::{
    ArcShape, Caption, ChartShape, CommonObjAttr, CurveShape, DrawingObjAttr, EllipseShape,
    GroupShape, HorzAlign, HorzRelTo, LineShape, OleDrawingAspect, OleShape, PolygonShape,
    RectangleShape, ShapeComponentAttr, ShapeObject, TextWrap, VertAlign, VertRelTo,
};
use crate::model::style::{Fill, ShapeBorderLine};
use crate::model::Padding;
use crate::model::Point;
use crate::parser::body_text::parse_paragraph_list;
use crate::parser::byte_reader::ByteReader;
use crate::parser::doc_info;
use crate::parser::record::Record;
use crate::parser::tags;

// ============================================================
// 그리기 개체 ('gso ')
// ============================================================

/// 그리기 개체 컨트롤 파싱
pub(crate) fn parse_gso_control(ctrl_data: &[u8], child_records: &[Record]) -> Control {
    // CTRL_HEADER에서 공통 개체 속성 파싱
    let common = parse_common_obj_attr(ctrl_data);

    // 자식 레코드에서 SHAPE_COMPONENT와 개별 도형 태그 찾기
    let mut drawing = DrawingObjAttr::default();
    let mut shape_tag_id: Option<u16> = None;
    let mut shape_tag_data: &[u8] = &[];
    let mut text_paragraphs = Vec::new();
    let mut is_container = false;
    // Task #195: 차트/OLE 감지
    let mut chart_data_bytes: Option<Vec<u8>> = None;
    let mut ole_tag_data: Option<&[u8]> = None;

    // 레벨 기반 필터링: 첫 번째 레코드(SHAPE_COMPONENT)의 레벨을 기준으로
    // 자신의 레코드만 처리하고, 중첩 컨트롤의 하위 레코드는 무시
    let base_level = child_records.first().map(|r| r.level).unwrap_or(0);
    let mut shape_component_parsed = false;

    // 그룹 컨테이너 사전 감지
    let has_container_tag = child_records
        .iter()
        .any(|r| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT_CONTAINER);
    let has_child_sc = if let Some((sc_idx, sc_rec)) = child_records
        .iter()
        .enumerate()
        .find(|(_, r)| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT)
    {
        let sc_level = sc_rec.level;
        child_records[sc_idx + 1..]
            .iter()
            .any(|r| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT && r.level == sc_level + 1)
    } else {
        false
    };
    if has_container_tag {
        is_container = true;
    } else if has_child_sc {
        is_container = true;
    }
    // SHAPE_COMPONENT 인덱스 찾기 (캡션/텍스트박스 LIST_HEADER 구분에 필요)
    let shape_comp_idx = child_records.iter().position(|r| {
        r.tag_id == tags::HWPTAG_SHAPE_COMPONENT
            || r.tag_id == tags::HWPTAG_SHAPE_COMPONENT_CONTAINER
    });

    for record in child_records {
        match record.tag_id {
            tags::HWPTAG_SHAPE_COMPONENT if !shape_component_parsed => {
                shape_component_parsed = true;
                let parsed = parse_shape_component_full(&record.data);
                drawing.shape_attr = parsed.attr;
                drawing.border_line = parsed.border;
                drawing.fill = parsed.fill;
                drawing.shadow_type = parsed.shadow_type;
                drawing.shadow_color = parsed.shadow_color;
                drawing.shadow_offset_x = parsed.shadow_offset_x;
                drawing.shadow_offset_y = parsed.shadow_offset_y;
                drawing.inst_id = parsed.inst_id;
                drawing.shadow_alpha = parsed.shadow_alpha;
            }
            tags::HWPTAG_SHAPE_COMPONENT_CONTAINER if !shape_component_parsed => {
                shape_component_parsed = true;
                is_container = true;
                let parsed = parse_shape_component_full(&record.data);
                drawing.shape_attr = parsed.attr;
            }
            tags::HWPTAG_SHAPE_COMPONENT_LINE
            | tags::HWPTAG_SHAPE_COMPONENT_RECTANGLE
            | tags::HWPTAG_SHAPE_COMPONENT_ELLIPSE
            | tags::HWPTAG_SHAPE_COMPONENT_ARC
            | tags::HWPTAG_SHAPE_COMPONENT_POLYGON
            | tags::HWPTAG_SHAPE_COMPONENT_CURVE
            | tags::HWPTAG_SHAPE_COMPONENT_PICTURE
                if record.level <= base_level + 1 =>
            {
                shape_tag_id = Some(record.tag_id);
                shape_tag_data = &record.data;
            }
            // Task #195: OLE 태그 (도형 타입으로 분류)
            tags::HWPTAG_SHAPE_COMPONENT_OLE if record.level <= base_level + 1 => {
                shape_tag_id = Some(record.tag_id);
                shape_tag_data = &record.data;
                ole_tag_data = Some(&record.data);
            }
            // Task #195: 차트 데이터 (하위 레코드 트리 전체를 raw로 병합 보존)
            tags::HWPTAG_CHART_DATA => {
                let mut buf = record.data.clone();
                // 이 CHART_DATA 이후의 더 깊은 레벨 하위 태그 전체를 병합 (단순화: 직접 자식만)
                // 단계 3 범위는 CHART_DATA 본문만으로 라운드트립 충분
                // (단계 5에서 필요 시 하위 태그 구조화 파싱)
                let _ = &mut buf; // suppress warning
                chart_data_bytes = Some(record.data.clone());
            }
            tags::HWPTAG_LIST_HEADER => {}
            _ => {}
        }
    }

    // 빈 묶음: 자식 SHAPE_COMPONENT/CONTAINER 태그가 없어도 component ctrl_id 가
    // '$con' 이면 컨테이너다 (HWP3 변환 서식류의 children=0 묶음이 사각형으로 오분류
    // → 라운드트립 렌더 대변위, #1892).
    if drawing.shape_attr.ctrl_id == tags::SHAPE_CONTAINER_ID {
        is_container = true;
    }

    // 캡션 파싱: SHAPE_COMPONENT 앞의 LIST_HEADER는 캡션
    let mut caption: Option<Caption> = None;
    if let Some(comp_idx) = shape_comp_idx {
        let caption_start = child_records[..comp_idx]
            .iter()
            .position(|r| r.tag_id == tags::HWPTAG_LIST_HEADER);
        if let Some(start) = caption_start {
            let caption_records: Vec<Record> =
                child_records[start..comp_idx].iter().cloned().collect();
            if !caption_records.is_empty() {
                caption = Some(parse_caption(&caption_records));
            }
        }
    }

    // 텍스트박스 LIST_HEADER + 문단 수집: SHAPE_COMPONENT 이후의 LIST_HEADER
    let mut list_started = false;
    let mut list_header_data: Option<&[u8]> = None;
    let mut list_records: Vec<&Record> = Vec::new();
    let after_shape_comp = shape_comp_idx.map(|i| i + 1).unwrap_or(0);
    for record in &child_records[after_shape_comp..] {
        if !list_started && record.tag_id == tags::HWPTAG_LIST_HEADER {
            list_started = true;
            list_header_data = Some(&record.data);
            continue;
        }
        if list_started {
            list_records.push(record);
        }
    }
    if !list_records.is_empty() {
        let owned: Vec<Record> = list_records.iter().map(|r| (*r).clone()).collect();
        text_paragraphs = parse_paragraph_list(&owned);
    }

    // 글상자 설정
    if !text_paragraphs.is_empty() {
        let mut text_box = crate::model::shape::TextBox {
            paragraphs: text_paragraphs,
            ..Default::default()
        };

        // LIST_HEADER 데이터 파싱: para_count(4) + list_attr(4) + margins(8) + max_width(4) = 20 bytes
        // Note: para_count는 스펙상 INT16이지만 실제 HWP 파일에서는 UINT32로 저장됨
        if let Some(lh_data) = list_header_data {
            let mut lr = ByteReader::new(lh_data);
            let _para_count = lr.read_u32().unwrap_or(0);
            text_box.list_attr = lr.read_u32().unwrap_or(0);
            // list_attr bit 5~6: 세로 정렬 (표 67)
            let v_align = ((text_box.list_attr >> 5) & 0x03) as u8;
            text_box.vertical_align = match v_align {
                1 => crate::model::table::VerticalAlign::Center,
                2 => crate::model::table::VerticalAlign::Bottom,
                _ => crate::model::table::VerticalAlign::Top,
            };
            text_box.margin_left = lr.read_i16().unwrap_or(0);
            text_box.margin_right = lr.read_i16().unwrap_or(0);
            text_box.margin_top = lr.read_i16().unwrap_or(0);
            text_box.margin_bottom = lr.read_i16().unwrap_or(0);
            text_box.max_width = lr.read_u32().unwrap_or(0);
            // 나머지 바이트 보존 (라운드트립용)
            if lr.remaining() > 0 {
                text_box.raw_list_header_extra =
                    lr.read_bytes(lr.remaining()).unwrap_or_default().to_vec();
            }
        }

        drawing.text_box = Some(text_box);
    }

    // 캡션을 drawing에 저장 (도형 공통)
    drawing.caption = caption;

    // Task #195: 차트 우선 분기 (CHART_DATA가 있으면 GSO 다른 태그 종류와 무관하게 차트로 분류)
    if let Some(raw_chart) = chart_data_bytes.take() {
        let mut chart = ChartShape::default();
        chart.common = common.clone();
        chart.drawing = drawing;
        chart.raw_chart_data = raw_chart;
        chart.caption = chart.drawing.caption.take();
        // 단계 4에서 chart_type/title/series를 raw_chart_data에서 추출
        return Control::Shape(Box::new(ShapeObject::Chart(Box::new(chart))));
    }

    // Task #195: OLE 개체 분기
    if shape_tag_id == Some(tags::HWPTAG_SHAPE_COMPONENT_OLE) {
        let ole_data = ole_tag_data.unwrap_or(shape_tag_data);
        let mut ole = parse_ole_shape(common.clone(), drawing, ole_data);
        ole.caption = ole.drawing.caption.take();
        return Control::Shape(Box::new(ShapeObject::Ole(Box::new(ole))));
    }

    // 그림 개체
    if shape_tag_id == Some(tags::HWPTAG_SHAPE_COMPONENT_PICTURE) {
        let mut picture = parse_picture(common, drawing.shape_attr.clone(), shape_tag_data);
        // 캡션은 drawing에서 이미 파싱됨 → picture.caption에 복사
        picture.caption = drawing.caption;
        return Control::Picture(Box::new(picture));
    }

    // 묶음 개체 (Group/Container)
    if is_container {
        let mut group = GroupShape::default();
        group.common = common;
        group.shape_attr = drawing.shape_attr;
        group.children = parse_container_children(child_records, 0);
        group.caption = drawing.caption;
        return Control::Shape(Box::new(ShapeObject::Group(group)));
    }

    // 일반 도형
    match shape_tag_id {
        Some(tags::HWPTAG_SHAPE_COMPONENT_LINE) => {
            let mut line = LineShape::default();
            line.common = common;
            let is_connector = drawing.shape_attr.ctrl_id == tags::SHAPE_CONNECTOR_ID;
            line.drawing = drawing;
            parse_line_shape_data(shape_tag_data, &mut line, is_connector);
            Control::Shape(Box::new(ShapeObject::Line(line)))
        }
        Some(tags::HWPTAG_SHAPE_COMPONENT_RECTANGLE) => {
            let mut rect = RectangleShape::default();
            rect.common = common;
            rect.drawing = drawing;
            parse_rect_shape_data(shape_tag_data, &mut rect);
            Control::Shape(Box::new(ShapeObject::Rectangle(rect)))
        }
        Some(tags::HWPTAG_SHAPE_COMPONENT_ELLIPSE) => {
            let mut ellipse = EllipseShape::default();
            ellipse.common = common;
            ellipse.drawing = drawing;
            parse_ellipse_shape_data(shape_tag_data, &mut ellipse);
            Control::Shape(Box::new(ShapeObject::Ellipse(ellipse)))
        }
        Some(tags::HWPTAG_SHAPE_COMPONENT_ARC) => {
            let mut arc = ArcShape::default();
            arc.common = common;
            arc.drawing = drawing;
            parse_arc_shape_data(shape_tag_data, &mut arc);
            Control::Shape(Box::new(ShapeObject::Arc(arc)))
        }
        Some(tags::HWPTAG_SHAPE_COMPONENT_POLYGON) => {
            let mut poly = PolygonShape::default();
            poly.common = common;
            poly.drawing = drawing;
            parse_polygon_shape_data(shape_tag_data, &mut poly);
            Control::Shape(Box::new(ShapeObject::Polygon(poly)))
        }
        Some(tags::HWPTAG_SHAPE_COMPONENT_CURVE) => {
            let mut curve = CurveShape::default();
            curve.common = common;
            curve.drawing = drawing;
            parse_curve_shape_data(shape_tag_data, &mut curve);
            Control::Shape(Box::new(ShapeObject::Curve(curve)))
        }
        _ => {
            // 알 수 없는 도형 → 사각형으로 대체
            // Task #195 이후: CHART_DATA/OLE은 위에서 분기되므로 이 경로로 오지 않음
            let mut rect = RectangleShape::default();
            rect.common = common;
            rect.drawing = drawing;
            Control::Shape(Box::new(ShapeObject::Rectangle(rect)))
        }
    }
}

// ============================================================
// Task #195: OLE 개체 파싱
// ============================================================

/// HWPTAG_SHAPE_COMPONENT_OLE 레코드 파싱
///
/// 1.hwp 실측 바이트 레이아웃 (30바이트):
/// ```text
/// 01 00 00 00   u32 property/type (1)
/// 20 1C 00 00   u32 extent_x (HWPUNIT)
/// 20 1C 00 00   u32 extent_y
/// 01 00 00 00   u32 bin_data_id  ← DocInfo BinData 목록의 storage_id
/// 00 00 00 00   u32 reserved/flags
/// 00 00 00 00   u32 reserved
/// 00 00 00 00   u32 reserved
/// 00 00         u16 reserved/aspect
/// ```
pub(crate) fn parse_ole_shape(
    common: CommonObjAttr,
    drawing: DrawingObjAttr,
    tag_data: &[u8],
) -> OleShape {
    let mut ole = OleShape::default();
    ole.common = common;
    ole.drawing = drawing;
    ole.raw_tag_data = tag_data.to_vec();

    let mut r = ByteReader::new(tag_data);
    let _property = r.read_u32().unwrap_or(0);
    ole.extent_x = r.read_i32().unwrap_or(0);
    ole.extent_y = r.read_i32().unwrap_or(0);
    ole.bin_data_id = r.read_u32().unwrap_or(0);
    // 뒤에 flags/aspect 필드가 있을 수 있으나 스펙 불확실 — 기본값 유지
    ole.flags = 0;
    ole.drawing_aspect = OleDrawingAspect::Content;
    ole
}

/// CTRL_HEADER 데이터에서 공통 개체 속성 파싱
pub(crate) fn parse_common_obj_attr(ctrl_data: &[u8]) -> CommonObjAttr {
    let mut common = CommonObjAttr::default();
    let mut r = ByteReader::new(ctrl_data);

    let attr = r.read_u32().unwrap_or(0);
    common.attr = attr;
    common.treat_as_char = attr & 0x01 != 0;
    // [#2784] affectLSpacing(줄 간격에 영향) — 개체 공통 속성 attr bit 2 (스펙 표 70).
    common.affect_line_spacing = attr & (1 << 2) != 0;
    common.flow_with_text = attr & (1 << 13) != 0;
    common.allow_overlap = attr & (1 << 14) != 0;
    common.size_protect = attr & (1 << 20) != 0;
    // 개체 잠금 — HWP5 는 attr **비트 30** 에 싣는다.
    //
    // 실측으로 뽑았다: 한글이 `Ctrl.Properties.Item("Lock")` 을 1 로 답하는 표들의 attr 이
    // 안 잠긴 표보다 정확히 `2^30` 만큼 크다(같은 문서 안 표 열둘로 대조). 여태 HWPX 경로에서만
    // 읽고 HWP5 는 늘 `false` 여서, 잠긴 개체가 저장·변환에서 풀려 나갔다.
    common.locked = attr & (1 << 30) != 0;
    common.hwp5_gen_shape_attr_bit26 = attr & (1 << 26) != 0;
    common.hwp5_gen_shape_attr_bit28 = attr & (1 << 28) != 0;
    // [#5864] 개체 번호 범주(캡션 번호·상호참조 계열) — attr bits 26-28 의 3비트
    // 열거다. 07276 실측: 표 155/155(0=NONE 23·2=TABLE 126·1=PICTURE 6), 수식
    // 8/8(=3), gso 분포도 한글 2024 SaveAs HWPX 의 numberingType 과 정합
    // (PICTURE 28·TABLE 1 정확 일치). 종전엔 안 읽어 h2x 산출이 전량 NONE 이
    // 됐고, 한글이 상호참조 순번을 전부 1 로 재계산했다(07276 상호참조 153중
    // 101 오염). bit26/28 개별 보존 플래그(hwp5_gen_shape_attr_bit26/28)는
    // attr verbatim 왕복용으로 그대로 둔다.
    common.numbering_type = match (attr >> 26) & 0x7 {
        1 => crate::model::shape::ObjectNumberingType::Picture,
        2 => crate::model::shape::ObjectNumberingType::Table,
        3 => crate::model::shape::ObjectNumberingType::Equation,
        _ => crate::model::shape::ObjectNumberingType::None,
    };
    common.vert_rel_to = match (attr >> 3) & 0x03 {
        1 => VertRelTo::Page,
        2 => VertRelTo::Para,
        _ => VertRelTo::Paper,
    };
    common.vert_align = match (attr >> 5) & 0x07 {
        0 => VertAlign::Top,
        1 => VertAlign::Center,
        2 => VertAlign::Bottom,
        3 => VertAlign::Inside,
        4 => VertAlign::Outside,
        _ => VertAlign::Top,
    };
    common.horz_rel_to = match (attr >> 8) & 0x03 {
        0 => HorzRelTo::Paper,  // 종이 영역 (HWPCTL 스펙)
        1 => HorzRelTo::Page,   // 쪽 영역
        2 => HorzRelTo::Column, // 다단 영역
        3 => HorzRelTo::Para,   // 문단 영역
        _ => HorzRelTo::Paper,
    };
    common.horz_align = match (attr >> 10) & 0x07 {
        0 => HorzAlign::Left,
        1 => HorzAlign::Center,
        2 => HorzAlign::Right,
        3 => HorzAlign::Inside,
        4 => HorzAlign::Outside,
        _ => HorzAlign::Left,
    };
    // bit 15-17: WidthCriterion (너비 기준)
    common.width_criterion = match (attr >> 15) & 0x07 {
        0 => crate::model::shape::SizeCriterion::Paper,
        1 => crate::model::shape::SizeCriterion::Page,
        2 => crate::model::shape::SizeCriterion::Column,
        3 => crate::model::shape::SizeCriterion::Para,
        _ => crate::model::shape::SizeCriterion::Absolute,
    };
    // bit 18-19: HeightCriterion (높이 기준)
    common.height_criterion = match (attr >> 18) & 0x03 {
        0 => crate::model::shape::SizeCriterion::Paper,
        1 => crate::model::shape::SizeCriterion::Page,
        _ => crate::model::shape::SizeCriterion::Absolute,
    };
    // hwplib 기준 TextFlowMethod: 0=어울림, 1=자리차지, 2=글뒤로, 3=글앞으로
    common.text_wrap = match (attr >> 21) & 0x07 {
        0 => TextWrap::Square,        // 어울림 (FitWithText)
        1 => TextWrap::TopAndBottom,  // 자리차지 (TakePlace)
        2 => TextWrap::BehindText,    // 글 뒤로
        3 => TextWrap::InFrontOfText, // 글 앞으로
        _ => TextWrap::Square,
    };
    // bit 24-25: TextFlowSide (텍스트 흐르는 방향)
    common.text_flow = match (attr >> 24) & 0x03 {
        0 => crate::model::shape::TextFlow::BothSides,
        1 => crate::model::shape::TextFlow::LeftOnly,
        2 => crate::model::shape::TextFlow::RightOnly,
        3 => crate::model::shape::TextFlow::LargestOnly,
        _ => crate::model::shape::TextFlow::BothSides,
    };

    common.vertical_offset = r.read_u32().unwrap_or(0);
    common.horizontal_offset = r.read_u32().unwrap_or(0);
    common.width = r.read_u32().unwrap_or(0);
    common.height = r.read_u32().unwrap_or(0);
    common.z_order = r.read_i32().unwrap_or(0);

    // 바깥 여백
    common.margin = Padding {
        left: r.read_i16().unwrap_or(0),
        right: r.read_i16().unwrap_or(0),
        top: r.read_i16().unwrap_or(0),
        bottom: r.read_i16().unwrap_or(0),
    };

    common.instance_id = r.read_u32().unwrap_or(0);

    // 쪽나눔 방지 (INT32, 4바이트)
    if r.remaining() >= 4 {
        common.prevent_page_break = r.read_i32().unwrap_or(0);
    }

    // 설명문 (있으면)
    if r.remaining() >= 2 {
        common.description = r.read_hwp_string().unwrap_or_default();
    }

    // 남은 바이트 보존 (라운드트립용)
    if r.remaining() > 0 {
        common.raw_extra = r.read_bytes(r.remaining()).unwrap_or_default().to_vec();
    }
    common
}

/// SHAPE_COMPONENT 파싱 결과
struct ShapeComponentParsed {
    attr: ShapeComponentAttr,
    border: ShapeBorderLine,
    fill: Fill,
    shadow_type: u32,
    shadow_color: u32,
    shadow_offset_x: i32,
    shadow_offset_y: i32,
    inst_id: u32,
    shadow_alpha: u8,
}

/// SHAPE_COMPONENT 레코드 전체 파싱 (ShapeComponentAttr + border_line + fill + shadow)
///
/// 레코드 구조:
/// - 컨트롤 ID (4바이트) × 1~2회 (GenShapeObject이면 2회)
/// - ShapeComponentAttr (42바이트)
/// - Rendering 정보 (2 + 48 + cnt×96 바이트)
/// - 테두리 선 정보 (13바이트: color 4 + width 4 + attr 4 + outline 1)
/// - 채우기 정보 (가변)
/// - 그림자 정보 (16바이트: type 4 + color 4 + offsetX 4 + offsetY 4)
fn parse_shape_component_full(data: &[u8]) -> ShapeComponentParsed {
    // 컨트롤 ID 건너뛰기: GenShapeObject(top-level)이면 ID 2회, group child이면 1회
    let is_two_ctrl_id = data.len() >= 8 && data[0..4] == data[4..8];
    let id_offset = if is_two_ctrl_id { 8 } else { 4 };

    if data.len() < id_offset {
        return ShapeComponentParsed {
            attr: ShapeComponentAttr::default(),
            border: ShapeBorderLine::default(),
            fill: Fill::default(),
            shadow_type: 0,
            shadow_color: 0,
            shadow_offset_x: 0,
            shadow_offset_y: 0,
            inst_id: 0,
            shadow_alpha: 0,
        };
    }

    // ctrl_id 보존 (라운드트립용)
    let ctrl_id = if data.len() >= 4 {
        u32::from_le_bytes([data[0], data[1], data[2], data[3]])
    } else {
        0
    };

    let mut r = ByteReader::new(&data[id_offset..]);

    // ShapeComponentAttr (42바이트)
    let mut attr = ShapeComponentAttr::default();
    attr.ctrl_id = ctrl_id;
    attr.is_two_ctrl_id = is_two_ctrl_id;
    attr.offset_x = r.read_i32().unwrap_or(0);
    attr.offset_y = r.read_i32().unwrap_or(0);
    attr.group_level = r.read_u16().unwrap_or(0);
    attr.local_file_version = r.read_u16().unwrap_or(0);
    attr.original_width = r.read_u32().unwrap_or(0);
    attr.original_height = r.read_u32().unwrap_or(0);
    attr.current_width = r.read_u32().unwrap_or(0);
    attr.current_height = r.read_u32().unwrap_or(0);

    let flip = r.read_u32().unwrap_or(0);
    attr.flip = flip;
    attr.horz_flip = flip & 0x01 != 0;
    attr.vert_flip = flip & 0x02 != 0;

    attr.rotation_angle = r.read_i16().unwrap_or(0);
    attr.rotation_center.x = r.read_i32().unwrap_or(0);
    attr.rotation_center.y = r.read_i32().unwrap_or(0);

    // 렌더링 행렬 시작 위치
    let rendering_start = id_offset + r.position();

    // Rendering 정보 파싱 (변환 행렬) — 합성 변환 계산 후 border/fill 파싱
    let cnt = r.read_u16().unwrap_or(0) as usize;
    {
        // 아핀 변환 행렬: [a, b, tx, c, d, ty] → (x',y') = (a*x+b*y+tx, c*x+d*y+ty)
        fn read_matrix(r: &mut ByteReader) -> [f64; 6] {
            let mut m = [0.0f64; 6];
            for v in m.iter_mut() {
                let bytes = r.read_bytes(8).unwrap_or_default();
                if bytes.len() == 8 {
                    *v = f64::from_le_bytes([
                        bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6],
                        bytes[7],
                    ]);
                }
            }
            m
        }
        // 두 아핀 행렬 합성: result = A × B
        fn compose(a: &[f64; 6], b: &[f64; 6]) -> [f64; 6] {
            [
                a[0] * b[0] + a[1] * b[3],        // a
                a[0] * b[1] + a[1] * b[4],        // b
                a[0] * b[2] + a[1] * b[5] + a[2], // tx
                a[3] * b[0] + a[4] * b[3],        // c
                a[3] * b[1] + a[4] * b[4],        // d
                a[3] * b[2] + a[4] * b[5] + a[5], // ty
            ]
        }

        let translation = read_matrix(&mut r);
        let mut result = translation;
        for _ in 0..cnt {
            let scale = read_matrix(&mut r);
            let rotation = read_matrix(&mut r);
            result = compose(&result, &rotation);
            result = compose(&result, &scale);
        }
        // 합성된 아핀 행렬 [a, b, tx, c, d, ty] 추출
        attr.render_sx = result[0]; // a
        attr.render_b = result[1]; // b (회전/전단 성분)
        attr.render_tx = result[2]; // tx
        attr.render_c = result[3]; // c (회전/전단 성분)
        attr.render_sy = result[4]; // d
        attr.render_ty = result[5]; // ty
    }

    // raw_rendering: 렌더링 행렬만 보존 (border/fill/shadow 제외)
    // 속성 편집 후에도 렌더링 행렬을 라운드트립 보존하기 위함
    let rendering_end = id_offset + r.position();
    if rendering_start < data.len() {
        attr.raw_rendering = data[rendering_start..rendering_end.min(data.len())].to_vec();
    }

    // 테두리 선 정보 (13바이트: color 4 + width 4 + attr 4 + outline 1)
    // hwplib 참조: color=readUInt4, thickness=readSInt4, property=readUInt4, outlineStyle=readUInt1
    let mut border = ShapeBorderLine::default();
    if r.remaining() >= 13 {
        border.color = r.read_color_ref().unwrap_or(0);
        border.width = r.read_i32().unwrap_or(0);
        border.attr = r.read_u32().unwrap_or(0);
        border.outline_style = r.read_u8().unwrap_or(0);
    }

    // 채우기 정보
    let fill = if r.remaining() >= 4 {
        doc_info::parse_fill(&mut r)
    } else {
        Fill::default()
    };

    // 그림자 정보 (hwplib ForShapeComponent.shadowInfo 참조)
    // type(u32) + color(u32) + offsetX(i32) + offsetY(i32) = 16바이트
    let (shadow_type, shadow_color, shadow_offset_x, shadow_offset_y) = if r.remaining() >= 16 {
        (
            r.read_u32().unwrap_or(0),
            r.read_u32().unwrap_or(0),
            r.read_i32().unwrap_or(0),
            r.read_i32().unwrap_or(0),
        )
    } else {
        (0, 0, 0, 0)
    };

    // 인스턴스 ID (4바이트) + 예약 (1바이트) + 그림자 투명도 (1바이트) = 6바이트
    let inst_id = if r.remaining() >= 4 {
        r.read_u32().unwrap_or(0)
    } else {
        0
    };
    if r.remaining() >= 1 {
        let _ = r.read_u8();
    } // 예약 (skip)
    let shadow_alpha = if r.remaining() >= 1 {
        r.read_u8().unwrap_or(0)
    } else {
        0
    };

    ShapeComponentParsed {
        attr,
        border,
        fill,
        shadow_type,
        shadow_color,
        shadow_offset_x,
        shadow_offset_y,
        inst_id,
        shadow_alpha,
    }
}

/// 묶음 개체(Container)의 자식 도형 파싱
///
/// SHAPE_COMPONENT_CONTAINER 또는 첫 SHAPE_COMPONENT 이후의 레코드에서
/// SHAPE_COMPONENT + 도형 태그 쌍을 찾아 각각을 개별 ShapeObject로 파싱한다.
/// [#4761] HWP5 묶음(그룹) 개체는 자식으로 다시 묶음을 가질 수 있고, 그 중첩 깊이는
/// `level` 필드로 파일에서 온다. 상한이 없으면 깊이 중첩된 그룹 체인 하나로 네이티브
/// 스택을 고갈시켜 프로세스를 죽일 수 있다(패닉과 달리 catch_unwind 로 못 잡는
/// SIGSEGV). HWP3 형제 `parse_shape_list` 의 `MAX_DRAWING_OBJECT_DEPTH`(#4285)와 같은
/// 취지·같은 값으로 상한을 둔다. 이 함수는 `Result` 가 아니므로 초과 시 빈 자식으로
/// 절단한다(크래시 대신 깊은 중첩 유실 — 실문서의 그룹 중첩은 이에 한참 못 미친다).
const MAX_HWP5_SHAPE_DEPTH: u32 = 256;

fn parse_container_children(child_records: &[Record], depth: u32) -> Vec<ShapeObject> {
    let mut children = Vec::new();
    if depth > MAX_HWP5_SHAPE_DEPTH {
        return children;
    }

    // SHAPE_COMPONENT_CONTAINER 이후 또는 구버전 그룹의 첫 SHAPE_COMPONENT 이후
    let container_idx = child_records
        .iter()
        .position(|r| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT_CONTAINER);

    // 첫 SHAPE_COMPONENT 위치 찾기 (캡션 등이 앞에 올 수 있음)
    let first_sc_idx = child_records
        .iter()
        .position(|r| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT);

    let start = match container_idx {
        Some(idx) => idx + 1,
        None => {
            // 구버전: CONTAINER 태그 없이 첫 SHAPE_COMPONENT가 그룹 자체
            if let Some(sc_idx) = first_sc_idx {
                sc_idx + 1 // 첫 SHAPE_COMPONENT(그룹 자체) 건너뛰고 자식부터 시작
            } else {
                return children;
            }
        }
    };

    let records = &child_records[start..];

    // SHAPE_COMPONENT를 기준으로 자식 도형 경계 식별
    // 직접 자식 레벨의 SHAPE_COMPONENT만 경계로 사용 (인라인 컨트롤의 깊은 레벨 제외)
    let parent_level = first_sc_idx
        .map(|i| child_records[i].level)
        .or_else(|| child_records.first().map(|r| r.level))
        .unwrap_or(0);
    let child_level = parent_level + 1;
    let mut comp_indices: Vec<usize> = Vec::new();
    for (i, record) in records.iter().enumerate() {
        if record.tag_id == tags::HWPTAG_SHAPE_COMPONENT && record.level == child_level {
            comp_indices.push(i);
        }
    }

    for (ci, &comp_start) in comp_indices.iter().enumerate() {
        let comp_end = if ci + 1 < comp_indices.len() {
            comp_indices[ci + 1]
        } else {
            records.len()
        };

        let child_slice = &records[comp_start..comp_end];
        if child_slice.is_empty() {
            continue;
        }

        // SHAPE_COMPONENT에서 속성+테두리+채우기+그림자 파싱
        let parsed = parse_shape_component_full(&child_slice[0].data);
        let mut child_drawing = DrawingObjAttr {
            shape_attr: parsed.attr,
            border_line: parsed.border,
            fill: parsed.fill,
            shadow_type: parsed.shadow_type,
            shadow_color: parsed.shadow_color,
            shadow_offset_x: parsed.shadow_offset_x,
            shadow_offset_y: parsed.shadow_offset_y,
            inst_id: parsed.inst_id,
            shadow_alpha: parsed.shadow_alpha,
            text_box: None,
            caption: None,
        };
        // tb_attr: SHAPE_COMPONENT 인라인 텍스트 속성 (미구현, 항상 None)
        let tb_attr: Option<(i16, i16, i16, i16, u32, u32)> = None;

        // 도형 태그 찾기 (직접 자식 level만 — 중첩 Group 자식 제외)
        let direct_child_level = child_slice[0].level + 1;
        let mut shape_tag_id: Option<u16> = None;
        let mut shape_tag_data: &[u8] = &[];
        for record in &child_slice[1..] {
            if record.level != direct_child_level {
                continue;
            }
            match record.tag_id {
                tags::HWPTAG_SHAPE_COMPONENT_LINE
                | tags::HWPTAG_SHAPE_COMPONENT_RECTANGLE
                | tags::HWPTAG_SHAPE_COMPONENT_ELLIPSE
                | tags::HWPTAG_SHAPE_COMPONENT_ARC
                | tags::HWPTAG_SHAPE_COMPONENT_POLYGON
                | tags::HWPTAG_SHAPE_COMPONENT_CURVE
                | tags::HWPTAG_SHAPE_COMPONENT_PICTURE => {
                    shape_tag_id = Some(record.tag_id);
                    shape_tag_data = &record.data;
                    break;
                }
                _ => {}
            }
        }

        // LIST_HEADER 이후 문단 수집 (자식 범위 내)
        let mut list_started = false;
        let mut list_header_data: Option<&[u8]> = None;
        let mut list_records: Vec<&Record> = Vec::new();
        for record in &child_slice[1..] {
            if record.tag_id == tags::HWPTAG_LIST_HEADER && !list_started {
                list_started = true;
                list_header_data = Some(&record.data);
                continue;
            }
            if list_started {
                list_records.push(record);
            }
        }
        if !list_records.is_empty() {
            let owned: Vec<Record> = list_records.iter().map(|r| (*r).clone()).collect();
            let paragraphs = parse_paragraph_list(&owned);
            if !paragraphs.is_empty() {
                let mut text_box = crate::model::shape::TextBox {
                    paragraphs,
                    ..Default::default()
                };
                // LIST_HEADER 데이터에서 글상자 속성 파싱
                if let Some(lh_data) = list_header_data {
                    let mut lr = ByteReader::new(lh_data);
                    let _para_count = lr.read_u32().unwrap_or(0);
                    text_box.list_attr = lr.read_u32().unwrap_or(0);
                    let v_align = ((text_box.list_attr >> 5) & 0x03) as u8;
                    text_box.vertical_align = match v_align {
                        1 => crate::model::table::VerticalAlign::Center,
                        2 => crate::model::table::VerticalAlign::Bottom,
                        _ => crate::model::table::VerticalAlign::Top,
                    };
                    text_box.margin_left = lr.read_i16().unwrap_or(0);
                    text_box.margin_right = lr.read_i16().unwrap_or(0);
                    text_box.margin_top = lr.read_i16().unwrap_or(0);
                    text_box.margin_bottom = lr.read_i16().unwrap_or(0);
                    text_box.max_width = lr.read_u32().unwrap_or(0);
                    if lr.remaining() > 0 {
                        text_box.raw_list_header_extra =
                            lr.read_bytes(lr.remaining()).unwrap_or_default().to_vec();
                    }
                } else if let Some((ml, mr, mt, mb, max_w, list_attr)) = tb_attr {
                    // LIST_HEADER 레코드가 없으면 SHAPE_COMPONENT 인라인 속성 사용
                    text_box.margin_left = ml;
                    text_box.margin_right = mr;
                    text_box.margin_top = mt;
                    text_box.margin_bottom = mb;
                    text_box.max_width = max_w;
                    text_box.list_attr = list_attr;
                    let v_align = ((list_attr >> 5) & 0x03) as u8;
                    text_box.vertical_align = match v_align {
                        1 => crate::model::table::VerticalAlign::Center,
                        2 => crate::model::table::VerticalAlign::Bottom,
                        _ => crate::model::table::VerticalAlign::Top,
                    };
                }
                child_drawing.text_box = Some(text_box);
            }
        }

        // 중첩 Group 감지: shape_tag_id가 없고 하위 SHAPE_COMPONENT가 있으면 재귀
        let has_nested_shapes = shape_tag_id.is_none()
            && child_slice.len() > 1
            && child_slice[1..].iter().any(|r| {
                r.tag_id == tags::HWPTAG_SHAPE_COMPONENT && r.level > child_slice[0].level
            });
        // CONTAINER 태그가 있거나 하위 SHAPE_COMPONENT가 있으면 중첩 Group.
        // 자식이 없어도 component ctrl_id 가 '$con' 이면 빈 묶음이다 (#1892 —
        // 사각형 폴백으로 빠지면 재파스 렌더 트리가 Group→Rect 로 갈라진다).
        let has_container_tag = child_slice[1..]
            .iter()
            .any(|r| r.tag_id == tags::HWPTAG_SHAPE_COMPONENT_CONTAINER);
        if has_container_tag
            || has_nested_shapes
            || child_drawing.shape_attr.ctrl_id == tags::SHAPE_CONTAINER_ID
        {
            let mut group = GroupShape::default();
            group.shape_attr = child_drawing.shape_attr.clone();
            group.children = parse_container_children(child_slice, depth + 1);
            children.push(ShapeObject::Group(group));
            continue;
        }

        // 도형 생성
        let shape = match shape_tag_id {
            Some(tags::HWPTAG_SHAPE_COMPONENT_LINE) => {
                let mut line = LineShape::default();
                let is_connector = child_drawing.shape_attr.ctrl_id == tags::SHAPE_CONNECTOR_ID;
                line.drawing = child_drawing;
                parse_line_shape_data(shape_tag_data, &mut line, is_connector);
                ShapeObject::Line(line)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_RECTANGLE) => {
                let mut rect = RectangleShape::default();
                rect.drawing = child_drawing;
                parse_rect_shape_data(shape_tag_data, &mut rect);
                ShapeObject::Rectangle(rect)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_ELLIPSE) => {
                let mut ellipse = EllipseShape::default();
                ellipse.drawing = child_drawing;
                parse_ellipse_shape_data(shape_tag_data, &mut ellipse);
                ShapeObject::Ellipse(ellipse)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_ARC) => {
                let mut arc = ArcShape::default();
                arc.drawing = child_drawing;
                parse_arc_shape_data(shape_tag_data, &mut arc);
                ShapeObject::Arc(arc)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_POLYGON) => {
                let mut poly = PolygonShape::default();
                poly.drawing = child_drawing;
                parse_polygon_shape_data(shape_tag_data, &mut poly);
                ShapeObject::Polygon(poly)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_CURVE) => {
                let mut curve = CurveShape::default();
                curve.drawing = child_drawing;
                parse_curve_shape_data(shape_tag_data, &mut curve);
                ShapeObject::Curve(curve)
            }
            Some(tags::HWPTAG_SHAPE_COMPONENT_PICTURE) => {
                let picture = parse_picture(
                    CommonObjAttr::default(),
                    child_drawing.shape_attr.clone(),
                    shape_tag_data,
                );
                ShapeObject::Picture(Box::new(picture))
            }
            _ => {
                let mut rect = RectangleShape::default();
                rect.drawing = child_drawing;
                ShapeObject::Rectangle(rect)
            }
        };

        children.push(shape);
    }

    children
}

/// 그림 개체 파싱
fn parse_picture(common: CommonObjAttr, shape_attr: ShapeComponentAttr, data: &[u8]) -> Picture {
    let mut pic = Picture::default();
    pic.common = common;
    pic.shape_attr = shape_attr;

    let mut r = ByteReader::new(data);

    pic.border_color = r.read_color_ref().unwrap_or(0);
    pic.border_width = r.read_i32().unwrap_or(0);

    // 테두리 속성 (attr u32, 표 87 참조)
    let border_attr_raw = r.read_u32().unwrap_or(0);
    pic.border_attr = ShapeBorderLine {
        color: pic.border_color,
        width: pic.border_width,
        attr: border_attr_raw,
        outline_style: 0,
    };

    // 꼭짓점 좌표 (4개씩)
    for i in 0..4 {
        pic.border_x[i] = r.read_i32().unwrap_or(0);
    }
    for i in 0..4 {
        pic.border_y[i] = r.read_i32().unwrap_or(0);
    }

    // 자르기 정보
    pic.crop.left = r.read_i32().unwrap_or(0);
    pic.crop.top = r.read_i32().unwrap_or(0);
    pic.crop.right = r.read_i32().unwrap_or(0);
    pic.crop.bottom = r.read_i32().unwrap_or(0);

    // 안쪽 여백
    pic.padding = Padding {
        left: r.read_i16().unwrap_or(0),
        right: r.read_i16().unwrap_or(0),
        top: r.read_i16().unwrap_or(0),
        bottom: r.read_i16().unwrap_or(0),
    };

    // 이미지 속성
    pic.image_attr.brightness = r.read_i8().unwrap_or(0);
    pic.image_attr.contrast = r.read_i8().unwrap_or(0);
    let effect = r.read_u8().unwrap_or(0);
    pic.image_attr.effect = match effect {
        1 => ImageEffect::GrayScale,
        2 => ImageEffect::BlackWhite,
        3 => ImageEffect::Pattern8x8,
        _ => ImageEffect::RealPic,
    };
    pic.image_attr.bin_data_id = r.read_u16().unwrap_or(0);

    // 남은 바이트 보존 (라운드트립용)
    if r.remaining() > 0 {
        pic.raw_picture_extra = r.read_bytes(r.remaining()).unwrap_or_default().to_vec();
        if let Some(&border_opacity) = pic.raw_picture_extra.first() {
            pic.border_opacity = border_opacity;
        }
        if pic.raw_picture_extra.len() >= 5 {
            pic.instance_id = u32::from_le_bytes([
                pic.raw_picture_extra[1],
                pic.raw_picture_extra[2],
                pic.raw_picture_extra[3],
                pic.raw_picture_extra[4],
            ]);
        }
        if pic.raw_picture_extra.len() >= 18 {
            if let Some(&alpha) = pic.raw_picture_extra.last() {
                pic.image_attr.transparency =
                    crate::model::image::alpha_byte_to_transparency_percent(alpha);
            }
        }
        // [#1929] extra 꼬리의 원본 이미지 크기(offset 9..17: w4+h4)를 img_dim 으로
        // 적재 — HWPX `hp:imgDim` 대응 필드. 종전에는 HWP5 파스가 이를 읽지 않아
        // HWPX→HWP5 왕복에서 imgDim 이 (0,0) 으로 소실됐다 (직렬화기 non-raw
        // 경로가 기록해도 재파스가 버림).
        if pic.raw_picture_extra.len() >= 17 {
            let e = &pic.raw_picture_extra;
            pic.img_dim = (
                u32::from_le_bytes([e[9], e[10], e[11], e[12]]),
                u32::from_le_bytes([e[13], e[14], e[15], e[16]]),
            );
        }
    }

    pic
}

/// 직선 도형 데이터 파싱
fn parse_line_shape_data(data: &[u8], line: &mut LineShape, is_connector: bool) {
    use crate::model::shape::{ConnectorControlPoint, ConnectorData, LinkLineType};
    let mut r = ByteReader::new(data);
    line.start.x = r.read_i32().unwrap_or(0);
    line.start.y = r.read_i32().unwrap_or(0);
    line.end.x = r.read_i32().unwrap_or(0);
    line.end.y = r.read_i32().unwrap_or(0);

    if is_connector {
        // 연결선: type(u32) + ssid(u32) + ssidx(u32) + esid(u32) + esidx(u32) + countCP(u32) + CPs + trailing
        let lt = r.read_u32().unwrap_or(0);
        let link_type = LinkLineType::from_u32(lt);
        let start_subject_id = r.read_u32().unwrap_or(0);
        let start_subject_index = r.read_u32().unwrap_or(0);
        let end_subject_id = r.read_u32().unwrap_or(0);
        let end_subject_index = r.read_u32().unwrap_or(0);
        // countCP 는 파일에서 온 u32 다. 남은 바이트로 실제 담을 수 있는 개수
        // (제어점당 4+4+2=10바이트)로 상한을 둔다. 종전엔 상한이 없어
        // (a) Vec::with_capacity 가 최대 ~51GB 예약을 시도해 RawVec 오버플로
        // panic/abort, (b) read_*().unwrap_or(0) 가 EOF 를 삼켜 루프가 count
        // 만큼(최대 40억회) 0 을 채우며 도는 문제가 있었다.
        let count = (r.read_u32().unwrap_or(0) as usize).min(r.remaining() / 10);
        let mut control_points = Vec::with_capacity(count);
        for _ in 0..count {
            if r.remaining() < 10 {
                break;
            }
            let x = r.read_i32().unwrap_or(0);
            let y = r.read_i32().unwrap_or(0);
            let point_type = r.read_u16().unwrap_or(0);
            control_points.push(ConnectorControlPoint { x, y, point_type });
        }
        // 나머지 바이트 보존 (패딩 등)
        let raw_trailing = if r.remaining() > 0 {
            r.read_bytes(r.remaining()).unwrap_or_default().to_vec()
        } else {
            Vec::new()
        };
        line.connector = Some(ConnectorData {
            link_type,
            start_subject_id,
            start_subject_index,
            end_subject_id,
            end_subject_index,
            control_points,
            raw_trailing,
        });
    } else {
        // 일반 선
        // hwp5 스펙 표92: 속성 필드는 UINT16(2바이트). 선 개체 속성 전체 길이가
        // 18바이트(4+4+4+4+2)로 명시되어 있는데 기존에는 INT32(4바이트)로 읽어
        // 남은 2바이트로는 항상 실패해 unwrap_or(0)으로 값이 소실되고 있었다.
        line.started_right_or_bottom = r.read_u16().unwrap_or(0) != 0;
    }
}

/// 사각형 도형 데이터 파싱
/// hwplib: 좌표가 (x1,y1),(x2,y2),(x3,y3),(x4,y4) 인터리브 순서로 저장
fn parse_rect_shape_data(data: &[u8], rect: &mut RectangleShape) {
    let mut r = ByteReader::new(data);
    rect.round_rate = r.read_u8().unwrap_or(0);
    for i in 0..4 {
        rect.x_coords[i] = r.read_i32().unwrap_or(0);
        rect.y_coords[i] = r.read_i32().unwrap_or(0);
    }
}

/// 타원 도형 데이터 파싱 (60바이트)
fn parse_ellipse_shape_data(data: &[u8], ellipse: &mut EllipseShape) {
    let mut r = ByteReader::new(data);
    ellipse.attr = r.read_u32().unwrap_or(0);
    ellipse.center.x = r.read_i32().unwrap_or(0);
    ellipse.center.y = r.read_i32().unwrap_or(0);
    ellipse.axis1.x = r.read_i32().unwrap_or(0);
    ellipse.axis1.y = r.read_i32().unwrap_or(0);
    ellipse.axis2.x = r.read_i32().unwrap_or(0);
    ellipse.axis2.y = r.read_i32().unwrap_or(0);
    ellipse.start1.x = r.read_i32().unwrap_or(0);
    ellipse.start1.y = r.read_i32().unwrap_or(0);
    ellipse.end1.x = r.read_i32().unwrap_or(0);
    ellipse.end1.y = r.read_i32().unwrap_or(0);
    ellipse.start2.x = r.read_i32().unwrap_or(0);
    ellipse.start2.y = r.read_i32().unwrap_or(0);
    ellipse.end2.x = r.read_i32().unwrap_or(0);
    ellipse.end2.y = r.read_i32().unwrap_or(0);
}

/// 호 도형 데이터 파싱 (hwplib: UINT8 arcType + 6×INT32 좌표 = 25바이트)
fn parse_arc_shape_data(data: &[u8], arc: &mut ArcShape) {
    let mut r = ByteReader::new(data);
    arc.arc_type = r.read_u8().unwrap_or(0);
    arc.center.x = r.read_i32().unwrap_or(0);
    arc.center.y = r.read_i32().unwrap_or(0);
    arc.axis1.x = r.read_i32().unwrap_or(0);
    arc.axis1.y = r.read_i32().unwrap_or(0);
    arc.axis2.x = r.read_i32().unwrap_or(0);
    arc.axis2.y = r.read_i32().unwrap_or(0);
}

/// 다각형 도형 데이터 파싱
/// hwplib: INT32 count + (INT32 x, INT32 y) × count + skip(4)
fn parse_polygon_shape_data(data: &[u8], poly: &mut PolygonShape) {
    let mut r = ByteReader::new(data);
    let cnt_raw = r.read_i32().unwrap_or(0);
    // 점 하나는 INT32 좌표 두 개(8 bytes)다. count field가 payload보다 큰 경우
    // EOF 뒤의 0을 반복해서 push하지 않도록 실제 좌표 바이트 수로 제한한다. (#4290)
    let cnt = if cnt_raw < 0 {
        0
    } else {
        (cnt_raw as usize).min(r.remaining() / 8)
    };
    poly.points.clear();
    for _ in 0..cnt {
        let x = r.read_i32().unwrap_or(0);
        let y = r.read_i32().unwrap_or(0);
        poly.points.push(Point { x, y });
    }
    poly.raw_trailing = if r.remaining() > 0 {
        r.read_bytes(r.remaining()).unwrap_or_default().to_vec()
    } else {
        Vec::new()
    };
}

/// 곡선 도형 데이터 파싱
/// hwplib: INT32 count + (INT32 x, INT32 y) × count + BYTE[count-1] segment_types + skip(4)
fn parse_curve_shape_data(data: &[u8], curve: &mut CurveShape) {
    let mut r = ByteReader::new(data);
    // count(INT32)는 파일에서 온 부호 있는 값이다. 음수(예: -1 = 0xFFFFFFFF)를
    // 검증 없이 `as usize` 로 캐스팅하면 부호 확장으로 usize::MAX 근처의 거대한
    // 값이 되어 아래 루프가 사실상 종료되지 않는(수십억 회) DoS 를 유발한다.
    // 캐스팅 전에 음수를 0(빈 곡선)으로 처리한다. (#3012 다각형과 동일 클래스)
    let cnt_raw = r.read_i32().unwrap_or(0);
    // 점 하나는 INT32 좌표 두 개(8 bytes)다. segment/padding이 잘린 기존
    // fallback semantics는 유지하되, fabricated positive count로 무한 loop나
    // 과대 Vec allocation이 생기지 않게 좌표 바이트 수를 상한으로 쓴다. (#4290)
    let cnt = if cnt_raw < 0 {
        0
    } else {
        (cnt_raw as usize).min(r.remaining() / 8)
    };
    curve.points.clear();
    for _ in 0..cnt {
        let x = r.read_i32().unwrap_or(0);
        let y = r.read_i32().unwrap_or(0);
        curve.points.push(Point { x, y });
    }
    // 세그먼트 타입 (cnt-1개, 0=line, 1=curve)
    curve.segment_types.clear();
    if cnt > 0 {
        for _ in 0..(cnt - 1) {
            curve.segment_types.push(r.read_u8().unwrap_or(0));
        }
    }
    // hwplib: sr.skip(4) — 4바이트 패딩
    let _ = r.read_u32();
}

// ============================================================
// Task #195: 단위 테스트 (OLE/Chart 파싱)
// ============================================================

#[cfg(test)]
mod task195_tests {
    use super::*;

    #[test]
    fn line_started_right_or_bottom_parsed_from_18byte_record() {
        // hwp5 스펙 표92: 선 개체 속성은 4+4+4+4+2=18바이트이며 마지막 필드는
        // UINT16. 18바이트만 주어져도 플래그(1)가 정확히 읽혀야 한다.
        let mut data = Vec::new();
        data.extend_from_slice(&0i32.to_le_bytes()); // start.x
        data.extend_from_slice(&0i32.to_le_bytes()); // start.y
        data.extend_from_slice(&0i32.to_le_bytes()); // end.x
        data.extend_from_slice(&0i32.to_le_bytes()); // end.y
        data.extend_from_slice(&1u16.to_le_bytes()); // 속성(방향 보정 플래그)

        let mut line = LineShape::default();
        parse_line_shape_data(&data, &mut line, false);
        assert!(
            line.started_right_or_bottom,
            "18바이트 레코드에서 UINT16 플래그가 true 로 읽혀야 함"
        );
    }

    #[test]
    fn connector_control_point_count_is_bounded_by_remaining() {
        // 악의적 countCP(0xFFFFFFFF)가 (a) ~51GB Vec 예약으로 abort 하거나
        // (b) EOF 를 삼킨 채 40억회 루프를 도는 일이 없어야 한다.
        // 페이로드: link_type(4)+ssid(4)+ssidx(4)+esid(4)+esidx(4)=20, 그 뒤 countCP.
        let mut data = Vec::new();
        data.extend_from_slice(&0i32.to_le_bytes()); // start.x
        data.extend_from_slice(&0i32.to_le_bytes()); // start.y
        data.extend_from_slice(&0i32.to_le_bytes()); // end.x
        data.extend_from_slice(&0i32.to_le_bytes()); // end.y
        data.extend_from_slice(&0u32.to_le_bytes()); // link_type
        data.extend_from_slice(&0u32.to_le_bytes()); // start_subject_id
        data.extend_from_slice(&0u32.to_le_bytes()); // start_subject_index
        data.extend_from_slice(&0u32.to_le_bytes()); // end_subject_id
        data.extend_from_slice(&0u32.to_le_bytes()); // end_subject_index
        data.extend_from_slice(&0xFFFF_FFFFu32.to_le_bytes()); // countCP (악성)

        let mut line = LineShape::default();
        parse_line_shape_data(&data, &mut line, true);
        let connector = line.connector.expect("connector 파싱");
        assert!(
            connector.control_points.is_empty(),
            "남은 바이트가 없으므로 제어점은 비어야 함: {}",
            connector.control_points.len()
        );
    }

    #[test]
    fn polygon_point_count_negative_is_treated_as_zero() {
        // count(INT32)에 음수(-1 = 0xFFFFFFFF)를 넣으면 as usize 부호확장으로
        // 사실상 무한 루프에 빠지면 안 되고 빈 다각형으로 처리되어야 한다.
        let mut data = Vec::new();
        data.extend_from_slice(&(-1i32).to_le_bytes()); // count (악성)

        let mut poly = PolygonShape::default();
        parse_polygon_shape_data(&data, &mut poly);
        assert!(
            poly.points.is_empty(),
            "음수 count는 빈 점 목록으로 처리되어야 함: {}",
            poly.points.len()
        );
    }

    #[test]
    fn curve_point_count_negative_is_treated_as_zero() {
        // count(INT32)에 음수(-1 = 0xFFFFFFFF)를 넣으면 as usize 부호확장으로
        // usize::MAX 근처의 거대한 값이 되어 `for _ in 0..cnt` 및
        // `for _ in 0..(cnt - 1)` 루프가 사실상 종료되지 않는(수십억 회) DoS 를
        // 유발한다. 음수 count 는 빈 곡선으로 처리되어야 한다. (#3012 다각형과 동일 클래스)
        let mut data = Vec::new();
        data.extend_from_slice(&(-1i32).to_le_bytes()); // count (악성)

        let mut curve = CurveShape::default();
        parse_curve_shape_data(&data, &mut curve);
        assert!(
            curve.points.is_empty(),
            "음수 count는 빈 점 목록으로 처리되어야 함: {}",
            curve.points.len()
        );
        assert!(
            curve.segment_types.is_empty(),
            "음수 count는 빈 세그먼트 목록으로 처리되어야 함: {}",
            curve.segment_types.len()
        );
    }

    #[test]
    fn oversized_positive_point_counts_are_bounded_by_payload_coordinates() {
        let mut polygon_data = Vec::new();
        polygon_data.extend_from_slice(&i32::MAX.to_le_bytes());
        polygon_data.extend_from_slice(&10i32.to_le_bytes());
        polygon_data.extend_from_slice(&20i32.to_le_bytes());

        let mut polygon = PolygonShape::default();
        parse_polygon_shape_data(&polygon_data, &mut polygon);
        assert_eq!(polygon.points.len(), 1);
        assert_eq!(polygon.points[0].x, 10);
        assert_eq!(polygon.points[0].y, 20);

        let mut curve_data = Vec::new();
        curve_data.extend_from_slice(&i32::MAX.to_le_bytes());
        curve_data.extend_from_slice(&30i32.to_le_bytes());
        curve_data.extend_from_slice(&40i32.to_le_bytes());

        let mut curve = CurveShape::default();
        parse_curve_shape_data(&curve_data, &mut curve);
        assert_eq!(curve.points.len(), 1);
        assert_eq!(curve.points[0].x, 30);
        assert_eq!(curve.points[0].y, 40);
        assert!(curve.segment_types.is_empty());
    }

    #[test]
    fn test_parse_ole_shape_minimal() {
        // 1.hwp 레이아웃 실측 기반: property(4) + extent_x(4) + extent_y(4) + bin_data_id(4)
        let mut data = Vec::new();
        data.extend_from_slice(&1u32.to_le_bytes()); // property
        data.extend_from_slice(&1000i32.to_le_bytes()); // extent_x
        data.extend_from_slice(&2000i32.to_le_bytes()); // extent_y
        data.extend_from_slice(&5u32.to_le_bytes()); // bin_data_id
        data.extend_from_slice(&[0u8; 14]); // padding

        let ole = parse_ole_shape(CommonObjAttr::default(), DrawingObjAttr::default(), &data);
        assert_eq!(ole.extent_x, 1000);
        assert_eq!(ole.extent_y, 2000);
        assert_eq!(ole.bin_data_id, 5);
        assert_eq!(ole.raw_tag_data.len(), data.len());
    }

    #[test]
    fn test_parse_ole_shape_bin_id_42() {
        let mut data = Vec::new();
        data.extend_from_slice(&0u32.to_le_bytes());
        data.extend_from_slice(&0i32.to_le_bytes());
        data.extend_from_slice(&0i32.to_le_bytes());
        data.extend_from_slice(&42u32.to_le_bytes());
        let ole = parse_ole_shape(CommonObjAttr::default(), DrawingObjAttr::default(), &data);
        assert_eq!(ole.bin_data_id, 42);
    }

    #[test]
    fn test_parse_ole_shape_truncated_graceful() {
        // 4바이트만 — 나머지 필드는 기본값으로 채워져야 함
        let data = [0x10, 0x00, 0x00, 0x00]; // property=16
        let ole = parse_ole_shape(CommonObjAttr::default(), DrawingObjAttr::default(), &data);
        assert_eq!(ole.extent_x, 0);
        assert_eq!(ole.extent_y, 0);
        assert_eq!(ole.bin_data_id, 0);
        assert_eq!(ole.raw_tag_data.len(), 4);
    }
}

#[cfg(test)]
mod shape_recursion_tests {
    use super::*;

    /// `level` 증가로 표현한 N겹 중첩 그룹 레코드. SCC(level0) 뒤에 SHAPE_COMPONENT
    /// level 1..=n 을 두면 각 재귀가 한 레벨씩 파고들어 n-깊이 중첩을 만든다. data 는
    /// 비워도 parse_shape_component_full 이 기본값을 돌려주므로 안전하다.
    fn nested_group_records(n: usize) -> Vec<Record> {
        let mut records = vec![Record {
            tag_id: tags::HWPTAG_SHAPE_COMPONENT_CONTAINER,
            level: 0,
            size: 0,
            data: Vec::new(),
        }];
        for lvl in 1..=n {
            records.push(Record {
                tag_id: tags::HWPTAG_SHAPE_COMPONENT,
                level: lvl as u16,
                size: 0,
                data: Vec::new(),
            });
        }
        records
    }

    fn group_nesting_depth(shapes: &[ShapeObject]) -> usize {
        shapes
            .iter()
            .map(|s| match s {
                ShapeObject::Group(g) => 1 + group_nesting_depth(&g.children),
                _ => 0,
            })
            .max()
            .unwrap_or(0)
    }

    #[test]
    fn deep_group_nesting_is_bounded_not_overflowed() {
        // 상한을 넘는 중첩 그룹은 스택을 고갈시키기 전에 유한 트리로 절단돼야 한다.
        // 가드가 없으면 입력 깊이만큼의 트리가 만들어져(또는 스택 오버플로) depth 가
        // 상한을 넘어 이 단언이 실패한다(회귀 포착). 넉넉한 스택 전용 스레드에서
        // 경계를 빌드 프로파일과 무관하게 결정적으로 시험한다. 가드는 depth > MAX
        // 에서 절단하므로 최대 중첩은 MAX+1 이다.
        let records = nested_group_records(MAX_HWP5_SHAPE_DEPTH as usize + 100);
        let depth = std::thread::Builder::new()
            .stack_size(64 * 1024 * 1024)
            .spawn(move || group_nesting_depth(&parse_container_children(&records, 0)))
            .expect("파서 스레드 생성 실패")
            .join()
            .expect("파서 스레드 패닉");
        assert!(
            depth <= MAX_HWP5_SHAPE_DEPTH as usize + 1,
            "그룹 중첩 depth {depth} 가 상한 {MAX_HWP5_SHAPE_DEPTH}(+1) 을 넘었다 — 깊이 가드 회귀"
        );
        assert!(depth > 0, "가드가 전부 버렸다 — 과잉 절단");
    }

    #[test]
    fn shallow_group_nesting_is_preserved() {
        // 상한 안쪽의 정상 중첩은 절단 없이 보존돼야 한다(가드가 과잉 차단 안 함).
        let records = nested_group_records(8);
        let depth = group_nesting_depth(&parse_container_children(&records, 0));
        assert!(
            (1..=8).contains(&depth),
            "얕은 중첩 depth {depth} 가 예상 범위(1..=8) 밖 — 가드 과잉 절단 의심"
        );
    }
}
