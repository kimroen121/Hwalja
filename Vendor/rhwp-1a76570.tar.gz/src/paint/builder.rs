use crate::model::style::UnderlineType;
use crate::paint::font_glyph::lower_font_native_glyph_sidecars_excluding;
use crate::paint::layer_tree::{
    CacheHint, ClipKind, GroupKind, LayerNode, LayerNodeKind, LayerOutputOptions, PageLayerTree,
};
use crate::paint::paint_op::{PaintOp, TextDecorationKind};
use crate::paint::profile::RenderProfile;
use crate::paint::shaping_glyph::lower_horizontal_shaping_page_sidecars;
use crate::paint::shaping_glyph_vertical::lower_vertical_shaping_page_sidecars;
use crate::paint::EmbeddedFontFace;
use crate::renderer::render_tree::{ControlCode, PageRenderTree, RenderNode, RenderNodeType};

const TEXT_MARK_BODY_CLIP_RIGHT_PAD: f64 = 48.0;

/// semantic render tree를 visual layer tree로 내린다.
pub struct LayerBuilder {
    profile: RenderProfile,
    output_options: LayerOutputOptions,
    bin_data_epoch: u32,
}

impl LayerBuilder {
    pub fn new(profile: RenderProfile) -> Self {
        Self {
            profile,
            output_options: LayerOutputOptions::default(),
            bin_data_epoch: 0,
        }
    }

    pub fn with_output_options(mut self, output_options: LayerOutputOptions) -> Self {
        self.output_options = output_options;
        self
    }

    pub fn with_bin_data_epoch(mut self, bin_data_epoch: u32) -> Self {
        self.bin_data_epoch = bin_data_epoch;
        self
    }

    pub fn build(&mut self, tree: &PageRenderTree) -> PageLayerTree {
        self.build_with_embedded_fonts(tree, &[])
    }

    pub fn build_with_embedded_fonts(
        &mut self,
        tree: &PageRenderTree,
        fonts: &[EmbeddedFontFace<'_>],
    ) -> PageLayerTree {
        let (page_width, page_height) = match &tree.root.node_type {
            RenderNodeType::Page(page) => (page.width, page.height),
            _ => (tree.root.bbox.width, tree.root.bbox.height),
        };

        let root = LayerNode::group(
            tree.root.bbox,
            Some(tree.root.id),
            self.build_children(&tree.root),
            self.cache_hint_for(&tree.root.node_type),
            GroupKind::Generic,
        )
        .with_layer(tree.root.layer);

        let mut layer_tree =
            PageLayerTree::with_profile(page_width, page_height, root, self.profile)
                .with_output_options(self.output_options)
                .with_bin_data_epoch(self.bin_data_epoch);
        publish_line_decoration_trims(&mut layer_tree.root);
        // Vertical exact-source publication owns its leaf slots first. The
        // horizontal and nominal lowerers remain independent and only share
        // the final claim set used to suppress duplicate nominal GlyphRuns.
        let mut claimed_glyph_run_sources = lower_vertical_shaping_page_sidecars(
            &mut layer_tree.root,
            &tree.frame,
            &mut layer_tree.resources,
        );
        claimed_glyph_run_sources.extend(lower_horizontal_shaping_page_sidecars(
            &mut layer_tree.root,
            tree.frame.horizontal_shaping_sidecars(),
            &mut layer_tree.resources,
        ));
        lower_font_native_glyph_sidecars_excluding(
            &mut layer_tree.root,
            &mut layer_tree.resources,
            fonts,
            &claimed_glyph_run_sources,
        );
        layer_tree
    }

    fn build_children(&mut self, node: &RenderNode) -> Vec<LayerNode> {
        let mut children = node
            .children
            .iter()
            .filter_map(|child| self.build_node(child))
            .collect::<Vec<_>>();
        if self.output_options.show_control_codes {
            let label = match &node.node_type {
                // 그림·수식은 전용 paint 하위화 경로에서 조판부호를 생성한다.
                RenderNodeType::Image(_) | RenderNodeType::Equation(_) => None,
                _ => node.control_code_label(),
            };
            if let Some(label) = label {
                children.push(
                    LayerNode::leaf(
                        node.bbox,
                        Some(node.id),
                        vec![PaintOp::control_label(node.bbox, label)],
                    )
                    .with_layer(node.layer),
                );
            }
        }
        children
    }

    fn build_node(&mut self, node: &RenderNode) -> Option<LayerNode> {
        if !node.visible || (node.editor_only && !self.profile.shows_editor_visuals()) {
            return None;
        }
        if matches!(
            &node.node_type,
            RenderNodeType::Placeholder(placeholder)
                if placeholder.kind
                    == crate::renderer::render_tree::PlaceholderKind::MissingPicture
                    && !self.profile.shows_editor_visuals()
        ) {
            return None;
        }

        let own_ops = match &node.node_type {
            RenderNodeType::PageBackground(background) => Some(vec![PaintOp::page_background(
                node.bbox,
                background.clone(),
            )]),
            RenderNodeType::TextRun(run) => {
                Some(text_run_ops(node.bbox, run.clone(), self.output_options))
            }
            RenderNodeType::FootnoteMarker(marker) => {
                Some(vec![PaintOp::footnote_marker(node.bbox, marker.clone())])
            }
            RenderNodeType::Line(line) => Some(vec![PaintOp::line(node.bbox, line.clone())]),
            RenderNodeType::Rectangle(rect) => {
                Some(vec![PaintOp::rectangle(node.bbox, rect.clone())])
            }
            RenderNodeType::Ellipse(ellipse) => {
                Some(vec![PaintOp::ellipse(node.bbox, ellipse.clone())])
            }
            RenderNodeType::Path(path) => Some(vec![PaintOp::path(node.bbox, path.clone())]),
            RenderNodeType::Image(image) => {
                let mut ops = vec![PaintOp::image(
                    node.bbox,
                    image.clone(),
                    crate::renderer::image_resolver::resolve_image_payload(image),
                )];
                if self.output_options.show_control_codes {
                    ops.push(PaintOp::control_label(node.bbox, "[그림]"));
                }
                Some(ops)
            }
            RenderNodeType::Equation(equation) => {
                let mut ops = vec![PaintOp::equation(node.bbox, equation.clone())];
                if self.output_options.show_control_codes {
                    ops.push(PaintOp::control_label(node.bbox, "[수식]"));
                }
                Some(ops)
            }
            RenderNodeType::FormObject(form) => {
                Some(vec![PaintOp::form_object(node.bbox, form.clone())])
            }
            RenderNodeType::Placeholder(placeholder) => {
                Some(vec![PaintOp::placeholder(node.bbox, placeholder.clone())])
            }
            RenderNodeType::RawSvg(raw) => Some(vec![PaintOp::raw_svg(node.bbox, raw.clone())]),
            _ => None,
        };

        if let Some(ops) = own_ops {
            let own_leaf = LayerNode::leaf(node.bbox, Some(node.id), ops).with_layer(node.layer);
            // 내부 문단이 없는 사각형도 원본 컨트롤 부호를 출력해야 한다.
            let has_source_marker = self.output_options.show_control_codes
                && matches!(node.control_code, ControlCode::Rectangle(_));
            return if node.children.is_empty() && !has_source_marker {
                Some(own_leaf)
            } else {
                let mut children = Vec::with_capacity(node.children.len() + 1);
                children.push(own_leaf);
                children.extend(self.build_children(node));
                Some(
                    LayerNode::group(
                        node.bbox,
                        Some(node.id),
                        children,
                        self.cache_hint_for(&node.node_type),
                        self.group_kind_for(&node.node_type),
                    )
                    .with_layer(node.layer),
                )
            };
        }

        match &node.node_type {
            RenderNodeType::Body {
                clip_rect: Some(clip),
            } => {
                let effective_clip = if self.output_options.show_paragraph_marks
                    || self.output_options.show_control_codes
                {
                    crate::renderer::render_tree::BoundingBox::new(
                        clip.x,
                        clip.y,
                        clip.width + TEXT_MARK_BODY_CLIP_RIGHT_PAD,
                        clip.height,
                    )
                } else {
                    *clip
                };
                let child = LayerNode::group(
                    node.bbox,
                    Some(node.id),
                    self.build_children(node),
                    self.cache_hint_for(&node.node_type),
                    GroupKind::Body,
                );
                Some(
                    LayerNode::clip_rect(
                        node.bbox,
                        Some(node.id),
                        effective_clip,
                        child,
                        ClipKind::Body,
                    )
                    .with_layer(node.layer),
                )
            }
            RenderNodeType::TableCell(cell) if cell.clip => {
                let child = LayerNode::group(
                    node.bbox,
                    Some(node.id),
                    self.build_children(node),
                    self.cache_hint_for(&node.node_type),
                    GroupKind::TableCell(cell.clone()),
                );
                Some(
                    LayerNode::clip_rect(
                        node.bbox,
                        Some(node.id),
                        node.bbox,
                        child,
                        ClipKind::TableCell,
                    )
                    .with_layer(node.layer),
                )
            }
            RenderNodeType::TextBox => {
                let child = LayerNode::group(
                    node.bbox,
                    Some(node.id),
                    self.build_children(node),
                    self.cache_hint_for(&node.node_type),
                    GroupKind::TextBox,
                );
                Some(
                    LayerNode::clip_rect(
                        node.bbox,
                        Some(node.id),
                        node.bbox,
                        child,
                        ClipKind::TextBox,
                    )
                    .with_layer(node.layer),
                )
            }
            _ => Some(
                LayerNode::group(
                    node.bbox,
                    Some(node.id),
                    self.build_children(node),
                    self.cache_hint_for(&node.node_type),
                    self.group_kind_for(&node.node_type),
                )
                .with_layer(node.layer),
            ),
        }
    }

    fn cache_hint_for(&self, node_type: &RenderNodeType) -> CacheHint {
        match node_type {
            RenderNodeType::Header | RenderNodeType::Footer | RenderNodeType::MasterPage => {
                CacheHint::StaticSubtree
            }
            RenderNodeType::PageBackground(_)
                if matches!(self.profile, RenderProfile::FastPreview) =>
            {
                CacheHint::PreferRaster
            }
            _ => CacheHint::None,
        }
    }

    fn group_kind_for(&self, node_type: &RenderNodeType) -> GroupKind {
        match node_type {
            RenderNodeType::MasterPage => GroupKind::MasterPage,
            RenderNodeType::Header => GroupKind::Header,
            RenderNodeType::Footer => GroupKind::Footer,
            RenderNodeType::Body { .. } => GroupKind::Body,
            RenderNodeType::Column(index) => GroupKind::Column(*index),
            RenderNodeType::FootnoteArea => GroupKind::FootnoteArea,
            RenderNodeType::TextLine(line) => GroupKind::TextLine(line.clone()),
            RenderNodeType::Table(table) => GroupKind::Table(table.clone()),
            RenderNodeType::TableCell(cell) => GroupKind::TableCell(cell.clone()),
            RenderNodeType::TextBox => GroupKind::TextBox,
            RenderNodeType::Group(group) => GroupKind::Group(group.clone()),
            _ => GroupKind::Generic,
        }
    }
}

fn line_decoration_trim_target(
    children: &[LayerNode],
) -> Option<(crate::paint::TextSourceSpan, usize)> {
    fn scan(node: &LayerNode, found: &mut Option<Option<(crate::paint::TextSourceSpan, usize)>>) {
        if found.is_some() {
            return;
        }
        match &node.kind {
            LayerNodeKind::Leaf { ops } => {
                for op in ops.iter().rev() {
                    if let PaintOp::TextRun {
                        run,
                        source: Some(source),
                        ..
                    } = op
                    {
                        if run.text.chars().any(|ch| ch != ' ') {
                            if run.is_para_end || run.is_line_break_end {
                                *found = Some(None);
                                return;
                            }
                            let trailing =
                                run.text.chars().rev().take_while(|ch| *ch == ' ').count();
                            *found = Some((trailing > 0).then_some((source.clone(), trailing)));
                            return;
                        }
                    }
                }
            }
            LayerNodeKind::Group { children, .. } => {
                for child in children.iter().rev() {
                    scan(child, found);
                    if found.is_some() {
                        return;
                    }
                }
            }
            LayerNodeKind::ClipRect { child, .. } => scan(child, found),
        }
    }
    let mut found = None;
    for child in children.iter().rev() {
        scan(child, &mut found);
        if found.is_some() {
            break;
        }
    }
    found.flatten()
}

fn publish_line_decoration_trims(node: &mut LayerNode) {
    if let LayerNodeKind::Group {
        children,
        group_kind: GroupKind::TextLine(_),
        ..
    } = &mut node.kind
    {
        if let Some((source, trim)) = line_decoration_trim_target(children) {
            set_decoration_trim_for_source(children, &source, trim);
        }
    }
    match &mut node.kind {
        LayerNodeKind::Group { children, .. } => {
            for child in children {
                publish_line_decoration_trims(child);
            }
        }
        LayerNodeKind::ClipRect { child, .. } => publish_line_decoration_trims(child),
        LayerNodeKind::Leaf { .. } => {}
    }
}

fn set_decoration_trim_for_source(
    nodes: &mut [LayerNode],
    source: &crate::paint::TextSourceSpan,
    trim: usize,
) {
    for node in nodes {
        match &mut node.kind {
            LayerNodeKind::Group { children, .. } => {
                set_decoration_trim_for_source(children, source, trim);
            }
            LayerNodeKind::ClipRect { child, .. } => {
                set_decoration_trim_for_source(std::slice::from_mut(child), source, trim);
            }
            LayerNodeKind::Leaf { ops } => {
                for op in ops {
                    if let PaintOp::TextDecoration {
                        source: Some(candidate),
                        trim_trailing_spaces,
                        ..
                    } = op
                    {
                        if candidate == source {
                            *trim_trailing_spaces = trim;
                        }
                    }
                }
            }
        }
    }
}

fn text_run_ops(
    bbox: crate::renderer::render_tree::BoundingBox,
    run: crate::renderer::render_tree::TextRunNode,
    output_options: LayerOutputOptions,
) -> Vec<PaintOp> {
    let has_char_overlap = run.char_overlap.is_some();
    let show_text_marks = output_options.show_paragraph_marks || output_options.show_control_codes;
    let has_control_mark = show_text_marks
        && (run.is_para_end
            || run.is_line_break_end
            || run.text.chars().any(|ch| matches!(ch, ' ' | '\t')));
    // Legacy renderers bypass normal text decoration/leader paint for overlap runs.
    let has_tab_leader = !has_char_overlap && !run.style.tab_leaders.is_empty();
    let has_underline = !has_char_overlap && run.style.underline != UnderlineType::None;
    let has_strikethrough = !has_char_overlap && run.style.strikethrough;
    let has_emphasis_dot = !has_char_overlap && run.style.emphasis_dot > 0;

    let mut ops = Vec::with_capacity(
        1 + has_char_overlap as usize
            + has_control_mark as usize
            + has_tab_leader as usize
            + has_underline as usize
            + has_strikethrough as usize
            + has_emphasis_dot as usize,
    );
    ops.push(PaintOp::text_run(bbox, run.clone()));
    if has_char_overlap {
        ops.push(PaintOp::char_overlap(bbox, run.clone()));
    }
    if has_control_mark {
        ops.push(PaintOp::text_control_mark(bbox, run.clone()));
    }
    if has_tab_leader {
        ops.push(PaintOp::tab_leader(bbox, run.clone()));
    }
    if has_underline {
        ops.push(PaintOp::text_decoration(
            bbox,
            run.clone(),
            TextDecorationKind::Underline,
        ));
    }
    if has_strikethrough {
        ops.push(PaintOp::text_decoration(
            bbox,
            run.clone(),
            TextDecorationKind::Strikethrough,
        ));
    }
    if has_emphasis_dot {
        ops.push(PaintOp::text_decoration(
            bbox,
            run,
            TextDecorationKind::EmphasisDot,
        ));
    }
    ops
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::control::FormType;
    use crate::model::shape::TextWrap;
    use crate::renderer::composer::CharOverlapInfo;
    use crate::renderer::equation::layout::{LayoutBox, LayoutKind};
    use crate::renderer::render_tree::{
        BoundingBox, EllipseNode, EquationNode, FieldMarkerType, FootnoteMarkerNode,
        FormObjectNode, ImageNode, LineNode, PageBackgroundNode, PageNode, PathNode,
        PlaceholderNode, RawSvgNode, RectangleNode, RenderLayerInfo, RenderNode, RenderNodeType,
        TableCellNode, TableNode, TextLineNode, TextRunNode,
    };
    use crate::renderer::{LineStyle, PathCommand, ShapeStyle, TabLeaderInfo, TextStyle};

    #[test]
    fn builds_body_clip_layer() {
        let mut tree = PageRenderTree::new(0, 800.0, 600.0);
        tree.root.node_type = RenderNodeType::Page(PageNode {
            page_index: 0,
            width: 800.0,
            height: 600.0,
            section_index: 0,
        });
        let body = RenderNode::new(
            1,
            RenderNodeType::Body {
                clip_rect: Some(BoundingBox::new(10.0, 20.0, 300.0, 400.0)),
            },
            BoundingBox::new(10.0, 20.0, 300.0, 400.0),
        );
        tree.root.children.push(body);

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);

        assert_eq!(layer_tree.page_width, 800.0);
        match &layer_tree.root.kind {
            LayerNodeKind::Group { children, .. } => {
                assert_eq!(children.len(), 1);
                match &children[0].kind {
                    LayerNodeKind::ClipRect {
                        clip, clip_kind, ..
                    } => {
                        assert_eq!(clip.x, 10.0);
                        assert_eq!(*clip_kind, ClipKind::Body);
                    }
                    other => panic!("expected clip rect, got {other:?}"),
                }
            }
            other => panic!("expected root group, got {other:?}"),
        }
    }

    #[test]
    fn normal_builder_export_keeps_text_fallback_and_font_native_sidecar_resources() {
        let bbox = BoundingBox::new(10.0, 20.0, 16.0, 16.0);
        let mut run = text_run("\u{E100}");
        run.char_shape_id = Some(2);
        run.style.font_size = 16.0;
        run.baseline = 12.0;
        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        tree.root
            .children
            .push(RenderNode::new(1, RenderNodeType::TextRun(run), bbox));
        let font = include_bytes!("../../tests/fixtures/fonts/RHWPBitmapSvgGlyphSmoke.ttf");
        let mut builder = LayerBuilder::new(RenderProfile::Screen);

        let layer_tree = builder.build_with_embedded_fonts(
            &tree,
            &[EmbeddedFontFace {
                char_shape_id: 2,
                language_index: 0,
                family: "RHWP Bitmap SVG Glyph Smoke",
                alternate_family: None,
                bytes: font,
                face_index: 0,
            }],
        );

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let LayerNodeKind::Leaf { ops } = &children[0].kind else {
            panic!("expected text leaf");
        };
        assert!(matches!(
            ops.as_slice(),
            [
                PaintOp::TextRun { .. },
                PaintOp::GlyphRun { .. },
                PaintOp::GlyphOutline { .. }
            ]
        ));
        assert_eq!(layer_tree.resources.image_count(), 1);
        assert_eq!(layer_tree.resources.font_blob_count(), 1);
        assert_eq!(layer_tree.resources.font_resources().blobs.len(), 1);
        assert_eq!(layer_tree.resources.font_resources().faces.len(), 1);
    }

    #[test]
    fn builder_keeps_oversized_compact_image_unresolved() {
        let mut bmp = vec![0u8; 58];
        bmp[..2].copy_from_slice(b"BM");
        bmp[2..6].copy_from_slice(&58u32.to_le_bytes());
        bmp[10..14].copy_from_slice(&54u32.to_le_bytes());
        bmp[14..18].copy_from_slice(&40u32.to_le_bytes());
        bmp[18..22].copy_from_slice(&8193i32.to_le_bytes());
        bmp[22..26].copy_from_slice(&8193i32.to_le_bytes());
        bmp[26..28].copy_from_slice(&1u16.to_le_bytes());
        bmp[28..30].copy_from_slice(&8u16.to_le_bytes());
        bmp[30..34].copy_from_slice(&1u32.to_le_bytes());
        bmp[54..58].copy_from_slice(&[0, 1, 0, 1]);
        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        tree.root.children.push(RenderNode::new(
            1,
            RenderNodeType::Image(ImageNode::new(1, Some(bmp))),
            BoundingBox::new(0.0, 0.0, 10.0, 10.0),
        ));

        let layer_tree = LayerBuilder::new(RenderProfile::Screen).build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let LayerNodeKind::Leaf { ops } = &children[0].kind else {
            panic!("expected image leaf");
        };
        assert!(matches!(
            ops.as_slice(),
            [PaintOp::Image { resolved: None, .. }]
        ));
    }

    #[test]
    fn copies_render_layer_metadata_to_layer_node() {
        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        let layer = RenderLayerInfo::new(Some(TextWrap::BehindText), 7, 42);
        let table = RenderNode::new(
            1,
            RenderNodeType::Table(TableNode {
                row_count: 1,
                col_count: 1,
                border_fill_id: 0,
                section_index: Some(0),
                para_index: Some(0),
                control_index: Some(0),
                cell_context: None,
            }),
            BoundingBox::new(0.0, 0.0, 10.0, 10.0),
        )
        .with_layer(layer);
        tree.root.children.push(table);

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);
        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let copied = children[0].layer.expect("table layer copied");

        assert_eq!(copied.text_wrap, Some(TextWrap::BehindText));
        assert_eq!(copied.z_order, 7);
        assert_eq!(copied.stable_index, 42);
    }

    #[test]
    fn builds_textbox_clip_layer() {
        let mut tree = PageRenderTree::new(0, 800.0, 600.0);
        let mut textbox = RenderNode::new(
            7,
            RenderNodeType::TextBox,
            BoundingBox::new(50.0, 80.0, 240.0, 120.0),
        );
        textbox.children.push(RenderNode::new(
            8,
            RenderNodeType::TextRun(text_run("글상자")),
            BoundingBox::new(60.0, 90.0, 60.0, 20.0),
        ));
        tree.root.children.push(textbox);

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        assert_eq!(children.len(), 1);

        let LayerNodeKind::ClipRect {
            clip,
            clip_kind,
            child,
        } = &children[0].kind
        else {
            panic!("expected textbox clip");
        };
        assert_eq!(*clip_kind, ClipKind::TextBox);
        assert_eq!(clip.x, 50.0);
        assert_eq!(clip.y, 80.0);
        assert_eq!(clip.width, 240.0);
        assert_eq!(clip.height, 120.0);

        let LayerNodeKind::Group {
            group_kind,
            children: textbox_children,
            ..
        } = &child.kind
        else {
            panic!("expected clipped textbox group");
        };
        assert!(matches!(group_kind, GroupKind::TextBox));
        assert!(matches!(
            &textbox_children[0].kind,
            LayerNodeKind::Leaf { .. }
        ));
    }

    #[test]
    fn preserves_leaf_payloads() {
        let mut tree = PageRenderTree::new(0, 800.0, 600.0);
        tree.root.children.push(RenderNode::new(
            1,
            RenderNodeType::PageBackground(PageBackgroundNode {
                background_color: Some(0x00FFFFFF),
                border_color: None,
                border_width: 0.0,
                gradient: None,
                image: None,
            }),
            BoundingBox::new(0.0, 0.0, 800.0, 600.0),
        ));
        tree.root.children.push(RenderNode::new(
            2,
            RenderNodeType::TableCell(TableCellNode {
                col: 0,
                row: 0,
                col_span: 1,
                row_span: 1,
                border_fill_id: 0,
                text_direction: 0,
                clip: true,
                page_fragment: false,
                model_cell_index: None,
            }),
            BoundingBox::new(100.0, 200.0, 150.0, 80.0),
        ));

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);

        match &layer_tree.root.kind {
            LayerNodeKind::Group { children, .. } => {
                assert_eq!(children.len(), 2);
                match &children[0].kind {
                    LayerNodeKind::Leaf { ops } => {
                        assert!(matches!(ops[0], PaintOp::PageBackground { .. }));
                    }
                    other => panic!("expected leaf, got {other:?}"),
                }
                match &children[1].kind {
                    LayerNodeKind::ClipRect { clip_kind, .. } => {
                        assert_eq!(*clip_kind, ClipKind::TableCell);
                    }
                    other => panic!("expected clip rect, got {other:?}"),
                }
            }
            other => panic!("expected root group, got {other:?}"),
        }
    }

    #[test]
    fn lowers_all_leaf_variants_to_explicit_paint_ops() {
        let cases: Vec<(RenderNodeType, fn(&PaintOp) -> bool, &'static str)> = vec![
            (
                RenderNodeType::PageBackground(PageBackgroundNode {
                    background_color: Some(0x00FFFFFF),
                    border_color: None,
                    border_width: 0.0,
                    gradient: None,
                    image: None,
                }),
                |op| matches!(op, PaintOp::PageBackground { .. }),
                "PageBackground",
            ),
            (
                RenderNodeType::TextRun(text_run("leaf")),
                |op| matches!(op, PaintOp::TextRun { .. }),
                "TextRun",
            ),
            (
                RenderNodeType::FootnoteMarker(FootnoteMarkerNode {
                    number: 1,
                    text: "1)".to_string(),
                    base_font_size: 12.0,
                    font_family: "serif".to_string(),
                    color: 0x00000000,
                    section_index: 0,
                    para_index: 0,
                    control_index: 0,
                }),
                |op| matches!(op, PaintOp::FootnoteMarker { .. }),
                "FootnoteMarker",
            ),
            (
                RenderNodeType::Line(LineNode::new(0.0, 0.0, 12.0, 0.0, LineStyle::default())),
                |op| matches!(op, PaintOp::Line { .. }),
                "Line",
            ),
            (
                RenderNodeType::Rectangle(RectangleNode::new(0.0, ShapeStyle::default(), None)),
                |op| matches!(op, PaintOp::Rectangle { .. }),
                "Rectangle",
            ),
            (
                RenderNodeType::Ellipse(EllipseNode::new(ShapeStyle::default(), None)),
                |op| matches!(op, PaintOp::Ellipse { .. }),
                "Ellipse",
            ),
            (
                RenderNodeType::Path(PathNode::new(
                    vec![PathCommand::MoveTo(0.0, 0.0), PathCommand::LineTo(8.0, 4.0)],
                    ShapeStyle::default(),
                    None,
                )),
                |op| matches!(op, PaintOp::Path { .. }),
                "Path",
            ),
            (
                RenderNodeType::Image(ImageNode::new(1, Some(vec![0x89, b'P', b'N', b'G']))),
                |op| matches!(op, PaintOp::Image { .. }),
                "Image",
            ),
            (
                RenderNodeType::Equation(equation_node()),
                |op| matches!(op, PaintOp::Equation { .. }),
                "Equation",
            ),
            (
                RenderNodeType::FormObject(form_object_node()),
                |op| matches!(op, PaintOp::FormObject { .. }),
                "FormObject",
            ),
            (
                RenderNodeType::Placeholder(PlaceholderNode::new(
                    0x00F0F0F0,
                    0x00000000,
                    "OLE".to_string(),
                )),
                |op| matches!(op, PaintOp::Placeholder { .. }),
                "Placeholder",
            ),
            (
                RenderNodeType::RawSvg(RawSvgNode::new(
                    "<g><path d=\"M0 0L1 1\"/></g>".to_string(),
                )),
                |op| matches!(op, PaintOp::RawSvg { .. }),
                "RawSvg",
            ),
        ];

        for (idx, (node_type, is_expected_op, label)) in cases.into_iter().enumerate() {
            let mut tree = PageRenderTree::new(0, 100.0, 100.0);
            tree.root.children.push(RenderNode::new(
                100 + idx as u32,
                node_type,
                BoundingBox::new(1.0, 2.0, 30.0, 20.0),
            ));

            let mut builder = LayerBuilder::new(RenderProfile::Screen);
            let layer_tree = builder.build(&tree);

            let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
                panic!("expected root group for {label}");
            };
            let LayerNodeKind::Leaf { ops } = &children[0].kind else {
                panic!("expected leaf for {label}, got {:?}", children[0].kind);
            };
            assert_eq!(ops.len(), 1, "{label} should lower to one paint op");
            assert!(is_expected_op(&ops[0]), "{label} lowered to {:?}", ops[0]);
        }
    }

    #[test]
    fn preserves_leaf_node_children_after_own_paint_op() {
        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        let mut form = RenderNode::new(
            1,
            RenderNodeType::FormObject(form_object_node()),
            BoundingBox::new(10.0, 10.0, 60.0, 24.0),
        );
        form.children.push(RenderNode::new(
            2,
            RenderNodeType::TextRun(text_run("label")),
            BoundingBox::new(14.0, 14.0, 40.0, 16.0),
        ));
        tree.root.children.push(form);

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let LayerNodeKind::Group {
            children: form_children,
            ..
        } = &children[0].kind
        else {
            panic!("expected form node with children to lower to a group");
        };
        assert_eq!(form_children.len(), 2);

        let LayerNodeKind::Leaf { ops: form_ops } = &form_children[0].kind else {
            panic!("expected own form paint op first");
        };
        assert!(matches!(form_ops[0], PaintOp::FormObject { .. }));

        let LayerNodeKind::Leaf { ops: label_ops } = &form_children[1].kind else {
            panic!("expected child text paint op second");
        };
        assert!(matches!(label_ops[0], PaintOp::TextRun { .. }));
    }

    #[test]
    fn lowers_text_special_visuals_to_external_paint_ops() {
        let mut run = text_run("special\ttext");
        run.field_marker = FieldMarkerType::FieldBegin;
        run.is_para_end = true;
        run.style.tab_leaders.push(TabLeaderInfo {
            start_x: 12.0,
            end_x: 36.0,
            fill_type: 3,
        });
        run.style.underline = UnderlineType::Bottom;
        run.style.strikethrough = true;
        run.style.emphasis_dot = 2;

        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        tree.root.children.push(RenderNode::new(
            1,
            RenderNodeType::TextRun(run),
            BoundingBox::new(1.0, 2.0, 80.0, 20.0),
        ));

        let mut builder =
            LayerBuilder::new(RenderProfile::Screen).with_output_options(LayerOutputOptions {
                show_paragraph_marks: true,
                show_control_codes: true,
                ..Default::default()
            });
        let layer_tree = builder.build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let LayerNodeKind::Leaf { ops } = &children[0].kind else {
            panic!("expected text leaf");
        };

        assert!(matches!(ops[0], PaintOp::TextRun { .. }));
        assert!(!ops
            .iter()
            .any(|op| matches!(op, PaintOp::CharOverlap { .. })));
        assert!(ops
            .iter()
            .any(|op| matches!(op, PaintOp::TextControlMark { .. })));
        assert!(ops.iter().any(|op| matches!(op, PaintOp::TabLeader { .. })));
        assert!(ops.iter().any(|op| matches!(
            op,
            PaintOp::TextDecoration {
                kind: TextDecorationKind::Underline,
                ..
            }
        )));
        assert!(ops.iter().any(|op| matches!(
            op,
            PaintOp::TextDecoration {
                kind: TextDecorationKind::Strikethrough,
                ..
            }
        )));
        assert!(ops.iter().any(|op| matches!(
            op,
            PaintOp::TextDecoration {
                kind: TextDecorationKind::EmphasisDot,
                ..
            }
        )));
    }

    #[test]
    fn lowers_space_and_tab_control_marks_without_an_end_marker() {
        let run = text_run("space\tmark");
        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        tree.root.children.push(RenderNode::new(
            1,
            RenderNodeType::TextRun(run),
            BoundingBox::new(1.0, 2.0, 80.0, 20.0),
        ));

        let mut builder =
            LayerBuilder::new(RenderProfile::Screen).with_output_options(LayerOutputOptions {
                show_control_codes: true,
                ..Default::default()
            });
        let layer_tree = builder.build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        let LayerNodeKind::Leaf { ops } = &children[0].kind else {
            panic!("expected text leaf");
        };
        assert!(ops
            .iter()
            .any(|op| matches!(op, PaintOp::TextControlMark { .. })));
    }

    #[test]
    fn either_view_option_preserves_legacy_text_mark_union_semantics() {
        let mut paragraph_run = text_run("plain");
        paragraph_run.is_para_end = true;
        let paragraph_ops = text_run_ops(
            BoundingBox::new(0.0, 0.0, 40.0, 10.0),
            paragraph_run,
            LayerOutputOptions {
                show_control_codes: true,
                ..Default::default()
            },
        );
        assert!(paragraph_ops
            .iter()
            .any(|op| matches!(op, PaintOp::TextControlMark { .. })));

        let space_ops = text_run_ops(
            BoundingBox::new(0.0, 0.0, 40.0, 10.0),
            text_run("a b"),
            LayerOutputOptions {
                show_paragraph_marks: true,
                ..Default::default()
            },
        );
        assert!(space_ops
            .iter()
            .any(|op| matches!(op, PaintOp::TextControlMark { .. })));
    }

    #[test]
    fn overlap_runs_do_not_gain_normal_text_decorations_or_tab_leaders() {
        let mut run = text_run("overlap");
        run.char_overlap = Some(CharOverlapInfo {
            border_type: 1,
            inner_char_size: 90,
        });
        run.style.tab_leaders.push(TabLeaderInfo {
            start_x: 2.0,
            end_x: 20.0,
            fill_type: 1,
        });
        run.style.underline = UnderlineType::Bottom;
        run.style.strikethrough = true;
        run.style.emphasis_dot = 1;

        let ops = text_run_ops(
            BoundingBox::new(0.0, 0.0, 40.0, 10.0),
            run,
            LayerOutputOptions::default(),
        );

        assert!(ops
            .iter()
            .any(|op| matches!(op, PaintOp::CharOverlap { .. })));
        assert!(!ops.iter().any(|op| matches!(op, PaintOp::TabLeader { .. })));
        assert!(!ops
            .iter()
            .any(|op| matches!(op, PaintOp::TextDecoration { .. })));
    }

    #[test]
    fn excludes_editor_only_nodes_from_print_profile() {
        let editor_line = RenderNode::new(
            1,
            RenderNodeType::Line(crate::renderer::render_tree::LineNode::new(
                0.0,
                0.0,
                20.0,
                0.0,
                crate::renderer::LineStyle::default(),
            )),
            BoundingBox::new(0.0, 0.0, 20.0, 1.0),
        )
        .with_editor_only();

        let mut tree = PageRenderTree::new(0, 100.0, 100.0);
        tree.root.children.push(editor_line);

        let screen = LayerBuilder::new(RenderProfile::Screen).build(&tree);
        let print = LayerBuilder::new(RenderProfile::Print).build(&tree);

        let LayerNodeKind::Group {
            children: screen_children,
            ..
        } = &screen.root.kind
        else {
            panic!("expected screen root group");
        };
        let LayerNodeKind::Group {
            children: print_children,
            ..
        } = &print.root.kind
        else {
            panic!("expected print root group");
        };

        assert_eq!(screen_children.len(), 1);
        assert!(print_children.is_empty());
    }

    #[test]
    fn preserves_structural_groups_and_clips_for_backend_replay() {
        let mut tree = PageRenderTree::new(0, 800.0, 600.0);
        tree.root.node_type = RenderNodeType::Page(PageNode {
            page_index: 0,
            width: 800.0,
            height: 600.0,
            section_index: 0,
        });

        let mut header = RenderNode::new(
            1,
            RenderNodeType::Header,
            BoundingBox::new(0.0, 0.0, 800.0, 80.0),
        );
        let mut header_line = RenderNode::new(
            2,
            RenderNodeType::TextLine(TextLineNode::with_para_vpos(20.0, 15.0, 0, 0, 0, 120)),
            BoundingBox::new(40.0, 20.0, 200.0, 20.0),
        );
        header_line.children.push(RenderNode::new(
            3,
            RenderNodeType::TextRun(text_run("머리말")),
            BoundingBox::new(40.0, 20.0, 60.0, 20.0),
        ));
        header.children.push(header_line);

        let footer = RenderNode::new(
            4,
            RenderNodeType::Footer,
            BoundingBox::new(0.0, 540.0, 800.0, 60.0),
        );

        let body_clip = BoundingBox::new(40.0, 90.0, 720.0, 420.0);
        let mut body = RenderNode::new(
            5,
            RenderNodeType::Body {
                clip_rect: Some(body_clip),
            },
            body_clip,
        );
        let mut column = RenderNode::new(
            6,
            RenderNodeType::Column(1),
            BoundingBox::new(40.0, 90.0, 340.0, 420.0),
        );
        let mut table = RenderNode::new(
            7,
            RenderNodeType::Table(TableNode {
                row_count: 1,
                col_count: 1,
                border_fill_id: 2,
                section_index: Some(0),
                para_index: Some(2),
                control_index: Some(0),
                cell_context: None,
            }),
            BoundingBox::new(60.0, 110.0, 180.0, 80.0),
        );
        let mut clipped_cell = RenderNode::new(
            8,
            RenderNodeType::TableCell(TableCellNode {
                col: 0,
                row: 0,
                col_span: 1,
                row_span: 1,
                border_fill_id: 3,
                text_direction: 0,
                clip: true,
                page_fragment: false,
                model_cell_index: Some(4),
            }),
            BoundingBox::new(60.0, 110.0, 180.0, 80.0),
        );
        let mut nested_table = RenderNode::new(
            9,
            RenderNodeType::Table(TableNode {
                row_count: 1,
                col_count: 1,
                border_fill_id: 5,
                section_index: Some(0),
                para_index: Some(2),
                control_index: Some(1),
                cell_context: None,
            }),
            BoundingBox::new(70.0, 120.0, 80.0, 40.0),
        );
        nested_table.children.push(RenderNode::new(
            10,
            RenderNodeType::TableCell(TableCellNode {
                col: 0,
                row: 0,
                col_span: 1,
                row_span: 1,
                border_fill_id: 6,
                text_direction: 0,
                clip: false,
                page_fragment: false,
                model_cell_index: None,
            }),
            BoundingBox::new(70.0, 120.0, 80.0, 40.0),
        ));
        clipped_cell.children.push(nested_table);
        table.children.push(clipped_cell);
        column.children.push(table);
        body.children.push(column);

        tree.root.children.push(header);
        tree.root.children.push(footer);
        tree.root.children.push(body);

        let mut builder = LayerBuilder::new(RenderProfile::Screen);
        let layer_tree = builder.build(&tree);

        let LayerNodeKind::Group { children, .. } = &layer_tree.root.kind else {
            panic!("expected root group");
        };
        assert_eq!(children.len(), 3);

        let LayerNodeKind::Group {
            group_kind,
            cache_hint,
            children: header_children,
        } = &children[0].kind
        else {
            panic!("expected header group");
        };
        assert!(matches!(group_kind, GroupKind::Header));
        assert_eq!(*cache_hint, CacheHint::StaticSubtree);
        let LayerNodeKind::Group {
            group_kind,
            children: line_children,
            ..
        } = &header_children[0].kind
        else {
            panic!("expected text line group");
        };
        match group_kind {
            GroupKind::TextLine(line) => {
                assert_eq!(line.para_index, Some(0));
                assert_eq!(line.vpos, Some(120));
            }
            other => panic!("expected text line group kind, got {other:?}"),
        }
        assert!(matches!(&line_children[0].kind, LayerNodeKind::Leaf { .. }));

        let LayerNodeKind::Group {
            group_kind,
            cache_hint,
            ..
        } = &children[1].kind
        else {
            panic!("expected footer group");
        };
        assert!(matches!(group_kind, GroupKind::Footer));
        assert_eq!(*cache_hint, CacheHint::StaticSubtree);

        let LayerNodeKind::ClipRect {
            clip,
            clip_kind,
            child,
        } = &children[2].kind
        else {
            panic!("expected body clip");
        };
        assert_eq!(clip.x, body_clip.x);
        assert_eq!(clip.y, body_clip.y);
        assert_eq!(clip.width, body_clip.width);
        assert_eq!(clip.height, body_clip.height);
        assert_eq!(*clip_kind, ClipKind::Body);

        let LayerNodeKind::Group {
            group_kind,
            children: body_children,
            ..
        } = &child.kind
        else {
            panic!("expected clipped body group");
        };
        assert!(matches!(group_kind, GroupKind::Body));

        let LayerNodeKind::Group {
            group_kind,
            children: column_children,
            ..
        } = &body_children[0].kind
        else {
            panic!("expected column group");
        };
        assert!(matches!(group_kind, GroupKind::Column(1)));

        let LayerNodeKind::Group {
            group_kind,
            children: table_children,
            ..
        } = &column_children[0].kind
        else {
            panic!("expected table group");
        };
        match group_kind {
            GroupKind::Table(table) => {
                assert_eq!(table.row_count, 1);
                assert_eq!(table.col_count, 1);
                assert_eq!(table.control_index, Some(0));
            }
            other => panic!("expected table group kind, got {other:?}"),
        }

        let LayerNodeKind::ClipRect {
            clip_kind, child, ..
        } = &table_children[0].kind
        else {
            panic!("expected table cell clip");
        };
        assert_eq!(*clip_kind, ClipKind::TableCell);

        let LayerNodeKind::Group {
            group_kind,
            children: cell_children,
            ..
        } = &child.kind
        else {
            panic!("expected clipped table cell group");
        };
        match group_kind {
            GroupKind::TableCell(cell) => {
                assert!(cell.clip);
                assert_eq!(cell.model_cell_index, Some(4));
            }
            other => panic!("expected table cell group kind, got {other:?}"),
        }
        assert!(matches!(
            &cell_children[0].kind,
            LayerNodeKind::Group {
                group_kind: GroupKind::Table(_),
                ..
            }
        ));
    }

    fn text_run(text: &str) -> TextRunNode {
        TextRunNode {
            text: text.to_string(),
            style: TextStyle::default(),
            char_shape_id: None,
            para_shape_id: None,
            section_index: None,
            para_index: None,
            char_start: None,
            cell_context: None,
            is_para_end: false,
            is_line_break_end: false,
            rotation: 0.0,
            is_vertical: false,
            char_overlap: None,
            border_fill_id: 0,
            baseline: 12.0,
            field_marker: Default::default(),
            layout_positions: None,
            display_text: None,
        }
    }

    fn equation_node() -> EquationNode {
        EquationNode {
            svg_content: "<text>x</text>".to_string(),
            layout_box: LayoutBox {
                x: 0.0,
                y: 0.0,
                width: 8.0,
                height: 12.0,
                baseline: 10.0,
                kind: LayoutKind::Text("x".to_string()),
            },
            color_str: "#000000".to_string(),
            color: 0x00000000,
            font_size: 12.0,
            script: String::new(),
            section_index: None,
            para_index: None,
            control_index: None,
            cell_index: None,
            cell_para_index: None,
            note_ref: None,
        }
    }

    fn form_object_node() -> FormObjectNode {
        FormObjectNode {
            form_type: FormType::PushButton,
            caption: "OK".to_string(),
            text: String::new(),
            display_text: None,
            appearance: Default::default(),
            fore_color: "#000000".to_string(),
            back_color: "#ffffff".to_string(),
            value: 0,
            enabled: true,
            section_index: 0,
            para_index: 0,
            control_index: 0,
            name: "button".to_string(),
            cell_location: None,
        }
    }
}
