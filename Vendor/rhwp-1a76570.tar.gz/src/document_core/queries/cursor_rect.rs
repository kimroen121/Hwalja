//! 커서 좌표/히트테스트/셀 커서/경로 기반 조작 관련 native 메서드

use super::super::helpers::{
    find_char_at_x, find_logical_control_positions, is_treat_as_char_object_control,
    navigable_text_len, LineInfoResult,
};
use crate::document_core::{header_footer_apply_to_u8, DocumentCore};
use crate::error::HwpError;
use crate::model::control::Control;
use crate::model::paragraph::Paragraph;
use crate::renderer::layout::{CellContext, CellPathEntry};
use crate::renderer::render_tree::TextRunNode;

/// 묶음 개체(GSO Group)인가. 자식 Image 노드는 외곽 Group의 control_index를 물려받는다.
fn is_group_shape_control(ctrl: &Control) -> bool {
    matches!(
        ctrl,
        Control::Shape(shape)
            if matches!(shape.as_ref(), crate::model::shape::ShapeObject::Group(_))
    )
}

/// 글자겹침 TextRun의 논리적 char_count (1) 반환, 아니면 실제 글자 수 반환.
///
/// `table-vpos-01.hwp`의 boxed 10/11/12처럼 CharOverlap payload가 여러
/// PUA 구성 글자를 갖더라도 편집 커서는 한 글자 단위로 이동해야 한다.
fn effective_char_count(text_run: &TextRunNode) -> usize {
    if text_run.char_overlap.is_some() {
        let chars: Vec<char> = text_run.text.chars().collect();
        return crate::renderer::composer::char_overlap_advance_units(&chars);
    }
    text_run.text.chars().count()
}

/// 표 셀 안 편집 캐럿과 IME 조합창이 공유하는 가시 경계다.
///
/// TextRun의 실제 좌표가 고정 높이 셀 밖으로 이어져도 문서 모델의 offset은 보존한다.
/// 대신 편집 UI가 사용할 좌표만 이 bbox 안으로 제한한다.
#[derive(Clone, Copy)]
struct CellCursorBounds {
    x: f64,
    y: f64,
    w: f64,
    h: f64,
}

fn clamp_cursor_to_cell_bounds(
    x: f64,
    y: f64,
    height: f64,
    bounds: CellCursorBounds,
) -> (f64, f64, f64, bool) {
    let right = bounds.x + bounds.w.max(0.0);
    let bottom = bounds.y + bounds.h.max(0.0);
    let clamped_height = height.min(bounds.h.max(0.0));
    let max_y = (bottom - clamped_height).max(bounds.y);
    let clamped_x = x.clamp(bounds.x, right);
    let clamped_y = y.clamp(bounds.y, max_y);
    let overflowed = (x - clamped_x).abs() > 0.01
        || (y - clamped_y).abs() > 0.01
        || (height - clamped_height).abs() > 0.01;
    (clamped_x, clamped_y, clamped_height, overflowed)
}

/// [#4149] fast path 의 페이지 단위 결과.
enum FastCellRectOutcome {
    /// legacy 와 동일한 JSON 을 확정 — 즉시 반환.
    Hit(String),
    /// 이 페이지에는 대상 (cell_para, offset) run 이 없음 — 다음 후보 페이지로.
    NoHit,
    /// 확신 불가 — 전체 legacy 폴백.
    Unsupported,
}

/// 셀 캐럿 TextRun 히트 — legacy 페이지 트리 탐색과 [#4149] fast path 프로브가
/// 공유한다 (매칭 규칙이 갈리면 패리티가 깨진다).
struct CellCursorHit {
    page_index: u32,
    x: f64,
    y: f64,
    height: f64,
}

/// 렌더 노드 트리에서 대상 셀의 bbox 를 찾는다 (legacy/fast 공유).
fn find_table_cell_bounds_in_node(
    node: &crate::renderer::render_tree::RenderNode,
    parent_para: usize,
    ctrl_idx: usize,
    c_idx: usize,
) -> Option<CellCursorBounds> {
    use crate::renderer::render_tree::RenderNodeType;
    if let RenderNodeType::Table(ref table) = node.node_type {
        let matches_table =
            table.para_index == Some(parent_para) && table.control_index == Some(ctrl_idx);
        if matches_table {
            for child in &node.children {
                if let RenderNodeType::TableCell(ref cell) = child.node_type {
                    if cell.model_cell_index == Some(c_idx as u32) {
                        return Some(CellCursorBounds {
                            x: child.bbox.x,
                            y: child.bbox.y,
                            w: child.bbox.width,
                            h: child.bbox.height,
                        });
                    }
                }
            }
        }
    }
    for child in &node.children {
        if let Some(bounds) = find_table_cell_bounds_in_node(child, parent_para, ctrl_idx, c_idx) {
            return Some(bounds);
        }
    }
    None
}

/// 렌더 노드 트리에서 (cell_para, offset) 캐럿 TextRun 을 찾는다 (legacy/fast 공유).
fn find_cursor_in_cell_node(
    node: &crate::renderer::render_tree::RenderNode,
    parent_para: usize,
    ctrl_idx: usize,
    c_idx: usize,
    cp_idx: usize,
    offset: usize,
    page_index: u32,
) -> Option<CellCursorHit> {
    use crate::renderer::render_tree::RenderNodeType;
    if let RenderNodeType::TextRun(ref text_run) = node.node_type {
        let matches_cell = text_run.cell_context.as_ref().map_or(false, |ctx| {
            // path.len()==1 가드가 없으면 중첩 표 *내부* 셀의 run 도
            // 매칭된다: 내부 run 의 path[0] 은 그 중첩 표를 품은 바깥 셀과
            // 정확히 같기 때문이다. 같은 파일의 cell_context_matches 가
            // path 길이 일치를 계약으로 명시한다.
            ctx.parent_para_index == parent_para
                && ctx.path.len() == 1
                && ctx.path[0].control_index == ctrl_idx
                && ctx.path[0].cell_index == c_idx
                && ctx.path[0].cell_para_index == cp_idx
        });
        // 번호/글머리표 TextRun (char_start: None)은 건너뛴다
        if let (true, Some(char_start)) = (matches_cell, text_run.char_start) {
            let char_count = effective_char_count(text_run);

            if offset >= char_start && offset <= char_start + char_count {
                let local_offset = offset - char_start;
                let positions = if text_run.char_overlap.is_some() && char_count == 1 {
                    vec![0.0, node.bbox.width]
                } else {
                    text_run.replay_positions_for(&text_run.text).into_owned()
                };
                let x_in_run = if local_offset < positions.len() {
                    positions[local_offset]
                } else if !positions.is_empty() {
                    *positions.last().unwrap()
                } else {
                    0.0
                };
                // 베이스라인 기반 캐럿 y 계산 (본문과 동일)
                let font_size = text_run.style.font_size;
                let ascent = font_size * 0.8;
                let caret_y = node.bbox.y + text_run.baseline - ascent;
                return Some(CellCursorHit {
                    page_index,
                    x: node.bbox.x + x_in_run,
                    y: caret_y,
                    height: font_size,
                });
            }
        }
    }
    for child in &node.children {
        if let Some(hit) = find_cursor_in_cell_node(
            child,
            parent_para,
            ctrl_idx,
            c_idx,
            cp_idx,
            offset,
            page_index,
        ) {
            return Some(hit);
        }
    }
    None
}

fn format_cursor_rect_json(
    page_index: u32,
    x: f64,
    y: f64,
    height: f64,
    cell_bounds: Option<CellCursorBounds>,
) -> String {
    if let Some(bounds) = cell_bounds {
        let (x, y, height, overflowed) = clamp_cursor_to_cell_bounds(x, y, height, bounds);
        format!(
            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1},\"cellBounds\":{{\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1}}},\"cellOverflowed\":{}}}",
            page_index, x, y, height, bounds.x, bounds.y, bounds.w, bounds.h, overflowed
        )
    } else {
        format!(
            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
            page_index, x, y, height
        )
    }
}

fn note_number_format_from_hwp_code(code: u8) -> crate::renderer::NumberFormat {
    match code {
        0 => crate::renderer::NumberFormat::Digit,
        1 => crate::renderer::NumberFormat::CircledDigit,
        2 => crate::renderer::NumberFormat::RomanUpper,
        3 => crate::renderer::NumberFormat::RomanLower,
        4 => crate::renderer::NumberFormat::LatinUpper,
        5 => crate::renderer::NumberFormat::LatinLower,
        8 => crate::renderer::NumberFormat::HangulGaNaDa,
        12 => crate::renderer::NumberFormat::HangulNumber,
        13 => crate::renderer::NumberFormat::HanjaNumber,
        _ => crate::renderer::NumberFormat::Digit,
    }
}

fn note_decoration_char(value: u16) -> Option<char> {
    if value == 0 {
        None
    } else {
        char::from_u32(value as u32).filter(|ch| *ch != '\0')
    }
}

fn note_marker_text(
    number: u16,
    number_shape: u32,
    before_decoration_letter: u16,
    after_decoration_letter: u16,
) -> String {
    let number = crate::renderer::format_number(
        number,
        note_number_format_from_hwp_code(number_shape as u8),
    );
    let prefix = note_decoration_char(before_decoration_letter)
        .map(|ch| ch.to_string())
        .unwrap_or_default();
    let suffix = note_decoration_char(after_decoration_letter)
        .unwrap_or(')')
        .to_string();
    format!("{}{}{}", prefix, number, suffix)
}

/// 한 시각 줄(line)을 구성하는 한 run 의, 클릭 x → 문자 위치 해석에 필요한 최소 정보.
///
/// `hit_test_native` 내부의 `RunInfo` 에서 줄별로 추려 만든 가벼운 view.
/// 이 view 만 분리해 두면 줄 단위 x 해석 로직(`resolve_x_on_line`)을 문서/페이지
/// 트리 없이 단위 테스트할 수 있다.
pub(crate) struct LineRunView<'a> {
    pub bbox_x: f64,
    pub bbox_w: f64,
    pub char_start: usize,
    pub char_count: usize,
    /// 각 글자의 run-local x 좌표(누적 advance). 비어 있으면 글자 위치 미상.
    pub char_positions: &'a [f64],
}

/// run-local x 에 해당하는 글자 인덱스. `hit_test_native` 내부 `find_char_at_x`
/// 와 동일 의미(positions[i] = i번째 글자의 left x, 0.0 포함 안 함)를 유지한다.
fn line_local_char_at_x(positions: &[f64], local_x: f64) -> usize {
    for (i, &px) in positions.iter().enumerate() {
        if i == 0 {
            if local_x < px / 2.0 {
                return 0;
            }
        } else {
            let mid = (positions[i - 1] + px) / 2.0;
            if local_x < mid {
                return i;
            }
        }
    }
    positions.len()
}

/// 한 시각 줄(line)에 속한 run 들(이미 bbox_x 오름차순 정렬) 안에서 클릭 x 를
/// 가장 가까운 문자 위치로 해석한다. 반환: (line_runs 내 인덱스, 절대 char offset).
///
/// 줄을 구성하는 run 이 1개든 여러 개든 동일하게:
///   - x 가 run bbox 안 → 정확한 글자 위치
///   - x 가 두 run 사이의 빈틈 → 더 가까운 쪽 경계(왼쪽 run 끝 / 오른쪽 run 시작)
///   - x 가 첫 run 왼쪽 → 첫 run 시작
///   - x 가 마지막 run 오른쪽 → 마지막 run 끝
///
/// 기존 fallback 들이 줄 시작/끝으로만 스냅하던 결함(클릭 y 가 글리프 bbox 의
/// 행간 여백에 떨어졌을 때, 그리고 다중 run 줄의 run 경계 빈틈)을 정정한다.
pub(crate) fn resolve_x_on_line(line_runs: &[LineRunView], x: f64) -> (usize, usize) {
    debug_assert!(!line_runs.is_empty());
    // 첫 run 왼쪽
    if x < line_runs[0].bbox_x {
        let r = &line_runs[0];
        return (0, r.char_start);
    }
    for (i, r) in line_runs.iter().enumerate() {
        if x <= r.bbox_x + r.bbox_w {
            // 이 run 의 bbox 안 (또는 이전 run 과의 빈틈 안)
            if x >= r.bbox_x {
                let local_x = x - r.bbox_x;
                // char_count 로 클램프: 빈 run(char_count=0)이지만 bbox_w 가 셀 폭만큼
                // 넓은 입력칸의 경우 char_positions(=[0.0])가 len()=1 을 돌려주어
                // char_start+1 (= 줄 끝 너머) 로 새던 결함을 막는다. 글자 인덱스는
                // 결코 그 run 의 char_count 를 넘을 수 없다.
                let local_idx = line_local_char_at_x(r.char_positions, local_x).min(r.char_count);
                return (i, r.char_start + local_idx);
            }
            // 이전 run 과 이 run 사이의 빈틈: 더 가까운 경계로 스냅
            let prev = &line_runs[i - 1];
            let prev_right = prev.bbox_x + prev.bbox_w;
            if (x - prev_right) <= (r.bbox_x - x) {
                return (i - 1, prev.char_start + prev.char_count);
            }
            return (i, r.char_start);
        }
    }
    // 마지막 run 오른쪽
    let last = line_runs.len() - 1;
    let r = &line_runs[last];
    (last, r.char_start + r.char_count)
}

impl DocumentCore {
    /// 1x1 TAC wrapper 표를 시각적으로 unwrap 하여 내부 표를 직접 렌더링한 경우,
    /// RenderNode 는 내부 표 cell_index 를 갖지만 cell_context 는 outer wrapper 표에
    /// 머무를 수 있다. 이 상태로는 `[(outer_ci, inner_cell_idx, ...)]` 처럼 존재하지
    /// 않는 outer cell 을 가리켜 Studio 커서 이동에서 by-path 조회가 실패한다.
    ///
    /// 모델을 확인해 outer 1x1 셀 안의 nested table control 로 path 를 복원한다.
    fn repair_unwrapped_wrapper_cell_context(&self, section_index: usize, ctx: &mut CellContext) {
        if ctx.path.len() != 1 {
            return;
        }
        let outer = ctx.path[0];
        let Some(table) = self
            .document
            .sections
            .get(section_index)
            .and_then(|s| s.paragraphs.get(ctx.parent_para_index))
            .and_then(|p| p.controls.get(outer.control_index))
            .and_then(|c| match c {
                Control::Table(t) => Some(t.as_ref()),
                _ => None,
            })
        else {
            return;
        };
        if table.cells.len() != 1 || outer.cell_index < table.cells.len() {
            return;
        }
        let Some(wrapper_cell) = table.cells.first() else {
            return;
        };
        let Some(wrapper_para) = wrapper_cell.paragraphs.first() else {
            return;
        };
        let Some(nested_ctrl_idx) =
            wrapper_para
                .controls
                .iter()
                .enumerate()
                .find_map(|(ci, ctrl)| match ctrl {
                    Control::Table(t) if outer.cell_index < t.cells.len() => Some(ci),
                    _ => None,
                })
        else {
            return;
        };

        if let Some(first) = ctx.path.first_mut() {
            first.cell_index = 0;
            first.cell_para_index = 0;
        }
        ctx.path.push(CellPathEntry {
            control_index: nested_ctrl_idx,
            cell_index: outer.cell_index,
            cell_para_index: outer.cell_para_index,
            text_direction: outer.text_direction,
        });
    }

    pub fn get_cursor_rect_native(
        &self,
        section_idx: usize,
        para_idx: usize,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::layout::{
            compute_char_positions, estimate_text_width, resolved_to_text_style,
        };
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        // 문단이 포함된 페이지 찾기 — [#4179] 텍스트가 렌더될 수 없는
        // 순수-중간 연속 컷 페이지는 후보에서 제외 (스캔 순서·결과 좌표 불변)
        let pages = self.find_text_scan_pages_for_paragraph(section_idx, para_idx)?;

        let footnote_marker_positions: Vec<(usize, usize)> = self
            .get_render_paragraph_ref(section_idx, para_idx)
            .ok()
            .map(|para| {
                let ctrl_positions = find_logical_control_positions(para);
                para.controls
                    .iter()
                    .enumerate()
                    .filter(|(_, ctrl)| matches!(ctrl, Control::Footnote(_) | Control::Endnote(_)))
                    .filter_map(|(ci, _)| ctrl_positions.get(ci).copied().map(|pos| (ci, pos)))
                    .collect()
            })
            .unwrap_or_default();

        // 커서 결과를 담을 구조체
        #[derive(Clone, Copy)]
        struct CursorHit {
            page_index: u32,
            x: f64,
            y: f64,
            height: f64,
        }

        fn is_inline_cursor_control(ctrl: &Control) -> bool {
            is_treat_as_char_object_control(ctrl)
        }

        fn text_offset_after_same_pos_inline_controls(
            para: &Paragraph,
            text_offset: usize,
        ) -> usize {
            let ctrl_positions = para.control_text_positions();
            let same_or_before_count = para
                .controls
                .iter()
                .enumerate()
                .filter(|(_, ctrl)| is_inline_cursor_control(ctrl))
                .filter_map(|(ci, _)| ctrl_positions.get(ci))
                .filter(|&&pos| pos <= text_offset)
                .count();
            text_offset + same_or_before_count
        }

        fn collect_inline_control_bboxes(
            node: &RenderNode,
            sec: usize,
            para: usize,
            bboxes: &mut std::collections::HashMap<usize, (f64, f64, f64, f64)>,
        ) {
            match &node.node_type {
                RenderNodeType::Image(image_node) => {
                    if image_node.section_index == Some(sec) && image_node.para_index == Some(para)
                    {
                        if let Some(ci) = image_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Equation(eq_node) => {
                    if eq_node.section_index == Some(sec) && eq_node.para_index == Some(para) {
                        if let Some(ci) = eq_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Group(group_node) => {
                    if group_node.section_index == Some(sec) && group_node.para_index == Some(para)
                    {
                        if let Some(ci) = group_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Rectangle(rect_node) => {
                    if rect_node.section_index == Some(sec) && rect_node.para_index == Some(para) {
                        if let Some(ci) = rect_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Line(line_node) => {
                    if line_node.section_index == Some(sec) && line_node.para_index == Some(para) {
                        if let Some(ci) = line_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Ellipse(ell_node) => {
                    if ell_node.section_index == Some(sec) && ell_node.para_index == Some(para) {
                        if let Some(ci) = ell_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Path(path_node) => {
                    if path_node.section_index == Some(sec) && path_node.para_index == Some(para) {
                        if let Some(ci) = path_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                RenderNodeType::Table(table_node) => {
                    if table_node.section_index == Some(sec) && table_node.para_index == Some(para)
                    {
                        if let Some(ci) = table_node.control_index {
                            bboxes.insert(
                                ci,
                                (node.bbox.x, node.bbox.y, node.bbox.width, node.bbox.height),
                            );
                        }
                    }
                }
                _ => {}
            }

            for child in &node.children {
                collect_inline_control_bboxes(child, sec, para, bboxes);
            }
        }

        fn collect_text_caret_stops(
            node: &RenderNode,
            sec: usize,
            para_idx: usize,
            para: &Paragraph,
            raw_text_index: &mut usize,
            stops: &mut std::collections::BTreeMap<usize, CursorHit>,
            page_index: u32,
        ) {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if text_run.section_index == Some(sec)
                    && text_run.para_index == Some(para_idx)
                    && text_run.cell_context.is_none()
                    && text_run.char_start.is_some()
                {
                    let para_chars: Vec<char> = para.text.chars().collect();
                    let run_chars: Vec<char> = text_run.text.chars().collect();
                    let positions = text_run.replay_positions_for(&text_run.text).into_owned();
                    let font_size = text_run.style.font_size;
                    let ascent = font_size * 0.8;
                    let caret_y = node.bbox.y + text_run.baseline - ascent;

                    if text_run.text.is_empty() && effective_char_count(text_run) == 0 {
                        if let Some(char_start) = text_run.char_start {
                            stops.entry(char_start).or_insert(CursorHit {
                                page_index,
                                x: node.bbox.x,
                                y: caret_y,
                                height: font_size.max(10.0),
                            });
                        }
                    }

                    for (idx, ch) in run_chars.iter().enumerate() {
                        if *ch == '\u{fffc}' {
                            continue;
                        }
                        if *raw_text_index >= para_chars.len() {
                            break;
                        }
                        if *ch != para_chars[*raw_text_index] {
                            continue;
                        }

                        let logical_start =
                            text_offset_after_same_pos_inline_controls(para, *raw_text_index);
                        let x0 = node.bbox.x + positions.get(idx).copied().unwrap_or(0.0);
                        let x1 = node.bbox.x
                            + positions
                                .get(idx + 1)
                                .copied()
                                .or_else(|| positions.last().copied())
                                .unwrap_or(0.0);

                        stops.entry(logical_start).or_insert(CursorHit {
                            page_index,
                            x: x0,
                            y: caret_y,
                            height: font_size,
                        });
                        stops.entry(logical_start + 1).or_insert(CursorHit {
                            page_index,
                            x: x1,
                            y: caret_y,
                            height: font_size,
                        });
                        *raw_text_index += 1;
                    }
                }
            }

            for child in &node.children {
                collect_text_caret_stops(
                    child,
                    sec,
                    para_idx,
                    para,
                    raw_text_index,
                    stops,
                    page_index,
                );
            }
        }

        fn find_inline_flow_cursor_hit(
            tree: &crate::renderer::render_tree::PageRenderTree,
            sec: usize,
            para_idx: usize,
            para: &Paragraph,
            offset: usize,
            page_index: u32,
        ) -> Option<CursorHit> {
            if !para.controls.iter().any(is_inline_cursor_control) {
                return None;
            }

            let mut stops = std::collections::BTreeMap::new();
            let mut raw_text_index = 0usize;
            collect_text_caret_stops(
                &tree.root,
                sec,
                para_idx,
                para,
                &mut raw_text_index,
                &mut stops,
                page_index,
            );

            let mut control_bboxes = std::collections::HashMap::new();
            collect_inline_control_bboxes(&tree.root, sec, para_idx, &mut control_bboxes);
            let ctrl_positions = find_logical_control_positions(para);
            let raw_ctrl_positions = para.control_text_positions();
            let mut inline_controls = Vec::new();

            for (ci, ctrl) in para.controls.iter().enumerate() {
                if !is_inline_cursor_control(ctrl) {
                    continue;
                }
                let Some(pos) = ctrl_positions.get(ci).copied() else {
                    continue;
                };
                let Some(raw_pos) = raw_ctrl_positions.get(ci).copied() else {
                    continue;
                };
                let Some((x, y, w, h)) = control_bboxes.get(&ci).copied() else {
                    continue;
                };
                inline_controls.push((ci, raw_pos, pos, x, x + w));

                let nearby_text_metrics = stops
                    .range(..=pos + 1)
                    .next_back()
                    .map(|(_, hit)| (hit.y, hit.height))
                    .or_else(|| stops.values().next().map(|hit| (hit.y, hit.height)));
                let line_metrics = nearby_text_metrics
                    .filter(|(text_y, text_h)| {
                        let text_mid = *text_y + *text_h / 2.0;
                        text_mid >= y && text_mid <= y + h
                    })
                    .unwrap_or_else(|| {
                        let fallback_h = 12.0;
                        let baseline = h * 0.85;
                        let ascent = fallback_h * 0.8;
                        (y + (baseline - ascent).max(0.0), fallback_h)
                    });

                stops.insert(
                    pos,
                    CursorHit {
                        page_index,
                        x,
                        y: line_metrics.0,
                        height: line_metrics.1,
                    },
                );
                stops.entry(pos + 1).or_insert(CursorHit {
                    page_index,
                    x: x + w,
                    y: line_metrics.0,
                    height: line_metrics.1,
                });
            }
            inline_controls.sort_by_key(|&(ci, raw_pos, pos, _, _)| (raw_pos, pos, ci));

            if para.text.is_empty()
                && para.controls.iter().all(|ctrl| {
                    matches!(ctrl, Control::Equation(_)) && is_treat_as_char_object_control(ctrl)
                })
            {
                let mut equation_controls = para
                    .controls
                    .iter()
                    .enumerate()
                    .filter_map(|(ci, ctrl)| {
                        if !matches!(ctrl, Control::Equation(_))
                            || !is_treat_as_char_object_control(ctrl)
                        {
                            return None;
                        }
                        let (x, y, w, h) = control_bboxes.get(&ci).copied()?;
                        let raw_pos = raw_ctrl_positions.get(ci).copied().unwrap_or(ci);
                        let pos = ctrl_positions.get(ci).copied().unwrap_or(ci);
                        Some((ci, raw_pos, pos, x, y, w, h))
                    })
                    .collect::<Vec<_>>();
                equation_controls.sort_by_key(|&(ci, raw_pos, pos, _, _, _, _)| (raw_pos, pos, ci));

                for (slot, (_, _, _, x, y, w, h)) in equation_controls.iter().enumerate() {
                    let fallback_h = 12.0;
                    let baseline = *h * 0.85;
                    let ascent = fallback_h * 0.8;
                    let caret_y = *y + (baseline - ascent).max(0.0);
                    if offset == slot * 2 {
                        return Some(CursorHit {
                            page_index,
                            x: *x,
                            y: caret_y,
                            height: fallback_h,
                        });
                    }
                    if offset == slot * 2 + 1 {
                        return Some(CursorHit {
                            page_index,
                            x: *x + *w,
                            y: caret_y,
                            height: fallback_h,
                        });
                    }
                }
            }

            let para_chars: Vec<char> = para.text.chars().collect();
            for pair in inline_controls.windows(2) {
                let (_, prev_raw, prev_pos, _, prev_right) = pair[0];
                let (_, next_raw, next_pos, next_left, _) = pair[1];
                if next_raw <= prev_raw || next_left <= prev_right {
                    continue;
                }

                let Some(between) = para_chars.get(prev_raw..next_raw) else {
                    continue;
                };
                if between.is_empty() || !between.iter().all(|ch| *ch == ' ') {
                    continue;
                }

                let space_count = between.len();
                if next_pos != prev_pos + 1 + space_count {
                    continue;
                }

                let Some(metrics) = stops
                    .get(&(prev_pos + 1))
                    .or_else(|| stops.get(&next_pos))
                    .or_else(|| stops.values().next())
                    .copied()
                else {
                    continue;
                };

                for step in 0..=space_count {
                    let ratio = step as f64 / space_count as f64;
                    let x = prev_right + (next_left - prev_right) * ratio;
                    stops.insert(
                        prev_pos + 1 + step,
                        CursorHit {
                            page_index,
                            x,
                            y: metrics.y,
                            height: metrics.height,
                        },
                    );
                }
            }

            stops.get(&offset).copied()
        }

        let (is_list_para, list_marker_char_shape_id) = self
            .get_render_paragraph_ref(section_idx, para_idx)
            .ok()
            .map(|para| {
                let is_list = self
                    .styles
                    .para_styles
                    .get(para.para_shape_id as usize)
                    .map(|ps| {
                        matches!(
                            ps.head_type,
                            crate::model::style::HeadType::Outline
                                | crate::model::style::HeadType::Number
                                | crate::model::style::HeadType::Bullet
                        )
                    })
                    .unwrap_or(false);
                let marker_style_id = para.char_shapes.first().map(|cs| cs.char_shape_id);
                (is_list, marker_style_id)
            })
            .unwrap_or((false, None));
        let list_marker_char_shape_id = if is_list_para {
            list_marker_char_shape_id
        } else {
            None
        };
        // [#7418] 마커 글자 x 에서 본문 시작까지 — 배치가 쓴 마커 기하(영역·정렬)와 같은 값.
        let list_marker_body_dx = if is_list_para {
            self.get_render_paragraph_ref(section_idx, para_idx)
                .ok()
                .and_then(|para| crate::renderer::layout::list_marker_geometry(para, &self.styles))
                .map(|geometry| -geometry.marker_dx_px)
        } else {
            None
        };

        // 렌더 트리에서 커서 위치를 찾는 재귀 함수
        // exact_only: true이면 정확한 매칭(zero-width 앵커)만 반환
        fn find_cursor_in_node(
            node: &RenderNode,
            sec: usize,
            para: usize,
            render_para: Option<&Paragraph>,
            offset: usize,
            page_index: u32,
            exact_only: bool,
            is_list_para: bool,
            footnote_marker_positions: &[(usize, usize)],
        ) -> Option<CursorHit> {
            if let RenderNodeType::FootnoteMarker(ref marker) = node.node_type {
                if marker.section_index == sec && marker.para_index == para {
                    if let Some((_, marker_pos)) = footnote_marker_positions
                        .iter()
                        .find(|(ci, _)| *ci == marker.control_index)
                    {
                        if offset == *marker_pos || offset == *marker_pos + 1 {
                            return Some(CursorHit {
                                page_index,
                                x: if offset == *marker_pos {
                                    node.bbox.x
                                } else {
                                    node.bbox.x + node.bbox.width
                                },
                                y: node.bbox.y,
                                height: node.bbox.height.max(10.0),
                            });
                        }
                    }
                }
            }

            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                // 번호/글머리표 TextRun (char_start: None)은 건너뛴다
                if let Some(char_start) = text_run.char_start {
                    if text_run.section_index == Some(sec)
                        && text_run.para_index == Some(para)
                        && text_run.cell_context.is_none()
                    {
                        let char_count = effective_char_count(text_run);

                        // 커서가 이 TextRun 범위 안에 있는지 확인
                        // char_start <= offset <= char_start + char_count
                        if offset >= char_start && offset <= char_start + char_count {
                            if node.bbox.width <= f64::EPSILON
                                && !text_run.text.is_empty()
                                && text_run.text.chars().all(|ch| ch == '\u{fffc}')
                            {
                                if let Some(render_para) = render_para {
                                    let visible: String = render_para
                                        .text
                                        .chars()
                                        .skip(char_start)
                                        .take(char_count)
                                        .collect();
                                    if !visible.is_empty()
                                        && visible.chars().any(|ch| ch != '\u{fffc}')
                                    {
                                        let positions =
                                            compute_char_positions(&visible, &text_run.style);
                                        let local_offset = offset - char_start;
                                        let x_in_run = if local_offset < positions.len() {
                                            positions[local_offset]
                                        } else if !positions.is_empty() {
                                            *positions.last().unwrap()
                                        } else {
                                            0.0
                                        };
                                        let font_size = text_run.style.font_size;
                                        let ascent = font_size * 0.8;
                                        let caret_y = node.bbox.y + text_run.baseline - ascent;
                                        return Some(CursorHit {
                                            page_index,
                                            x: node.bbox.x + x_in_run,
                                            y: caret_y,
                                            height: font_size,
                                        });
                                    }
                                }
                                // 실제 문단 텍스트로 복원할 수 없는 placeholder는 cursor hit에서 제외한다.
                            } else {
                                let empty_list_anchor = is_list_para
                                    && char_count == 0
                                    && offset == char_start
                                    && text_run.text.is_empty();
                                // exact_only 모드: zero-width 앵커(bbox.width==0)만 허용
                                if empty_list_anchor {
                                    // 빈 번호/글머리표 문단의 body anchor 는 marker 앞쪽 x 에
                                    // 놓일 수 있으므로 fallback 에서 marker 오른쪽 끝으로 보정한다.
                                } else if exact_only
                                    && !(char_count == 0
                                        && offset == char_start
                                        && node.bbox.width == 0.0)
                                {
                                    // skip: 이 TextRun은 경계 매칭일 뿐 정확한 앵커가 아님
                                } else {
                                    let local_offset = offset - char_start;
                                    // PUA 다자리 글자겹침: 커서 위치는 [0.0, bbox.width]
                                    let positions = if text_run.char_overlap.is_some()
                                        && char_count == 1
                                    {
                                        vec![0.0, node.bbox.width]
                                    } else {
                                        text_run.replay_positions_for(&text_run.text).into_owned()
                                    };
                                    let x_in_run = if local_offset < positions.len() {
                                        positions[local_offset]
                                    } else if !positions.is_empty() {
                                        *positions.last().unwrap()
                                    } else {
                                        0.0
                                    };
                                    // 베이스라인 기반 캐럿 y 계산:
                                    // 같은 줄에 서로 다른 글꼴 크기가 혼재할 때
                                    // 각 글자의 ascent 위치에서 캐럿이 시작되어야 함
                                    let font_size = text_run.style.font_size;
                                    let ascent = font_size * 0.8;
                                    let caret_y = node.bbox.y + text_run.baseline - ascent;
                                    return Some(CursorHit {
                                        page_index,
                                        x: node.bbox.x + x_in_run,
                                        y: caret_y,
                                        height: font_size,
                                    });
                                }
                            }
                        }
                    }
                } // if let Some(char_start)

                // 도형 조판부호 마커 (char_start=None, ShapeMarker(pos))
                if let crate::renderer::render_tree::FieldMarkerType::ShapeMarker(marker_pos) =
                    text_run.field_marker
                {
                    if text_run.section_index == Some(sec)
                        && text_run.para_index == Some(para)
                        && text_run.cell_context.is_none()
                    {
                        let font_size = text_run.style.font_size;
                        let ascent = font_size * 0.8;
                        let caret_y = node.bbox.y + text_run.baseline - ascent;
                        if marker_pos == offset {
                            // 마커 왼쪽 (마커 앞)
                            return Some(CursorHit {
                                page_index,
                                x: node.bbox.x,
                                y: caret_y,
                                height: font_size.max(10.0),
                            });
                        }
                        if marker_pos + 1 == offset {
                            // 마커 오른쪽 (마커 뒤)
                            return Some(CursorHit {
                                page_index,
                                x: node.bbox.x + node.bbox.width,
                                y: caret_y,
                                height: font_size.max(10.0),
                            });
                        }
                    }
                }
            }
            for child in &node.children {
                if let Some(hit) = find_cursor_in_node(
                    child,
                    sec,
                    para,
                    render_para,
                    offset,
                    page_index,
                    exact_only,
                    is_list_para,
                    footnote_marker_positions,
                ) {
                    return Some(hit);
                }
            }
            None
        }

        // 대상 문단이 빈 문단(비인라인 표/도형만 호스팅)이면 char_offset 매칭 텍스트가
        // 애초에 어느 페이지에도 존재하지 않는다 — 페이지별 render tree 구축을 건너뛰고
        // 곧장 아래의 앵커 위치 폴백(조판부호 감추기 인라인 컨트롤 / OLE / 문단 줄 위치)으로 간다.
        //
        // 단, TAC 그림·수식 같은 **인라인(treat_as_char) 컨트롤**이나 각주/미주 마커를
        // 호스팅하는 문단은 텍스트가 비어 있어도 페이지 스캔이 인라인 앵커(그림 끝 위치,
        // zero-width 노드)를 찾아 캐럿을 놓는다 — 스킵하면 두 그림의 캐럿이 같은 좌표로
        // 붕괴한다 (issue_1452_saved_caret 회귀 실측). 스킵은 페이지 스캔이 원리적으로
        // 아무것도 찾을 수 없는 경우로만 한정한다.
        let para_page_scan_can_hit = self
            .get_render_paragraph_ref(section_idx, para_idx)
            .map(|p| {
                !p.text.is_empty()
                    || p.controls.iter().any(|ctrl| {
                        is_inline_cursor_control(ctrl)
                            || matches!(ctrl, Control::Footnote(_) | Control::Endnote(_))
                    })
                    // 빈 ClickHere는 TextRun이 아니라 renderer가 만든 zero-width anchor로
                    // 캐럿 위치를 보존한다. 빈 호스트 문단 최적화가 이 anchor를 찾는
                    // 페이지 scan까지 건너뛰면 TextLine 좌단 fallback으로 떨어져 문단
                    // 가운데·오른쪽 정렬이 사라진다 (#6766).
                    || p.field_ranges.iter().any(|range| {
                        range.start_char_idx == range.end_char_idx
                            && matches!(
                                p.controls.get(range.control_idx),
                                Some(Control::Field(field))
                                    if field.field_type
                                        == crate::model::control::FieldType::ClickHere
                            )
                    })
            })
            .unwrap_or(true);

        // 후보 페이지를 순회하며 커서 위치 탐색
        // 1차: 정확한 앵커(zero-width 노드) 우선 검색, 2차: 일반 검색
        if para_page_scan_can_hit {
            for &page_num in &pages {
                let tree = self.build_page_tree_cached(page_num)?;
                if !self.show_control_codes {
                    if let Ok(para) = self.get_render_paragraph_ref(section_idx, para_idx) {
                        if let Some(hit) = find_inline_flow_cursor_hit(
                            &tree,
                            section_idx,
                            para_idx,
                            para,
                            char_offset,
                            page_num,
                        ) {
                            return Ok(format!(
                                "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                                hit.page_index, hit.x, hit.y, hit.height
                            ));
                        }
                    }
                }
                let render_para_for_cursor =
                    self.get_render_paragraph_ref(section_idx, para_idx).ok();
                let exact_hit = find_cursor_in_node(
                    &tree.root,
                    section_idx,
                    para_idx,
                    render_para_for_cursor,
                    char_offset,
                    page_num,
                    true,
                    is_list_para,
                    &footnote_marker_positions,
                );
                let hit_result = exact_hit.or_else(|| {
                    find_cursor_in_node(
                        &tree.root,
                        section_idx,
                        para_idx,
                        render_para_for_cursor,
                        char_offset,
                        page_num,
                        false,
                        is_list_para,
                        &footnote_marker_positions,
                    )
                });
                if let Some(hit) = hit_result {
                    return Ok(format!(
                        "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                        hit.page_index, hit.x, hit.y, hit.height
                    ));
                }
            }
        }

        // 조판부호 감추기 모드: 인라인 도형 컨트롤 위치에서 커서 좌표 반환
        // treat_as_char Shape는 inline_shape_positions에서 좌표를 가져와 커서 표시
        if !self.show_control_codes {
            if let Ok(para) = self.get_render_paragraph_ref(section_idx, para_idx) {
                let text_len = para.text.chars().count();
                let ctrl_positions =
                    crate::document_core::helpers::find_logical_control_positions(para);

                // char_offset 위치에 인라인 컨트롤이 있는지 확인
                let inline_ctrl = para.controls.iter().enumerate().find(|(ci, ctrl)| {
                    is_inline_cursor_control(ctrl)
                        && ctrl_positions.get(*ci).copied() == Some(char_offset)
                        && char_offset != text_len
                });
                // 텍스트 범위 밖이지만 navigable 범위 내 (도형이 텍스트 뒤에 있을 때)
                let beyond_ctrl =
                    if char_offset > text_len && char_offset <= navigable_text_len(para) {
                        para.controls.iter().enumerate().find(|(ci, ctrl)| {
                            is_inline_cursor_control(ctrl)
                                && ctrl_positions.get(*ci).copied() == Some(char_offset)
                        })
                    } else {
                        None
                    };

                if let Some((ci, _ctrl)) = inline_ctrl.or(beyond_ctrl) {
                    // inline_shape_positions에서 Shape 좌표 조회
                    let first_page = pages[0];
                    let tree = self.build_page_tree(first_page)?;
                    if let Some((sx, sy)) =
                        tree.get_inline_shape_position(section_idx, para_idx, ci, None)
                    {
                        let shape_h = if let Some(Control::Shape(s)) = para.controls.get(ci) {
                            crate::renderer::hwpunit_to_px(
                                s.common().height as i32,
                                crate::renderer::DEFAULT_DPI,
                            )
                        } else if let Some(Control::Picture(p)) = para.controls.get(ci) {
                            crate::renderer::hwpunit_to_px(
                                p.common.height as i32,
                                crate::renderer::DEFAULT_DPI,
                            )
                        } else {
                            16.0
                        };
                        return Ok(format!(
                            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                            first_page, sx, sy, shape_h
                        ));
                    }
                }
            }
        }

        // TextRun에서 찾지 못한 경우 (빈 문단 등): 첫 페이지에서 문단 위치 추정
        let first_page = pages[0];
        let tree = self.build_page_tree(first_page)?;

        #[derive(Clone, Copy)]
        struct ParaLineHit {
            line_x: f64,
            y: f64,
            height: f64,
            first_body_x: Option<f64>,
            marker_end_x: Option<f64>,
        }

        impl ParaLineHit {
            fn cursor_x(self, is_list_para: bool, char_offset: usize) -> f64 {
                if is_list_para && char_offset == 0 {
                    self.marker_end_x
                        .or(self.first_body_x)
                        .unwrap_or(self.line_x)
                } else if is_list_para {
                    self.first_body_x
                        .or(self.marker_end_x)
                        .unwrap_or(self.line_x)
                } else {
                    self.line_x
                }
            }
        }

        fn collect_para_line_text_runs(
            node: &RenderNode,
            sec: usize,
            para: usize,
            is_list_para: bool,
            list_marker_char_shape_id: Option<u32>,
            list_marker_body_dx: Option<f64>,
            styles: &crate::renderer::style_resolver::ResolvedStyleSet,
            hit: &mut ParaLineHit,
        ) {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if text_run.section_index == Some(sec)
                    && text_run.para_index == Some(para)
                    && text_run.cell_context.is_none()
                {
                    if text_run.char_start.is_some() {
                        hit.first_body_x.get_or_insert(node.bbox.x);
                        hit.height = hit.height.max(text_run.style.font_size);
                    } else if is_list_para
                        && text_run.field_marker
                            == crate::renderer::render_tree::FieldMarkerType::None
                    {
                        let marker_width = list_marker_body_dx
                            .or_else(|| {
                                list_marker_char_shape_id.map(|cs_id| {
                                    let marker_style = resolved_to_text_style(styles, cs_id, 0);
                                    estimate_text_width(&text_run.text, &marker_style)
                                })
                            })
                            .unwrap_or(node.bbox.width);
                        hit.marker_end_x.get_or_insert(node.bbox.x + marker_width);
                        hit.height = hit.height.max(text_run.style.font_size);
                    }
                }
            }

            for child in &node.children {
                collect_para_line_text_runs(
                    child,
                    sec,
                    para,
                    is_list_para,
                    list_marker_char_shape_id,
                    list_marker_body_dx,
                    styles,
                    hit,
                );
            }
        }

        // 해당 문단의 첫 TextLine을 찾아 빈 list 문단이면 marker 뒤 본문 시작 x까지 수집한다.
        fn find_para_line(
            node: &RenderNode,
            sec: usize,
            para: usize,
            is_list_para: bool,
            list_marker_char_shape_id: Option<u32>,
            list_marker_body_dx: Option<f64>,
            styles: &crate::renderer::style_resolver::ResolvedStyleSet,
        ) -> Option<ParaLineHit> {
            if let RenderNodeType::TextLine(ref line) = node.node_type {
                if line.section_index == Some(sec) && line.para_index == Some(para) {
                    let mut hit = ParaLineHit {
                        line_x: node.bbox.x,
                        y: node.bbox.y,
                        height: node.bbox.height,
                        first_body_x: None,
                        marker_end_x: None,
                    };
                    collect_para_line_text_runs(
                        node,
                        sec,
                        para,
                        is_list_para,
                        list_marker_char_shape_id,
                        list_marker_body_dx,
                        styles,
                        &mut hit,
                    );
                    return Some(hit);
                }
            }

            // TextLine을 찾지 못하는 예외적인 렌더 트리에서는 기존 TextRun fallback을 보존한다.
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if text_run.section_index == Some(sec)
                    && text_run.para_index == Some(para)
                    && text_run.cell_context.is_none()
                    && text_run.char_start.is_some()
                {
                    return Some(ParaLineHit {
                        line_x: node.bbox.x,
                        y: node.bbox.y,
                        height: node.bbox.height,
                        first_body_x: Some(node.bbox.x),
                        marker_end_x: None,
                    });
                }
            }

            for child in &node.children {
                if let Some(r) = find_para_line(
                    child,
                    sec,
                    para,
                    is_list_para,
                    list_marker_char_shape_id,
                    list_marker_body_dx,
                    styles,
                ) {
                    return Some(r);
                }
            }
            None
        }

        fn is_non_inline_ole_control(para: &Paragraph, control_index: usize) -> bool {
            if !para.text.is_empty() {
                return false;
            }
            para.controls.get(control_index).is_some_and(|control| {
                matches!(
                    control,
                    Control::Shape(shape)
                        if matches!(shape.as_ref(), crate::model::shape::ShapeObject::Ole(_))
                            && !shape.common().treat_as_char
                )
            })
        }

        fn ole_object_caret_metrics(
            para: &Paragraph,
            styles: &crate::renderer::style_resolver::ResolvedStyleSet,
            ole_top: f64,
        ) -> (f64, f64) {
            let line_height = para
                .line_segs
                .first()
                .map(|line| {
                    crate::renderer::hwpunit_to_px(line.line_height, crate::renderer::DEFAULT_DPI)
                })
                .filter(|height| *height > 0.0)
                .unwrap_or(13.0);
            let text_height = para
                .line_segs
                .first()
                .map(|line| {
                    crate::renderer::hwpunit_to_px(line.text_height, crate::renderer::DEFAULT_DPI)
                })
                .filter(|height| *height > 0.0)
                .unwrap_or(line_height);
            let baseline = para
                .line_segs
                .first()
                .map(|line| {
                    crate::renderer::hwpunit_to_px(
                        line.baseline_distance,
                        crate::renderer::DEFAULT_DPI,
                    )
                })
                .filter(|baseline| *baseline > 0.0)
                .unwrap_or(text_height * 0.85);
            let font_size = para
                .char_shape_id_at(0)
                .and_then(|id| styles.char_styles.get(id as usize))
                .map(|style| style.font_size)
                .filter(|size| *size > 0.0)
                .unwrap_or(text_height)
                .max(10.0);
            let caret_height = font_size.min(line_height.max(font_size));
            let caret_y = ole_top + (baseline - caret_height * 0.85).max(0.0);
            (caret_y, caret_height)
        }

        fn find_ole_object_cursor_hit(
            node: &RenderNode,
            sec: usize,
            para_idx: usize,
            render_para: Option<&Paragraph>,
            styles: &crate::renderer::style_resolver::ResolvedStyleSet,
            offset: usize,
            page_index: u32,
        ) -> Option<CursorHit> {
            if offset != 0 {
                return None;
            }

            let control_ref = match &node.node_type {
                RenderNodeType::RawSvg(raw_node) => raw_node.control_ref.as_ref(),
                RenderNodeType::Placeholder(placeholder_node) => {
                    placeholder_node.control_ref.as_ref()
                }
                _ => None,
            };
            if let Some(control_ref) = control_ref.filter(|control_ref| control_ref.kind == "ole") {
                if control_ref.section_index == sec
                    && control_ref.para_index == para_idx
                    && render_para.is_some_and(|para| {
                        is_non_inline_ole_control(para, control_ref.control_index)
                    })
                {
                    let (y, height) = render_para
                        .map(|para| ole_object_caret_metrics(para, styles, node.bbox.y))
                        .unwrap_or((node.bbox.y, 10.0));
                    return Some(CursorHit {
                        page_index,
                        x: node.bbox.x + node.bbox.width,
                        y,
                        height,
                    });
                }
            }

            for child in &node.children {
                if let Some(hit) = find_ole_object_cursor_hit(
                    child,
                    sec,
                    para_idx,
                    render_para,
                    styles,
                    offset,
                    page_index,
                ) {
                    return Some(hit);
                }
            }
            None
        }

        if let Some(hit) = find_ole_object_cursor_hit(
            &tree.root,
            section_idx,
            para_idx,
            self.get_render_paragraph_ref(section_idx, para_idx).ok(),
            &self.styles,
            char_offset,
            first_page,
        ) {
            return Ok(format!(
                "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                hit.page_index, hit.x, hit.y, hit.height
            ));
        }

        if let Some(line_hit) = find_para_line(
            &tree.root,
            section_idx,
            para_idx,
            is_list_para,
            list_marker_char_shape_id,
            list_marker_body_dx,
            &self.styles,
        ) {
            let x = line_hit.cursor_x(is_list_para, char_offset);
            let y = line_hit.y;
            let h = line_hit.height;
            // 인라인 도형 컨트롤이 있는 경우: char_offset에 따라 x 위치 조정
            let adjusted_x = if char_offset > 0 {
                // 해당 문단의 인라인 Shape/Picture/Table 노드 bbox를 수집
                fn collect_inline_bboxes(
                    node: &RenderNode,
                    sec: usize,
                    para: usize,
                    render_para: Option<&Paragraph>,
                    bboxes: &mut Vec<(f64, f64)>,
                ) {
                    fn is_caret_control(
                        render_para: Option<&Paragraph>,
                        control_index: Option<usize>,
                    ) -> bool {
                        let Some(ci) = control_index else {
                            return false;
                        };
                        render_para
                            .and_then(|para| para.controls.get(ci))
                            .is_some_and(is_treat_as_char_object_control)
                    }

                    match &node.node_type {
                        RenderNodeType::Line(ln)
                            if ln.section_index == Some(sec) && ln.para_index == Some(para) =>
                        {
                            if is_caret_control(render_para, ln.control_index) {
                                bboxes.push((node.bbox.x, node.bbox.x + node.bbox.width));
                            }
                        }
                        RenderNodeType::Rectangle(rn)
                            if rn.section_index == Some(sec) && rn.para_index == Some(para) =>
                        {
                            if is_caret_control(render_para, rn.control_index) {
                                bboxes.push((node.bbox.x, node.bbox.x + node.bbox.width));
                            }
                        }
                        RenderNodeType::Ellipse(en)
                            if en.section_index == Some(sec) && en.para_index == Some(para) =>
                        {
                            if is_caret_control(render_para, en.control_index) {
                                bboxes.push((node.bbox.x, node.bbox.x + node.bbox.width));
                            }
                        }
                        RenderNodeType::Table(tn)
                            if tn.section_index == Some(sec) && tn.para_index == Some(para) =>
                        {
                            if is_caret_control(render_para, tn.control_index) {
                                bboxes.push((node.bbox.x, node.bbox.x + node.bbox.width));
                            }
                        }
                        RenderNodeType::Image(im)
                            if im.section_index == Some(sec) && im.para_index == Some(para) =>
                        {
                            if is_caret_control(render_para, im.control_index) {
                                bboxes.push((node.bbox.x, node.bbox.x + node.bbox.width));
                            }
                        }
                        _ => {}
                    }
                    for child in &node.children {
                        collect_inline_bboxes(child, sec, para, render_para, bboxes);
                    }
                }
                let mut bboxes = Vec::new();
                let render_para = self.get_render_paragraph_ref(section_idx, para_idx).ok();
                collect_inline_bboxes(&tree.root, section_idx, para_idx, render_para, &mut bboxes);
                bboxes.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));

                if char_offset <= bboxes.len() && !bboxes.is_empty() {
                    if char_offset >= bboxes.len() {
                        // 마지막 도형 뒤
                        bboxes.last().map_or(x, |b| b.1)
                    } else {
                        // char_offset번째 도형의 왼쪽
                        bboxes[char_offset].0
                    }
                } else {
                    x
                }
            } else {
                x
            };

            return Ok(format!(
                "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                first_page, adjusted_x, y, h
            ));
        }

        Err(HwpError::RenderError(format!(
            "커서 위치를 찾을 수 없습니다: sec={}, para={}, offset={}",
            section_idx, para_idx, char_offset
        )))
    }

    /// 페이지 좌표에서 문서 위치 찾기 (네이티브)
    pub fn hit_test_native(&self, page_num: u32, x: f64, y: f64) -> Result<String, HwpError> {
        use crate::renderer::layout::{CellContext, CellPathEntry};
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree_cached(page_num)?;

        // 문자 위치를 미리 계산한 TextRun 정보
        struct RunInfo {
            section_index: usize,
            paragraph_index: usize,
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
            // 셀/글상자 컨텍스트 (본문 텍스트는 None)
            cell_context: Option<CellContext>,
            is_textbox: bool,
            // 소속 칼럼 인덱스 (다단 지원)
            column_index: Option<u16>,
            // 소속 표 RenderNode id. 중첩 표에서 같은 cell_index가 반복되므로
            // TextRun과 TableCell bbox를 같은 표 단위로 묶는 데 사용한다.
            table_id: Option<u32>,
        }

        /// 안내문(guide text) TextRun 정보 (char_start: None)
        struct GuideRunInfo {
            section_index: usize,
            paragraph_index: usize,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
            cell_context: Option<CellContext>,
        }

        /// 셀 bbox 정보
        struct CellBboxInfo {
            table_id: Option<u32>,
            section_index: usize,
            parent_para_index: usize,
            control_index: usize,
            cell_index: usize,
            text_direction: u8,
            x: f64,
            y: f64,
            w: f64,
            h: f64,
            // Table 노드에서 meta가 채워졌는지 여부 (false이면 TextRun에서만 보완됨)
            has_meta: bool,
            cell_context: Option<CellContext>,
        }

        /// [Task #919] 글상자(TextBox) bbox 정보 — Shape 컨트롤의 외곽 도형 노드
        /// (Rectangle/Ellipse/Path) 가 layout_textbox_content 로 자식에 텍스트를 가진 경우.
        /// 글상자 안 빈 영역 클릭 시 첫 paragraph 진입에 사용.
        struct TextBoxBboxInfo {
            section_index: usize,
            parent_para_index: usize,
            control_index: usize,
            x: f64,
            y: f64,
            w: f64,
            h: f64,
        }

        fn table_ctx_from_node(
            node: &RenderNode,
            current_table_ctx: Option<&CellContext>,
            current_cell_ctx: Option<&CellContext>,
        ) -> Option<CellContext> {
            if let RenderNodeType::Table(ref tn) = node.node_type {
                match (tn.para_index, tn.control_index) {
                    (Some(pi), Some(ci)) => {
                        if let Some(parent_ctx) = current_cell_ctx {
                            let mut ctx = parent_ctx.clone();
                            if let Some(last) = ctx.path.last_mut() {
                                last.cell_para_index = pi;
                            }
                            ctx.path.push(CellPathEntry {
                                control_index: ci,
                                cell_index: 0,
                                cell_para_index: 0,
                                text_direction: 0,
                            });
                            Some(ctx)
                        } else {
                            Some(CellContext {
                                in_textbox: false,
                                parent_para_index: pi,
                                path: vec![CellPathEntry {
                                    control_index: ci,
                                    cell_index: 0,
                                    cell_para_index: 0,
                                    text_direction: 0,
                                }],
                            })
                        }
                    }
                    _ => current_table_ctx.cloned(),
                }
            } else {
                current_table_ctx.cloned()
            }
        }

        fn cell_ctx_for_table_cell(
            table_ctx: Option<&CellContext>,
            cell_index: usize,
            cell_para_index: usize,
            text_direction: u8,
        ) -> Option<CellContext> {
            table_ctx.map(|ctx| {
                let mut cell_ctx = ctx.clone();
                if let Some(last) = cell_ctx.path.last_mut() {
                    last.cell_index = cell_index;
                    last.cell_para_index = cell_para_index;
                    last.text_direction = text_direction;
                }
                cell_ctx
            })
        }

        fn effective_cell_context(
            text_ctx: &Option<CellContext>,
            traversal_ctx: &Option<CellContext>,
        ) -> Option<CellContext> {
            match (text_ctx, traversal_ctx) {
                (Some(text_ctx), Some(traversal_ctx))
                    if traversal_ctx.path.len() > text_ctx.path.len() =>
                {
                    let mut ctx = traversal_ctx.clone();
                    if let (Some(dst), Some(src)) = (ctx.path.last_mut(), text_ctx.path.last()) {
                        dst.cell_para_index = src.cell_para_index;
                        dst.text_direction = src.text_direction;
                    }
                    Some(ctx)
                }
                (Some(text_ctx), _) => Some(text_ctx.clone()),
                (None, _) => None,
            }
        }

        fn collect_runs(
            node: &RenderNode,
            runs: &mut Vec<RunInfo>,
            guide_runs: &mut Vec<GuideRunInfo>,
            cell_bboxes: &mut Vec<CellBboxInfo>,
            textbox_bboxes: &mut Vec<TextBoxBboxInfo>,
            current_column: Option<u16>,
            current_table_id: Option<u32>,
            // Table 노드에서 전파되는 (section_index, parent_para_index, control_index)
            current_table_meta: Option<(usize, usize, usize)>,
            current_table_ctx: Option<CellContext>,
            current_cell_ctx: Option<CellContext>,
        ) {
            // Column 노드 진입 시 칼럼 인덱스 전파
            let col = if let RenderNodeType::Column(col_idx) = node.node_type {
                Some(col_idx)
            } else {
                current_column
            };
            // Table 노드 진입 시 section_index / parent_para_index / control_index 전파
            let current_table_id = if matches!(node.node_type, RenderNodeType::Table(_)) {
                Some(node.id)
            } else {
                current_table_id
            };
            let table_ctx =
                table_ctx_from_node(node, current_table_ctx.as_ref(), current_cell_ctx.as_ref());
            let table_section_index = if let RenderNodeType::Table(ref tn) = node.node_type {
                tn.section_index
                    .or_else(|| current_table_meta.map(|(si, _, _)| si))
            } else {
                current_table_meta.map(|(si, _, _)| si)
            };
            let table_meta = if let Some(ref ctx) = table_ctx {
                table_section_index.and_then(|si| {
                    ctx.path
                        .first()
                        .map(|e| (si, ctx.parent_para_index, e.control_index))
                })
            } else if let RenderNodeType::Table(ref tn) = node.node_type {
                match (tn.section_index, tn.para_index, tn.control_index) {
                    (Some(si), Some(pi), Some(ci)) => Some((si, pi, ci)),
                    _ => current_table_meta,
                }
            } else {
                current_table_meta
            };
            let mut child_cell_ctx = current_cell_ctx.clone();
            // [Task #919] 글상자(TextBox) bbox 수집 — Shape 컨트롤 (Rectangle/Ellipse/Path)
            // 노드가 layout_textbox_content 로 자식에 텍스트를 가진 경우. 외곽 도형 노드의
            // section/para/control 메타 + bbox 가 모두 채워져 있으므로 그대로 사용.
            // (글상자 안 빈 영역 클릭 시 첫 paragraph 진입에 사용)
            let textbox_meta: Option<(usize, usize, usize)> = match &node.node_type {
                RenderNodeType::Rectangle(r) => {
                    match (r.section_index, r.para_index, r.control_index) {
                        (Some(si), Some(pi), Some(ci)) => Some((si, pi, ci)),
                        _ => None,
                    }
                }
                RenderNodeType::Ellipse(e) => {
                    match (e.section_index, e.para_index, e.control_index) {
                        (Some(si), Some(pi), Some(ci)) => Some((si, pi, ci)),
                        _ => None,
                    }
                }
                RenderNodeType::Path(p) => match (p.section_index, p.para_index, p.control_index) {
                    (Some(si), Some(pi), Some(ci)) => Some((si, pi, ci)),
                    _ => None,
                },
                _ => None,
            };
            if let Some((si, pi, ci)) = textbox_meta {
                textbox_bboxes.push(TextBoxBboxInfo {
                    section_index: si,
                    parent_para_index: pi,
                    control_index: ci,
                    x: node.bbox.x,
                    y: node.bbox.y,
                    w: node.bbox.width,
                    h: node.bbox.height,
                });
            }
            // TableCell 노드의 bbox 수집
            if let RenderNodeType::TableCell(ref tc) = node.node_type {
                if let Some(cell_idx) = tc.model_cell_index {
                    let cell_ctx = cell_ctx_for_table_cell(
                        table_ctx.as_ref(),
                        cell_idx as usize,
                        0,
                        tc.text_direction,
                    );
                    child_cell_ctx = cell_ctx.clone();
                    // table_meta가 있으면 즉시 보완, 없으면 자식 TextRun에서 보완
                    let (si, ppi, ci, has_meta) = table_meta
                        .map(|(si, ppi, ci)| (si, ppi, ci, true))
                        .unwrap_or((0, 0, 0, false));
                    cell_bboxes.push(CellBboxInfo {
                        table_id: current_table_id,
                        section_index: si,
                        parent_para_index: ppi,
                        control_index: ci,
                        cell_index: cell_idx as usize,
                        text_direction: tc.text_direction,
                        x: node.bbox.x,
                        y: node.bbox.y,
                        w: node.bbox.width,
                        h: node.bbox.height,
                        has_meta,
                        cell_context: cell_ctx,
                    });
                }
            }
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if let (Some(si), Some(pi)) = (text_run.section_index, text_run.para_index) {
                    let cell_context =
                        effective_cell_context(&text_run.cell_context, &current_cell_ctx);
                    // 머리말/꼬리말·각주 마커 TextRun 건너뛰기
                    if pi >= (usize::MAX - 3000) { /* skip marker runs */
                    } else if let Some(cs) = text_run.char_start {
                        let ecc = effective_char_count(text_run);
                        let positions = if text_run.char_overlap.is_some() && ecc == 1 {
                            vec![0.0, node.bbox.width]
                        } else {
                            text_run.replay_positions_for(&text_run.text).into_owned()
                        };
                        runs.push(RunInfo {
                            section_index: si,
                            paragraph_index: pi,
                            char_start: cs,
                            char_count: ecc,
                            char_positions: positions,
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            bbox_w: node.bbox.width,
                            bbox_h: node.bbox.height,
                            cell_context,
                            is_textbox: false,
                            column_index: col,
                            table_id: current_table_id,
                        });
                    } else {
                        // char_start: None → 안내문 TextRun
                        guide_runs.push(GuideRunInfo {
                            section_index: si,
                            paragraph_index: pi,
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            bbox_w: node.bbox.width,
                            bbox_h: node.bbox.height,
                            cell_context,
                        });
                    }
                }
            }
            for child in &node.children {
                collect_runs(
                    child,
                    runs,
                    guide_runs,
                    cell_bboxes,
                    textbox_bboxes,
                    col,
                    current_table_id,
                    table_meta,
                    table_ctx.clone(),
                    child_cell_ctx.clone(),
                );
            }
        }

        /// 줄 단위 x 해석을 모듈 스코프 `resolve_x_on_line` 에 위임한다.
        /// (모듈 스코프 함수는 문서/페이지 트리 없이 단위 테스트가 가능하다.)
        fn resolve_x_on_line(line_runs: &[&RunInfo], x: f64) -> (usize, usize) {
            let views: Vec<super::cursor_rect::LineRunView> = line_runs
                .iter()
                .map(|r| super::cursor_rect::LineRunView {
                    bbox_x: r.bbox_x,
                    bbox_w: r.bbox_w,
                    char_start: r.char_start,
                    char_count: r.char_count,
                    char_positions: &r.char_positions,
                })
                .collect();
            super::cursor_rect::resolve_x_on_line(&views, x)
        }

        fn format_hit(run: &RunInfo, offset: usize, page_num: u32) -> String {
            let base = format!(
                "\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":{}",
                run.section_index, run.paragraph_index, offset
            );
            // 커서 x 좌표: char_positions로 정확한 위치 계산
            let cursor_x = if offset <= run.char_start {
                run.bbox_x
            } else {
                let local_idx = offset - run.char_start;
                if local_idx < run.char_positions.len() {
                    run.bbox_x + run.char_positions[local_idx]
                } else if !run.char_positions.is_empty() {
                    run.bbox_x + run.char_positions.last().copied().unwrap_or(0.0)
                } else {
                    run.bbox_x
                }
            };
            let cursor_rect = format!(
                ",\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                page_num, cursor_x, run.bbox_y, run.bbox_h
            );
            if let Some(ref ctx) = run.cell_context {
                let outer = ctx.path.first();
                let tb = if run.is_textbox {
                    ",\"isTextBox\":true"
                } else {
                    ""
                };
                // cellPath: 전체 중첩 경로 배열
                let path_entries: Vec<String> = ctx
                    .path
                    .iter()
                    .map(|e| {
                        format!(
                            "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                            e.control_index, e.cell_index, e.cell_para_index
                        )
                    })
                    .collect();
                let cell_path = format!(",\"cellPath\":[{}]", path_entries.join(","));
                if let Some(outer) = outer {
                    format!("{{{},\"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}{}{}{}}}",
                        base, ctx.parent_para_index, outer.control_index, outer.cell_index, outer.cell_para_index,
                        cell_path, tb, cursor_rect)
                } else {
                    format!("{{{}{}}}", base, cursor_rect)
                }
            } else {
                format!("{{{}{}}}", base, cursor_rect)
            }
        }

        /// [Task #919] 글상자 빈 영역 클릭 시 글상자 첫 paragraph (cellParaIndex=0)
        /// 시작 위치로 진입 응답을 만든다. table-in-tbox.hwp 의 글상자 안 표 셀
        /// 빈 영역 등을 한컴 UX 정합으로 처리.
        fn format_textbox_entry(tb: &TextBoxBboxInfo, page_num: u32) -> String {
            // cell_index=0 (글상자 외곽 자체), cellParaIndex=0 (글상자 첫 paragraph)
            // 캐럿: 글상자 좌상단 + 약간 안쪽 패딩.
            let caret_h = (tb.h - 4.0).max(12.0).min(20.0);
            format!(
                "{{\"sectionIndex\":{},\"paragraphIndex\":0,\"charOffset\":0,\
                 \"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":0,\"cellParaIndex\":0,\
                 \"cellPath\":[{{\"controlIndex\":{},\"cellIndex\":0,\"cellParaIndex\":0}}],\
                 \"isTextBox\":true,\
                 \"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                tb.section_index,
                tb.parent_para_index,
                tb.control_index,
                tb.control_index,
                page_num,
                tb.x + 2.0,
                tb.y + 2.0,
                caret_h
            )
        }

        fn text_run_hit_allowed_by_textbox_bbox(
            run: &RunInfo,
            textbox_bboxes: &[TextBoxBboxInfo],
            x: f64,
            y: f64,
        ) -> bool {
            if !run.is_textbox {
                return true;
            }
            let Some(ctx) = run.cell_context.as_ref() else {
                return false;
            };
            let Some(outer) = ctx.path.first() else {
                return false;
            };
            textbox_bboxes.iter().any(|tb| {
                tb.section_index == run.section_index
                    && tb.parent_para_index == ctx.parent_para_index
                    && tb.control_index == outer.control_index
                    && x >= tb.x
                    && x <= tb.x + tb.w
                    && y >= tb.y
                    && y <= tb.y + tb.h
            })
        }

        fn same_cell_context(a: &Option<CellContext>, b: &Option<CellContext>) -> bool {
            match (a, b) {
                (None, None) => true,
                (Some(a), Some(b)) => {
                    a.parent_para_index == b.parent_para_index
                        && a.path.len() == b.path.len()
                        && a.path.iter().zip(&b.path).all(|(a, b)| {
                            a.control_index == b.control_index
                                && a.cell_index == b.cell_index
                                && a.cell_para_index == b.cell_para_index
                                && a.text_direction == b.text_direction
                        })
                }
                _ => false,
            }
        }

        fn inline_image_caret_metrics(y: f64, h: f64) -> (f64, f64) {
            let fallback_h = 12.0;
            let baseline = h * 0.85;
            let ascent = fallback_h * 0.8;
            (y + (baseline - ascent).max(0.0), fallback_h)
        }

        fn collect_body_inline_image_hits(
            core: &DocumentCore,
            node: &RenderNode,
            hits: &mut Vec<(usize, usize, usize, f64, f64, f64, f64)>,
        ) {
            if let RenderNodeType::Image(ref img) = node.node_type {
                if img.cell_context.is_none() {
                    if let (Some(si), Some(pi), Some(ci)) =
                        (img.section_index, img.para_index, img.control_index)
                    {
                        let char_offset = core
                            .document
                            .sections
                            .get(si)
                            .and_then(|section| section.paragraphs.get(pi))
                            .and_then(|para| {
                                let ctrl = para.controls.get(ci)?;
                                if !is_treat_as_char_object_control(ctrl) {
                                    return None;
                                }
                                // 묶음 자식 Image는 외곽 Group 인덱스를 물려받고 paint bbox가
                                // 페이지 전체로 팽창될 수 있다. 그 bbox를 본문 인라인 hit로
                                // 등록하면 표/셀 검사보다 먼저 선점한다 (#4753).
                                if is_group_shape_control(ctrl) {
                                    return None;
                                }
                                find_logical_control_positions(para).get(ci).copied()
                            });
                        if let Some(char_offset) = char_offset {
                            hits.push((
                                si,
                                pi,
                                char_offset,
                                node.bbox.x,
                                node.bbox.y,
                                node.bbox.width,
                                node.bbox.height,
                            ));
                        }
                    }
                }
            }

            for child in &node.children {
                collect_body_inline_image_hits(core, child, hits);
            }
        }

        fn format_body_inline_image_hit(
            page_num: u32,
            si: usize,
            pi: usize,
            offset: usize,
            x: f64,
            y: f64,
            h: f64,
        ) -> String {
            format!(
                "{{\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":{},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                si, pi, offset, page_num, x, y, h
            )
        }

        let mut runs: Vec<RunInfo> = Vec::new();
        let mut guide_runs: Vec<GuideRunInfo> = Vec::new();
        let mut cell_bboxes: Vec<CellBboxInfo> = Vec::new();
        let mut textbox_bboxes: Vec<TextBoxBboxInfo> = Vec::new();
        collect_runs(
            &tree.root,
            &mut runs,
            &mut guide_runs,
            &mut cell_bboxes,
            &mut textbox_bboxes,
            None,
            None,
            None,
            None,
            None,
        );

        // cell_bboxes의 section_index/parent_para_index/control_index/cellPath를 runs로 보완.
        // Table 노드에서 이미 채워진 최외곽 메타는 유지하되, 중첩 표의 Table 노드에는
        // 메타가 없을 수 있으므로 같은 RenderNode 표 안의 TextRun cell_context를 템플릿으로 쓴다.
        // cell_index는 표마다 반복되므로 같은 table_id 범위 안에서만 매칭해야 한다.
        for cb in &mut cell_bboxes {
            let same_cell_run = runs.iter().find(|r| {
                r.table_id == cb.table_id
                    && r.cell_context.as_ref().is_some_and(|ctx| {
                        ctx.innermost()
                            .is_some_and(|e| e.cell_index == cb.cell_index)
                    })
            });
            let template_run = same_cell_run.or_else(|| {
                runs.iter()
                    .find(|r| r.table_id == cb.table_id && r.cell_context.is_some())
            });

            if let Some(run) = template_run {
                if let Some(ref ctx) = run.cell_context {
                    let mut cell_ctx = ctx.clone();
                    if let Some(last) = cell_ctx.path.last_mut() {
                        last.cell_index = cb.cell_index;
                        last.cell_para_index = 0;
                        last.text_direction = cb.text_direction;
                    }
                    cb.section_index = run.section_index;
                    cb.parent_para_index = cell_ctx.parent_para_index;
                    if let Some(first) = cell_ctx.path.first() {
                        cb.control_index = first.control_index;
                    }
                    cb.cell_context = Some(cell_ctx);
                    cb.has_meta = true;
                }
            }
        }

        // is_textbox 정확 판별: document의 실제 컨트롤 타입으로 재확인
        for run in &mut runs {
            if let Some(ref ctx) = run.cell_context {
                let Some(outer) = ctx.path.first() else {
                    run.is_textbox = false;
                    continue;
                };
                if outer.cell_index == 0 {
                    let is_shape = self
                        .document
                        .sections
                        .get(run.section_index)
                        .and_then(|s| s.paragraphs.get(ctx.parent_para_index))
                        .and_then(|p| p.controls.get(outer.control_index))
                        .map(|c| matches!(c, Control::Shape(_)))
                        .unwrap_or(false);
                    run.is_textbox = is_shape;
                } else {
                    run.is_textbox = false;
                }
            } else {
                run.is_textbox = false;
            }
        }

        for run in &mut runs {
            if let Some(ref mut ctx) = run.cell_context {
                self.repair_unwrapped_wrapper_cell_context(run.section_index, ctx);
            }
        }
        for cb in &mut cell_bboxes {
            if let Some(ref mut ctx) = cb.cell_context {
                self.repair_unwrapped_wrapper_cell_context(cb.section_index, ctx);
                if let Some(outer) = ctx.path.first() {
                    cb.parent_para_index = ctx.parent_para_index;
                    cb.control_index = outer.control_index;
                }
                if let Some(inner) = ctx.innermost() {
                    cb.cell_index = inner.cell_index;
                }
            }
        }

        let mut inline_image_hits = Vec::new();
        collect_body_inline_image_hits(self, &tree.root, &mut inline_image_hits);
        for (si, pi, char_offset, ix, iy, iw, ih) in inline_image_hits {
            let (caret_y, caret_h) = inline_image_caret_metrics(iy, ih);
            let right = ix + iw;
            if x >= ix && x <= right && y >= iy && y <= iy + ih {
                let offset = if x > ix + iw / 2.0 {
                    char_offset + 1
                } else {
                    char_offset
                };
                let caret_x = if offset == char_offset { ix } else { right };
                return Ok(format_body_inline_image_hit(
                    page_num, si, pi, offset, caret_x, caret_y, caret_h,
                ));
            }
            if x >= right && x <= right + caret_h && y >= caret_y && y <= caret_y + caret_h {
                return Ok(format_body_inline_image_hit(
                    page_num,
                    si,
                    pi,
                    char_offset + 1,
                    right,
                    caret_y,
                    caret_h,
                ));
            }
            if x <= ix && x >= ix - caret_h && y >= caret_y && y <= caret_y + caret_h {
                return Ok(format_body_inline_image_hit(
                    page_num,
                    si,
                    pi,
                    char_offset,
                    ix,
                    caret_y,
                    caret_h,
                ));
            }
        }

        // 0. 안내문(guide text) 히트 검사 — 필드 클릭 진입
        // 안내문 위 클릭 시 해당 필드의 시작 위치로 커서를 보낸다.
        for gr in &guide_runs {
            if x >= gr.bbox_x
                && x <= gr.bbox_x + gr.bbox_w
                && y >= gr.bbox_y
                && y <= gr.bbox_y + gr.bbox_h
            {
                let guide_char_offset = runs
                    .iter()
                    .find(|run| {
                        run.section_index == gr.section_index
                            && run.paragraph_index == gr.paragraph_index
                            && run.char_count == 0
                            && same_cell_context(&run.cell_context, &gr.cell_context)
                            && (run.bbox_x - gr.bbox_x).abs() < 0.5
                            && (run.bbox_y - gr.bbox_y).abs() < 1.0
                    })
                    .map(|run| run.char_start);
                // 필드 시작 위치 찾기: 해당 문단의 field_ranges에서 검색
                if let Some(field_hit) = self.find_field_hit_for_guide(
                    gr.section_index,
                    gr.paragraph_index,
                    &gr.cell_context,
                    page_num,
                    guide_char_offset,
                    gr.bbox_x,
                    gr.bbox_y,
                    gr.bbox_h,
                ) {
                    return Ok(field_hit);
                }
            }
        }

        if runs.is_empty() {
            // 텍스트가 없는 페이지: 첫 구역의 첫 문단 시작 반환
            let (page_content, _, _) = self.find_page(page_num)?;
            return Ok(format!(
                "{{\"sectionIndex\":{},\"paragraphIndex\":0,\"charOffset\":0}}",
                page_content.section_index
            ));
        }

        // 0.5. 인라인 Shape 히트 검사 (treat_as_char 도형 클릭)
        // inline_shape_positions에 등록된 Shape의 bbox를 검사하여
        // 클릭 시 해당 Shape의 텍스트 위치(char_offset)를 반환
        for (key, &(sx, sy)) in tree.inline_shape_positions() {
            let (si, pi, ci, ref cell_path) = *key;
            // [Task #1151 v4] 셀 안 inline picture/shape 도 hit-test 진입.
            // cell_path 가 있으면 셀 안 paragraph 에서 control 을 조회, 없으면 outer
            // paragraph 에서 조회 (기존 본문 path).
            if let Some(section) = self.document.sections.get(si) {
                let target_para = if cell_path.is_empty() {
                    section.paragraphs.get(pi)
                } else {
                    // cell_path 의 마지막 entry = picture/shape 가 있는 셀의 (table_ci,
                    // cell_idx, cell_para_idx). 중첩 표는 본 분기에서 첫 외곽 표 하나만
                    // resolve (셀 안 표 안 picture 는 후속 task).
                    let last = cell_path.last().copied().unwrap_or((0, 0, 0));
                    section
                        .paragraphs
                        .get(pi)
                        .and_then(|p| p.controls.get(last.0))
                        .and_then(|c| match c {
                            Control::Table(t) => t.cells.get(last.1),
                            _ => None,
                        })
                        .and_then(|cell| cell.paragraphs.get(last.2))
                };
                if let Some(para) = target_para {
                    if let Some(ctrl) = para.controls.get(ci) {
                        let (sw, sh) = match ctrl {
                            Control::Shape(s) => (
                                crate::renderer::hwpunit_to_px(
                                    s.common().width as i32,
                                    crate::renderer::DEFAULT_DPI,
                                ),
                                crate::renderer::hwpunit_to_px(
                                    s.common().height as i32,
                                    crate::renderer::DEFAULT_DPI,
                                ),
                            ),
                            Control::Picture(p) => (
                                crate::renderer::hwpunit_to_px(
                                    p.common.width as i32,
                                    crate::renderer::DEFAULT_DPI,
                                ),
                                crate::renderer::hwpunit_to_px(
                                    p.common.height as i32,
                                    crate::renderer::DEFAULT_DPI,
                                ),
                            ),
                            _ => continue,
                        };
                        if x >= sx && x <= sx + sw && y >= sy && y <= sy + sh {
                            // [Task #919] 글상자(Shape with text_box) 영역 hit — 본문
                            // TextRun 위치가 아닌 메인 매칭으로 fall-through 한다.
                            // 메인 매칭 (cell hit / textbox hit / body hit) 이 글상자
                            // 안 표 셀 / 글상자 빈 영역 / 본문 우선순위로 처리.
                            // (이 분기에서 글상자 안 표 셀을 가로채면 안 됨)
                            let shape_has_textbox = match ctrl {
                                Control::Shape(s) => match s.as_ref() {
                                    crate::model::shape::ShapeObject::Rectangle(r) => {
                                        r.drawing.text_box.is_some()
                                    }
                                    crate::model::shape::ShapeObject::Ellipse(e) => {
                                        e.drawing.text_box.is_some()
                                    }
                                    crate::model::shape::ShapeObject::Polygon(p) => {
                                        p.drawing.text_box.is_some()
                                    }
                                    crate::model::shape::ShapeObject::Arc(a) => {
                                        a.drawing.text_box.is_some()
                                    }
                                    crate::model::shape::ShapeObject::Curve(c) => {
                                        c.drawing.text_box.is_some()
                                    }
                                    _ => false,
                                },
                                _ => false,
                            };
                            if shape_has_textbox {
                                // 글상자는 메인 매칭에서 처리 — 0.5 분기 break.
                                break;
                            }
                            if !is_treat_as_char_object_control(ctrl) {
                                // 자리차지/글 앞으로/글 뒤로 개체는 본문 문자 슬롯이 아니므로
                                // 그림 bbox 클릭을 커서 앞/뒤 offset으로 변환하지 않는다.
                                continue;
                            }
                            let ctrl_positions =
                                crate::document_core::helpers::find_logical_control_positions(para);
                            let char_offset = ctrl_positions.get(ci).copied().unwrap_or(0);
                            // 클릭이 Shape 오른쪽 절반이면 Shape 뒤(offset+1)
                            let offset = if x > sx + sw / 2.0 {
                                char_offset + 1
                            } else {
                                char_offset
                            };
                            // 가장 가까운 TextRun을 찾아 format_hit 호출
                            let nearest = runs
                                .iter()
                                .enumerate()
                                .filter(|(_, r)| {
                                    r.section_index == si
                                        && r.paragraph_index == pi
                                        && r.cell_context.is_none()
                                })
                                .min_by_key(|(_, r)| {
                                    if offset >= r.char_start
                                        && offset <= r.char_start + r.char_count
                                    {
                                        0i64
                                    } else {
                                        (offset as i64 - r.char_start as i64).abs()
                                    }
                                });
                            if let Some((idx, _)) = nearest {
                                return Ok(format_hit(&runs[idx], offset, page_num));
                            }
                            // TextRun이 없으면 기본 반환
                            // [Task #1151 v4] cell_path 가 있으면 cellPath / innerControlIdx
                            // 정보 추가 — studio 측 picture select / 그림 속성 대화상자가
                            // cellPath 인식하여 셀 안 picture 를 정상 처리.
                            let cell_path_str = if cell_path.is_empty() {
                                String::new()
                            } else {
                                let entries: Vec<String> = cell_path
                                    .iter()
                                    .map(|(t, c, p)| format!("[{},{},{}]", t, c, p))
                                    .collect();
                                format!(
                                    ",\"cellPath\":[{}],\"innerControlIdx\":{}",
                                    entries.join(","),
                                    ci
                                )
                            };
                            return Ok(format!(
                                "{{\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":{},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}{}}}",
                                si, pi, offset, page_num, sx, sy, sh, cell_path_str
                            ));
                        }
                    }
                }
            }
        }

        // 1. 정확한 bbox 히트 검사
        // 셀/글상자 TextRun을 본문 TextRun보다 우선한다.
        // (본문 TextRun이 컨트롤 높이만큼 큰 bbox를 가져서 글상자 영역을 덮을 수 있음)
        // 셀 후보가 여럿이면 bbox 면적이 가장 작은 것 = 가장 specific 한 셀 선택.
        // (Task #717 의 cell_bboxes selection L671-675 와 동일 best-match 패턴 — closes #857.
        //  중첩 표에서 외곽 셀의 빈 placeholder TextRun (bbox 가 paragraph 영역 전체) 이
        //  inner cell 의 실제 TextRun (작은 bbox) 보다 트리 순서상 먼저 매칭되어
        //  외곽이 선점되던 결함 정정.)
        let mut hit_body: Option<(usize, usize)> = None; // (run_idx, char_offset)
        let mut hit_cell: Option<(usize, usize)> = None;
        let mut hit_cell_area: Option<i64> = None;
        for (i, run) in runs.iter().enumerate() {
            if !text_run_hit_allowed_by_textbox_bbox(run, &textbox_bboxes, x, y) {
                continue;
            }
            if x >= run.bbox_x
                && x <= run.bbox_x + run.bbox_w
                && y >= run.bbox_y
                && y <= run.bbox_y + run.bbox_h
            {
                let local_x = x - run.bbox_x;
                let char_offset = find_char_at_x(&run.char_positions, local_x);
                if run.cell_context.is_some() {
                    let area = (run.bbox_w.max(0.0) * run.bbox_h.max(0.0) * 1000.0) as i64;
                    if hit_cell_area.map_or(true, |best_area| area < best_area) {
                        hit_cell = Some((i, run.char_start + char_offset));
                        hit_cell_area = Some(area);
                    }
                } else if hit_body.is_none() {
                    hit_body = Some((i, run.char_start + char_offset));
                }
            }
        }

        // [Task #919] 우선순위 — 가장 specific 한 매칭부터:
        //   1. hit_cell (셀 안 텍스트 위 hit — best-match area)
        //   2. clicked_cell (셀 bbox 매칭 — 텍스트가 없는 빈 셀 포함)
        //      ⇒ 글상자 안 표의 빈 셀도 여기서 매칭
        //   3. textbox_hit (글상자 안 빈 영역 — 셀 없는 영역)
        //   4. hit_body (본문 fall-through)
        //
        // 글상자 안 표 셀 (textbox 안 cell) 매칭이 textbox 영역보다 specific 이므로
        // clicked_cell 을 textbox_hit 보다 먼저 처리한다.

        // 2. 셀 bbox 기반으로 클릭한 셀 판별 (글상자 안 표 셀 포함)
        // hit_cell 반환 전에 미리 계산한다 — 바깥 칸 run 이 안쪽 칸의 빈 영역·괘선을
        // 덮는지 판별하기 위해 필요 (#7442).
        let clicked_cell: Option<&CellBboxInfo> = cell_bboxes
            .iter()
            .filter(|cb| cb.has_meta)
            .filter(|cb| x >= cb.x && x <= cb.x + cb.w && y >= cb.y && y <= cb.y + cb.h)
            .min_by_key(|cb| ((cb.w.max(0.0) * cb.h.max(0.0)) * 1000.0) as i64);

        // [#7442] 중첩 표를 품은 바깥 칸의 run은 TAC 줄 높이만큼 bbox가 커서 안쪽 칸의
        // 빈 영역·괘선까지 덮는다. hit_cell이 있어도 클릭된 칸이 그 run보다 더 깊은
        // 경로(같은 parent_para_index 아래 run 경로를 (control,cell) 접두사로 갖는
        // 자손 칸)를 가리키면 run hit를 건너뛰고 그 칸 분기를 사용한다. 같은 깊이나
        // 무관한 경로에서는 지금처럼 텍스트 run 정밀도가 우선한다.
        let hit_cell = hit_cell.filter(|&(idx, _)| {
            match (
                runs[idx].cell_context.as_ref(),
                clicked_cell.and_then(|cb| cb.cell_context.as_ref()),
            ) {
                (Some(run_ctx), Some(cell_ctx)) => {
                    let clicked_is_descendant = cell_ctx.parent_para_index
                        == run_ctx.parent_para_index
                        && cell_ctx.path.len() > run_ctx.path.len()
                        && run_ctx.path.iter().zip(&cell_ctx.path).all(|(r, c)| {
                            r.control_index == c.control_index && r.cell_index == c.cell_index
                        });
                    !clicked_is_descendant
                }
                _ => true,
            }
        });

        if let Some((idx, offset)) = hit_cell {
            return Ok(format_hit(&runs[idx], offset, page_num));
        }

        // 클릭 좌표가 속한 칼럼 결정 (다단 지원)
        let click_column = self.find_column_at_x(page_num, x);

        // 셀 내부 클릭이면: 해당 셀의 run만 검색하여 가장 가까운 위치 반환
        if let Some(cb) = clicked_cell {
            let cell_runs: Vec<&RunInfo> = runs
                .iter()
                .filter(|r| {
                    r.cell_context.as_ref().is_some_and(|ctx| {
                        r.table_id == cb.table_id
                            && ctx.parent_para_index == cb.parent_para_index
                            && ctx
                                .innermost()
                                .is_some_and(|e| e.cell_index == cb.cell_index)
                    })
                })
                .collect();

            if !cell_runs.is_empty() {
                // 클릭이 속한 시각 줄(line)을 고른다.
                //   1순위: 클릭 y 가 글리프 bbox 안에 드는 run 의 줄
                //   2순위: (행간 여백 클릭) 클릭 y 에 세로로 가장 가까운 run 의 줄
                // 줄 식별은 run 의 bbox_y(줄 윗변)로 한다. 같은 줄의 run 은 bbox_y 가 같다.
                let line_y = cell_runs
                    .iter()
                    .filter(|r| y >= r.bbox_y && y <= r.bbox_y + r.bbox_h)
                    .map(|r| r.bbox_y)
                    .next()
                    .or_else(|| {
                        cell_runs
                            .iter()
                            .min_by(|a, b| {
                                let da = (y - (a.bbox_y + a.bbox_h / 2.0)).abs();
                                let db = (y - (b.bbox_y + b.bbox_h / 2.0)).abs();
                                da.partial_cmp(&db).unwrap()
                            })
                            .map(|r| r.bbox_y)
                    });

                if let Some(ly) = line_y {
                    let mut line_runs: Vec<&RunInfo> = cell_runs
                        .iter()
                        .copied()
                        .filter(|r| (r.bbox_y - ly).abs() < 1.0)
                        .collect();
                    line_runs.sort_by(|a, b| a.bbox_x.partial_cmp(&b.bbox_x).unwrap());
                    let (idx, offset) = resolve_x_on_line(&line_runs, x);
                    return Ok(format_hit(line_runs[idx], offset, page_num));
                }
                return Ok(format_hit(cell_runs[0], cell_runs[0].char_start, page_num));
            }

            // 양식 컨트롤(FormObject)만 있는 셀: TextRun이 없어 cell_runs가 비어있음.
            // table_meta(또는 runs)에서 채워진 meta로 커서 진입.
            if cb.has_meta {
                let caret_h = (cb.h - 4.0).max(12.0);
                if let Some(ref ctx) = cb.cell_context {
                    if let (Some(outer), Some(inner)) = (ctx.path.first(), ctx.innermost()) {
                        let path_entries: Vec<String> = ctx
                            .path
                            .iter()
                            .map(|e| {
                                format!(
                                    "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                                    e.control_index, e.cell_index, e.cell_para_index
                                )
                            })
                            .collect();
                        return Ok(format!(
                            "{{\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":0,\
                             \"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{},\
                             \"cellPath\":[{}],\
                             \"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                            cb.section_index, inner.cell_para_index,
                            ctx.parent_para_index, outer.control_index, outer.cell_index, outer.cell_para_index,
                            path_entries.join(","),
                            page_num,
                            cb.x + 2.0, cb.y + 2.0, caret_h
                        ));
                    }
                }
                return Ok(format!(
                    "{{\"sectionIndex\":{},\"paragraphIndex\":0,\"charOffset\":0,\
                     \"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":0,\
                     \"cellPath\":[{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":0}}],\
                     \"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                    cb.section_index,
                    cb.parent_para_index, cb.control_index, cb.cell_index,
                    cb.control_index, cb.cell_index,
                    page_num,
                    cb.x + 2.0, cb.y + 2.0, caret_h
                ));
            }
        }

        // [Task #919] 글상자 빈 영역 매칭 — clicked_cell 매칭 안 됐으면 글상자 시도.
        // 글상자 안 표 셀은 위쪽 clicked_cell 분기에서 이미 처리됨.
        // 후보 여럿이면 가장 작은 (가장 specific) 것 선택.
        let textbox_hit: Option<&TextBoxBboxInfo> = textbox_bboxes
            .iter()
            .filter(|tb| x >= tb.x && x <= tb.x + tb.w && y >= tb.y && y <= tb.y + tb.h)
            .min_by_key(|tb| ((tb.w.max(0.0) * tb.h.max(0.0)) * 1000.0) as i64);
        if let Some(tb) = textbox_hit {
            return Ok(format_textbox_entry(tb, page_num));
        }

        // 본문 hit (1차 hit 검사에서 발견된 본문 paragraph)
        if let Some((idx, offset)) = hit_body {
            return Ok(format_hit(&runs[idx], offset, page_num));
        }

        // 같은 줄(y 범위)에서 가장 가까운 본문 TextRun 찾기
        // 다단: 클릭 칼럼의 run만 필터
        let mut same_line_runs: Vec<&RunInfo> = runs
            .iter()
            .filter(|r| r.cell_context.is_none()) // 본문 run만
            .filter(|r| text_run_hit_allowed_by_textbox_bbox(r, &textbox_bboxes, x, y))
            .filter(|r| y >= r.bbox_y && y <= r.bbox_y + r.bbox_h)
            .filter(|r| {
                click_column.is_none() || r.column_index.is_none() || r.column_index == click_column
            })
            .collect();

        if !same_line_runs.is_empty() {
            same_line_runs.sort_by(|a, b| a.bbox_x.partial_cmp(&b.bbox_x).unwrap());
            // 줄 안에서 클릭 x 를 가장 가까운 문자 위치로 해석
            // (다중 run 줄의 run 경계 빈틈 포함 — 줄 끝으로 스냅하지 않음)
            let (idx, offset) = resolve_x_on_line(&same_line_runs, x);
            return Ok(format_hit(same_line_runs[idx], offset, page_num));
        }

        // 3. 가장 가까운 줄 찾기 (y 거리 기준)
        // 다단: 클릭 칼럼의 run을 우선 후보로 사용
        let column_runs: Vec<&RunInfo> = runs
            .iter()
            .filter(|r| text_run_hit_allowed_by_textbox_bbox(r, &textbox_bboxes, x, y))
            .filter(|r| {
                click_column.is_none() || r.column_index.is_none() || r.column_index == click_column
            })
            .collect();
        let all_allowed_runs: Vec<&RunInfo> = runs
            .iter()
            .filter(|r| text_run_hit_allowed_by_textbox_bbox(r, &textbox_bboxes, x, y))
            .collect();
        let candidate_runs = if column_runs.is_empty() {
            &all_allowed_runs
        } else {
            &column_runs
        };
        if candidate_runs.is_empty() {
            let (page_content, _, _) = self.find_page(page_num)?;
            return Ok(format!(
                "{{\"sectionIndex\":{},\"paragraphIndex\":0,\"charOffset\":0}}",
                page_content.section_index
            ));
        }

        let closest = candidate_runs
            .iter()
            .min_by(|a, b| {
                let dist_a = (y - (a.bbox_y + a.bbox_h / 2.0)).abs();
                let dist_b = (y - (b.bbox_y + b.bbox_h / 2.0)).abs();
                dist_a.partial_cmp(&dist_b).unwrap()
            })
            .unwrap();

        let target_y = closest.bbox_y;
        let target_h = closest.bbox_h;
        let mut line_runs: Vec<&RunInfo> = candidate_runs
            .iter()
            .filter(|r| (r.bbox_y - target_y).abs() < 1.0 && (r.bbox_h - target_h).abs() < 1.0)
            .copied()
            .collect();
        line_runs.sort_by(|a, b| a.bbox_x.partial_cmp(&b.bbox_x).unwrap());

        // 줄 안에서 클릭 x 를 가장 가까운 문자 위치로 해석
        // (run 경계 빈틈 포함 — 줄 끝으로만 스냅하지 않음)
        let (idx, offset) = resolve_x_on_line(&line_runs, x);
        Ok(format_hit(line_runs[idx], offset, page_num))
    }

    /// 안내문 클릭 시 필드 시작 위치를 찾아 hitTest 결과를 반환한다.
    fn find_field_hit_for_guide(
        &self,
        section_index: usize,
        paragraph_index: usize,
        cell_context: &Option<crate::renderer::layout::CellContext>,
        page_num: u32,
        guide_char_offset: Option<usize>,
        guide_x: f64,
        guide_y: f64,
        guide_h: f64,
    ) -> Option<String> {
        use crate::model::control::{Control, FieldType};

        // 문단 접근: cell_context가 있으면 전체 경로를 따라가기 (중첩 표 지원)
        let para = if let Some(ctx) = cell_context {
            let path: Vec<(usize, usize, usize)> = ctx
                .path
                .iter()
                .map(|e| (e.control_index, e.cell_index, e.cell_para_index))
                .collect();
            self.resolve_paragraph_by_path(section_index, ctx.parent_para_index, &path)
                .ok()?
        } else {
            self.document
                .sections
                .get(section_index)?
                .paragraphs
                .get(paragraph_index)?
        };

        let build_hit = |char_offset: usize, field: &crate::model::control::Field| {
            let base = format!(
                "\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":{}",
                section_index, paragraph_index, char_offset,
            );
            let cursor_rect = format!(
                ",\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                page_num, guide_x, guide_y, guide_h,
            );
            let field_info = format!(
                ",\"isField\":true,\"fieldId\":{},\"fieldType\":\"{}\"",
                field.field_id,
                field.field_type_str(),
            );
            if let Some(ctx) = cell_context {
                if let Some(outer) = ctx.path.first() {
                    let tb = if matches!(
                        self.document
                            .sections
                            .get(section_index)
                            .and_then(|s| s.paragraphs.get(ctx.parent_para_index))
                            .and_then(|p| p.controls.get(outer.control_index)),
                        Some(Control::Shape(_))
                    ) {
                        ",\"isTextBox\":true"
                    } else {
                        ""
                    };
                    let path_entries: Vec<String> = ctx
                        .path
                        .iter()
                        .map(|e| {
                            format!(
                                "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                                e.control_index, e.cell_index, e.cell_para_index
                            )
                        })
                        .collect();
                    let cell_path = format!(",\"cellPath\":[{}]", path_entries.join(","));
                    format!(
                        "{{{},\"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}{}{}{}{}}}",
                        base, ctx.parent_para_index, outer.control_index,
                        outer.cell_index, outer.cell_para_index,
                        cell_path, tb, field_info, cursor_rect,
                    )
                } else {
                    format!("{{{}{}{}}}", base, field_info, cursor_rect)
                }
            } else {
                format!("{{{}{}{}}}", base, field_info, cursor_rect)
            }
        };

        let mut first_empty_clickhere = None;
        let mut first_clickhere = None;

        // 안내문은 빈 ClickHere에만 표시되므로 빈 field range를 우선 매칭한다.
        for fr in &para.field_ranges {
            if let Some(Control::Field(field)) = para.controls.get(fr.control_idx) {
                if field.field_type == FieldType::ClickHere {
                    let is_empty = fr.start_char_idx == fr.end_char_idx;
                    if is_empty {
                        if guide_char_offset == Some(fr.start_char_idx) {
                            return Some(build_hit(fr.start_char_idx, field));
                        }
                        if first_empty_clickhere.is_none() {
                            first_empty_clickhere = Some(build_hit(fr.start_char_idx, field));
                        }
                    }
                    if first_clickhere.is_none() {
                        first_clickhere = Some(build_hit(fr.start_char_idx, field));
                    }
                }
            }
        }

        first_empty_clickhere.or(first_clickhere)
    }

    /// 셀의 (col, row, pad_left_px, pad_top_px, pad_bottom_px)를 모델에서 조회한다.
    pub(crate) fn resolve_cell_position(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
    ) -> Result<(u16, u16, f64, f64, f64), HwpError> {
        use crate::model::control::Control;
        let para = self
            .document
            .sections
            .get(section_idx)
            .and_then(|s| s.paragraphs.get(parent_para_idx))
            .ok_or_else(|| HwpError::RenderError("문단 없음".to_string()))?;
        let ctrl = para
            .controls
            .get(control_idx)
            .ok_or_else(|| HwpError::RenderError("컨트롤 없음".to_string()))?;
        match ctrl {
            Control::Table(ref tbl) => {
                let cell = tbl
                    .cells
                    .get(cell_idx)
                    .ok_or_else(|| HwpError::RenderError("셀 없음".to_string()))?;
                let dpi_scale = 96.0 / 7200.0;
                Ok((
                    cell.col,
                    cell.row,
                    cell.padding.left as f64 * dpi_scale,
                    cell.padding.top as f64 * dpi_scale,
                    cell.padding.bottom as f64 * dpi_scale,
                ))
            }
            Control::Shape(_) | Control::Picture(_) => {
                // 글상자/그림 캡션은 패딩 없음
                Ok((0, 0, 0.0, 0.0, 0.0))
            }
            _ => Err(HwpError::RenderError("표 컨트롤이 아닙니다".to_string())),
        }
    }

    /// 표 셀 내부 커서의 픽셀 좌표를 반환한다 (네이티브).
    ///
    /// [#4149] 페이지 트리 없이 rect 를 구하는 fast path 를 먼저 시도한다.
    /// fast path 는 확신이 없는 모든 경우 `None` 을 돌려주고, 그 경우 종전
    /// 페이지 트리 경로(`cursor_rect_in_cell_via_page_tree`)로 폴백한다 —
    /// fast path 는 탈출구 있는 최적화지 제2의 진실원천이 아니다.
    pub fn get_cursor_rect_in_cell_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        if let Some(json) = self.cursor_rect_in_cell_fast(
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
            char_offset,
        )? {
            return Ok(json);
        }
        self.cursor_rect_in_cell_via_page_tree(
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
            char_offset,
        )
    }

    /// [#4149] 종전 legacy 경로 — 페이지 트리를 빌드해 캐럿 rect 를 찾는다.
    /// fast path 의 패리티 기준(진실원천)이며, 차등 테스트가 직접 호출한다.
    pub(crate) fn cursor_rect_in_cell_via_page_tree(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        // 표 캡션은 cell_index=65534 센티널로 렌더 트리에도 동일하게 저장됨

        // [#4128] 대상 셀 위치가 실제로 렌더되는 페이지로 좁힌다 (해석 실패 시 legacy 폴백 내장)
        let pages = self.find_pages_for_cell_position(
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            Some((cell_para_idx, char_offset)),
        )?;

        for &page_num in &pages {
            let tree = self.build_page_tree(page_num)?;
            let cell_bounds =
                find_table_cell_bounds_in_node(&tree.root, parent_para_idx, control_idx, cell_idx);
            if let Some(hit) = find_cursor_in_cell_node(
                &tree.root,
                parent_para_idx,
                control_idx,
                cell_idx,
                cell_para_idx,
                char_offset,
                page_num,
            ) {
                return Ok(format_cursor_rect_json(
                    hit.page_index,
                    hit.x,
                    hit.y,
                    hit.height,
                    cell_bounds,
                ));
            }
        }

        // 빈 셀 fallback: 해당 셀의 아무 TextRun을 찾아 위치 반환.
        // [#4128] fallback 앵커는 legacy 와 동일하게 "표의 첫 페이지" — 좁힌 후보의
        // 첫 페이지(대상 문단이 실제 렌더되는 페이지)로 바꾸면 TextRun 없는 중첩
        // host 문단의 캐럿 페이지가 legacy 와 달라진다. 그쪽이 UX 로는 나을 수
        // 있으나 본 변경은 출력 불변 계약 — 개선은 별도 이슈로 다룬다.
        let first_page = self
            .find_pages_for_paragraph(section_idx, parent_para_idx)?
            .first()
            .copied()
            .unwrap_or(pages[0]);
        let tree = self.build_page_tree(first_page)?;
        let first_page_cell_bounds =
            find_table_cell_bounds_in_node(&tree.root, parent_para_idx, control_idx, cell_idx);

        fn find_cell_run(
            node: &RenderNode,
            parent_para: usize,
            ctrl_idx: usize,
            c_idx: usize,
            cp_idx: usize,
        ) -> Option<(f64, f64, f64)> {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                let matches_cell = text_run.cell_context.as_ref().map_or(false, |ctx| {
                    // path.len()==1 가드가 없으면 중첩 표 *내부* 셀의 run 도
                    // 매칭된다: 내부 run 의 path[0] 은 그 중첩 표를 품은 바깥 셀과
                    // 정확히 같기 때문이다. 같은 파일의 cell_context_matches 가
                    // path 길이 일치를 계약으로 명시한다.
                    ctx.parent_para_index == parent_para
                        && ctx.path.len() == 1
                        && ctx.path[0].control_index == ctrl_idx
                        && ctx.path[0].cell_index == c_idx
                        && ctx.path[0].cell_para_index == cp_idx
                });
                if matches_cell {
                    return Some((node.bbox.x, node.bbox.y, node.bbox.height));
                }
            }
            for child in &node.children {
                if let Some(r) = find_cell_run(child, parent_para, ctrl_idx, c_idx, cp_idx) {
                    return Some(r);
                }
            }
            None
        }

        if let Some((x, y, h)) = find_cell_run(
            &tree.root,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
        ) {
            return Ok(format_cursor_rect_json(
                first_page,
                x,
                y,
                h,
                first_page_cell_bounds,
            ));
        }

        // 빈 셀 최종 fallback: 모델에서 셀의 col/row를 조회한 뒤
        // 렌더 트리의 TableCell 노드 bbox + 패딩으로 커서 위치 산출
        let cell_pos =
            self.resolve_cell_position(section_idx, parent_para_idx, control_idx, cell_idx)?;

        fn find_table_cell_bbox(
            node: &RenderNode,
            parent_para: usize,
            ctrl_idx: usize,
            target_col: u16,
            target_row: u16,
        ) -> Option<(f64, f64, f64, f64)> {
            if let RenderNodeType::Table(ref tn) = node.node_type {
                let matches_table =
                    tn.para_index == Some(parent_para) && tn.control_index == Some(ctrl_idx);
                if matches_table {
                    for child in &node.children {
                        if let RenderNodeType::TableCell(ref tc) = child.node_type {
                            if tc.col == target_col && tc.row == target_row {
                                return Some((
                                    child.bbox.x,
                                    child.bbox.y,
                                    child.bbox.width,
                                    child.bbox.height,
                                ));
                            }
                        }
                    }
                }
            }
            for child in &node.children {
                if let Some(r) =
                    find_table_cell_bbox(child, parent_para, ctrl_idx, target_col, target_row)
                {
                    return Some(r);
                }
            }
            None
        }

        if let Some((cx, cy, _cw, ch)) = find_table_cell_bbox(
            &tree.root,
            parent_para_idx,
            control_idx,
            cell_pos.0,
            cell_pos.1,
        ) {
            // 셀 bbox 좌상단 + 패딩 위치에 커서 배치
            let pad_left = cell_pos.2;
            let pad_top = cell_pos.3;
            let caret_h = (ch - pad_top - cell_pos.4).max(10.0); // 패딩 제외한 높이
            return Ok(format_cursor_rect_json(
                first_page,
                cx + pad_left,
                cy + pad_top,
                caret_h,
                Some(CellCursorBounds {
                    x: cx,
                    y: cy,
                    w: _cw,
                    h: ch,
                }),
            ));
        }

        Err(HwpError::RenderError(format!(
            "셀 커서 위치를 찾을 수 없습니다: sec={}, parentPara={}, ctrl={}, cell={}, cellPara={}, offset={}",
            section_idx, parent_para_idx, control_idx, cell_idx, cell_para_idx, char_offset
        )))
    }

    /// [#4149] 페이지 트리 없이 셀 캐럿 rect 를 구하는 fast path.
    ///
    /// `Ok(Some(json))` 은 legacy 와 동일한 JSON 임이 계약이다 (차등 테스트가 검증).
    /// 조금이라도 불확실한 모든 경우 `Ok(None)` — 호출자가 legacy 로 폴백한다.
    ///
    /// 구조: 후보 페이지(#4128 좁히기)마다, 그 페이지의 유일한 컬럼 선두
    /// PartialTable 조각을 전량 빌드와 동일한 입력으로 재현하되 대상 셀 하나만
    /// 방출하는 프로브(`PartialTableCellProbe`)를 돌리고, legacy 와 같은 매칭
    /// 함수로 캐럿 run 을 찾는다. 좌표 산식은 전부 production 코드 재사용 —
    /// 프로브는 "생략"만 하고 "변형"은 하지 않는다.
    pub(crate) fn cursor_rect_in_cell_fast(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
        char_offset: usize,
    ) -> Result<Option<String>, HwpError> {
        use crate::model::control::Control;

        // 캡션 센티널(65534)·비표 컨트롤은 legacy 전용
        if cell_idx == 65534 {
            return Ok(None);
        }
        let is_table = self
            .document
            .sections
            .get(section_idx)
            .and_then(|s| s.paragraphs.get(parent_para_idx))
            .and_then(|p| p.controls.get(control_idx))
            .is_some_and(|c| matches!(c, Control::Table(_)));
        if !is_table {
            return Ok(None);
        }

        // 후보 페이지 — legacy 와 동일 소스·순서. (셀 units 메모가 여기서 예열되므로
        // 폴백 시에도 이 비용은 legacy 가 재사용한다.)
        let pages = self.find_pages_for_cell_position(
            section_idx,
            parent_para_idx,
            control_idx,
            cell_idx,
            Some((cell_para_idx, char_offset)),
        )?;
        let sec_offset: u32 = self
            .pagination
            .iter()
            .take(section_idx)
            .map(|p| p.pages.len() as u32)
            .sum();
        let sec_len = self
            .pagination
            .get(section_idx)
            .map(|p| p.pages.len() as u32)
            .unwrap_or(0);

        for &page_num in &pages {
            if page_num < sec_offset || page_num >= sec_offset + sec_len {
                return Ok(None);
            }
            match self.cursor_rect_in_cell_fast_on_page(
                section_idx,
                parent_para_idx,
                control_idx,
                cell_idx,
                cell_para_idx,
                char_offset,
                page_num,
            )? {
                FastCellRectOutcome::Hit(json) => return Ok(Some(json)),
                // legacy 도 이 페이지 트리에서 캐럿 run 을 못 찾고 다음 후보로 넘어간다
                FastCellRectOutcome::NoHit => continue,
                FastCellRectOutcome::Unsupported => return Ok(None),
            }
        }
        // 모든 후보에서 미발견 → legacy 의 빈 셀 fallback 경로가 진실원천
        Ok(None)
    }

    /// [#4149] 한 후보 페이지에 대한 fast path 시도.
    #[allow(clippy::too_many_arguments)]
    fn cursor_rect_in_cell_fast_on_page(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
        cell_para_idx: usize,
        char_offset: usize,
        page_num: u32,
    ) -> Result<FastCellRectOutcome, HwpError> {
        use crate::model::control::Control;
        use crate::renderer::layout::{layout_rect_to_bbox, PartialTableCellProbe, ProbeCutPlan};
        use crate::renderer::pagination::PageItem;
        use crate::renderer::render_tree::{PageLayoutContext, RenderNode, RenderNodeType};
        use FastCellRectOutcome::{Hit, NoHit, Unsupported};

        let Ok((page_content, paragraphs, _composed)) = self.find_page(page_num) else {
            // 후보 페이지 해석 실패 — legacy 가 같은 상황을 자체 처리한다
            return Ok(Unsupported);
        };
        if page_content.section_index != section_idx {
            return Ok(Unsupported);
        }
        // ── 페이지 게이트: 단일 컬럼 + 컬럼 선두가 대상 표의 PartialTable 조각 ──
        // (선두가 아니면 앞 항목들의 흐름 y·vpos 보정을 재현해야 해서 확신 불가)
        if page_content.column_contents.len() != 1 {
            return Ok(Unsupported);
        }
        let col = &page_content.column_contents[0];
        if col.zone_layout.is_some()
            || col.zone_y_offset != 0.0
            || col.endnote_flow
            || col.start_height < -0.5
            || !col.wrap_around_paras.is_empty()
            || !col.wrap_anchors.is_empty()
        {
            return Ok(Unsupported);
        }
        let Some(PageItem::PartialTable {
            para_index,
            control_index,
            start_row,
            end_row,
            is_continuation,
            start_cut,
            end_cut,
            is_block_split,
            start_cut_is_block,
            row_cursor_is_nested,
            end_row_height_override,
            start_row_height_override,
        }) = col.items.first()
        else {
            return Ok(Unsupported);
        };
        if *para_index != parent_para_idx || *control_index != control_idx {
            return Ok(Unsupported);
        }
        // host 문단 앵커의 Shape/Table 아이템은 shape_reserved 사전 점프를 만들 수
        // 있다 — 보수적 폴백
        if col.items.iter().any(|it| {
            matches!(it,
                PageItem::Shape { para_index, .. } | PageItem::Table { para_index, .. }
                    if *para_index == parent_para_idx)
        }) {
            return Ok(Unsupported);
        }
        let Some(pr) = self.pagination.get(section_idx) else {
            return Ok(Unsupported);
        };
        // 미주 병합 슬라이스(combined) 재현을 피한다 — 값은 같지만 표면을 줄인다
        if !pr.endnote_paragraphs.is_empty() {
            return Ok(Unsupported);
        }

        // ── 모델 게이트 (legacy build 와 동일한 렌더 정규화본 기준) ──
        let Some(host_para) = paragraphs.get(parent_para_idx) else {
            return Ok(Unsupported);
        };
        let Some(Control::Table(table)) = host_para.controls.get(control_idx) else {
            return Ok(Unsupported);
        };
        if table.common.treat_as_char || table.caption.is_some() {
            return Ok(Unsupported);
        }
        let Some(cell) = table.cells.get(cell_idx) else {
            return Ok(Unsupported);
        };
        if cell.paragraphs.get(cell_para_idx).is_none() {
            return Ok(Unsupported);
        }
        // 프로브는 보통 캐럿 문단까지만 셀을 방출한다. 그러나 뒤 문단의 중첩 표는
        // 모든 셀 렌더 후 수행되는 border clip 확장으로 바깥 셀 bbox를 넓힐 수 있다.
        // `cellBounds`도 공개 JSON 계약이므로, 이 형상에서는 대상 셀만 끝까지
        // 렌더해 같은 후처리를 재현한다. 다른 셀과 페이지 트리는 여전히 생략한다.
        let needs_full_cell_for_bounds = cell
            .paragraphs
            .iter()
            .skip(cell_para_idx.saturating_add(1))
            .any(|para| {
                para.controls
                    .iter()
                    .any(|control| matches!(control, Control::Table(_)))
            });
        // 반복 제목행 사본으로 그려질 수 있는 셀은 컷 창 모델 밖
        let cell_row = cell.row as usize;
        let cell_end_row = cell_row + (cell.row_span as usize).max(1);
        if *is_continuation && table.repeat_header && cell_end_row <= *start_row {
            return Ok(Unsupported);
        }
        // [#6976] 쪽을 끝내는 조각은 마지막 그린 행의 상자를 배치 뒤에 접고, 그 양은
        // 그 행 **모든 칸**이 내놓는 여분의 최솟값이다. 셀 하나만 방출하는 이 프로브는
        // 대상 셀이 그 행의 유일한 칸일 때만 같은 값을 재현한다 — 그 밖에는 legacy 로
        // 폴백한다. 접는 조각에서는 여분이 실제 배치 커서로 정해지므로 대상 셀을 끝까지
        // 렌더한다(`needs_full_cell_for_bounds` 와 같은 이유·같은 방법).
        let fragment_may_fold = end_cut.iter().any(|&unit| unit > 0);
        if fragment_may_fold {
            let Some(fold_row) = (*end_row).min(table.row_count as usize).checked_sub(1) else {
                return Ok(Unsupported);
            };
            let sole_target = table.cells.iter().enumerate().all(|(idx, c)| {
                c.row as usize + (c.row_span as usize).max(1) != fold_row + 1 || idx == cell_idx
            });
            if !sole_target {
                return Ok(Unsupported);
            }
        }

        // ── 좌표계 프라이밍 — build_page_tree/build_single_column 과 동일 상태.
        // (memoized cell_units 등 포인터-키 캐시가 동일 값으로 채워지도록, 상태
        // 의존 게이트·컷 계획보다 먼저 프라이밍한다.)
        self.layout_engine
            .set_show_transparent_borders(self.show_transparent_borders);
        self.layout_engine.set_clip_enabled(self.clip_enabled);
        self.layout_engine
            .set_show_control_codes(self.show_control_codes);
        self.layout_engine
            .set_layout_profile(self.effective_layout_profile());
        self.layout_engine.set_hwp3_origin_flow_spacing_before(
            super::rendering::uses_hwp3_origin_flow_spacing_before(&self.document),
        );
        self.layout_engine
            .set_active_field(self.active_field.as_ref().map(|af| {
                (
                    af.section_idx,
                    af.para_idx,
                    af.control_idx,
                    af.cell_path.clone(),
                )
            }));
        self.layout_engine
            .set_hidden_header_footer(&self.hidden_header_footer);
        let total_pages: u32 = self.pagination.iter().map(|p| p.pages.len() as u32).sum();
        self.layout_engine.set_total_pages(total_pages);
        self.layout_engine.set_file_name(&self.file_name);
        self.layout_engine
            .set_hidden_empty_paras(&pr.hidden_empty_paras);
        self.layout_engine
            .set_pre_emitted_host_paras(&pr.pre_emitted_host_paras);
        self.layout_engine.set_pre_emitted_host_heights(
            &pr.pre_emitted_host_heights,
            &pr.pre_emitted_host_content_heights,
        );
        let layout = &page_content.layout;
        self.layout_engine.prime_column_layout_env(layout);

        // ── 상태 의존 게이트: auto counter 소비(개요/번호·AutoNumber·캡션 번호)가
        // 표 서브트리에 있으면 이전 페이지 replay 없이는 번호가 어긋난다 ──
        if self
            .layout_engine
            .table_subtree_blocks_cursor_probe(table, &self.styles)
        {
            return Ok(Unsupported);
        }

        // ── 컷 계획: 이 조각에서 대상 셀의 컷 창과 창 문단 범위 ──
        let plan = self.layout_engine.partial_table_cell_probe_plan(
            table,
            cell,
            *start_row,
            *end_row,
            start_cut,
            end_cut,
            *is_block_split,
            *start_cut_is_block,
            &self.styles,
            cell_para_idx,
        );
        // 전량 compose 를 허용하는 셀 크기 상한 — 정확성이 아니라 fast path 의
        // 존재 이유(속도)를 지키는 게이트다.
        const FULL_COMPOSE_MAX: usize = 64;
        let n_paras = cell.paragraphs.len();
        let (windowed, window_paras) = match plan {
            ProbeCutPlan::Unsupported => return Ok(Unsupported),
            ProbeCutPlan::Uncut => {
                if n_paras > FULL_COMPOSE_MAX {
                    return Ok(Unsupported);
                }
                (false, (0, n_paras.saturating_sub(1)))
            }
            ProbeCutPlan::Cut {
                window_paras,
                split_proven,
                target_in_window,
            } => {
                if !target_in_window {
                    // 창 밖 문단은 이 페이지에 cell_para 매칭 run 이 없다 —
                    // legacy 도 이 페이지에서 못 찾고 다음 후보로 간다.
                    return Ok(NoHit);
                }
                if n_paras <= FULL_COMPOSE_MAX {
                    (false, window_paras)
                } else {
                    // windowed 사전 증명:
                    //  (a) line_segs>=2 문단 존재 → shrink 패딩 축소 조기탈출과 동일
                    //  (b) Top 정렬 확정 — split 증명 또는 원래 valign 이 Top
                    //  (c) 가로쓰기 (세로쓰기는 전량 슬라이스 필요)
                    let any_multiline = cell.paragraphs.iter().any(|p| p.line_segs.len() >= 2);
                    let top_ok = split_proven
                        || matches!(cell.vertical_align, crate::model::table::VerticalAlign::Top);
                    if !any_multiline || !top_ok || cell.text_direction != 0 {
                        return Ok(Unsupported);
                    }
                    (true, window_paras)
                }
            }
        };

        // ── 컬럼 선두 흐름 y 재현: 게이트로 보장된 조건에서 y = col_area.y ──
        // (build_single_column: start_shift=0, body_wide_reserved 없음(단일 컬럼),
        //  shape_reserved 앵커 없음(게이트), 첫 아이템은 HeightCursor.vpos_adjust 가
        //  prev 부재로 항등)
        let zone_layout = layout; // col.zone_layout None 게이트 통과
        let col_area_idx = col.column_index as usize;
        let col_area = if col_area_idx < zone_layout.column_areas.len() {
            zone_layout.column_areas[col_area_idx]
        } else {
            zone_layout.body_area
        };
        let y_offset = col_area.y;

        // layout_partial_table_item 의 지오메트리 입력 재현 (host 텍스트 방출은
        // 캐럿과 무관 — pt_y_start 는 host 렌더 유무와 관계없이 y_offset)
        let (pt_margin_left, pt_margin_right) = {
            let ps = self
                .styles
                .para_styles
                .get(host_para.para_shape_id as usize);
            let ml = ps.map(|s| s.margin_left).unwrap_or(0.0);
            let ind = ps.map(|s| s.indent).unwrap_or(0.0);
            let mr = ps.map(|s| s.margin_right).unwrap_or(0.0);
            (if ind > 0.0 { ml + ind } else { ml }, mr)
        };
        let pt_mt = self.measured_tables.get(section_idx).and_then(|v| {
            v.iter()
                .find(|mt| mt.para_index == parent_para_idx && mt.control_index == control_idx)
        });
        let outline_num_id = self
            .document
            .sections
            .get(section_idx)
            .map(|s| s.section_def.outline_numbering_id)
            .unwrap_or(0);

        // ── 대상 셀 하나만 방출하는 프로브 레이아웃 ──
        // [#4277] 캐럿 rect 프로브도 paint 트리가 아니라 흐름 상태만 만든다.
        let mut scratch_frame = PageLayoutContext::new(
            page_content.page_index,
            layout.page_width,
            layout.page_height,
        );
        let col_id = scratch_frame.next_id();
        let mut scratch_col = RenderNode::new(
            col_id,
            RenderNodeType::Column(col.column_index),
            layout_rect_to_bbox(&col_area),
        );
        let probe = PartialTableCellProbe {
            cell_idx,
            stop_after_para: if needs_full_cell_for_bounds || fragment_may_fold {
                n_paras - 1
            } else {
                cell_para_idx
            },
            // 큰 분할 셀의 현재 쪽은 `window_paras` 밖 문단을 원래부터 그리지
            // 않는다. 창을 전량으로 넓히면 cellBounds는 맞지만 모든 문단을
            // compose해 fast path의 지연 시간 계약을 잃는다. 종료 문단까지만
            // 순회를 열되 기존 창을 유지하면, 이 조각의 중첩 표 border만
            // 후처리에 참여해 legacy와 같은 clip을 만든다.
            windowed,
            window_paras,
        };
        self.layout_engine.layout_partial_table(
            &mut scratch_frame,
            &mut scratch_col,
            paragraphs,
            parent_para_idx,
            control_idx,
            section_idx,
            &self.styles,
            outline_num_id,
            &col_area,
            y_offset,
            &self.document.bin_data_content,
            *start_row,
            *end_row,
            *is_continuation,
            start_cut,
            end_cut,
            *is_block_split,
            *start_cut_is_block,
            *row_cursor_is_nested,
            *end_row_height_override,
            *start_row_height_override,
            pt_margin_left,
            pt_margin_right,
            pt_mt,
            None,
            false,
            Some(&probe),
            col.paragraph_float_placements
                .get(&(parent_para_idx, control_idx))
                .map(|p| col_area.y + p.table_top),
        );

        // legacy 와 동일한 매칭 함수로 캐럿·셀 bbox 탐색
        let cell_bounds =
            find_table_cell_bounds_in_node(&scratch_col, parent_para_idx, control_idx, cell_idx);
        if let Some(hit) = find_cursor_in_cell_node(
            &scratch_col,
            parent_para_idx,
            control_idx,
            cell_idx,
            cell_para_idx,
            char_offset,
            page_num,
        ) {
            return Ok(Hit(format_cursor_rect_json(
                hit.page_index,
                hit.x,
                hit.y,
                hit.height,
                cell_bounds,
            )));
        }
        Ok(NoHit)
    }

    // ─── 컨테이너 렌더 범위 조회 ──────────────────────────────

    /// 지정된 컨테이너(글상자/표 셀) 내에서 실제로 렌더링된 마지막 문단 인덱스를 반환한다.
    /// 렌더 트리의 TextRun 노드 중 해당 컨테이너에 속한 것의 cell_para_index 최대값을 구한다.
    /// 렌더된 TextRun이 없으면 None을 반환한다.
    pub(crate) fn last_rendered_para_in_container(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        control_idx: usize,
        cell_idx: usize,
    ) -> Option<usize> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        fn max_para_in_node(
            node: &RenderNode,
            parent_para: usize,
            ctrl_idx: usize,
            c_idx: usize,
        ) -> Option<usize> {
            let mut result: Option<usize> = None;
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                if let Some(ref ctx) = tr.cell_context {
                    // 위와 동일 근거의 path.len()==1 가드. 이 함수는 max 를 취하므로
                    // 중첩 표 내부 run 이 섞이면 바깥 셀이 실제로 그려지지 않은
                    // 페이지에서도 "그려졌다"고 보고해 캐럿 클램프가 어긋난다.
                    if ctx.parent_para_index == parent_para
                        && ctx.path.len() == 1
                        && ctx.path[0].control_index == ctrl_idx
                        && ctx.path[0].cell_index == c_idx
                    {
                        let cp = ctx.path[0].cell_para_index;
                        result = Some(result.map_or(cp, |prev: usize| prev.max(cp)));
                    }
                }
            }
            for child in &node.children {
                if let Some(cp) = max_para_in_node(child, parent_para, ctrl_idx, c_idx) {
                    result = Some(result.map_or(cp, |prev: usize| prev.max(cp)));
                }
            }
            result
        }

        // [#4128] 셀이 실제로 걸친 페이지에서만 검색 (target=None: 행/블록 겹침 수준)
        let pages = self
            .find_pages_for_cell_position(section_idx, parent_para_idx, control_idx, cell_idx, None)
            .ok()?;
        let mut max_para: Option<usize> = None;
        for &page_num in &pages {
            let tree = self.build_page_tree(page_num).ok()?;
            if let Some(cp) = max_para_in_node(&tree.root, parent_para_idx, control_idx, cell_idx) {
                max_para = Some(max_para.map_or(cp, |prev: usize| prev.max(cp)));
            }
        }
        max_para
    }

    // ─── 경로 기반 중첩 표 Native API ──────────────────────────

    /// 경로 기반 커서 좌표 조회 (네이티브).
    pub(crate) fn get_cursor_rect_by_path_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        self.get_cursor_rect_by_path_with_hint(
            section_idx,
            parent_para_idx,
            path_json,
            char_offset,
            None,
        )
    }

    /// [#2021] 후보 페이지를 힌트 페이지(±1) 우선으로 재배열한다 — 거대 표처럼 호스트
    /// 문단이 수십 페이지에 걸칠 때, 캐시 무효화 직후의 선형 페이지 트리 재빌드 탐색이
    /// 캐럿 페이지 인덱스에 비례해 커지는 것을 차단한다 (탐색 순서만 변경, 좌표 불변).
    fn order_pages_by_hint(pages: Vec<u32>, hint_page: Option<u32>) -> Vec<u32> {
        let Some(hint) = hint_page else { return pages };
        let mut ordered = Vec::with_capacity(pages.len());
        for cand in [Some(hint), hint.checked_sub(1), hint.checked_add(1)]
            .into_iter()
            .flatten()
        {
            if pages.contains(&cand) && !ordered.contains(&cand) {
                ordered.push(cand);
            }
        }
        for p in pages {
            if !ordered.contains(&p) {
                ordered.push(p);
            }
        }
        ordered
    }

    pub(crate) fn get_cursor_rect_by_path_with_hint(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
        char_offset: usize,
        hint_page: Option<u32>,
    ) -> Result<String, HwpError> {
        use crate::renderer::layout::{CellContext, CellPathEntry};
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let path = Self::parse_cell_path(path_json)?;
        if path.is_empty() {
            return Err(HwpError::RenderError("경로가 비어있습니다".to_string()));
        }

        let _para = self.resolve_paragraph_by_path(section_idx, parent_para_idx, &path)?;

        // 커서 좌표를 렌더 트리에서 찾기 ([#2021] 힌트 페이지 우선 탐색)
        // [#4128] 바깥 표 셀 기준으로 후보를 좁힌다. depth 1 이면 char_offset 까지,
        // 중첩 표(depth > 1)면 바깥 셀 행/블록 겹침 수준까지만.
        let (ctrl0, cell0, cpi0) = path[0];
        let cell_target = if path.len() == 1 {
            Some((cpi0, char_offset))
        } else {
            None
        };
        let pages = Self::order_pages_by_hint(
            self.find_pages_for_cell_position(
                section_idx,
                parent_para_idx,
                ctrl0,
                cell0,
                cell_target,
            )?,
            hint_page,
        );

        fn table_ctx_from_node(
            node: &RenderNode,
            current_table_ctx: Option<&CellContext>,
            current_cell_ctx: Option<&CellContext>,
        ) -> Option<CellContext> {
            if let RenderNodeType::Table(ref tn) = node.node_type {
                match (tn.para_index, tn.control_index) {
                    (Some(pi), Some(ci)) => {
                        if let Some(parent_ctx) = current_cell_ctx {
                            let mut ctx = parent_ctx.clone();
                            if let Some(last) = ctx.path.last_mut() {
                                last.cell_para_index = pi;
                            }
                            ctx.path.push(CellPathEntry {
                                control_index: ci,
                                cell_index: 0,
                                cell_para_index: 0,
                                text_direction: 0,
                            });
                            Some(ctx)
                        } else {
                            Some(CellContext {
                                in_textbox: false,
                                parent_para_index: pi,
                                path: vec![CellPathEntry {
                                    control_index: ci,
                                    cell_index: 0,
                                    cell_para_index: 0,
                                    text_direction: 0,
                                }],
                            })
                        }
                    }
                    _ => current_table_ctx.cloned(),
                }
            } else {
                current_table_ctx.cloned()
            }
        }

        fn cell_ctx_for_table_cell(
            table_ctx: Option<&CellContext>,
            cell_index: usize,
            cell_para_index: usize,
            text_direction: u8,
        ) -> Option<CellContext> {
            table_ctx.map(|ctx| {
                let mut cell_ctx = ctx.clone();
                if let Some(last) = cell_ctx.path.last_mut() {
                    last.cell_index = cell_index;
                    last.cell_para_index = cell_para_index;
                    last.text_direction = text_direction;
                }
                cell_ctx
            })
        }

        fn effective_cell_context(
            text_ctx: &Option<CellContext>,
            traversal_ctx: &Option<CellContext>,
        ) -> Option<CellContext> {
            match (text_ctx, traversal_ctx) {
                (Some(text_ctx), Some(traversal_ctx))
                    if traversal_ctx.path.len() > text_ctx.path.len() =>
                {
                    let mut ctx = traversal_ctx.clone();
                    if let (Some(dst), Some(src)) = (ctx.path.last_mut(), text_ctx.path.last()) {
                        dst.cell_para_index = src.cell_para_index;
                        dst.text_direction = src.text_direction;
                    }
                    Some(ctx)
                }
                (Some(text_ctx), _) => Some(text_ctx.clone()),
                (None, _) => None,
            }
        }

        fn cell_context_matches(
            ctx: &Option<CellContext>,
            parent_para: usize,
            path: &[(usize, usize, usize)],
        ) -> bool {
            ctx.as_ref().map_or(false, |ctx| {
                ctx.parent_para_index == parent_para
                    && ctx.path.len() == path.len()
                    && ctx.path.iter().zip(path.iter()).all(|(a, b)| {
                        a.control_index == b.0 && a.cell_index == b.1 && a.cell_para_index == b.2
                    })
            })
        }

        fn cell_context_descends_from(
            ctx: &Option<CellContext>,
            parent_para: usize,
            path: &[(usize, usize, usize)],
        ) -> bool {
            ctx.as_ref().is_some_and(|ctx| {
                ctx.parent_para_index == parent_para
                    && ctx.path.len() > path.len()
                    && ctx.path.iter().zip(path.iter()).all(|(a, b)| {
                        a.control_index == b.0 && a.cell_index == b.1 && a.cell_para_index == b.2
                    })
            })
        }

        // 렌더 트리에서 경로가 일치하는 TextRun 찾기
        fn find_cursor_by_path(
            core: &DocumentCore,
            node: &RenderNode,
            section_idx: usize,
            parent_para: usize,
            path: &[(usize, usize, usize)],
            offset: usize,
            page: u32,
            current_table_ctx: Option<CellContext>,
            current_cell_ctx: Option<CellContext>,
            current_cell_bounds: Option<CellCursorBounds>,
        ) -> Option<(u32, f64, f64, f64, Option<CellCursorBounds>)> {
            let table_ctx =
                table_ctx_from_node(node, current_table_ctx.as_ref(), current_cell_ctx.as_ref());
            let mut child_cell_ctx = current_cell_ctx.clone();
            let mut child_cell_bounds = current_cell_bounds;
            if let RenderNodeType::TableCell(ref tc) = node.node_type {
                if let Some(cell_idx) = tc.model_cell_index {
                    child_cell_ctx = cell_ctx_for_table_cell(
                        table_ctx.as_ref(),
                        cell_idx as usize,
                        0,
                        tc.text_direction,
                    );
                    child_cell_bounds = Some(CellCursorBounds {
                        x: node.bbox.x,
                        y: node.bbox.y,
                        w: node.bbox.width,
                        h: node.bbox.height,
                    });
                }
            }
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                let mut cell_context = effective_cell_context(&tr.cell_context, &current_cell_ctx);
                if let Some(ref mut ctx) = cell_context {
                    core.repair_unwrapped_wrapper_cell_context(section_idx, ctx);
                }
                // 번호/글머리표 TextRun (char_start: None)은 건너뛴다
                if let (true, Some(cs)) = (
                    cell_context_matches(&cell_context, parent_para, path),
                    tr.char_start,
                ) {
                    let cc = effective_char_count(tr);
                    if offset >= cs && offset <= cs + cc {
                        let positions = if tr.char_overlap.is_some() && cc == 1 {
                            vec![0.0, node.bbox.width]
                        } else {
                            tr.replay_positions_for(&tr.text).into_owned()
                        };
                        let lo = offset - cs;
                        let xr = if lo < positions.len() {
                            positions[lo]
                        } else if !positions.is_empty() {
                            *positions.last().unwrap()
                        } else {
                            0.0
                        };
                        return Some((
                            page,
                            node.bbox.x + xr,
                            node.bbox.y,
                            node.bbox.height,
                            child_cell_bounds,
                        ));
                    }
                }
            }
            for child in &node.children {
                if let Some(hit) = find_cursor_by_path(
                    core,
                    child,
                    section_idx,
                    parent_para,
                    path,
                    offset,
                    page,
                    table_ctx.clone(),
                    child_cell_ctx.clone(),
                    child_cell_bounds,
                ) {
                    return Some(hit);
                }
            }
            None
        }

        for &page_num in &pages {
            let tree = self.build_page_tree_cached(page_num)?;
            if let Some((pi, x, y, h, cell_bounds)) = find_cursor_by_path(
                self,
                &tree.root,
                section_idx,
                parent_para_idx,
                &path,
                char_offset,
                page_num,
                None,
                None,
                None,
            ) {
                return Ok(format_cursor_rect_json(pi, x, y, h, cell_bounds));
            }
        }

        // fallback: 아무 TextRun이라도 찾기
        for &page_num in &pages {
            let tree = self.build_page_tree_cached(page_num)?;
            fn find_any_run(
                core: &DocumentCore,
                node: &RenderNode,
                section_idx: usize,
                parent_para: usize,
                path: &[(usize, usize, usize)],
                page: u32,
                current_table_ctx: Option<CellContext>,
                current_cell_ctx: Option<CellContext>,
                current_cell_bounds: Option<CellCursorBounds>,
            ) -> Option<(u32, f64, f64, f64, Option<CellCursorBounds>)> {
                // TextRun이 하나도 없는 table-only 셀 문단은 Esc로 중첩 표 선택을
                // 해제한 뒤에도 유효한 caret anchor가 필요하다. 현재 Table이 놓인
                // 부모 셀 문단 context가 요청 경로와 같으면 표 좌상단을 반환한다.
                // 기존 fallback traversal 안에서 판정하므로 페이지 순회는 늘지 않는다.
                if let (RenderNodeType::Table(tn), Some(mut parent_ctx)) =
                    (&node.node_type, current_cell_ctx.clone())
                {
                    if let Some(pi) = tn.para_index {
                        if let Some(last) = parent_ctx.path.last_mut() {
                            last.cell_para_index = pi;
                        }
                    }
                    if cell_context_matches(&Some(parent_ctx), parent_para, path) {
                        return Some((page, node.bbox.x, node.bbox.y, 12.0, current_cell_bounds));
                    }
                }
                let table_ctx = table_ctx_from_node(
                    node,
                    current_table_ctx.as_ref(),
                    current_cell_ctx.as_ref(),
                );
                let mut child_cell_ctx = current_cell_ctx.clone();
                let mut child_cell_bounds = current_cell_bounds;
                if let RenderNodeType::TableCell(ref tc) = node.node_type {
                    if let Some(cell_idx) = tc.model_cell_index {
                        child_cell_ctx = cell_ctx_for_table_cell(
                            table_ctx.as_ref(),
                            cell_idx as usize,
                            0,
                            tc.text_direction,
                        );
                        child_cell_bounds = Some(CellCursorBounds {
                            x: node.bbox.x,
                            y: node.bbox.y,
                            w: node.bbox.width,
                            h: node.bbox.height,
                        });
                    }
                }
                if let RenderNodeType::TextRun(ref tr) = node.node_type {
                    let mut cell_context =
                        effective_cell_context(&tr.cell_context, &current_cell_ctx);
                    if let Some(ref mut ctx) = cell_context {
                        core.repair_unwrapped_wrapper_cell_context(section_idx, ctx);
                    }
                    if cell_context_matches(&cell_context, parent_para, path) {
                        return Some((
                            page,
                            node.bbox.x,
                            node.bbox.y,
                            node.bbox.height,
                            child_cell_bounds,
                        ));
                    }
                    if cell_context_descends_from(&cell_context, parent_para, path) {
                        return Some((
                            page,
                            node.bbox.x,
                            node.bbox.y,
                            node.bbox.height.max(1.0),
                            child_cell_bounds,
                        ));
                    }
                }
                for child in &node.children {
                    if let Some(hit) = find_any_run(
                        core,
                        child,
                        section_idx,
                        parent_para,
                        path,
                        page,
                        table_ctx.clone(),
                        child_cell_ctx.clone(),
                        child_cell_bounds,
                    ) {
                        return Some(hit);
                    }
                }
                None
            }
            if let Some((pi, x, y, h, cell_bounds)) = find_any_run(
                self,
                &tree.root,
                section_idx,
                parent_para_idx,
                &path,
                page_num,
                None,
                None,
                None,
            ) {
                return Ok(format_cursor_rect_json(pi, x, y, h, cell_bounds));
            }
        }

        Err(HwpError::RenderError(format!(
            "경로 기반 커서 위치를 찾을 수 없습니다: sec={}, ppi={}, path={}, offset={}",
            section_idx, parent_para_idx, path_json, char_offset
        )))
    }

    /// 경로 기반 셀 정보 조회 (네이티브).
    pub(crate) fn get_cell_info_by_path_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
    ) -> Result<String, HwpError> {
        let path = Self::parse_cell_path(path_json)?;
        let cell = self.resolve_cell_by_path(section_idx, parent_para_idx, &path)?;

        Ok(format!(
            "{{\"row\":{},\"col\":{},\"rowSpan\":{},\"colSpan\":{}}}",
            cell.row, cell.col, cell.row_span, cell.col_span
        ))
    }

    /// 경로 기반 표 차원 조회 (네이티브).
    pub(crate) fn get_table_dimensions_by_path_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
    ) -> Result<String, HwpError> {
        let path = Self::parse_cell_path(path_json)?;
        let table = self.resolve_table_by_path(section_idx, parent_para_idx, &path)?;

        Ok(format!(
            "{{\"rowCount\":{},\"colCount\":{},\"cellCount\":{}}}",
            table.row_count,
            table.col_count,
            table.cells.len()
        ))
    }

    /// 경로 기반 표 셀 바운딩박스 조회 (네이티브).
    pub(crate) fn get_table_cell_bboxes_by_path_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let path = Self::parse_cell_path(path_json)?;
        // 표가 존재하는지 검증
        let _table = self.resolve_table_by_path(section_idx, parent_para_idx, &path)?;

        // 렌더 트리에서 TextRun의 cell_context.path가 일치하는 TableCell의 부모 Table 노드를 찾는다
        fn find_nested_table_cells(
            node: &RenderNode,
            parent_para: usize,
            path: &[(usize, usize, usize)],
            page_idx: usize,
            result: &mut Vec<String>,
        ) -> bool {
            // Table 노드를 발견하면 자식 TableCell 중 TextRun의 cell_context가 경로와 일치하는지 확인
            if let RenderNodeType::Table(_) = node.node_type {
                // 이 테이블의 셀에서 TextRun을 찾아 경로 매칭 여부 확인
                fn check_table_match(
                    node: &RenderNode,
                    parent_para: usize,
                    path: &[(usize, usize, usize)],
                ) -> bool {
                    if let RenderNodeType::TextRun(ref tr) = node.node_type {
                        return tr.cell_context.as_ref().map_or(false, |ctx| {
                            ctx.parent_para_index == parent_para
                                && ctx.path.len() == path.len()
                                && ctx.path.iter().zip(path.iter()).enumerate().all(
                                    |(i, (a, b))| {
                                        if i < path.len() - 1 {
                                            // 중간 경로: 전체 매칭 (어떤 셀/문단을 경유하는지)
                                            a.control_index == b.0
                                                && a.cell_index == b.1
                                                && a.cell_para_index == b.2
                                        } else {
                                            // 마지막 경로: control_index만 매칭 (이 표의 모든 셀 포함)
                                            a.control_index == b.0
                                        }
                                    },
                                )
                        });
                    }
                    for child in &node.children {
                        // 중첩 Table 노드는 건너뛴다 — find_nested_table_cells가 별도로 처리
                        if matches!(child.node_type, RenderNodeType::Table(_)) {
                            continue;
                        }
                        if check_table_match(child, parent_para, path) {
                            return true;
                        }
                    }
                    false
                }

                if check_table_match(node, parent_para, path) {
                    // 이 테이블의 직속 셀 bbox 수집
                    for (cell_idx, child) in node.children.iter().enumerate() {
                        if let RenderNodeType::TableCell(ref cn) = child.node_type {
                            result.push(format!(
                                "{{\"cellIdx\":{},\"row\":{},\"col\":{},\"rowSpan\":{},\"colSpan\":{},\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1}}}",
                                cell_idx, cn.row, cn.col, cn.row_span, cn.col_span,
                                page_idx,
                                child.bbox.x, child.bbox.y, child.bbox.width, child.bbox.height
                            ));
                        }
                    }
                    return true;
                }
            }

            for child in &node.children {
                if find_nested_table_cells(child, parent_para, path, page_idx, result) {
                    return true;
                }
            }
            false
        }

        let mut cells = Vec::new();
        let total_pages = self.page_count() as usize;
        let mut found = false;
        for page_num in 0..total_pages {
            // Studio에서 보이거나 prefetch된 페이지는 이미 cache에 있다. 객체 선택
            // 때마다 같은 페이지를 다시 조판하면 keydown을 수백 ms 막으므로, 문서
            // mutation 시 함께 무효화되는 표준 page-tree cache를 재사용한다 (#4252).
            let tree = self.build_page_tree_cached(page_num as u32)?;
            if find_nested_table_cells(&tree.root, parent_para_idx, &path, page_num, &mut cells) {
                found = true;
            } else if found {
                // 이전 페이지에서 표를 찾았으나 이 페이지에는 없음 → 표가 끝남
                break;
            }
        }

        if cells.is_empty() {
            return Err(HwpError::RenderError(format!(
                "경로 기반 표 셀 bbox를 찾을 수 없습니다: sec={}, ppi={}, path={}",
                section_idx, parent_para_idx, path_json
            )));
        }

        Ok(format!("[{}]", cells.join(",")))
    }

    /// 경로 기반 수직 커서 이동 (네이티브).
    pub(crate) fn move_vertical_by_path_native(
        &self,
        section_idx: usize,
        parent_para_idx: usize,
        path_json: &str,
        char_offset: usize,
        delta: i32,
        preferred_x: f64,
    ) -> Result<String, HwpError> {
        let path = Self::parse_cell_path(path_json)?;
        if path.is_empty() {
            return Err(HwpError::RenderError("경로가 비어있습니다".to_string()));
        }

        let cell = self.resolve_cell_by_path(section_idx, parent_para_idx, &path)?;
        let cell_para_count = cell.paragraphs.len();
        let current_para_idx = path.last().unwrap().2; // cellParaIndex

        let para = cell.paragraphs.get(current_para_idx).ok_or_else(|| {
            HwpError::RenderError(format!("셀문단 {} 범위 초과", current_para_idx))
        })?;

        // preferredX 결정
        let actual_px = if preferred_x < 0.0 {
            match self.get_cursor_rect_by_path_native(
                section_idx,
                parent_para_idx,
                path_json,
                char_offset,
            ) {
                Ok(json) => super::super::helpers::json_f64(&json, "x").unwrap_or(0.0),
                Err(_) => 0.0,
            }
        } else {
            preferred_x
        };

        // 줄 정보 계산
        let line_info =
            Self::compute_line_info_struct(para, char_offset).unwrap_or(LineInfoResult {
                line_index: 0,
                line_count: 1,
                char_start: 0,
                char_end: navigable_text_len(para),
            });
        let target_line = line_info.line_index as i32 + delta;

        // 결과: (new_path, new_char_offset)
        let (new_path, new_offset) = if target_line >= 0
            && (target_line as usize) < line_info.line_count
        {
            // CASE A: 같은 문단 내 다른 줄 — preferredX 기반 오프셋 찾기
            let target_range = Self::get_line_char_range(para, target_line as usize);
            let best = self.find_best_offset_by_x_in_path(
                section_idx,
                parent_para_idx,
                &path,
                current_para_idx,
                target_range.0,
                target_range.1,
                actual_px,
            );
            let mut p = path.clone();
            p.last_mut().unwrap().2 = current_para_idx;
            (p, best)
        } else if delta < 0 && current_para_idx > 0 {
            // CASE B-1: 이전 문단 마지막 줄
            let prev_para = current_para_idx - 1;
            let prev = &cell.paragraphs[prev_para];
            let prev_line_count = Self::compute_line_info_struct(prev, 0)
                .map(|li| li.line_count)
                .unwrap_or(1);
            let last_line = prev_line_count.saturating_sub(1);
            let target_range = Self::get_line_char_range(prev, last_line);
            let best = self.find_best_offset_by_x_in_path(
                section_idx,
                parent_para_idx,
                &path,
                prev_para,
                target_range.0,
                target_range.1,
                actual_px,
            );
            let mut p = path.clone();
            p.last_mut().unwrap().2 = prev_para;
            (p, best)
        } else if delta > 0 && current_para_idx + 1 < cell_para_count {
            // CASE B-2: 다음 문단 첫 줄
            let next_para = current_para_idx + 1;
            let next = &cell.paragraphs[next_para];
            let target_range = Self::get_line_char_range(next, 0);
            let best = self.find_best_offset_by_x_in_path(
                section_idx,
                parent_para_idx,
                &path,
                next_para,
                target_range.0,
                target_range.1,
                actual_px,
            );
            let mut p = path.clone();
            p.last_mut().unwrap().2 = next_para;
            (p, best)
        } else {
            // CASE C: 셀 경계 — 인접 셀 이동 시도
            let table = self.resolve_table_by_path(section_idx, parent_para_idx, &path)?;
            let last_entry = path.last().unwrap();
            let cell_idx = last_entry.1;
            let current_cell = &table.cells[cell_idx];

            let target_row = if delta > 0 {
                (current_cell.row + current_cell.row_span) as i32
            } else {
                current_cell.row as i32 - 1
            };

            if target_row >= 0 && (target_row as u16) < table.row_count {
                if let Some(target_cell_idx) =
                    table.cell_index_at(target_row as u16, current_cell.col)
                {
                    // 인접 셀로 이동
                    let target_cell = &table.cells[target_cell_idx];
                    let (target_cpi, target_line_idx) = if delta > 0 {
                        (0usize, 0usize)
                    } else {
                        let last_cpi = target_cell.paragraphs.len().saturating_sub(1);
                        let last_line = target_cell
                            .paragraphs
                            .get(last_cpi)
                            .map(|p| {
                                if p.line_segs.is_empty() {
                                    0
                                } else {
                                    p.line_segs.len() - 1
                                }
                            })
                            .unwrap_or(0);
                        (last_cpi, last_line)
                    };
                    let mut new_p = path.clone();
                    let last = new_p.last_mut().unwrap();
                    last.1 = target_cell_idx; // cellIndex 갱신
                    last.2 = target_cpi; // cellParaIndex 갱신

                    if let Some(target_para) = target_cell.paragraphs.get(target_cpi) {
                        let target_range = Self::get_line_char_range(target_para, target_line_idx);
                        let best = self.find_best_offset_by_x_in_path(
                            section_idx,
                            parent_para_idx,
                            &new_p,
                            target_cpi,
                            target_range.0,
                            target_range.1,
                            actual_px,
                        );
                        (new_p, best)
                    } else {
                        (new_p, 0)
                    }
                } else {
                    // 해당 행/열에 셀 없음 — 현재 위치 유지
                    (path.clone(), char_offset)
                }
            } else {
                // CASE D: 중첩 표 경계 탈출 — 부모 셀의 다음/이전 문단으로
                if path.len() >= 2 {
                    // 부모 레벨 경로로 올라감
                    let mut parent_path = path[..path.len() - 1].to_vec();
                    let parent_last = parent_path.last().unwrap();
                    let parent_cell =
                        self.resolve_cell_by_path(section_idx, parent_para_idx, &parent_path)?;
                    let parent_cpi = parent_last.2;

                    if delta > 0 && parent_cpi + 1 < parent_cell.paragraphs.len() {
                        // 부모 셀의 다음 문단 첫 줄
                        let next_cpi = parent_cpi + 1;
                        let next_para = &parent_cell.paragraphs[next_cpi];
                        let target_range = Self::get_line_char_range(next_para, 0);
                        parent_path.last_mut().unwrap().2 = next_cpi;
                        let best = self.find_best_offset_by_x_in_path(
                            section_idx,
                            parent_para_idx,
                            &parent_path,
                            next_cpi,
                            target_range.0,
                            target_range.1,
                            actual_px,
                        );
                        (parent_path, best)
                    } else if delta < 0 && parent_cpi > 0 {
                        // 부모 셀의 이전 문단 마지막 줄
                        let prev_cpi = parent_cpi - 1;
                        let prev_para = &parent_cell.paragraphs[prev_cpi];
                        let prev_line_count = Self::compute_line_info_struct(prev_para, 0)
                            .map(|li| li.line_count)
                            .unwrap_or(1);
                        let last_line = prev_line_count.saturating_sub(1);
                        let target_range = Self::get_line_char_range(prev_para, last_line);
                        parent_path.last_mut().unwrap().2 = prev_cpi;
                        let best = self.find_best_offset_by_x_in_path(
                            section_idx,
                            parent_para_idx,
                            &parent_path,
                            prev_cpi,
                            target_range.0,
                            target_range.1,
                            actual_px,
                        );
                        (parent_path, best)
                    } else {
                        // 부모 셀 경계에서도 더 이상 이동 불가 — 현재 위치 유지
                        (path.clone(), char_offset)
                    }
                } else {
                    // depth=1 표 경계 — 현재 위치 유지 (본문 탈출은 flat API에서 처리)
                    (path.clone(), char_offset)
                }
            }
        };

        let new_para = new_path.last().unwrap().2;
        let path_json_out = Self::format_path_json(&new_path);

        // 커서 좌표 획득
        let (rect_valid, page_idx, fx, fy, fh) = match self.get_cursor_rect_by_path_native(
            section_idx,
            parent_para_idx,
            &path_json_out,
            new_offset,
        ) {
            Ok(json) => (
                true,
                super::super::helpers::json_f64(&json, "pageIndex").unwrap_or(0.0) as usize,
                super::super::helpers::json_f64(&json, "x").unwrap_or(0.0),
                super::super::helpers::json_f64(&json, "y").unwrap_or(0.0),
                super::super::helpers::json_f64(&json, "height").unwrap_or(18.0),
            ),
            Err(_) => (false, 0, 0.0, 0.0, 18.0),
        };

        // MoveVerticalResult 형식 (톱레벨 pageIndex/x/y/height)
        let rect_valid_str = if rect_valid {
            ""
        } else {
            ",\"rectValid\":false"
        };
        Ok(format!(
            "{{\"sectionIndex\":{},\"paragraphIndex\":{},\"charOffset\":{},\"parentParaIndex\":{},\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{},\"cellPath\":{},\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1},\"preferredX\":{:.1}{}}}",
            section_idx, new_para, new_offset,
            parent_para_idx, new_path[0].0, new_path[0].1, new_path[0].2,
            path_json_out,
            page_idx, fx, fy, fh, actual_px, rect_valid_str
        ))
    }

    /// 경로 기반 문단 내 지정 범위에서 preferredX에 가장 가까운 char offset을 찾는다.
    pub(crate) fn find_best_offset_by_x_in_path(
        &self,
        sec: usize,
        ppi: usize,
        path: &[(usize, usize, usize)],
        para_idx: usize,
        range_start: usize,
        range_end: usize,
        target_x: f64,
    ) -> usize {
        let mut best_offset = range_start;
        let mut best_dist = f64::MAX;

        // 경로에서 para_idx를 사용하는 새 경로 생성
        let mut test_path = path.to_vec();
        if let Some(last) = test_path.last_mut() {
            last.2 = para_idx;
        }
        let path_json = Self::format_path_json(&test_path);

        for offset in range_start..=range_end {
            if let Ok(json) = self.get_cursor_rect_by_path_native(sec, ppi, &path_json, offset) {
                if let Some(x) = super::super::helpers::json_f64(&json, "x") {
                    let dist = (x - target_x).abs();
                    if dist < best_dist {
                        best_dist = dist;
                        best_offset = offset;
                    }
                }
            }
        }
        best_offset
    }

    /// CellPath를 JSON 문자열로 포맷한다.
    pub(crate) fn format_path_json(path: &[(usize, usize, usize)]) -> String {
        let entries: Vec<String> = path
            .iter()
            .map(|(ci, cei, cpi)| {
                format!(
                    "{{\"controlIndex\":{},\"cellIndex\":{},\"cellParaIndex\":{}}}",
                    ci, cei, cpi
                )
            })
            .collect();
        format!("[{}]", entries.join(","))
    }

    // ─── Phase 2 Native 끝 ──────────────────────────────────

    /// 클릭 x 좌표가 속한 칼럼 인덱스를 반환한다 (다단 히트 테스트용).
    pub(crate) fn find_column_at_x(&self, page_num: u32, x: f64) -> Option<u16> {
        let (page_content, _, _) = self.find_page(page_num).ok()?;
        let areas = &page_content.layout.column_areas;
        if areas.len() <= 1 {
            return None; // 단일 단 — 칼럼 필터링 불필요
        }
        for (i, area) in areas.iter().enumerate() {
            if x >= area.x && x <= area.x + area.width {
                return Some(i as u16);
            }
        }
        // 칼럼 영역 사이(간격)에 클릭한 경우 가장 가까운 칼럼 반환
        areas
            .iter()
            .enumerate()
            .min_by(|(_, a), (_, b)| {
                let da = (x - (a.x + a.width / 2.0)).abs();
                let db = (x - (b.x + b.width / 2.0)).abs();
                da.partial_cmp(&db).unwrap_or(std::cmp::Ordering::Equal)
            })
            .map(|(i, _)| i as u16)
    }

    /// 머리말/꼬리말 내 커서 좌표를 반환한다.
    ///
    /// `preview_page_hint`가 구역 대표 페이지이면 그 페이지에 요청한 정의를 투영한다.
    /// 그 밖의 유효한 페이지는 실제 적용 정의가 일치할 때만 사용하며, 음수이면 실제 적용
    /// 페이지를 앞에서부터 찾는 CLI·구버전 호출부 호환 경로로 동작한다.
    ///
    /// 반환: JSON `{"pageIndex":N,"x":F,"y":F,"height":F}`
    pub fn get_cursor_rect_in_header_footer_native(
        &self,
        section_idx: usize,
        is_header: bool,
        apply_to: u8,
        hf_para_idx: usize,
        char_offset: usize,
        preview_page_hint: i32,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        // 머리말/꼬리말 문단의 para_index 마커 값
        // layout_header_footer_paragraphs에서 para_index = usize::MAX - i 로 설정됨
        let marker_para_idx = usize::MAX - hf_para_idx;

        // Header/Footer 노드 타입 판별
        let is_target_node = |nt: &RenderNodeType| -> bool {
            if is_header {
                matches!(nt, RenderNodeType::Header)
            } else {
                matches!(nt, RenderNodeType::Footer)
            }
        };

        struct CursorHit {
            page_index: u32,
            x: f64,
            y: f64,
            height: f64,
        }

        // Header/Footer 서브트리에서 TextRun 찾기
        fn find_cursor_in_hf_subtree(
            node: &RenderNode,
            marker_para: usize,
            offset: usize,
            page_index: u32,
        ) -> Option<CursorHit> {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if let Some(char_start) = text_run.char_start {
                    if text_run.para_index == Some(marker_para) && text_run.cell_context.is_none() {
                        let char_count = effective_char_count(text_run);
                        if offset >= char_start && offset <= char_start + char_count {
                            let local_offset = offset - char_start;
                            let positions = if text_run.char_overlap.is_some() && char_count == 1 {
                                vec![0.0, node.bbox.width]
                            } else {
                                text_run.replay_positions_for(&text_run.text).into_owned()
                            };
                            let x_in_run = if local_offset < positions.len() {
                                positions[local_offset]
                            } else if !positions.is_empty() {
                                *positions.last().unwrap()
                            } else {
                                0.0
                            };
                            let font_size = text_run.style.font_size;
                            let ascent = font_size * 0.8;
                            let caret_y = node.bbox.y + text_run.baseline - ascent;
                            return Some(CursorHit {
                                page_index,
                                x: node.bbox.x + x_in_run,
                                y: caret_y,
                                height: font_size,
                            });
                        }
                    }
                }
            }
            for child in &node.children {
                if let Some(hit) = find_cursor_in_hf_subtree(child, marker_para, offset, page_index)
                {
                    return Some(hit);
                }
            }
            None
        }

        // Header/Footer 노드에서 빈 문단 폴백
        fn find_hf_para_line(node: &RenderNode, marker_para: usize) -> Option<(f64, f64, f64)> {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if text_run.para_index == Some(marker_para)
                    && text_run.cell_context.is_none()
                    && text_run.char_start.is_some()
                {
                    return Some((node.bbox.x, node.bbox.y, node.bbox.height));
                }
            }
            if let RenderNodeType::TextLine(ref line) = node.node_type {
                if line.para_index == Some(marker_para) {
                    return Some((node.bbox.x, node.bbox.y, node.bbox.height));
                }
            }
            for child in &node.children {
                if let Some(r) = find_hf_para_line(child, marker_para) {
                    return Some(r);
                }
            }
            None
        }

        // 대표 페이지 힌트가 지정되면 해당 페이지를 먼저 탐색한다. 대표 페이지가 아닌
        // 힌트에서는 실제 적용 정의가 일치해야 하므로 클릭 페이지가 편집 surface를 바꾸지 않는다.
        let total_pages = self.page_count();
        let page_order: Vec<u32> =
            if preview_page_hint >= 0 && (preview_page_hint as u32) < total_pages {
                let preview = preview_page_hint as u32;
                std::iter::once(preview)
                    .chain((0..total_pages).filter(move |&page| page != preview))
                    .collect()
            } else {
                (0..total_pages).collect()
            };
        for page_num in page_order {
            let actual_target = self.resolve_header_footer_target(page_num, is_header);
            let is_preview_page = preview_page_hint >= 0
                && page_num == preview_page_hint as u32
                && self
                    .header_footer_preview_page_for_section(section_idx)
                    .is_ok_and(|preview| preview == page_num);
            if actual_target != (section_idx, apply_to) && !is_preview_page {
                continue;
            }
            let tree = if actual_target == (section_idx, apply_to) {
                self.build_page_tree_cached(page_num)?
            } else {
                self.build_header_footer_edit_preview_tree(
                    page_num,
                    section_idx,
                    is_header,
                    apply_to,
                )?
            };
            // 루트의 자식에서 Header/Footer 노드 찾기
            for child in &tree.root.children {
                if is_target_node(&child.node_type) {
                    if let Some(hit) =
                        find_cursor_in_hf_subtree(child, marker_para_idx, char_offset, page_num)
                    {
                        return Ok(format!(
                            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                            hit.page_index, hit.x, hit.y, hit.height
                        ));
                    }
                    // 빈 문단 폴백
                    if let Some((x, y, h)) = find_hf_para_line(child, marker_para_idx) {
                        return Ok(format!(
                            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                            page_num, x, y, h
                        ));
                    }
                    // Header/Footer 노드는 있지만 TextRun이 없는 경우 — 영역 좌표 반환
                    return Ok(format!(
                        "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                        page_num,
                        child.bbox.x,
                        child.bbox.y,
                        if child.bbox.height > 0.0 { 12.0 } else { 12.0 }
                    ));
                }
            }
        }

        Err(HwpError::RenderError(format!(
            "머리말/꼬리말 커서 위치를 찾을 수 없습니다: sec={}, is_header={}, hf_para={}",
            section_idx, is_header, hf_para_idx
        )))
    }

    /// 머리말/꼬리말 영역의 히트테스트
    ///
    /// 페이지 좌표가 머리말 또는 꼬리말 영역에 해당하는지 판별.
    /// 반환: JSON `{"hit":true,"isHeader":bool,"sectionIndex":N,"applyTo":N}`
    /// 또는 `{"hit":false}`
    ///
    /// Issue #595: Header/Footer 노드의 bbox 는 `expand_bbox_to_children` 으로
    /// 자식 (예: 단 구분선 line) 까지 확장되어 본문 영역을 침범할 수 있음.
    /// hit 판정은 layout 의 정확한 `header_area` / `footer_area` 로 수행하여
    /// bbox 확장과 무관하게 본질 영역만 hit.
    pub fn hit_test_header_footer_native(
        &self,
        page_num: u32,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        let (page_content, _, _) = self.find_page(page_num)?;
        let layout = &page_content.layout;

        // 머리말 영역 hit 판정 (layout.header_area — 정확한 머리말 범위)
        let h = &layout.header_area;
        if x >= h.x && x <= h.x + h.width && y >= h.y && y <= h.y + h.height {
            let (section_idx, apply_to) = self.resolve_header_footer_target(page_num, true);
            return Ok(format!(
                "{{\"hit\":true,\"isHeader\":true,\"sectionIndex\":{},\"applyTo\":{}}}",
                section_idx, apply_to
            ));
        }

        // 꼬리말 영역 hit 판정 (layout.footer_area)
        let f = &layout.footer_area;
        if x >= f.x && x <= f.x + f.width && y >= f.y && y <= f.y + f.height {
            let (section_idx, apply_to) = self.resolve_header_footer_target(page_num, false);
            return Ok(format!(
                "{{\"hit\":true,\"isHeader\":false,\"sectionIndex\":{},\"applyTo\":{}}}",
                section_idx, apply_to
            ));
        }

        Ok("{\"hit\":false}".to_string())
    }

    /// 이 쪽에서 머리말/꼬리말을 편집할 때 대상이 되는 (구역, applyTo) 를 반환한다.
    ///
    /// 편집 대상은 **그 쪽에 실제로 렌더되는 컨트롤**(`page.active_header`/`active_footer`)이다.
    /// 어느 컨트롤이 렌더되는지는 쪽 홀짝이 정하며(홀수/짝수가 양 쪽을 이긴다 —
    /// `renderer/pagination/engine.rs` 의 `active_header` 결정), 구역에 자기 머리말이 없으면
    /// 앞 구역에서 상속된다(`source_section_index`). 요청한 applyTo 로 대상을 고정하면
    /// 화면에 보이는 컨트롤과 다른 것을 편집하게 된다 (Task #3206).
    ///
    /// 렌더되는 컨트롤이 없으면(빈 머리말 영역) 이 쪽이 속한 구역에 `양 쪽`으로 새로
    /// 만드는 것이 대상이다.
    pub(crate) fn resolve_header_footer_target(
        &self,
        page_num: u32,
        is_header: bool,
    ) -> (usize, u8) {
        self.get_active_hf_info(page_num, is_header)
            .unwrap_or_else(|| (self.find_section_for_page(page_num).0, 0))
    }

    /// `resolve_header_footer_target` 의 JSON 반환 — 좌표 없이 쪽만으로 편집 대상을 묻는
    /// 경로(툴바 `머리말`/`꼬리말`)용. 히트테스트는 영역 판정이 앞에 붙을 뿐 같은 답을 쓴다.
    ///
    /// 반환: JSON `{"ok":true,"sectionIndex":N,"applyTo":N}`
    pub fn get_header_footer_edit_target_native(
        &self,
        page_num: u32,
        is_header: bool,
    ) -> Result<String, HwpError> {
        let (section_idx, apply_to) = self.resolve_header_footer_target(page_num, is_header);
        Ok(super::super::helpers::json_ok_with(&format!(
            "\"sectionIndex\":{},\"applyTo\":{}",
            section_idx, apply_to
        )))
    }

    /// 페이지 번호로 구역 인덱스를 찾는다.
    fn find_section_for_page(&self, page_num: u32) -> (usize, usize) {
        let mut offset = 0u32;
        for (si, pr) in self.pagination.iter().enumerate() {
            let count = pr.pages.len() as u32;
            if page_num < offset + count {
                return (si, (page_num - offset) as usize);
            }
            offset += count;
        }
        (0, 0)
    }

    /// 해당 페이지에서 활성화된 머리말/꼬리말의 (source_section_index, apply_to)를 반환한다.
    fn get_active_hf_info(&self, page_num: u32, is_header: bool) -> Option<(usize, u8)> {
        let mut offset = 0u32;
        for (_si, pr) in self.pagination.iter().enumerate() {
            let count = pr.pages.len() as u32;
            if page_num < offset + count {
                let local_page = (page_num - offset) as usize;
                let page = &pr.pages[local_page];
                let hf_ref = if is_header {
                    &page.active_header
                } else {
                    &page.active_footer
                };
                if let Some(ref r) = hf_ref {
                    let source_sec = r.source_section_index;
                    if let Some(section) = self.document.sections.get(source_sec) {
                        if let Some(para) = section.paragraphs.get(r.para_index) {
                            if let Some(ctrl) = para.controls.get(r.control_index) {
                                let apply_to = match ctrl {
                                    Control::Header(h) => header_footer_apply_to_u8(h.apply_to),
                                    Control::Footer(f) => header_footer_apply_to_u8(f.apply_to),
                                    _ => 0,
                                };
                                return Some((source_sec, apply_to));
                            }
                        }
                    }
                }
                return None;
            }
            offset += count;
        }
        None
    }

    /// 머리말/꼬리말 내부 텍스트 히트테스트
    ///
    /// 편집 모드에서 클릭한 좌표가 어느 문단·문자 위치에 해당하는지 반환.
    /// 반환: JSON `{"hit":true,"paraIndex":N,"charOffset":N,"cursorRect":{...}}`
    /// 또는 `{"hit":false}`
    pub fn hit_test_in_header_footer_native(
        &self,
        page_num: u32,
        is_header: bool,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        let (section_idx, apply_to) = self.resolve_header_footer_target(page_num, is_header);
        self.hit_test_in_header_footer_target_native(
            page_num,
            section_idx,
            is_header,
            apply_to,
            x,
            y,
        )
    }

    /// 대표 편집 페이지에서 명시한 HF target으로 내부 텍스트를 히트테스트한다.
    ///
    /// 일반 페이지는 실제 active target과 일치할 때만 허용하고, target source section의
    /// 첫 페이지에서만 가상 대표 트리를 사용한다.
    pub fn hit_test_in_header_footer_target_native(
        &self,
        page_num: u32,
        section_idx: usize,
        is_header: bool,
        apply_to: u8,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let actual_target = self.resolve_header_footer_target(page_num, is_header);
        let is_preview_page = self
            .header_footer_preview_page_for_section(section_idx)
            .is_ok_and(|preview| preview == page_num);
        if actual_target != (section_idx, apply_to) && !is_preview_page {
            return Ok("{\"hit\":false}".to_string());
        }
        let tree = if actual_target == (section_idx, apply_to) {
            self.build_page_tree_cached(page_num)?
        } else {
            self.build_header_footer_edit_preview_tree(page_num, section_idx, is_header, apply_to)?
        };
        let resolved_section_idx = section_idx;
        let resolved_apply_to = apply_to;

        // Header/Footer 서브트리 찾기
        let hf_node = tree.root.children.iter().find(|child| {
            if is_header {
                matches!(child.node_type, RenderNodeType::Header)
            } else {
                matches!(child.node_type, RenderNodeType::Footer)
            }
        });
        let hf_node = match hf_node {
            Some(n) => n,
            None => return Ok("{\"hit\":false}".to_string()),
        };

        // TextRun 정보 수집
        struct HfRunInfo {
            hf_para_idx: usize, // 머리말/꼬리말 내 문단 인덱스 (0, 1, 2, ...)
            char_start: usize,
            /// 모델 글자 수 — 오프셋은 이 공간에서 센다.
            char_count: usize,
            /// 표시 글자 위치 — 폭·x 는 이 공간에서 잰다.
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
            baseline: f64,
            font_size: f64,
        }

        fn collect_hf_runs(node: &RenderNode, runs: &mut Vec<HfRunInfo>) {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if let (Some(marker_para), Some(cs)) = (text_run.para_index, text_run.char_start) {
                    // marker_para = usize::MAX - hf_para_idx → 복원
                    if marker_para >= (usize::MAX - 1000) {
                        let hf_para_idx = usize::MAX - marker_para;
                        // 폭은 화면에 그려지는 글자로, 오프셋은 모델 글자로 센다.
                        // 필드는 모델 1자가 표시 N자라 둘이 다르다 (Task #3216).
                        let positions = text_run
                            .replay_positions_for(text_run.display_or_text())
                            .into_owned();
                        runs.push(HfRunInfo {
                            hf_para_idx,
                            char_start: cs,
                            char_count: text_run.text.chars().count(),
                            char_positions: positions,
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            bbox_w: node.bbox.width,
                            bbox_h: node.bbox.height,
                            baseline: text_run.baseline,
                            font_size: text_run.style.font_size,
                        });
                    }
                }
            }
            for child in &node.children {
                collect_hf_runs(child, runs);
            }
        }

        let mut runs: Vec<HfRunInfo> = Vec::new();
        collect_hf_runs(hf_node, &mut runs);

        if runs.is_empty() {
            // TextRun이 없는 경우 — 빈 머리말/꼬리말
            return Ok(format!(
                "{{\"hit\":true,\"sectionIndex\":{},\"applyTo\":{},\"paraIndex\":0,\"charOffset\":0,\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                resolved_section_idx,
                resolved_apply_to,
                page_num,
                hf_node.bbox.x,
                hf_node.bbox.y,
                12.0
            ));
        }

        // hitTest용 헬퍼: char_positions에서 x 좌표로 문자 오프셋 찾기
        fn find_char_at_x_hf(positions: &[f64], local_x: f64) -> usize {
            for (i, &px) in positions.iter().enumerate() {
                if i == 0 {
                    if local_x < px / 2.0 {
                        return 0;
                    }
                } else {
                    let mid = (positions[i - 1] + px) / 2.0;
                    if local_x < mid {
                        return i;
                    }
                }
            }
            positions.len()
        }

        /// 표시 인덱스를 모델 인덱스로 옮긴다.
        ///
        /// 머리말/꼬리말 필드는 모델 1자가 화면에서 N자로 보이므로 두 공간의 길이가
        /// 다르다. 경계로 반올림하면 필드는 앞/뒤에만 캐럿이 놓이고(원자적 필드), 길이가
        /// 같은 보통 런은 항등이다 (Task #3216).
        fn model_index_in_run(run: &HfRunInfo, display_idx: usize) -> usize {
            let display_len = run.char_positions.len().saturating_sub(1);
            if display_len == 0 || display_len == run.char_count {
                return display_idx.min(run.char_count);
            }
            (display_idx * run.char_count + display_len / 2) / display_len
        }

        /// 모델 인덱스를 표시 인덱스로 되돌린다 — 캐럿 x 를 재는 쪽.
        fn display_index_in_run(run: &HfRunInfo, model_idx: usize) -> usize {
            let display_len = run.char_positions.len().saturating_sub(1);
            if display_len == 0 || display_len == run.char_count || run.char_count == 0 {
                return model_idx;
            }
            (model_idx * display_len + run.char_count / 2) / run.char_count
        }

        fn format_hf_hit(
            run: &HfRunInfo,
            char_offset: usize,
            page_num: u32,
            section_idx: usize,
            apply_to: u8,
        ) -> String {
            let cursor_x = if char_offset <= run.char_start {
                run.bbox_x
            } else {
                let local_idx = display_index_in_run(run, char_offset - run.char_start);
                if local_idx < run.char_positions.len() {
                    run.bbox_x + run.char_positions[local_idx]
                } else if !run.char_positions.is_empty() {
                    run.bbox_x + run.char_positions.last().copied().unwrap_or(0.0)
                } else {
                    run.bbox_x
                }
            };
            let ascent = run.font_size * 0.8;
            let cursor_y = run.bbox_y + run.baseline - ascent;
            format!(
                "{{\"hit\":true,\"sectionIndex\":{},\"applyTo\":{},\"paraIndex\":{},\"charOffset\":{},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                section_idx,
                apply_to,
                run.hf_para_idx,
                char_offset,
                page_num,
                cursor_x,
                cursor_y,
                run.font_size
            )
        }

        // 1단계: 정확한 bbox 히트
        for run in &runs {
            if x >= run.bbox_x
                && x <= run.bbox_x + run.bbox_w
                && y >= run.bbox_y
                && y <= run.bbox_y + run.bbox_h
            {
                let local_x = x - run.bbox_x;
                let display_idx = find_char_at_x_hf(&run.char_positions, local_x);
                let char_offset = model_index_in_run(run, display_idx);
                return Ok(format_hf_hit(
                    run,
                    run.char_start + char_offset,
                    page_num,
                    resolved_section_idx,
                    resolved_apply_to,
                ));
            }
        }

        // 2단계: 같은 줄(y 범위)에서 가장 가까운 run
        let same_line: Vec<&HfRunInfo> = runs
            .iter()
            .filter(|r| y >= r.bbox_y && y <= r.bbox_y + r.bbox_h)
            .collect();
        if !same_line.is_empty() {
            if x < same_line[0].bbox_x {
                let run = same_line[0];
                return Ok(format_hf_hit(
                    run,
                    run.char_start,
                    page_num,
                    resolved_section_idx,
                    resolved_apply_to,
                ));
            }
            let last = same_line.last().unwrap();
            return Ok(format_hf_hit(
                last,
                last.char_start + last.char_count,
                page_num,
                resolved_section_idx,
                resolved_apply_to,
            ));
        }

        // 3단계: 가장 가까운 줄
        let closest = runs
            .iter()
            .min_by(|a, b| {
                let da = (y - (a.bbox_y + a.bbox_h / 2.0)).abs();
                let db = (y - (b.bbox_y + b.bbox_h / 2.0)).abs();
                da.partial_cmp(&db).unwrap_or(std::cmp::Ordering::Equal)
            })
            .unwrap();

        let target_y = closest.bbox_y;
        let target_h = closest.bbox_h;
        let mut line_runs: Vec<&HfRunInfo> = runs
            .iter()
            .filter(|r| (r.bbox_y - target_y).abs() < 1.0 && (r.bbox_h - target_h).abs() < 1.0)
            .collect();
        line_runs.sort_by(|a, b| a.bbox_x.partial_cmp(&b.bbox_x).unwrap());

        if x < line_runs[0].bbox_x {
            let run = line_runs[0];
            return Ok(format_hf_hit(
                run,
                run.char_start,
                page_num,
                resolved_section_idx,
                resolved_apply_to,
            ));
        }

        for run in &line_runs {
            if x >= run.bbox_x && x <= run.bbox_x + run.bbox_w {
                let local_x = x - run.bbox_x;
                let display_idx = find_char_at_x_hf(&run.char_positions, local_x);
                let char_offset = model_index_in_run(run, display_idx);
                return Ok(format_hf_hit(
                    run,
                    run.char_start + char_offset,
                    page_num,
                    resolved_section_idx,
                    resolved_apply_to,
                ));
            }
        }

        let last = line_runs.last().unwrap();
        Ok(format_hf_hit(
            last,
            last.char_start + last.char_count,
            page_num,
            resolved_section_idx,
            resolved_apply_to,
        ))
    }

    /// 머리말/꼬리말 내부 선택 영역의 줄별 사각형을 계산한다.
    ///
    /// 선택은 `(section_idx, is_header, apply_to)` 정의에 속하고, 이 API는 요청한 한
    /// 페이지에 그 정의가 실제 active target일 때만 페이지 지역 사각형을 반환한다.
    #[allow(clippy::too_many_arguments)]
    pub fn get_selection_rects_in_header_footer_native(
        &self,
        section_idx: usize,
        is_header: bool,
        apply_to: u8,
        page_num: u32,
        start_hf_para_idx: usize,
        start_char_offset: usize,
        end_hf_para_idx: usize,
        end_char_offset: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let actual_target = self.resolve_header_footer_target(page_num, is_header);
        let is_preview_page = self
            .header_footer_preview_page_for_section(section_idx)
            .is_ok_and(|preview| preview == page_num);
        if actual_target != (section_idx, apply_to) && !is_preview_page {
            return Ok("[]".to_string());
        }

        {
            let paragraphs = self.get_hf_paragraphs_ref(section_idx, is_header, apply_to)?;
            if start_hf_para_idx >= paragraphs.len() || end_hf_para_idx >= paragraphs.len() {
                return Err(HwpError::RenderError(format!(
                    "머리말/꼬리말 문단 범위 초과 (start={}, end={}, total={})",
                    start_hf_para_idx,
                    end_hf_para_idx,
                    paragraphs.len()
                )));
            }
            let start_len = paragraphs[start_hf_para_idx].text.chars().count();
            let end_len = paragraphs[end_hf_para_idx].text.chars().count();
            if start_char_offset > start_len || end_char_offset > end_len {
                return Err(HwpError::RenderError(format!(
                    "머리말/꼬리말 문자 범위 초과 (start={}/{}, end={}/{})",
                    start_char_offset, start_len, end_char_offset, end_len
                )));
            }
        }

        let tree = if actual_target == (section_idx, apply_to) {
            self.build_page_tree_cached(page_num)?
        } else {
            self.build_header_footer_edit_preview_tree(page_num, section_idx, is_header, apply_to)?
        };
        let Some(hf_node) = tree.root.children.iter().find(|child| {
            if is_header {
                matches!(child.node_type, RenderNodeType::Header)
            } else {
                matches!(child.node_type, RenderNodeType::Footer)
            }
        }) else {
            return Ok("[]".to_string());
        };

        #[derive(Clone)]
        struct HfRunInfo {
            hf_para_idx: usize,
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
        }

        fn collect_runs(node: &RenderNode, runs: &mut Vec<HfRunInfo>) {
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                if let (Some(marker_para), Some(char_start)) = (tr.para_index, tr.char_start) {
                    if marker_para >= usize::MAX - 1000 && tr.cell_context.is_none() {
                        runs.push(HfRunInfo {
                            hf_para_idx: usize::MAX - marker_para,
                            char_start,
                            char_count: effective_char_count(tr),
                            char_positions: tr
                                .replay_positions_for(tr.display_or_text())
                                .into_owned(),
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            bbox_w: node.bbox.width,
                            bbox_h: node.bbox.height,
                        });
                    }
                }
            }
            for child in &node.children {
                collect_runs(child, runs);
            }
        }

        fn cmp_pos(a_para: usize, a_off: usize, b_para: usize, b_off: usize) -> std::cmp::Ordering {
            a_para.cmp(&b_para).then_with(|| a_off.cmp(&b_off))
        }

        fn display_index_for_model_offset(run: &HfRunInfo, char_offset: usize) -> usize {
            let local_model = char_offset
                .saturating_sub(run.char_start)
                .min(run.char_count);
            let display_len = run.char_positions.len().saturating_sub(1);
            if display_len == 0 || display_len == run.char_count || run.char_count == 0 {
                local_model.min(display_len)
            } else {
                ((local_model * display_len + run.char_count / 2) / run.char_count).min(display_len)
            }
        }

        fn x_at(run: &HfRunInfo, char_offset: usize) -> f64 {
            if char_offset <= run.char_start {
                return run.bbox_x;
            }
            let display_idx = display_index_for_model_offset(run, char_offset);
            run.char_positions
                .get(display_idx)
                .map(|x| run.bbox_x + x)
                .unwrap_or(run.bbox_x + run.bbox_w)
        }

        let ((start_para, start_offset), (end_para, end_offset)) = if cmp_pos(
            start_hf_para_idx,
            start_char_offset,
            end_hf_para_idx,
            end_char_offset,
        )
            == std::cmp::Ordering::Greater
        {
            (
                (end_hf_para_idx, end_char_offset),
                (start_hf_para_idx, start_char_offset),
            )
        } else {
            (
                (start_hf_para_idx, start_char_offset),
                (end_hf_para_idx, end_char_offset),
            )
        };
        if (start_para, start_offset) == (end_para, end_offset) {
            return Ok("[]".to_string());
        }

        let mut runs = Vec::new();
        collect_runs(hf_node, &mut runs);
        runs.sort_by(|a, b| {
            a.hf_para_idx
                .cmp(&b.hf_para_idx)
                .then_with(|| {
                    a.bbox_y
                        .partial_cmp(&b.bbox_y)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
                .then_with(|| {
                    a.bbox_x
                        .partial_cmp(&b.bbox_x)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
        });

        let mut rects = Vec::new();
        for run in runs {
            let run_start = (run.hf_para_idx, run.char_start);
            let run_end = (run.hf_para_idx, run.char_start + run.char_count);
            if cmp_pos(run_end.0, run_end.1, start_para, start_offset)
                != std::cmp::Ordering::Greater
                || cmp_pos(run_start.0, run_start.1, end_para, end_offset)
                    != std::cmp::Ordering::Less
            {
                continue;
            }

            let selected_start = if run.hf_para_idx == start_para {
                start_offset.max(run.char_start)
            } else {
                run.char_start
            };
            let selected_end = if run.hf_para_idx == end_para {
                end_offset.min(run.char_start + run.char_count)
            } else {
                run.char_start + run.char_count
            };
            if selected_end <= selected_start {
                continue;
            }

            let x1 = x_at(&run, selected_start);
            let x2 = x_at(&run, selected_end);
            rects.push(format!(
                "{{\"pageIndex\":{},\"x\":{:.2},\"y\":{:.2},\"width\":{:.2},\"height\":{:.2}}}",
                page_num,
                x1,
                run.bbox_y,
                (x2 - x1).max(1.0),
                run.bbox_h
            ));
        }

        Ok(format!("[{}]", rects.join(",")))
    }

    /// 각주 영역 히트테스트
    ///
    /// 페이지에 각주 영역이 존재하는지 빠르게 확인.
    /// 페이지네이션 메타데이터(footnotes Vec)만 조회하므로 render tree build가 필요 없다.
    /// hitTestFootnote fast-reject (#2428) 전용.
    pub fn page_has_footnote_footholds_native(&self, page_num: u32) -> bool {
        let (page_content, _, _) = match self.find_page(page_num) {
            Ok(result) => result,
            Err(_) => return false,
        };
        !page_content.footnotes.is_empty()
    }

    /// 페이지 좌표가 각주 영역에 해당하는지 판별.
    /// 반환: JSON `{"hit":true,"footnoteIndex":N}` 또는 `{"hit":false}`
    pub fn hit_test_footnote_native(
        &self,
        page_num: u32,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::RenderNodeType;

        let tree = self.build_page_tree(page_num)?;

        for child in &tree.root.children {
            if !matches!(child.node_type, RenderNodeType::FootnoteArea) {
                continue;
            }

            if x >= child.bbox.x
                && x <= child.bbox.x + child.bbox.width
                && y >= child.bbox.y
                && y <= child.bbox.y + child.bbox.height
            {
                // FootnoteArea 내에서 가장 가까운 TextRun의 footnote_index 반환
                let mut fn_idx = 0usize;
                fn find_fn_idx(node: &crate::renderer::render_tree::RenderNode, best: &mut usize) {
                    if let RenderNodeType::TextRun(ref tr) = node.node_type {
                        if let Some(pi) = tr.para_index {
                            if pi >= (usize::MAX - 3000) {
                                if let Some(si) = tr.section_index {
                                    *best = si;
                                }
                            }
                        }
                    }
                    for c in &node.children {
                        find_fn_idx(c, best);
                    }
                }
                find_fn_idx(child, &mut fn_idx);
                return Ok(format!("{{\"hit\":true,\"footnoteIndex\":{}}}", fn_idx));
            }
        }

        Ok("{\"hit\":false}".to_string())
    }

    /// 각주 내부 텍스트 히트테스트
    ///
    /// 편집 모드에서 클릭한 좌표의 각주 내 문단·문자 위치를 반환.
    /// 반환: JSON `{"hit":true,"fnParaIndex":N,"charOffset":N,"footnoteIndex":N,"cursorRect":{...}}`
    pub fn hit_test_in_footnote_native(
        &self,
        page_num: u32,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree(page_num)?;

        let fn_node = tree
            .root
            .children
            .iter()
            .find(|child| matches!(child.node_type, RenderNodeType::FootnoteArea));
        let fn_node = match fn_node {
            Some(n) => n,
            None => return Ok("{\"hit\":false}".to_string()),
        };

        // 각주 TextRun 정보 수집
        struct FnRunInfo {
            footnote_index: usize,
            fn_para_idx: usize,
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
            baseline: f64,
            font_size: f64,
        }

        // 번호 TextRun(char_start: None) 정보 — 빈 각주의 footnoteIndex/위치 결정용
        struct FnNumberInfo {
            footnote_index: usize,
            fn_para_idx: usize,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
            font_size: f64,
            baseline: f64,
        }

        fn collect_fn_runs(
            node: &RenderNode,
            runs: &mut Vec<FnRunInfo>,
            number_runs: &mut Vec<FnNumberInfo>,
        ) {
            if let RenderNodeType::TextRun(ref text_run) = node.node_type {
                if let (Some(marker_para), Some(marker_section)) =
                    (text_run.para_index, text_run.section_index)
                {
                    if marker_para >= (usize::MAX - 3000) && marker_para < (usize::MAX - 1000) {
                        let fn_para_idx = usize::MAX - 2000 - marker_para;
                        if let Some(cs) = text_run.char_start {
                            // 본문 텍스트 TextRun
                            let positions =
                                text_run.replay_positions_for(&text_run.text).into_owned();
                            runs.push(FnRunInfo {
                                footnote_index: marker_section,
                                fn_para_idx,
                                char_start: cs,
                                char_count: text_run.text.chars().count(),
                                char_positions: positions,
                                bbox_x: node.bbox.x,
                                bbox_y: node.bbox.y,
                                bbox_w: node.bbox.width,
                                bbox_h: node.bbox.height,
                                baseline: text_run.baseline,
                                font_size: text_run.style.font_size,
                            });
                        } else {
                            // 번호 TextRun (char_start: None)
                            number_runs.push(FnNumberInfo {
                                footnote_index: marker_section,
                                fn_para_idx,
                                bbox_x: node.bbox.x,
                                bbox_y: node.bbox.y,
                                bbox_w: node.bbox.width,
                                bbox_h: node.bbox.height,
                                font_size: text_run.style.font_size,
                                baseline: text_run.baseline,
                            });
                        }
                    }
                }
            }
            for child in &node.children {
                collect_fn_runs(child, runs, number_runs);
            }
        }

        let mut runs: Vec<FnRunInfo> = Vec::new();
        let mut number_runs: Vec<FnNumberInfo> = Vec::new();
        collect_fn_runs(fn_node, &mut runs, &mut number_runs);

        // Y 좌표로 가장 가까운 각주의 footnoteIndex 결정 (텍스트 run이 없는 빈 각주 지원)
        if runs.is_empty()
            || !runs
                .iter()
                .any(|r| y >= r.bbox_y && y <= r.bbox_y + r.bbox_h)
        {
            // 번호 run에서 Y 좌표로 가장 가까운 각주 찾기
            let closest_num = number_runs.iter().min_by(|a, b| {
                let da = (y - (a.bbox_y + a.bbox_h / 2.0)).abs();
                let db = (y - (b.bbox_y + b.bbox_h / 2.0)).abs();
                da.partial_cmp(&db).unwrap_or(std::cmp::Ordering::Equal)
            });
            if let Some(nr) = closest_num {
                let ascent = nr.font_size * 0.8;
                let cursor_y = nr.bbox_y + nr.baseline - ascent;
                return Ok(format!(
                    "{{\"hit\":true,\"fnParaIndex\":{},\"charOffset\":0,\"footnoteIndex\":{},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                    nr.fn_para_idx, nr.footnote_index, page_num,
                    nr.bbox_x + nr.bbox_w, cursor_y, nr.font_size
                ));
            }
            return Ok(format!(
                "{{\"hit\":true,\"fnParaIndex\":0,\"charOffset\":0,\"footnoteIndex\":0,\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                page_num, fn_node.bbox.x, fn_node.bbox.y, 12.0
            ));
        }

        fn find_char_at_x(positions: &[f64], local_x: f64) -> usize {
            for (i, &px) in positions.iter().enumerate() {
                if i == 0 {
                    if local_x < px / 2.0 {
                        return 0;
                    }
                } else {
                    let mid = (positions[i - 1] + px) / 2.0;
                    if local_x < mid {
                        return i;
                    }
                }
            }
            positions.len()
        }

        fn format_fn_hit(run: &FnRunInfo, char_offset: usize, page_num: u32) -> String {
            let cursor_x = if char_offset <= run.char_start {
                run.bbox_x
            } else {
                let local_idx = char_offset - run.char_start;
                if local_idx < run.char_positions.len() {
                    run.bbox_x + run.char_positions[local_idx]
                } else if !run.char_positions.is_empty() {
                    run.bbox_x + run.char_positions.last().copied().unwrap_or(0.0)
                } else {
                    run.bbox_x
                }
            };
            let ascent = run.font_size * 0.8;
            let cursor_y = run.bbox_y + run.baseline - ascent;
            format!(
                "{{\"hit\":true,\"fnParaIndex\":{},\"charOffset\":{},\"footnoteIndex\":{},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
                run.fn_para_idx, char_offset, run.footnote_index, page_num, cursor_x, cursor_y, run.font_size
            )
        }

        // 1단계: 정확한 bbox 히트
        for run in &runs {
            if x >= run.bbox_x
                && x <= run.bbox_x + run.bbox_w
                && y >= run.bbox_y
                && y <= run.bbox_y + run.bbox_h
            {
                let local_x = x - run.bbox_x;
                let char_offset = find_char_at_x(&run.char_positions, local_x);
                return Ok(format_fn_hit(run, run.char_start + char_offset, page_num));
            }
        }

        // 2단계: 같은 줄(y 범위)에서 가장 가까운 run
        let same_line: Vec<&FnRunInfo> = runs
            .iter()
            .filter(|r| y >= r.bbox_y && y <= r.bbox_y + r.bbox_h)
            .collect();
        if !same_line.is_empty() {
            if x < same_line[0].bbox_x {
                let run = same_line[0];
                return Ok(format_fn_hit(run, run.char_start, page_num));
            }
            let last = same_line.last().unwrap();
            return Ok(format_fn_hit(
                last,
                last.char_start + last.char_count,
                page_num,
            ));
        }

        // 3단계: 가장 가까운 줄
        let closest = runs
            .iter()
            .min_by(|a, b| {
                let da = (y - (a.bbox_y + a.bbox_h / 2.0)).abs();
                let db = (y - (b.bbox_y + b.bbox_h / 2.0)).abs();
                da.partial_cmp(&db).unwrap_or(std::cmp::Ordering::Equal)
            })
            .unwrap();

        let target_y = closest.bbox_y;
        let target_h = closest.bbox_h;
        let mut line_runs: Vec<&FnRunInfo> = runs
            .iter()
            .filter(|r| (r.bbox_y - target_y).abs() < 1.0 && (r.bbox_h - target_h).abs() < 1.0)
            .collect();
        line_runs.sort_by(|a, b| a.bbox_x.partial_cmp(&b.bbox_x).unwrap());

        if x < line_runs[0].bbox_x {
            let run = line_runs[0];
            return Ok(format_fn_hit(run, run.char_start, page_num));
        }

        let last = line_runs.last().unwrap();
        Ok(format_fn_hit(
            last,
            last.char_start + last.char_count,
            page_num,
        ))
    }

    /// 각주/미주 내부 선택 영역의 줄별 사각형을 계산한다.
    pub fn get_selection_rects_in_footnote_native(
        &self,
        page_num: u32,
        footnote_index: usize,
        start_fn_para_idx: usize,
        start_char_offset: usize,
        end_fn_para_idx: usize,
        end_char_offset: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree(page_num)?;
        let Some(fn_node) = tree
            .root
            .children
            .iter()
            .find(|child| matches!(child.node_type, RenderNodeType::FootnoteArea))
        else {
            return Ok("[]".to_string());
        };

        #[derive(Clone)]
        struct FnRunInfo {
            fn_para_idx: usize,
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
        }

        fn collect_runs(node: &RenderNode, footnote_index: usize, runs: &mut Vec<FnRunInfo>) {
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                if tr.section_index == Some(footnote_index) {
                    if let (Some(marker_para), Some(cs)) = (tr.para_index, tr.char_start) {
                        if marker_para >= (usize::MAX - 3000) && marker_para < (usize::MAX - 1000) {
                            let fn_para_idx = usize::MAX - 2000 - marker_para;
                            runs.push(FnRunInfo {
                                fn_para_idx,
                                char_start: cs,
                                char_count: tr.text.chars().count(),
                                char_positions: tr.replay_positions_for(&tr.text).into_owned(),
                                bbox_x: node.bbox.x,
                                bbox_y: node.bbox.y,
                                bbox_w: node.bbox.width,
                                bbox_h: node.bbox.height,
                            });
                        }
                    }
                }
            }
            for child in &node.children {
                collect_runs(child, footnote_index, runs);
            }
        }

        fn cmp_pos(a_para: usize, a_off: usize, b_para: usize, b_off: usize) -> std::cmp::Ordering {
            a_para.cmp(&b_para).then_with(|| a_off.cmp(&b_off))
        }

        fn x_at(run: &FnRunInfo, char_offset: usize) -> f64 {
            if char_offset <= run.char_start {
                return run.bbox_x;
            }
            let local_idx = char_offset - run.char_start;
            if local_idx < run.char_positions.len() {
                run.bbox_x + run.char_positions[local_idx]
            } else {
                run.bbox_x + run.bbox_w
            }
        }

        let mut runs = Vec::new();
        collect_runs(fn_node, footnote_index, &mut runs);
        runs.sort_by(|a, b| {
            a.fn_para_idx
                .cmp(&b.fn_para_idx)
                .then_with(|| {
                    a.bbox_y
                        .partial_cmp(&b.bbox_y)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
                .then_with(|| {
                    a.bbox_x
                        .partial_cmp(&b.bbox_x)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
        });

        let mut rects = Vec::new();
        for run in runs {
            let run_start = (run.fn_para_idx, run.char_start);
            let run_end = (run.fn_para_idx, run.char_start + run.char_count);

            if cmp_pos(run_end.0, run_end.1, start_fn_para_idx, start_char_offset)
                != std::cmp::Ordering::Greater
                || cmp_pos(run_start.0, run_start.1, end_fn_para_idx, end_char_offset)
                    != std::cmp::Ordering::Less
            {
                continue;
            }

            let sel_start = if run.fn_para_idx == start_fn_para_idx {
                start_char_offset.max(run.char_start)
            } else {
                run.char_start
            };
            let sel_end = if run.fn_para_idx == end_fn_para_idx {
                end_char_offset.min(run.char_start + run.char_count)
            } else {
                run.char_start + run.char_count
            };

            if sel_end <= sel_start {
                continue;
            }

            let x1 = x_at(&run, sel_start);
            let x2 = x_at(&run, sel_end);
            let width = (x2 - x1).max(1.0);
            rects.push(format!(
                "{{\"pageIndex\":{},\"x\":{:.2},\"y\":{:.2},\"width\":{:.2},\"height\":{:.2}}}",
                page_num, x1, run.bbox_y, width, run.bbox_h
            ));
        }

        Ok(format!("[{}]", rects.join(",")))
    }

    fn global_page_base_for_section(&self, section_idx: usize) -> u32 {
        self.pagination
            .iter()
            .take(section_idx)
            .map(|pr| pr.pages.len() as u32)
            .sum()
    }

    fn cursor_rect_for_render_paragraph(
        &self,
        page_num: u32,
        section_idx: usize,
        para_idx: usize,
        char_offset: usize,
    ) -> Result<Option<String>, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        struct CursorRun {
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            baseline: f64,
            font_size: f64,
        }

        fn collect_runs(
            node: &RenderNode,
            section_idx: usize,
            para_idx: usize,
            runs: &mut Vec<CursorRun>,
        ) {
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                if tr.section_index == Some(section_idx) && tr.para_index == Some(para_idx) {
                    if let Some(cs) = tr.char_start {
                        let positions = tr.replay_positions_for(&tr.text).into_owned();
                        runs.push(CursorRun {
                            char_start: cs,
                            char_count: effective_char_count(tr),
                            char_positions: positions,
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            baseline: tr.baseline,
                            font_size: tr.style.font_size,
                        });
                    }
                }
            }
            for child in &node.children {
                collect_runs(child, section_idx, para_idx, runs);
            }
        }

        let tree = self.build_page_tree(page_num)?;
        let mut runs = Vec::new();
        collect_runs(&tree.root, section_idx, para_idx, &mut runs);
        runs.sort_by(|a, b| {
            a.char_start
                .cmp(&b.char_start)
                .then_with(|| {
                    a.bbox_y
                        .partial_cmp(&b.bbox_y)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
                .then_with(|| {
                    a.bbox_x
                        .partial_cmp(&b.bbox_x)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
        });
        if runs.is_empty() {
            return Ok(None);
        }

        for run in &runs {
            if char_offset >= run.char_start && char_offset <= run.char_start + run.char_count {
                let local_idx = char_offset - run.char_start;
                let cursor_x = if local_idx < run.char_positions.len() {
                    run.bbox_x + run.char_positions[local_idx]
                } else if !run.char_positions.is_empty() {
                    run.bbox_x + run.char_positions.last().copied().unwrap_or(0.0)
                } else {
                    run.bbox_x
                };
                let ascent = run.font_size * 0.8;
                let cursor_y = run.bbox_y + run.baseline - ascent;
                return Ok(Some(format!(
                    "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                    page_num, cursor_x, cursor_y, run.font_size
                )));
            }
        }

        let last = runs.last().unwrap();
        let cursor_x = if !last.char_positions.is_empty() {
            last.bbox_x + last.char_positions.last().copied().unwrap_or(0.0)
        } else {
            last.bbox_x
        };
        let ascent = last.font_size * 0.8;
        let cursor_y = last.bbox_y + last.baseline - ascent;
        Ok(Some(format!(
            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
            page_num, cursor_x, cursor_y, last.font_size
        )))
    }

    fn find_body_footnote_edit_target(
        &self,
        section_idx: usize,
        para_idx: usize,
        control_idx: usize,
    ) -> Option<(u32, usize)> {
        use crate::renderer::pagination::FootnoteSource;

        let pr = self.pagination.get(section_idx)?;
        let page_base = self.global_page_base_for_section(section_idx);
        for (local_page_idx, page) in pr.pages.iter().enumerate() {
            if let Some(footnote_idx) = page.footnotes.iter().position(|fn_ref| {
                matches!(
                    &fn_ref.source,
                    FootnoteSource::Body { para_index, control_index }
                        if *para_index == para_idx && *control_index == control_idx
                )
            }) {
                return Some((page_base + local_page_idx as u32, footnote_idx));
            }
        }
        None
    }

    fn find_endnote_edit_target(
        &self,
        section_idx: usize,
        para_idx: usize,
        control_idx: usize,
        note_para_idx: usize,
    ) -> Option<(u32, usize, usize)> {
        let pr = self.pagination.get(section_idx)?;
        let local_idx = pr.endnote_para_sources.iter().position(|src| {
            src.section_index == section_idx
                && src.para_index == para_idx
                && src.control_index == control_idx
                && src.note_para_index == note_para_idx
        })?;
        let virtual_para_idx =
            self.document.sections.get(section_idx)?.paragraphs.len() + local_idx;
        let page_base = self.global_page_base_for_section(section_idx);
        for (local_page_idx, page) in pr.pages.iter().enumerate() {
            if page
                .column_contents
                .iter()
                .flat_map(|col| col.items.iter())
                .any(|item| item.para_index() == virtual_para_idx)
            {
                return Some((
                    page_base + local_page_idx as u32,
                    local_idx,
                    virtual_para_idx,
                ));
            }
        }
        None
    }

    pub fn get_note_edit_info_native(
        &self,
        section_idx: usize,
        para_idx: usize,
        control_idx: usize,
    ) -> Result<String, HwpError> {
        let section = self.document.sections.get(section_idx).ok_or_else(|| {
            HwpError::RenderError(format!("구역 인덱스 {} 범위 초과", section_idx))
        })?;
        let para = section
            .paragraphs
            .get(para_idx)
            .ok_or_else(|| HwpError::RenderError(format!("문단 인덱스 {} 범위 초과", para_idx)))?;
        let ctrl = para.controls.get(control_idx).ok_or_else(|| {
            HwpError::RenderError(format!("컨트롤 인덱스 {} 범위 초과", control_idx))
        })?;

        match ctrl {
            Control::Footnote(_) => {
                let (page_num, footnote_index) = self
                    .find_body_footnote_edit_target(section_idx, para_idx, control_idx)
                    .ok_or_else(|| {
                        HwpError::RenderError("각주 렌더 위치를 찾을 수 없습니다".to_string())
                    })?;
                Ok(format!(
                    "{{\"ok\":true,\"kind\":\"footnote\",\"pageNum\":{},\"footnoteIndex\":{},\"fnParaIndex\":0,\"charOffset\":2}}",
                    page_num, footnote_index
                ))
            }
            Control::Endnote(_) => {
                let (page_num, endnote_index, virtual_para_idx) = self
                    .find_endnote_edit_target(section_idx, para_idx, control_idx, 0)
                    .ok_or_else(|| {
                        HwpError::RenderError("미주 렌더 위치를 찾을 수 없습니다".to_string())
                    })?;
                Ok(format!(
                    "{{\"ok\":true,\"kind\":\"endnote\",\"pageNum\":{},\"footnoteIndex\":{},\"fnParaIndex\":0,\"charOffset\":2,\"virtualParaIndex\":{}}}",
                    page_num, endnote_index, virtual_para_idx
                ))
            }
            _ => Err(HwpError::RenderError(
                "지정된 컨트롤이 각주/미주가 아닙니다".to_string(),
            )),
        }
    }

    pub fn get_cursor_rect_in_note_native(
        &self,
        section_idx: usize,
        para_idx: usize,
        control_idx: usize,
        note_para_idx: usize,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        let section = self.document.sections.get(section_idx).ok_or_else(|| {
            HwpError::RenderError(format!("구역 인덱스 {} 범위 초과", section_idx))
        })?;
        let para = section
            .paragraphs
            .get(para_idx)
            .ok_or_else(|| HwpError::RenderError(format!("문단 인덱스 {} 범위 초과", para_idx)))?;
        let ctrl = para.controls.get(control_idx).ok_or_else(|| {
            HwpError::RenderError(format!("컨트롤 인덱스 {} 범위 초과", control_idx))
        })?;

        match ctrl {
            Control::Footnote(_) => {
                let (page_num, footnote_index) = self
                    .find_body_footnote_edit_target(section_idx, para_idx, control_idx)
                    .ok_or_else(|| {
                        HwpError::RenderError("각주 렌더 위치를 찾을 수 없습니다".to_string())
                    })?;
                self.get_cursor_rect_in_footnote_native(
                    page_num,
                    footnote_index,
                    note_para_idx,
                    char_offset,
                )
            }
            Control::Endnote(endnote) => {
                let (page_num, _, virtual_para_idx) = self
                    .find_endnote_edit_target(section_idx, para_idx, control_idx, note_para_idx)
                    .ok_or_else(|| {
                        HwpError::RenderError("미주 렌더 위치를 찾을 수 없습니다".to_string())
                    })?;
                let render_char_offset = if note_para_idx == 0 {
                    char_offset
                        + note_marker_text(
                            endnote.number,
                            endnote.number_shape,
                            endnote.before_decoration_letter,
                            endnote.after_decoration_letter,
                        )
                        .chars()
                        .count()
                        + 1
                } else {
                    char_offset
                };
                self.cursor_rect_for_render_paragraph(
                    page_num,
                    section_idx,
                    virtual_para_idx,
                    render_char_offset,
                )?
                .ok_or_else(|| {
                    HwpError::RenderError("미주 커서 위치를 찾을 수 없습니다".to_string())
                })
            }
            _ => Err(HwpError::RenderError(
                "지정된 컨트롤이 각주/미주가 아닙니다".to_string(),
            )),
        }
    }

    /// 각주 내 커서 위치 (커서 렉트) 계산
    ///
    /// 반환: JSON `{"pageIndex":N,"x":F,"y":F,"height":F}`
    pub fn get_cursor_rect_in_footnote_native(
        &self,
        page_num: u32,
        footnote_index: usize,
        fn_para_idx: usize,
        char_offset: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        let tree = self.build_page_tree(page_num)?;

        let fn_node = tree
            .root
            .children
            .iter()
            .find(|child| matches!(child.node_type, RenderNodeType::FootnoteArea));
        let fn_node = match fn_node {
            Some(n) => n,
            None => {
                return Err(HwpError::RenderError(
                    "각주 영역을 찾을 수 없습니다".to_string(),
                ))
            }
        };

        let marker_para = usize::MAX - 2000 - fn_para_idx;

        // 해당 각주/문단의 TextRun 찾기
        struct FnCursorRun {
            char_start: usize,
            char_count: usize,
            char_positions: Vec<f64>,
            bbox_x: f64,
            bbox_y: f64,
            bbox_h: f64,
            baseline: f64,
            font_size: f64,
        }

        fn collect_cursor_runs(
            node: &RenderNode,
            target_section: usize,
            target_para: usize,
            runs: &mut Vec<FnCursorRun>,
        ) {
            if let RenderNodeType::TextRun(ref tr) = node.node_type {
                if tr.section_index == Some(target_section) && tr.para_index == Some(target_para) {
                    if let Some(cs) = tr.char_start {
                        let positions = tr.replay_positions_for(&tr.text).into_owned();
                        runs.push(FnCursorRun {
                            char_start: cs,
                            char_count: tr.text.chars().count(),
                            char_positions: positions,
                            bbox_x: node.bbox.x,
                            bbox_y: node.bbox.y,
                            bbox_h: node.bbox.height,
                            baseline: tr.baseline,
                            font_size: tr.style.font_size,
                        });
                    }
                }
            }
            for c in &node.children {
                collect_cursor_runs(c, target_section, target_para, runs);
            }
        }

        let mut runs: Vec<FnCursorRun> = Vec::new();
        collect_cursor_runs(fn_node, footnote_index, marker_para, &mut runs);

        if runs.is_empty() {
            // 폴백: 번호 TextRun(char_start=None) 뒤의 위치를 찾기
            // 번호 run은 section_index=footnote_index, para_index=marker_para, char_start=None
            fn find_number_run_end(
                node: &RenderNode,
                target_sec: usize,
                target_para: usize,
            ) -> Option<(f64, f64, f64)> {
                if let RenderNodeType::TextRun(ref tr) = node.node_type {
                    if tr.section_index == Some(target_sec)
                        && tr.para_index == Some(target_para)
                        && tr.char_start.is_none()
                    {
                        // 번호 run의 오른쪽 끝
                        return Some((
                            node.bbox.x + node.bbox.width,
                            node.bbox.y + tr.baseline - tr.style.font_size * 0.8,
                            tr.style.font_size,
                        ));
                    }
                }
                for c in &node.children {
                    if let Some(r) = find_number_run_end(c, target_sec, target_para) {
                        return Some(r);
                    }
                }
                None
            }
            if let Some((x, y, h)) = find_number_run_end(fn_node, footnote_index, marker_para) {
                return Ok(format!(
                    "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                    page_num, x, y, h
                ));
            }
            return Ok(format!(
                "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                page_num, fn_node.bbox.x, fn_node.bbox.y, 12.0
            ));
        }

        // char_offset에 해당하는 run 찾기
        for run in &runs {
            if char_offset >= run.char_start && char_offset <= run.char_start + run.char_count {
                let local_idx = char_offset - run.char_start;
                let cursor_x = if local_idx < run.char_positions.len() {
                    run.bbox_x + run.char_positions[local_idx]
                } else if !run.char_positions.is_empty() {
                    run.bbox_x + run.char_positions.last().copied().unwrap_or(0.0)
                } else {
                    run.bbox_x
                };
                let ascent = run.font_size * 0.8;
                let cursor_y = run.bbox_y + run.baseline - ascent;
                return Ok(format!(
                    "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
                    page_num, cursor_x, cursor_y, run.font_size
                ));
            }
        }

        // 마지막 run의 끝
        let last = runs.last().unwrap();
        let cursor_x = if !last.char_positions.is_empty() {
            last.bbox_x + last.char_positions.last().copied().unwrap_or(0.0)
        } else {
            last.bbox_x
        };
        let ascent = last.font_size * 0.8;
        let cursor_y = last.bbox_y + last.baseline - ascent;
        Ok(format!(
            "{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}",
            page_num, cursor_x, cursor_y, last.font_size
        ))
    }

    fn find_page_body_footnote_index(
        &self,
        page_num: u32,
        section_idx: usize,
        para_idx: usize,
        control_idx: usize,
    ) -> Option<usize> {
        use crate::renderer::pagination::FootnoteSource;

        let (page_section_idx, local_page) = self.find_section_for_page(page_num);
        if page_section_idx != section_idx {
            return None;
        }

        let pr = self.pagination.get(section_idx)?;
        let page = pr.pages.get(local_page)?;
        page.footnotes.iter().position(|fn_ref| {
            matches!(
                &fn_ref.source,
                FootnoteSource::Body { para_index, control_index }
                    if *para_index == para_idx && *control_index == control_idx
            )
        })
    }

    /// 본문 인라인 각주 마커 히트테스트
    ///
    /// 각주 영역(zone)이 아니라 본문 TextLine 안의 FootnoteMarker bbox를 대상으로 한다.
    /// 반환: JSON `{"hit":true,...}` 또는 `{"hit":false}`
    pub fn hit_test_body_footnote_marker_native(
        &self,
        page_num: u32,
        x: f64,
        y: f64,
    ) -> Result<String, HwpError> {
        use crate::renderer::render_tree::{RenderNode, RenderNodeType};

        struct MarkerHit {
            section_index: usize,
            paragraph_index: usize,
            control_index: usize,
            footnote_number: u16,
            bbox_x: f64,
            bbox_y: f64,
            bbox_w: f64,
            bbox_h: f64,
        }

        fn find_marker(node: &RenderNode, x: f64, y: f64) -> Option<MarkerHit> {
            if let RenderNodeType::FootnoteMarker(ref marker) = node.node_type {
                if x >= node.bbox.x
                    && x <= node.bbox.x + node.bbox.width
                    && y >= node.bbox.y
                    && y <= node.bbox.y + node.bbox.height
                {
                    return Some(MarkerHit {
                        section_index: marker.section_index,
                        paragraph_index: marker.para_index,
                        control_index: marker.control_index,
                        footnote_number: marker.number,
                        bbox_x: node.bbox.x,
                        bbox_y: node.bbox.y,
                        bbox_w: node.bbox.width,
                        bbox_h: node.bbox.height,
                    });
                }
            }

            for child in &node.children {
                if let Some(hit) = find_marker(child, x, y) {
                    return Some(hit);
                }
            }

            None
        }

        let tree = self.build_page_tree_cached(page_num)?;
        let hit = match find_marker(&tree.root, x, y) {
            Some(hit) => hit,
            None => return Ok("{\"hit\":false}".to_string()),
        };

        let footnote_index = match self.find_page_body_footnote_index(
            page_num,
            hit.section_index,
            hit.paragraph_index,
            hit.control_index,
        ) {
            Some(idx) => idx,
            None => return Ok("{\"hit\":false}".to_string()),
        };

        Ok(format!(
            "{{\"hit\":true,\"sectionIndex\":{},\"paragraphIndex\":{},\"controlIndex\":{},\"footnoteNumber\":{},\"footnoteIndex\":{},\"bbox\":{{\"x\":{:.1},\"y\":{:.1},\"w\":{:.1},\"h\":{:.1}}},\"cursorRect\":{{\"pageIndex\":{},\"x\":{:.1},\"y\":{:.1},\"height\":{:.1}}}}}",
            hit.section_index,
            hit.paragraph_index,
            hit.control_index,
            hit.footnote_number,
            footnote_index,
            hit.bbox_x,
            hit.bbox_y,
            hit.bbox_w,
            hit.bbox_h,
            page_num,
            hit.bbox_x + hit.bbox_w,
            hit.bbox_y,
            hit.bbox_h
        ))
    }

    /// 페이지의 각주 참조 정보를 반환한다.
    ///
    /// footnoteIndex에 해당하는 FootnoteRef의 source(para_index, control_index)를 반환.
    /// 반환: JSON `{"ok":true,"sectionIdx":N,"paraIdx":N,"controlIdx":N}`
    pub fn get_page_footnote_info_native(
        &self,
        page_num: u32,
        footnote_index: usize,
    ) -> Result<String, HwpError> {
        use crate::renderer::pagination::FootnoteSource;

        let (section_idx, local_page) = self.find_section_for_page(page_num);
        let pr = self
            .pagination
            .get(section_idx)
            .ok_or_else(|| HwpError::RenderError("구역을 찾을 수 없습니다".to_string()))?;
        let page = pr
            .pages
            .get(local_page)
            .ok_or_else(|| HwpError::RenderError("페이지를 찾을 수 없습니다".to_string()))?;

        let fn_ref = page.footnotes.get(footnote_index).ok_or_else(|| {
            HwpError::RenderError(format!(
                "각주 인덱스 {} 범위 초과 (총 {}개)",
                footnote_index,
                page.footnotes.len()
            ))
        })?;

        let (para_idx, control_idx, source_type) = match &fn_ref.source {
            FootnoteSource::Body {
                para_index,
                control_index,
            } => (*para_index, *control_index, "body"),
            FootnoteSource::TableCell {
                para_index,
                table_control_index,
                ..
            } => (*para_index, *table_control_index, "table"),
            FootnoteSource::ShapeTextBox {
                para_index,
                shape_control_index,
                ..
            } => (*para_index, *shape_control_index, "shape"),
        };

        Ok(format!(
            "{{\"ok\":true,\"sectionIdx\":{},\"paraIdx\":{},\"controlIdx\":{},\"sourceType\":\"{}\"}}",
            section_idx, para_idx, control_idx, source_type
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::{clamp_cursor_to_cell_bounds, resolve_x_on_line, CellCursorBounds, LineRunView};

    #[test]
    fn cell_cursor_bounds_clamp_coordinates_and_height() {
        let bounds = CellCursorBounds {
            x: 10.0,
            y: 20.0,
            w: 30.0,
            h: 8.0,
        };
        let (x, y, height, overflowed) = clamp_cursor_to_cell_bounds(50.0, 40.0, 14.0, bounds);
        assert_eq!((x, y, height, overflowed), (40.0, 20.0, 8.0, true));
    }

    // 줄 단위 x 해석(`resolve_x_on_line`)의 회귀 테스트.
    //
    // 핵심은 "줄 시작/끝으로 스냅하지 않는다" 이다. char_positions 는 production
    // 의 `compute_char_positions` 와 동일하게 `[0.0, w1, w1+w2, ...]` (char_count+1
    // 개, 0.0 포함) 형태로 구성한다. 줄 안 글자 경계로의 정확한 라운딩은
    // production `find_char_at_x` 의 미드포인트 규칙을 그대로 따르므로, 여기서는
    // "줄 시작/끝 상수로 붕괴하지 않고 x 에 따라 단조 증가" 라는 회귀 핵심 속성을
    // 검증한다.

    /// char_count 개 글자가 균등 폭 `w` 로 놓인 한 run.
    fn run(
        bbox_x: f64,
        char_start: usize,
        char_count: usize,
        w: f64,
        positions: &[f64],
    ) -> LineRunView<'_> {
        LineRunView {
            bbox_x,
            bbox_w: w * char_count as f64,
            char_start,
            char_count,
            char_positions: positions,
        }
    }

    /// 10글자 run 하나로 된 줄. bbox_x=100, 글자 폭 10px. char_start=7 (줄 시작이
    /// 문단 offset 0 이 아님을 확인).
    const POS10: [f64; 11] = [
        0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0,
    ];

    /// 회귀: 줄 한가운데 x 의 클릭은 줄 시작도 끝도 아닌 중간 글자 offset 으로
    /// 해석되어야 한다. (leading-gap 클릭이 줄 시작/끝으로 스냅하던 버그)
    ///
    /// `resolve_x_on_line` 은 클릭 y 와 무관하게 줄 안에서 x 만으로 해석하므로,
    /// 글리프 bbox 의 행간 여백(leading gap)에 떨어진 클릭도 동일하게 이 경로를
    /// 타게 되어 더 이상 줄 시작/끝으로 스냅하지 않는다.
    #[test]
    fn mid_line_x_resolves_to_mid_line_offset_not_start_or_end() {
        let line = vec![run(100.0, 7, 10, 10.0, &POS10)];
        let line_start = 7; // char_start
        let line_end = 17; // char_start + char_count

        // 줄 한가운데(x=150)
        let (idx, offset) = resolve_x_on_line(&line, 150.0);
        assert_eq!(idx, 0, "단일 run 줄이므로 run 인덱스는 0");
        assert!(
            offset > line_start && offset < line_end,
            "회귀: 줄 한가운데(x=150) 클릭이 줄 시작({line_start})/끝({line_end}) 사이의 \
             중간 글자로 해석되어야 함, got {offset}"
        );
    }

    /// 줄 전체에 x 를 쓸어가며 해석한 offset 이 (약)단조 증가하고, 시작/끝 상수로
    /// 붕괴하지 않아야 한다. (어떤 내부 x 도 줄 시작/끝으로 스냅하지 않음을 확인)
    #[test]
    fn interior_x_sweep_is_monotonic_and_spans_the_line() {
        let line = vec![run(100.0, 7, 10, 10.0, &POS10)];
        let mut prev = 0usize;
        let mut distinct = std::collections::BTreeSet::new();
        let mut x = 100.0; // bbox_x
        while x <= 200.0 {
            let (_, offset) = resolve_x_on_line(&line, x);
            assert!(
                offset >= prev,
                "x={x} 에서 offset={offset} 이 직전 {prev} 보다 작음 (단조 증가 위반)"
            );
            distinct.insert(offset);
            prev = offset;
            x += 2.0;
        }
        assert!(
            distinct.len() >= 8,
            "회귀: 줄 내부 x 스윕이 {} 개의 distinct offset 만 냄 {distinct:?}; \
             줄 시작/끝 상수로 스냅하면 1~2 개로 붕괴함",
            distinct.len()
        );
    }

    /// 줄 경계 밖: 왼쪽은 줄 시작, 오른쪽은 줄 끝으로 클램프.
    #[test]
    fn outside_line_clamps_to_start_and_end() {
        let line = vec![run(100.0, 7, 10, 10.0, &POS10)];
        assert_eq!(resolve_x_on_line(&line, 50.0), (0, 7), "줄 왼쪽 → 줄 시작");
        assert_eq!(
            resolve_x_on_line(&line, 999.0),
            (0, 17),
            "줄 오른쪽 → 줄 끝"
        );
    }

    /// 다중 run 줄: 두 run 사이의 빈틈 클릭은 줄 끝으로 스냅하지 않고
    /// 더 가까운 run 경계로 해석되어야 한다. (다중 run 줄 inter-run-gap 버그)
    #[test]
    fn inter_run_gap_snaps_to_nearer_boundary_not_line_end() {
        const P0: [f64; 4] = [0.0, 10.0, 20.0, 30.0]; // 3 chars, 폭 10
        const P1: [f64; 4] = [0.0, 10.0, 20.0, 30.0]; // 3 chars, 폭 10
                                                      // run0: x[100,130], chars 0..3 ; 빈틈 ; run1: x[200,230], chars 5..8
        let line = vec![run(100.0, 0, 3, 10.0, &P0), run(200.0, 5, 3, 10.0, &P1)];
        let line_end = 5 + 3; // 8

        // 빈틈 안에서 왼쪽 run 에 가까운 x(140) → 왼쪽 run 끝 (offset 3)
        let (idx, offset) = resolve_x_on_line(&line, 140.0);
        assert_eq!((idx, offset), (0, 3), "빈틈 왼쪽 → 왼쪽 run 끝");
        assert_ne!(
            offset, line_end,
            "회귀: 빈틈 클릭이 줄 끝으로 스냅하면 안 됨"
        );

        // 빈틈 안에서 오른쪽 run 에 가까운 x(190) → 오른쪽 run 시작 (offset 5)
        let (idx, offset) = resolve_x_on_line(&line, 190.0);
        assert_eq!((idx, offset), (1, 5), "빈틈 오른쪽 → 오른쪽 run 시작");
    }

    /// 회귀: 빈 입력칸(char_count=0)이지만 bbox_w 가 셀 폭만큼 넓은 run.
    /// char_positions = [0.0] 한 개뿐이라 라운딩 함수가 len()=1 을 돌려주지만,
    /// 글자 인덱스는 char_count(=0) 로 클램프되어 offset 은 항상 char_start 여야 한다.
    /// (exam_social/exam_science 답안지 `성명` 빈 입력칸 클릭이 offset 1 로 새던 버그)
    #[test]
    fn empty_run_with_wide_bbox_clamps_to_char_start() {
        const EMPTY: [f64; 1] = [0.0];
        let line = vec![LineRunView {
            bbox_x: 212.7,
            bbox_w: 97.0, // 빈 입력칸 폭(글자 없음)
            char_start: 0,
            char_count: 0,
            char_positions: &EMPTY,
        }];
        // bbox 한참 안쪽 클릭(x=250)도 빈 run 이므로 offset 0 (줄/run 시작).
        assert_eq!(resolve_x_on_line(&line, 250.0), (0, 0));
        // 오른쪽 끝 너머도 마찬가지.
        assert_eq!(resolve_x_on_line(&line, 999.0), (0, 0));
    }

    /// [#2021] 계측 프로브 — 대형 표 문서의 콜드 rect 비용 분해.
    /// 실행: cargo test --profile release-test --lib document_core::queries::cursor_rect -- --ignored --nocapture
    #[test]
    #[ignore = "계측 프로브 — 수동 실행"]
    fn probe_2021_cursor_rect_by_path_cold_cost() {
        use std::time::Instant;
        let p = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("samples/issue1949_giant_cell_nested_tables_perf.hwp");
        let bytes = std::fs::read(&p).expect("read sample");
        let core = crate::document_core::DocumentCore::from_bytes(&bytes).expect("parse");

        let doc = core.document();
        let mut host = None;
        'outer: for (pi, para) in doc.sections[0].paragraphs.iter().enumerate() {
            for (ci, c) in para.controls.iter().enumerate() {
                if matches!(c, crate::model::control::Control::Table(_)) {
                    host = Some((pi, ci));
                    break 'outer;
                }
            }
        }
        let (host_pi, host_ci) = host.expect("표 없음");
        let path_json = format!(
            r#"[{{"controlIndex":{},"cellIndex":0,"cellParaIndex":0}}]"#,
            host_ci
        );

        let total_pages = core.page_count();
        let pages = core.find_pages_for_paragraph(0, host_pi).expect("pages");
        eprintln!(
            "#2021 probe: 총 {}쪽 / 호스트 pi={} 걸친 페이지 = {}개 (first={:?} last={:?})",
            total_pages,
            host_pi,
            pages.len(),
            pages.first(),
            pages.last()
        );

        let t = Instant::now();
        let warm = core.get_cursor_rect_by_path_native(0, host_pi, &path_json, 0);
        eprintln!(
            "#2021 probe: 웜 ok={} ({:.1}ms)",
            warm.is_ok(),
            t.elapsed().as_secs_f64() * 1000.0
        );

        core.invalidate_page_tree_cache();
        let t = Instant::now();
        let cold = core.get_cursor_rect_by_path_native(0, host_pi, &path_json, 0);
        let cold_ms = t.elapsed().as_secs_f64() * 1000.0;
        eprintln!(
            "#2021 probe: 콜드 ok={} ({:.1}ms) rect={:?}",
            cold.is_ok(),
            cold_ms,
            cold.as_deref().unwrap_or("-")
        );

        // 셀 내부 깊은 문단 — 실제 시나리오(후반 페이지에 렌더되는 셀 문단) 재현
        if let Some(crate::model::control::Control::Table(t)) =
            doc.sections[0].paragraphs[host_pi].controls.get(host_ci)
        {
            let n_paras = t.cells.first().map(|c| c.paragraphs.len()).unwrap_or(0);
            for frac in [2usize, 4, 10] {
                let cpi = n_paras.saturating_sub(1) / frac * (frac - 1);
                let path_deep = format!(
                    r#"[{{"controlIndex":{},"cellIndex":0,"cellParaIndex":{}}}]"#,
                    host_ci, cpi
                );
                core.invalidate_page_tree_cache();
                let t2 = Instant::now();
                let r = core.get_cursor_rect_by_path_native(0, host_pi, &path_deep, 0);
                eprintln!(
                    "#2021 probe: 셀0 문단 {}/{} 콜드 ok={} ({:.1}ms) rect={:?}",
                    cpi,
                    n_paras,
                    r.is_ok(),
                    t2.elapsed().as_secs_f64() * 1000.0,
                    r.as_deref().unwrap_or("-")
                );
            }
        }

        // 뒤쪽 셀(마지막 셀) — 캐럿 페이지가 문서 후반일 때의 선형 탐색 비용
        if let Some(crate::model::control::Control::Table(t)) =
            doc.sections[0].paragraphs[host_pi].controls.get(host_ci)
        {
            let last_cell = t.cells.len().saturating_sub(1);
            let path_last = format!(
                r#"[{{"controlIndex":{},"cellIndex":{},"cellParaIndex":0}}]"#,
                host_ci, last_cell
            );
            core.invalidate_page_tree_cache();
            let t2 = Instant::now();
            let cold_last = core.get_cursor_rect_by_path_native(0, host_pi, &path_last, 0);
            eprintln!(
                "#2021 probe: 마지막 셀(idx {}) 콜드 ok={} ({:.1}ms) rect={:?}",
                last_cell,
                cold_last.is_ok(),
                t2.elapsed().as_secs_f64() * 1000.0,
                cold_last.as_deref().unwrap_or("-")
            );
        }

        if let Ok(ref json) = cold {
            let page: u32 = json
                .split("\"pageIndex\":")
                .nth(1)
                .and_then(|s| s.split(&[',', '}'][..]).next())
                .and_then(|s| s.trim().parse().ok())
                .unwrap_or(0);
            core.invalidate_page_tree_cache();
            let t = Instant::now();
            let _ = core.build_page_tree_cached(page);
            eprintln!(
                "#2021 probe: 캐럿 페이지({}) 1장 빌드 = {:.1}ms",
                page,
                t.elapsed().as_secs_f64() * 1000.0
            );
        }
    }

    /// [#2021] 힌트 탐색 동등성 핀 — 힌트 유/무·오힌트 fallback 모두 좌표 완전 일치.
    #[test]
    fn issue_2021_hint_search_equivalence() {
        let p = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("samples/issue1949_giant_cell_nested_tables_perf.hwp");
        let bytes = std::fs::read(&p).expect("read sample");
        let core = crate::document_core::DocumentCore::from_bytes(&bytes).expect("parse");
        let doc = core.document();
        let mut host = None;
        'outer: for (pi, para) in doc.sections[0].paragraphs.iter().enumerate() {
            for (ci, c) in para.controls.iter().enumerate() {
                if matches!(c, crate::model::control::Control::Table(_)) {
                    host = Some((pi, ci));
                    break 'outer;
                }
            }
        }
        let (host_pi, host_ci) = host.expect("표 없음");
        let total = core.page_count() as u32;
        for cell in 0..3usize {
            let path = format!(
                r#"[{{"controlIndex":{},"cellIndex":{},"cellParaIndex":0}}]"#,
                host_ci, cell
            );
            core.invalidate_page_tree_cache();
            let base = core
                .get_cursor_rect_by_path_with_hint(0, host_pi, &path, 0, None)
                .expect("base rect");
            // 정힌트(정답 페이지) / 오힌트(마지막 페이지·범위 밖) 전부 동일해야 한다.
            let base_page: u32 = base
                .split("\"pageIndex\":")
                .nth(1)
                .and_then(|s| s.split(&[',', '}'][..]).next())
                .and_then(|s| s.trim().parse().ok())
                .expect("pageIndex");
            for hint in [
                Some(base_page),
                Some(total.saturating_sub(1)),
                Some(total + 7),
            ] {
                core.invalidate_page_tree_cache();
                let hinted = core
                    .get_cursor_rect_by_path_with_hint(0, host_pi, &path, 0, hint)
                    .expect("hinted rect");
                assert_eq!(
                    base, hinted,
                    "#2021 힌트 {hint:?} 좌표 불일치 (cell {cell})"
                );
            }
        }
    }

    /// [#4128] 공통 픽스처: (core, host_pi, host_ci, cell_idx).
    /// 거대 분할 표에서 콘텐츠가 페이지에 걸치는(문단 최다) 셀을 대상으로 잡는다.
    fn issue4128_fixture() -> (crate::document_core::DocumentCore, usize, usize, usize) {
        let p = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("samples/issue1949_giant_cell_nested_tables_perf.hwp");
        let bytes = std::fs::read(&p).expect("read sample");
        let core = crate::document_core::DocumentCore::from_bytes(&bytes).expect("parse");
        let doc = core.document();
        let mut host = None;
        'outer: for (pi, para) in doc.sections[0].paragraphs.iter().enumerate() {
            for (ci, c) in para.controls.iter().enumerate() {
                if matches!(c, crate::model::control::Control::Table(_)) {
                    host = Some((pi, ci));
                    break 'outer;
                }
            }
        }
        let (host_pi, host_ci) = host.expect("표 없음");
        let crate::model::control::Control::Table(ref table) =
            doc.sections[0].paragraphs[host_pi].controls[host_ci]
        else {
            unreachable!()
        };
        // 거대 셀 = 콘텐츠가 페이지에 걸치는 셀. 이 샘플의 텍스트는 중첩 표 안에
        // 있어 직접 text 길이는 짧다 — 문단 수가 가장 많은 셀이 페이지-스팬 셀이다.
        let (cell_idx, _) = table
            .cells
            .iter()
            .enumerate()
            .max_by_key(|(_, c)| c.paragraphs.len())
            .expect("셀 없음");
        (core, host_pi, host_ci, cell_idx)
    }

    /// [#4128] 그리드: 거대 셀의 문단 축(step)을 훑고, 문단마다 offset {0, len/2, len}.
    fn issue4128_grid(
        core: &crate::document_core::DocumentCore,
        host_pi: usize,
        host_ci: usize,
        cell_idx: usize,
    ) -> Vec<(usize, usize)> {
        let doc = core.document();
        let crate::model::control::Control::Table(ref table) =
            doc.sections[0].paragraphs[host_pi].controls[host_ci]
        else {
            unreachable!()
        };
        let paras = &table.cells[cell_idx].paragraphs;
        let step = (paras.len() / 60).max(1);
        let mut grid = Vec::new();
        let mut cpi = 0usize;
        while cpi < paras.len() {
            let len = paras[cpi].text.chars().count();
            grid.push((cpi, 0));
            if len > 0 {
                grid.push((cpi, len / 2));
                grid.push((cpi, len));
            }
            cpi += step;
        }
        grid
    }

    /// [#4128] 셀 위치 페이지 좁히기 — legacy 부분집합이며 항상 ≤2쪽(컷 경계만 2쪽).
    /// 그리드가 표의 전 구간을 커버하는지도 확인해 특정 페이지 쏠림을 배제한다.
    #[test]
    fn issue4128_cell_position_pages_subset_and_small() {
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        let legacy = core.find_pages_for_paragraph(0, host_pi).expect("legacy");
        assert!(
            legacy.len() > 10,
            "샘플 전제: 표가 다수 페이지에 걸침 (실측 {}쪽)",
            legacy.len()
        );

        let grid = issue4128_grid(&core, host_pi, host_ci, cell_idx);
        assert!(
            grid.len() > 30,
            "그리드 {}점 — 샘플 전제 확인 필요",
            grid.len()
        );
        let mut covered = std::collections::BTreeSet::new();
        for &(cpi, off) in &grid {
            let narrowed = core
                .find_pages_for_cell_position(0, host_pi, host_ci, cell_idx, Some((cpi, off)))
                .expect("narrowed");
            assert!(!narrowed.is_empty(), "cpi={cpi} off={off}: 빈 결과");
            assert!(
                narrowed.len() <= 2,
                "cpi={cpi} off={off}: {}쪽 — 좁히기 실패",
                narrowed.len()
            );
            assert!(
                narrowed.iter().all(|p| legacy.contains(p)),
                "cpi={cpi} off={off}: legacy 부분집합 위반 {narrowed:?}"
            );
            covered.extend(narrowed.iter().copied());
        }
        eprintln!(
            "#4128: 그리드 {}점 → 커버 {}쪽 / legacy {}쪽",
            grid.len(),
            covered.len(),
            legacy.len()
        );
        assert!(
            covered.len() * 2 > legacy.len(),
            "그리드가 {}쪽만 커버 (legacy {}쪽) — 특정 페이지로 쏠림",
            covered.len(),
            legacy.len()
        );

        // target=None(셀 전체)은 셀이 걸친 전 페이지 — 비어 있으면 안 된다.
        let whole = core
            .find_pages_for_cell_position(0, host_pi, host_ci, cell_idx, None)
            .expect("whole-cell");
        assert!(!whole.is_empty());
        assert!(whole.iter().all(|p| legacy.contains(p)));
    }

    /// [#4128] 콜드 셀 캐럿 질의가 page tree 를 최대 2장만 빌드하는지 —
    /// 이슈의 수용 기준("콜드 호출당 신규 빌드 ≤ 1, 컷 경계 2")을 캐시 슬롯
    /// 계수로 판정한다.
    #[test]
    fn issue4128_cold_cell_rect_builds_at_most_two_page_trees() {
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        let n_paras = {
            let doc = core.document();
            let crate::model::control::Control::Table(ref t) =
                doc.sections[0].paragraphs[host_pi].controls[host_ci]
            else {
                unreachable!()
            };
            t.cells[cell_idx].paragraphs.len()
        };
        let built = |c: &crate::document_core::DocumentCore| {
            c.page_tree_cache
                .borrow()
                .iter()
                .filter(|t| t.is_some())
                .count()
        };
        // 표 앞/중간/끝 — 문단 축으로 페이지 전 구간을 대표. 캐럿 rect 는 TextRun
        // 이 필요하므로 각 앵커에서 가장 가까운 텍스트 문단을 고른다 (중첩 표 host
        // 문단의 rect 실패는 legacy 와 동일 — A/C 덤프 diff 가 검증).
        let pick_text_para = |from: usize| {
            let doc = core.document();
            let crate::model::control::Control::Table(ref t) =
                doc.sections[0].paragraphs[host_pi].controls[host_ci]
            else {
                unreachable!()
            };
            let paras = &t.cells[cell_idx].paragraphs;
            (from..paras.len())
                .find(|&i| !paras[i].text.trim().is_empty() && !paras[i].line_segs.is_empty())
                .unwrap_or(from)
        };
        for anchor in [0, n_paras / 4, n_paras / 2, n_paras * 3 / 4, n_paras - 1] {
            let cpi = pick_text_para(anchor);
            let path = format!(
                r#"[{{"controlIndex":{},"cellIndex":{},"cellParaIndex":{}}}]"#,
                host_ci, cell_idx, cpi
            );
            core.invalidate_page_tree_cache();
            let r = core.get_cursor_rect_by_path_native(0, host_pi, &path, 0);
            assert!(r.is_ok(), "cpi={cpi}: {:?}", r.err());
            let n = built(&core);
            assert!(n <= 2, "cpi={cpi}: 콜드 page tree {}장 빌드 (기준 ≤2)", n);
        }
    }

    /// [#4128 진단] 샘플의 PartialTable 메타데이터 실측 — 컷 모델 확인용. 수동 실행.
    #[test]
    #[ignore = "진단 덤프 — 수동 실행"]
    fn issue4128_dump_partial_table_metadata() {
        use crate::renderer::pagination::PageItem;
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        let doc = core.document();
        let crate::model::control::Control::Table(ref table) =
            doc.sections[0].paragraphs[host_pi].controls[host_ci]
        else {
            unreachable!()
        };
        eprintln!(
            "표: {}행×{}열, page_break={:?}, cells={}",
            table.row_count,
            table.col_count,
            table.page_break,
            table.cells.len()
        );
        for (i, c) in table.cells.iter().enumerate() {
            eprintln!(
                "  cell[{i}]: row={} col={} row_span={} col_span={} paras={} text_len={}",
                c.row,
                c.col,
                c.row_span,
                c.col_span,
                c.paragraphs.len(),
                c.paragraphs.iter().map(|p| p.text.len()).sum::<usize>()
            );
        }
        let giant = &table.cells[cell_idx];
        for cpi in [0usize, 1, 2, 626, 1253, 2506] {
            if let Some(p) = giant.paragraphs.get(cpi) {
                eprintln!(
                    "  para[{cpi}]: text_len={} segs={} controls={}",
                    p.text.chars().count(),
                    p.line_segs.len(),
                    p.controls.len()
                );
            }
        }
        let units = core
            .layout_engine
            .debug_cell_units(giant, table, &core.styles);
        eprintln!("units 총 {}개; 처음 14개:", units.len());
        for (i, u) in units.iter().take(14).enumerate() {
            eprintln!(
                "  unit[{i}]: para={} vis=[{},{}) spacer={} nested_row={:?}",
                u.0, u.1, u.2, u.3, u.4
            );
        }
        for (pi, page) in core.pagination[0].pages.iter().enumerate() {
            for col in &page.column_contents {
                for item in &col.items {
                    if let PageItem::PartialTable {
                        para_index,
                        control_index,
                        start_row,
                        end_row,
                        is_continuation,
                        start_cut,
                        end_cut,
                        is_block_split,
                        ..
                    } = item
                    {
                        if *para_index == host_pi && *control_index == host_ci {
                            eprintln!(
                                "p{pi}: rows[{start_row},{end_row}) cont={is_continuation} block={is_block_split} sc={start_cut:?} ec={end_cut:?}"
                            );
                        }
                    }
                }
            }
        }
    }

    /// [#4128] A/C 차분 덤프 — 패치 전(devel)/후 워크트리에서 같은 명령을 실행해
    /// 출력 diff 가 0 인지 확인한다 (pageIndex 포함 좌표 완전 동일 검증). 수동 실행:
    /// cargo test --profile release-test --lib document_core::queries::cursor_rect \
    ///   -- --ignored issue4128_dump --nocapture
    #[test]
    #[ignore = "차분 덤프 — 수동 실행"]
    fn issue4128_dump_cell_cursor_rects_for_diff() {
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        for (cpi, off) in issue4128_grid(&core, host_pi, host_ci, cell_idx) {
            match core.get_cursor_rect_in_cell_native(0, host_pi, host_ci, cell_idx, cpi, off) {
                Ok(json) => println!("DUMP {cpi} {off} {json}"),
                Err(e) => println!("DUMP {cpi} {off} ERR {e}"),
            }
        }
    }

    // ─── [#4149] 셀 캐럿 fast path 차등(패리티) 테스트 ─────────────────────
    //
    // 합격 기준: fast path 가 Some 을 돌려준 모든 지점에서 legacy
    // (`cursor_rect_in_cell_via_page_tree`) JSON 과 완전 일치. fast 가 None 인
    // 지점은 wrapper 가 legacy 로 폴백하므로 정의상 동일 출력이다.

    /// 샘플의 모든 최상위 표 × 셀 × (스텝된) 문단 × offset {0, len/2, len} 그리드에서
    /// fast/legacy 차등 검증. (fast_some, checked) 를 반환한다.
    fn issue4149_assert_fast_parity(sample: &str, max_points: usize) -> (usize, usize) {
        let p = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(sample);
        let bytes = std::fs::read(&p).expect("read sample");
        let core = crate::document_core::DocumentCore::from_bytes(&bytes).expect("parse");
        let doc = core.document();

        // 그리드 수집 (모든 섹션의 최상위 표)
        let mut points: Vec<(usize, usize, usize, usize, usize, usize)> = Vec::new();
        for (si, sec) in doc.sections.iter().enumerate() {
            for (pi, para) in sec.paragraphs.iter().enumerate() {
                for (ci, ctrl) in para.controls.iter().enumerate() {
                    let crate::model::control::Control::Table(ref t) = ctrl else {
                        continue;
                    };
                    for (cell_i, cell) in t.cells.iter().enumerate() {
                        let n = cell.paragraphs.len();
                        if n == 0 {
                            continue;
                        }
                        let step = (n / 80).max(1);
                        let mut cpi = 0usize;
                        while cpi < n {
                            let len = cell.paragraphs[cpi].text.chars().count();
                            points.push((si, pi, ci, cell_i, cpi, 0));
                            if len > 0 {
                                points.push((si, pi, ci, cell_i, cpi, len / 2));
                                points.push((si, pi, ci, cell_i, cpi, len));
                            }
                            cpi += step;
                        }
                    }
                }
            }
        }
        // 결정적 상한 (전수에 가깝게, 러닝타임 폭주만 차단)
        if points.len() > max_points {
            let step = points.len().div_ceil(max_points);
            points = points.into_iter().step_by(step).collect();
        }

        let mut fast_some = 0usize;
        let mut checked = 0usize;
        for &(si, pi, ci, cell_i, cpi, off) in &points {
            checked += 1;
            // fast 의 에러는 legacy 도 같은 좁히기에서 에러 — 폴백 경로로 취급
            let fast = core
                .cursor_rect_in_cell_fast(si, pi, ci, cell_i, cpi, off)
                .unwrap_or_default();
            let Some(fast_json) = fast else { continue };
            fast_some += 1;
            let legacy = core
                .cursor_rect_in_cell_via_page_tree(si, pi, ci, cell_i, cpi, off)
                .unwrap_or_else(|e| {
                    panic!(
                        "{sample} (s{si} p{pi} c{ci} cell{cell_i} cp{cpi} off{off}): \
                         fast=Some 인데 legacy 에러 {e}"
                    )
                });
            assert_eq!(
                fast_json, legacy,
                "{sample} 패리티 불일치 (s{si} p{pi} c{ci} cell{cell_i} cp{cpi} off{off})"
            );
        }
        eprintln!(
            "#4149 {}: fast 적중 {} / 검사 {} ({:.1}%)",
            sample,
            fast_some,
            checked,
            fast_some as f64 * 100.0 / checked.max(1) as f64
        );
        (fast_some, checked)
    }

    /// [#4149 진단] fast path 게이트 단계별 통과 여부 — 수동 실행.
    #[test]
    #[ignore = "게이트 진단 — 수동 실행"]
    fn issue4149_diag_fast_path_gates() {
        use crate::model::control::Control;
        use crate::renderer::layout::ProbeCutPlan;
        use crate::renderer::pagination::PageItem;
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        let pages = core
            .find_pages_for_cell_position(0, host_pi, host_ci, cell_idx, Some((6, 5)))
            .expect("pages");
        eprintln!("pages={pages:?}");
        let page_num = pages[0];
        let (page_content, paragraphs, _c) = core.find_page(page_num).expect("find_page");
        eprintln!(
            "cols={} zone={:?} zoff={} endnote={} start_h={} wrapA={} wrapAnch={}",
            page_content.column_contents.len(),
            page_content.column_contents[0].zone_layout.is_some(),
            page_content.column_contents[0].zone_y_offset,
            page_content.column_contents[0].endnote_flow,
            page_content.column_contents[0].start_height,
            page_content.column_contents[0].wrap_around_paras.len(),
            page_content.column_contents[0].wrap_anchors.len(),
        );
        let col = &page_content.column_contents[0];
        eprintln!("items0 = {:?}", col.items.first());
        let host_anchor = col.items.iter().any(|it| {
            matches!(it,
                PageItem::Shape { para_index, .. } | PageItem::Table { para_index, .. }
                    if *para_index == host_pi)
        });
        eprintln!("host_anchor_items = {host_anchor}");
        let pr = &core.pagination[0];
        eprintln!("endnote_paras = {}", pr.endnote_paragraphs.len());
        let host = &paragraphs[host_pi];
        let Control::Table(ref table) = host.controls[host_ci] else {
            panic!()
        };
        eprintln!(
            "tac={} caption={} repeat_header={}",
            table.common.treat_as_char,
            table.caption.is_some(),
            table.repeat_header
        );
        let blocked = core
            .layout_engine
            .table_subtree_blocks_cursor_probe(table, &core.styles);
        eprintln!("subtree_blocked = {blocked}");
        if blocked {
            // 차단 원인 탐색 (스캔 로직 복제 + 보고)
            fn why(
                paras: &[crate::model::paragraph::Paragraph],
                styles: &crate::renderer::style_resolver::ResolvedStyleSet,
                depth: usize,
            ) -> Option<String> {
                use crate::model::style::HeadType;
                for (i, p) in paras.iter().enumerate() {
                    let head = styles
                        .para_styles
                        .get(p.para_shape_id as usize)
                        .map(|s| s.head_type)
                        .unwrap_or(HeadType::None);
                    if matches!(head, HeadType::Outline | HeadType::Number) {
                        return Some(format!("d{depth} p{i} head={head:?}"));
                    }
                    for (ci, c) in p.controls.iter().enumerate() {
                        match c {
                            Control::AutoNumber(_) => {
                                return Some(format!("d{depth} p{i} c{ci} AutoNumber"))
                            }
                            Control::NewNumber(_) => {
                                return Some(format!("d{depth} p{i} c{ci} NewNumber"))
                            }
                            Control::Table(t) => {
                                if t.caption.is_some() {
                                    return Some(format!("d{depth} p{i} c{ci} nested caption"));
                                }
                                for (cei, cell) in t.cells.iter().enumerate() {
                                    if let Some(w) = why(&cell.paragraphs, styles, depth + 1) {
                                        return Some(format!(
                                            "d{depth} p{i} c{ci} cell{cei} → {w}"
                                        ));
                                    }
                                }
                            }
                            Control::Shape(s) => {
                                use crate::model::shape::ShapeObject;
                                match &**s {
                                    ShapeObject::Rectangle(_)
                                    | ShapeObject::Ellipse(_)
                                    | ShapeObject::Polygon(_)
                                    | ShapeObject::Curve(_)
                                    | ShapeObject::Line(_)
                                    | ShapeObject::Arc(_) => {}
                                    other => {
                                        return Some(format!(
                                            "d{depth} p{i} c{ci} shape variant {:?}",
                                            std::mem::discriminant(other)
                                        ))
                                    }
                                }
                            }
                            Control::Picture(pic) => {
                                if pic.caption.is_some() {
                                    return Some(format!("d{depth} p{i} c{ci} picture caption"));
                                }
                            }
                            _ => {}
                        }
                    }
                }
                None
            }
            for (cei, cell) in table.cells.iter().enumerate() {
                if let Some(w) = why(&cell.paragraphs, &core.styles, 0) {
                    eprintln!("blocked by: cell{cei} → {w}");
                    break;
                }
            }
        }
        if let Some(PageItem::PartialTable {
            start_row,
            end_row,
            start_cut,
            end_cut,
            is_block_split,
            start_cut_is_block,
            ..
        }) = col.items.first()
        {
            let cell = &table.cells[cell_idx];
            let plan = core.layout_engine.partial_table_cell_probe_plan(
                table,
                cell,
                *start_row,
                *end_row,
                start_cut,
                end_cut,
                *is_block_split,
                *start_cut_is_block,
                &core.styles,
                6,
            );
            match plan {
                ProbeCutPlan::Unsupported => eprintln!("plan=Unsupported"),
                ProbeCutPlan::Uncut => eprintln!("plan=Uncut (n={})", cell.paragraphs.len()),
                ProbeCutPlan::Cut {
                    window_paras,
                    split_proven,
                    target_in_window,
                } => eprintln!(
                    "plan=Cut window={window_paras:?} split_proven={split_proven} in_window={target_in_window} any_multiline={} valign={:?} dir={}",
                    cell.paragraphs.iter().any(|p| p.line_segs.len() >= 2),
                    cell.vertical_align,
                    cell.text_direction
                ),
            }
        }
        let fast = core
            .cursor_rect_in_cell_fast(0, host_pi, host_ci, cell_idx, 6, 5)
            .expect("fast");
        eprintln!("fast = {fast:?}");
    }

    /// [#4149] 거대 셀 분할 표 — fast path 의 주 대상. 적중률이 유의미해야 한다.
    #[test]
    fn issue4149_fast_path_parity_giant_cell() {
        let (fast_some, checked) = issue4149_assert_fast_parity(
            "samples/issue1949_giant_cell_nested_tables_perf.hwp",
            400,
        );
        assert!(checked > 50, "그리드 {}점 — 샘플 전제 확인 필요", checked);
        // 거대 문서에서 대부분 적중해야 fast path 가 의미 있다.
        assert!(
            fast_some * 2 > checked,
            "적중 {}/{} — 거대 셀 문서에서 과반 적중 실패",
            fast_some,
            checked
        );
    }

    /// [#4149] KTX.hwp — 일반 표 문서. 패리티만 요구 (적중률은 보고).
    #[test]
    fn issue4149_fast_path_parity_ktx() {
        issue4149_assert_fast_parity("samples/KTX.hwp", 400);
    }

    /// [#4149] hwp_table_test_saved.hwp — 저장 왕복 표 문서. 패리티만 요구.
    #[test]
    fn issue4149_fast_path_parity_table_saved() {
        issue4149_assert_fast_parity("samples/hwp_table_test_saved.hwp", 400);
    }

    /// [#4149] 웜 캐럿 질의는 전체 페이지 트리를 재빌드하지 않아야 한다.
    /// #3743에서 전체 렌더도 가시 창만 compose하게 되어 두 경로의 지연 배율은
    /// 더 이상 작업량의 대리 지표가 아니다. 기존 thread-local 카운터로 원래
    /// 계약을 직접 검증하고, 시간은 진단값으로만 남긴다.
    #[test]
    fn issue4149_fast_path_giant_cell_warm_avoids_page_tree_builds() {
        use crate::diagnostics::perf_counters;
        use std::time::Instant;
        let (core, host_pi, host_ci, cell_idx) = issue4128_fixture();
        // 브라우저 실측 좌표와 동일 (ppi0 ci2 cell2 para6 off5) — 픽스처가 같은 셀을 고른다.
        let warmup = core.get_cursor_rect_in_cell_native(0, host_pi, host_ci, cell_idx, 6, 5);
        assert!(warmup.is_ok(), "웜업 실패: {:?}", warmup.err());
        // fast path 적중 확인 — 미적중이면 이 테스트는 legacy 지연을 재는 셈이 된다.
        let fast = core
            .cursor_rect_in_cell_fast(0, host_pi, host_ci, cell_idx, 6, 5)
            .expect("fast");
        assert!(fast.is_some(), "perf 대상 좌표에서 fast path 미적중");

        // 다른 테스트 스레드의 빌드는 포함하지 않는다. 공개 진입점이 legacy로
        // 폴백하면 아래의 0-build 계약이 실패해야 한다.
        let iters = 10;
        perf_counters::reset_thread_page_tree_builds();
        let t = Instant::now();
        for _ in 0..iters {
            let rect = core
                .get_cursor_rect_in_cell_native(0, host_pi, host_ci, cell_idx, 6, 5)
                .expect("rect");
            assert_eq!(Some(&rect), fast.as_ref());
        }
        let fast_ms = t.elapsed().as_secs_f64() * 1000.0 / iters as f64;
        assert_eq!(perf_counters::thread_page_tree_builds(), 0);
        perf_counters::reset_thread_page_tree_builds();
        let t = Instant::now();
        for _ in 0..iters {
            let rect = core
                .cursor_rect_in_cell_via_page_tree(0, host_pi, host_ci, cell_idx, 6, 5)
                .expect("legacy rect");
            assert_eq!(Some(&rect), fast.as_ref());
        }
        let legacy_ms = t.elapsed().as_secs_f64() * 1000.0 / iters as f64;
        eprintln!("#4149 웜 지연: fast {fast_ms:.3}ms vs legacy {legacy_ms:.3}ms/call");
        assert!(
            perf_counters::thread_page_tree_builds() >= iters,
            "페이지 경로의 실제 빌드를 카운터로 관측해야 한다"
        );
    }
}
